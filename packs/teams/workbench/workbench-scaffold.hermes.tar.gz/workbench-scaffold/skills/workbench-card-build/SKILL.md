---
name: workbench-card-build
description: "Use when building a Workbench card web app."
version: 1.0.0
---

# Workbench card build: Ready → Ready-for-QA

Team protocol (roles, card flow, handoff rules) lives in
`~/.hermes/teams/workbench/TEAM.md` — read it first. The live board is the kanban
board `workbench` (your Build task arrives via the dispatcher; `kanban_show` it).
`WORK.md` is the shipped record, not the board.
This skill is the execution layer: how to build, how to prove the acceptance checks
in a running app, and how to hand off so Smoke's QA pass is fast.

## Build recipe (small static-ish app)

Zero-dependency Node, no build ceremony — a framework is ceremony here unless the
card's accept checks demand one:

- `server.js`: plain `http` server. Serves `public/` statically and exposes a
  `GET /<data>` JSON endpoint that does the parsing work server-side. Resolve the
  data file by path relative to the repo, with an env override (`BOARD` / `PORT`)
  so a second instance can point elsewhere.
- `public/`: `index.html` + `app.js` + `style.css`. The page fetches the JSON
  endpoint and re-polls every ~15 s so board/content edits appear live.
- `package.json` with `"start": "node server.js"`. Pick a fixed port (3121 was
  clear when last checked); the card's notes MUST name it.
- One git repo per project under `~/.hermes/teams/workbench/repos/<project>/`;
  `git init` + one initial commit on first build.

## Verifying acceptance checks (prove, don't inspect)

Every `accept` line must pass against a running app before handoff:

1. **Data/parse checks:** curl the JSON endpoint and assert fields and ordering in
   a python one-liner (`assert ids == [...]`), not by eyeballing JSON.
2. **Render checks:** read the rendered DOM text from a browser, never curl the HTML
   source — a static `index.html` always "passes" curl while the JS render can be
   broken.
3. **State-dependent behavior the live data can't show** (e.g. "Shipped cards render
   first" when no card is Shipped yet): run a SECOND instance of the SAME server on
   a spare port with the data-file env pointing at a fixture covering the needed
   states. Verify in the browser, then kill that instance and delete the fixture —
   but keep its screenshots as evidence. Never verify ordering logic against the
   real data when the real data lacks the required states; and never hand-roll a
   separate test parser that can drift from the shipping one.

   **Ordering/positioning requirements need a worst-case-id fixture.** "State X
   renders first" is only proven when an X-state item carries a HIGHER id than
   every other item (that's the case a naive group-then-sort breaks). A fixture
   where the target state happens to have the lowest id will pass even when the
   order is wrong — that exact mask bounced Card 1 once (Shipped-lowest-id
   fixtures passed, Shipped-highest-id failed; fix was a stable partition). Use
   two fixtures when cheap: target-state-lowest-id AND target-state-highest-id.
   And read your own sort code before declaring it right — "group then sort"
   vs "sort each group" is a one-liner apart.

### Browser fallback

The `browser_exec` tool can fail with "Chromium browser is missing" and KEEP failing
after `npx playwright install chromium` (its daemon caches the miss / wants its own
browser). Don't loop on reinstalls. Fallback that works, via terminal:

```
npx agent-browser open http://localhost:PORT/
npx agent-browser wait 800
npx agent-browser get text body            # rendered text
npx agent-browser eval "<js expression>"   # DOM assertions, returns value
npx agent-browser screenshot /abs/path.png
```

Then run `vision_analyze` on the PNG for a visual pass. The `agent-browser` CLI
manages its own browser independently of the browser tool's daemon, and
`npx agent-browser install --with-deps` is its one-time setup.

### Cleanup pitfalls

- Kill spare dev servers by port — `lsof -ti :PORT | xargs kill` — not by
  process-pattern `pkill -f`: env-var prefixes often don't match the command line
  and the server survives.
- Leave the MAIN app running on its named port so Smoke tests a live app; only
  fixture/spare instances get killed.

## Evidence and handoff

- Screenshots + a short pre-QA note go in the team's `reports/` dir (e.g.
  `qa-pending-<card>.md` with the per-check PASS lines and PNGs); keep fixture
  screenshots even after the fixture file is deleted.
- Handoff mechanics (v1.1, in this exact order):
  1. `kanban_complete` the Build task — summary = what was built + which accept
     checks you self-verified and how + watch-outs; metadata = changed_files,
     run_command, port, watchouts.
  2. `kanban_create` the QA task: title `QA Card <N>: <title>`, assignee
     `workbench-smoke`, `parents=[<build task id>]`, body = run command + port +
     watch-outs + the accept-check list. The parent edge is the handoff.
  3. ONE short DM to Smoke: QA task id, run command, port, watch-outs.
  Never mark Shipped — that's Smoke's gate (QA verdict PASS).

## Post-ship data fixes (no-bounce hygiene bumps)

- A teammate's data-hygiene finding is still a CLAIM: re-verify it against BOTH
  the live source AND the local raw fetch artifacts (e.g. saved PDP HTML) before
  touching shared research data. Only then edit the shared snapshot VERBATIM,
  re-run the sync step, confirm the repo copy is byte-identical to the shared
  source again, commit with a "data bump" message, and log it on the board.
- Check who owns the live instance before restarting: if the server reads its
  data files from disk per request (the zero-dep recipe does), a data-only bump
  is live with NO restart — verify via the running server's endpoint, don't
  kill the teammate's process.
- Log data bumps as a `kanban_comment` on the relevant task (post-ship, no state
  change) and note whether a backlog task already covers the bigger version of the
  fix — don't claim that task just to do the small fix.
- Never 'normalize' source data (casing, spacing, hyphens): the snapshot must
  mirror the source exactly, quirks included. That's the data-integrity contract.
- Bot-walled product URLs: when a PDP re-fetch hits Imperva, use the canonical
  URL form from the data (e.g. safeway's `/shop/pd/<slug>/<sku>`), not the
  legacy `product-details.<id>.html` URLs.
