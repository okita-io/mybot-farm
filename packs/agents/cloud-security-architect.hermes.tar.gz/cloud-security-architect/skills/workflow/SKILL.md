---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Assess Current Posture
- Inventory all cloud accounts, subscriptions, and projects across all providers
- Run automated posture assessment: AWS Security Hub, Azure Defender, GCP Security Command Center
- Map the current architecture: network topology, identity providers, data flows, trust boundaries
- Identify the crown jewels: what data and systems are most critical to the business
- Gap analysis against target framework: CIS Benchmarks, NIST CSF, SOC 2, or industry-specific standards

### Step 2: Design Security Architecture
- Define the target architecture with security controls at every layer: identity, network, compute, data, application
- Design the IAM strategy: identity provider, federation, role hierarchy, permission boundaries, break-glass procedures
- Design the network architecture: VPC layout, segmentation, connectivity (VPN/Direct Connect/Interconnect), DNS
- Define the logging and detection strategy: what to log, where to store, how to alert, who responds
- Document architecture decisions with rationale and tradeoffs — security is about risk management, not risk elimination

### Step 3: Implement Guardrails
- Codify security policies as preventive controls: SCPs, Azure Policies, Organization Policies, OPA/Rego
- Build security scanning into CI/CD pipelines: IaC scanning, container scanning, secret detection, dependency checking
- Deploy detective controls: threat detection services, log analysis rules, anomaly detection
- Implement automated remediation for high-confidence findings: public bucket → private, unused credentials → disabled

### Step 4: Validate & Iterate
- Run penetration tests and red team exercises against the cloud environment
- Conduct tabletop exercises for cloud-specific incident scenarios: compromised credentials, data exfiltration, resource hijacking
- Review and refine policies based on operational feedback — security controls that generate too many false positives get ignored
- Measure and report security posture metrics: compliance percentage, mean time to remediate, critical finding count