---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

AWS Multi-Account Security Architecture (Terraform)
```hcl
# AWS Organization with security-focused OU structure
# Implements SCPs, centralized logging, and GuardDuty

resource "aws_organizations_organization" "org" {
  feature_set = "ALL"
  enabled_policy_types = [
    "SERVICE_CONTROL_POLICY",
    "TAG_POLICY",
  ]
}

# === Service Control Policies (Guardrails) ===

resource "aws_organizations_policy" "deny_root_usage" {
  name        = "deny-root-account-usage"
  description = "Prevent root user actions in member accounts"
  type        = "SERVICE_CONTROL_POLICY"
  content     = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "DenyRootActions"
        Effect    = "Deny"
        Action    = "*"
        Resource  = "*"
        Condition = {
          StringLike = {
            "aws:PrincipalArn" = "arn:aws:iam::*:root"
          }
        }
      }
    ]
  })
}

resource "aws_organizations_policy" "deny_leave_org" {
  name    = "deny-leave-organization"
  type    = "SERVICE_CONTROL_POLICY"
  content = jsonencode({
    Version = "2012-10-17"
# … truncated for farm planting — see upstream for the full sample
```

### Kubernetes Network Policy (Zero Trust Pod-to-Pod)
```yaml
# Default deny all traffic — explicit allow only
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-all
  namespace: production
spec:
  podSelector: {}
  policyTypes:
    - Ingress
    - Egress

---
# Allow frontend → backend API only on port 8080
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-frontend-to-api
  namespace: production
spec:
  podSelector:
    matchLabels:
      app: backend-api
  policyTypes:
    - Ingress
  ingress:
    - from:
        - podSelector:
            matchLabels:
              app: frontend
      ports:
        - protocol: TCP
          port: 8080

---
# Allow backend API → database on port 5432
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-api-to-database
# … truncated for farm planting — see upstream for the full sample
```

### CI/CD Pipeline Security (GitHub Actions with OIDC)
```yaml
# Secure deployment pipeline — no long-lived credentials
name: Deploy to AWS
on:
  push:
    branches: [main]

permissions:
  id-token: write   # Required for OIDC federation
  contents: read

jobs:
  security-scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      # Scan IaC for misconfigurations
      - name: Checkov — Infrastructure Policy Check
        uses: bridgecrewio/checkov-action@v12
        with:
          directory: ./terraform
          framework: terraform
          soft_fail: false  # Fail the pipeline on policy violations
          output_format: sarif

      # Scan for leaked secrets
      - name: Gitleaks — Secret Detection
        uses: gitleaks/gitleaks-action@v2
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}

      # Scan container images
      - name: Trivy — Container Vulnerability Scan
        uses: aquasecurity/trivy-action@master
        with:
          image-ref: ${{ env.IMAGE_TAG }}
          format: sarif
          severity: CRITICAL,HIGH
          exit-code: 1  # Fail on critical/high vulnerabilities

# … truncated for farm planting — see upstream for the full sample
```

### Cloud Security Posture Checklist
```markdown
# Cloud Security Posture Review

## Identity & Access Management
- [ ] No root/owner account used for daily operations
- [ ] MFA enforced for all human users (hardware keys for admins)
- [ ] Service accounts use workload identity / IRSA / managed identity (no long-lived keys)
- [ ] IAM policies follow least privilege — no wildcards (*) in production
- [ ] Dormant accounts (90+ days inactive) are automatically disabled
- [ ] Cross-account access uses role assumption with external ID, not shared credentials
- [ ] Break-glass procedure documented and tested for emergency access

## Network Security
- [ ] Default VPC deleted in all regions
- [ ] No security group rules allow 0.0.0.0/0 to management ports (22, 3389)
- [ ] Private subnets used for all workloads — public subnets only for load balancers
- [ ] VPC Flow Logs enabled on all VPCs
- [ ] DNS logging enabled (Route 53 query logs / Cloud DNS logging)
- [ ] Network segmentation between environments (dev/staging/prod)
- [ ] Private endpoints used for cloud service access (S3, KMS, ECR)

## Data Protection…