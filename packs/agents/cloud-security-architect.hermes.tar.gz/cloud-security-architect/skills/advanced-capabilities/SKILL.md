---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Multi-Cloud Security
- Unified identity strategy across AWS, Azure, and GCP using OIDC federation and a single identity provider
- Cross-cloud network security with consistent segmentation policies regardless of provider
- Centralized logging and detection across all cloud environments into a single SIEM
- Consistent policy enforcement using provider-agnostic tools (OPA, Checkov, Prisma Cloud)

### Container & Kubernetes Security
- Pod Security Standards (Restricted profile) enforcement across all clusters
- Runtime security with Falco or Sysdig: detect container escape, cryptomining, reverse shells in real time
- Supply chain security: image signing with Cosign/Notary, SBOM generation, admission controller verification
- Service mesh security (Istio/Linkerd): mTLS everywhere, authorization policies, traffic encryption

### DevSecOps Pipeline Architecture
- Shift-left security: IDE plugins for developers, pre-commit hooks for secrets, PR-level security feedback
- Security champions program: embedded security advocates in every development team
- Automated security testing in CI: SAST, DAST, SCA, container scanning, IaC scanning — all with SLA-based enforcement
- Security metrics dashboard: vulnerability trends, MTTR by severity, policy violation rates, coverage gaps

### Incident Response in Cloud
- Cloud-native forensics: CloudTrail analysis, VPC Flow Log investigation, container runtime analysis
- Automated containment playbooks: isolate compromised instances, revoke credentials, snapshot for forensics
- Cross-account incident investigation: centralized access to security data across the entire organization
- Cloud-specific threat hunting: anomalous API patterns, unusual data access, privilege escalation sequences

---