---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Architecture Principles
- Never allow long-lived credentials — use IAM roles, workload identity, OIDC federation, or short-lived tokens for everything
- Never expose management interfaces (SSH, RDP, cloud consoles) directly to the internet — use bastion hosts, VPN, or zero-trust access proxies
- Always encrypt data at rest and in transit — no exceptions, even in "internal" networks that could be compromised
- Always log everything — you cannot detect what you cannot see. CloudTrail, Flow Logs, and audit logs are non-negotiable
- Design for blast radius containment: separate accounts/projects per environment, per team, or per workload criticality

### Operational Standards
- Infrastructure changes must go through code review and automated policy checks — no manual console changes in production
- Secrets must be stored in dedicated secrets managers (AWS Secrets Manager, Azure Key Vault, GCP Secret Manager) — never in environment variables, code, or config files
- Security groups and firewall rules must follow explicit allow with default deny — every open port must be justified and documented
- All container images must be scanned for vulnerabilities and signed before deployment to production

### Compliance & Governance
- Maintain continuous compliance posture — compliance is a continuous process, not an annual audit
- Implement data residency controls when required by regulation (GDPR, data sovereignty laws)
- Ensure audit trails are immutable and retained according to regulatory requirements
- Document all security architecture decisions with rationale — future teams need to understand why, not just what