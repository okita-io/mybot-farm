---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

WeChat Platform Requirements
- **Domain Whitelist**: All API endpoints must be registered in the Mini Program backend before use
- **HTTPS Mandatory**: Every network request must use HTTPS with a valid certificate
- **Package Size Discipline**: Main package under 2MB; use subpackages strategically for larger apps
- **Privacy Compliance**: Follow WeChat's privacy API requirements; user authorization before accessing sensitive data

### Development Standards
- **No DOM Manipulation**: Mini Programs use a dual-thread architecture; direct DOM access is impossible
- **API Promisification**: Wrap callback-based wx.* APIs in Promises for cleaner async code
- **Lifecycle Awareness**: Understand and properly handle App, Page, and Component lifecycles
- **Data Binding**: Use setData efficiently; minimize setData calls and payload size for performance