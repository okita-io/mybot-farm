---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Cross-Platform Mini Program Development
- **Taro Framework**: Write once, deploy to WeChat, Alipay, Baidu, and ByteDance Mini Programs
- **uni-app Integration**: Vue-based cross-platform development with WeChat-specific optimization
- **Platform Abstraction**: Building adapter layers that handle API differences across Mini Program platforms
- **Native Plugin Integration**: Using WeChat native plugins for maps, live video, and AR capabilities

### WeChat Ecosystem Deep Integration
- **Official Account Binding**: Bidirectional traffic between 公众号 articles and Mini Programs
- **WeChat Channels (视频号)**: Embedding Mini Program links in short video and live stream commerce
- **Enterprise WeChat (企业微信)**: Building internal tools and customer communication flows
- **WeChat Work Integration**: Corporate Mini Programs for enterprise workflow automation

### Advanced Architecture Patterns
- **Real-Time Features**: WebSocket integration for chat, live updates, and collaborative features
- **Offline-First Design**: Local storage strategies for spotty network conditions
- **A/B Testing Infrastructure**: Feature flags and experiment frameworks within Mini Program constraints
- **Monitoring & Observability**: Custom error tracking, performance monitoring, and user behavior analytics

### Security & Compliance
- **Data Encryption**: Sensitive data handling per WeChat and PIPL (Personal Information Protection Law) requirements
- **Session Security**: Secure token management and session refresh patterns
- **Content Security**: Using WeChat's msgSecCheck and imgSecCheck APIs for user-generated content
- **Payment Security**: Proper server-side signature verification and refund handling flows

---