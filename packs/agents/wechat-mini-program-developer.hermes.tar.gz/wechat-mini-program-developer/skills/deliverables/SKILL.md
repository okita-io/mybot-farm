---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Mini Program Project Structure
```
├── app.js                 # App lifecycle and global data
├── app.json               # Global configuration (pages, window, tabBar)
├── app.wxss               # Global styles
├── project.config.json    # IDE and project settings
├── sitemap.json           # WeChat search index configuration
├── pages/
│   ├── index/             # Home page
│   │   ├── index.js
│   │   ├── index.json
│   │   ├── index.wxml
│   │   └── index.wxss
│   ├── product/           # Product detail
│   └── order/             # Order flow
├── components/            # Reusable custom components
│   ├── product-card/
│   └── price-display/
├── utils/
│   ├── request.js         # Unified network request wrapper
│   ├── auth.js            # Login and token management
│   └── analytics.js       # Event tracking
├── services/              # Business logic and API calls
└── subpackages/           # Subpackages for size management
    ├── user-center/
    └── marketing-pages/
```

### Core Request Wrapper Implementation
```javascript
// utils/request.js - Unified API request with auth and error handling
const BASE_URL = 'https://api.example.com/miniapp/v1';

const request = (options) => {
  return new Promise((resolve, reject) => {
    const [REDACTED]'access_token');

    wx.request({
      url: `${BASE_URL}${options.url}`,
      method: options.method || 'GET',
      data: options.data || {},
      header: {
        'Content-Type': 'application/json',
        'Authorization': token ? `Bearer ${token}` : '',
        ...options.header,
      },
      success: (res) => {
        if (res.statusCode === 401) {
          // Token expired, re-trigger login flow
          return refreshTokenAndRetry(options).then(resolve).catch(reject);
        }
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(res.data);
        } else {
          reject({ code: res.statusCode, message: res.data.message || 'Request failed' });
        }
      },
      fail: (err) => {
        reject({ code: -1, message: 'Network error', detail: err });
      },
    });
  });
};

// WeChat login flow with server-side session
const login = async () => {
  const { code } = await wx.login();
  const { data } = await request({
    url: '/auth/wechat-login',
    method: 'POST',
# … truncated for farm planting — see upstream for the full sample
```

### WeChat Pay Integration Template
```javascript
// services/payment.js - WeChat Pay Mini Program integration
const { request } = require('../utils/request');

const createOrder = async (orderData) => {
  // Step 1: Create order on your server, get prepay parameters
  const prepayResult = await request({
    url: '/orders/create',
    method: 'POST',
    data: {
      items: orderData.items,
      address_id: orderData.addressId,
      coupon_id: orderData.couponId,
    },
  });

  // Step 2: Invoke WeChat Pay with server-provided parameters
  return new Promise((resolve, reject) => {
    wx.requestPayment({
      timeStamp: prepayResult.timeStamp,
      nonceStr: prepayResult.nonceStr,
      package: prepayResult.package,       // prepay_id format
      signType: prepayResult.signType,     // RSA or MD5
      paySign: prepayResult.paySign,
      success: (res) => {
        resolve({ success: true, orderId: prepayResult.orderId });
      },
      fail: (err) => {
        if (err.errMsg.includes('cancel')) {
          resolve({ success: false, reason: 'cancelled' });
        } else {
          reject({ success: false, reason: 'payment_failed', detail: err });
        }
      },
    });
  });
};

// Subscription message authorization (replaces deprecated template messages)
const requestSubscription = async (templateIds) => {
  return new Promise((resolve) => {
# … truncated for farm planting — see upstream for the full sample
```

### Performance-Optimized Page Template
```javascript
// pages/product/product.js - Performance-optimized product detail page
const { request } = require('../../utils/request');

Page({
  data: {
    product: null,
    loading: true,
    skuSelected: {},
  },

  onLoad(options) {
    const { id } = options;
    // Enable initial rendering while data loads
    this.productId = id;
    this.loadProduct(id);

    // Preload next likely page data
    if (options.from === 'list') {
      this.preloadRelatedProducts(id);
    }
  },

  async loadProduct(id) {
    try {
      const product = await request({ url: `/products/${id}` });…