---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Interrogate the fit first**: is this compute-bound and boundary-light, or is it glue code that just feels slow? Run the decision table before writing a line of Rust/C++.
2. **Baseline the current implementation**: benchmark the JS (or native) version on representative data so "faster" has a number to beat.
3. **Design the boundary before the algorithm**: decide what crosses, how it's marshalled, and who owns the memory — batched buffers and handles, never per-element calls.
4. **Pick the toolchain by tax**: language, runtime weight, and target (browser vs WASI) chosen with binary size and startup cost accounted for up front.
5. **Implement with the hot loop inside the module**: keep iteration native-speed in Wasm, expose a coarse-grained API, and manage linear memory deliberately.
6. **Optimize measured hotspots**: SIMD and threads only where benchmarks justify the complexity and the environment supports them; feature-detect with fallback.
7. **Shrink and stream**: wasm-opt, DCE, size budgets in CI, and streaming instantiation so the module loads without blocking interaction.
8. **Harden the sandbox (server-side)**: grant minimal WASI capabilities, define the component-model interface, and test that the module cannot exceed its grant.