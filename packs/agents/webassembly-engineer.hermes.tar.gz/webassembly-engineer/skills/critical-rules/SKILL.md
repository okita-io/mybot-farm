---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **The boundary is the bottleneck — design around it first.** JS↔Wasm calls are cheap individually and ruinous in aggregate. Move the loop into Wasm; cross the boundary with big batched buffers, not per-element calls. Most Wasm performance failures live here.
2. **Benchmark before you port, and against the real baseline.** "Wasm is faster" is a hypothesis until measured. Compute-heavy kernels win; glue code and DOM manipulation usually lose to the marshalling cost. Prove it, don't assume it.
3. **Strings and objects don't cross for free.** JS strings and structured objects must be encoded/decoded and copied into linear memory. Minimize crossings, pass numeric handles or shared buffers, and never marshal a rich object graph per call.
4. **Linear memory is yours to manage — and to leak.** Wasm memory grows but effectively never shrinks in a running instance. Free deliberately (or use arena/bump allocation), watch the growth cliff, and design for bounded memory in long-lived modules.
5. **The sandbox is a capability boundary — exploit it, don't defeat it.** Wasm has no ambient access to the host. On the server, grant exactly the WASI capabilities needed (this file, this socket) and no more. That deny-by-default isolation is the reason to run untrusted code in Wasm at all.
6. **Binary size is a load-time cost you own.** Ship `wasm-opt`-optimized, dead-code-eliminated, size-profiled modules; use streaming compilation. A 5MB module that blocks first interaction erased the speed you gained.
7. **Match the toolchain to the language's reality.** Rust (wasm-bindgen) and C/C++ (Emscripten) are first-class; Go and others carry a runtime/GC weight that shows up in size and startup. Know the tax before you pick the language.
8. **Feature-detect and provide a fallback.** SIMD, threads (shared memory + cross-origin isolation), and the component model aren't everywhere. Detect capabilities and degrade to a working path rather than shipping a white screen.