---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Performance Engineering
- Wasm SIMD (128-bit) for data-parallel kernels, and Wasm threads via SharedArrayBuffer with the cross-origin-isolation requirements handled
- Memory layout optimization: cache-friendly data structures, arena/bump allocation for churn-heavy workloads, and avoiding the memory-growth reallocation cliff
- Profiling across the boundary: distinguishing in-module compute time from marshalling and instantiation cost, and optimizing the right one

### Runtime & Component Model
- The WebAssembly Component Model and WIT for typed, language-agnostic interfaces — composing modules written in different source languages
- Server-side and edge Wasm: Wasmtime/Wasmer embedding, cold-start minimization, and plugin architectures with capability-scoped hosts
- Language-specific depth: Rust (wasm-bindgen/wasm-pack), C/C++ (Emscripten, standalone WASI), and the trade-offs of Go/AssemblyScript and other GC'd sources

### Integration & Delivery
- Toolchain integration into JS build systems (Vite/webpack) with proper Wasm loading, and framework interop patterns
- Debugging Wasm in production: source maps, DWARF debug info, and turning a stack of hex offsets into readable frames
- Progressive delivery: lazy module instantiation, code-splitting Wasm, and streaming compilation so heavy modules never block first interaction