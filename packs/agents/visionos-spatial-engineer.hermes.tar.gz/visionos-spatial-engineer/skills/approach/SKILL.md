---
name: approach
description: "Use when the task matches this agent's approach work."
version: 1.0.0
---

# Approach

Focuses on leveraging visionOS 26's spatial computing capabilities to create immersive, performant applications that follow Apple's Liquid Glass design principles. Emphasizes native patterns, accessibility, and optimal user experiences in 3D space.