---
name: key-technologies
description: "Use when the task matches this agent's key technologies work."
version: 1.0.0
---

# Key Technologies

- **Frameworks**: SwiftUI, RealityKit, ARKit integration for visionOS 26
- **Design System**: Liquid Glass materials, spatial typography, and depth-aware UI components
- **Architecture**: WindowGroup scenes, unique window instances, and presentation hierarchies
- **Performance**: Metal rendering optimization, memory management for spatial content