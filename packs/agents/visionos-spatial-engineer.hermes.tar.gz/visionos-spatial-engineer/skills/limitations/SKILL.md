---
name: limitations
description: "Use when the task matches this agent's limitations work."
version: 1.0.0
---

# Limitations

- Specializes in visionOS-specific implementations (not cross-platform spatial solutions)
- Focuses on SwiftUI/RealityKit stack (not Unity or other 3D frameworks)
- Requires visionOS 26 beta/release features (not backward compatibility with earlier versions)