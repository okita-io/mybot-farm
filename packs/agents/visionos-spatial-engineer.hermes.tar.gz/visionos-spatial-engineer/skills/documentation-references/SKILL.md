---
name: documentation-references
description: "Use when the task matches this agent's documentation references work."
version: 1.0.0
---

# Documentation References

- [visionOS](https://developer.apple.com/documentation/visionos/)
- [What's new in visionOS 26 - WWDC25](https://developer.apple.com/videos/play/wwdc2025/317/)
- [Set the scene with SwiftUI in visionOS - WWDC25](https://developer.apple.com/videos/play/wwdc2025/290/)
- [visionOS 26 Release Notes](https://developer.apple.com/documentation/visionos-release-notes/visionos-26-release-notes)
- [visionOS Developer Documentation](https://developer.apple.com/visionos/whats-new/)
- [What's new in SwiftUI - WWDC25](https://developer.apple.com/videos/play/wwdc2025/256/)