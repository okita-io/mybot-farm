---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

OIDC Authorization Code + PKCE (the only flow you should be reaching for)

```typescript
// Start: generate per-request secrets, bind them to the session, send the user off
import { randomBytes, createHash } from 'crypto';

export function beginLogin(session: Session): string {
  const state = randomBytes(32).toString('base64url');        // CSRF binding
  const nonce = randomBytes(32).toString('base64url');        // ID-token replay binding
  const verifier = randomBytes(32).toString('base64url');     // PKCE
  const challenge = createHash('sha256').update(verifier).digest('base64url');

  session.auth = { state, nonce, verifier };                   // server-side, short TTL

  const url = new URL('https://idp.example.com/authorize');
  url.search = new URLSearchParams({
    response_type: 'code',
    client_id: process.env.OIDC_CLIENT_ID!,
    redirect_uri: 'https://app.example.com/callback',          // exact match, registered
    scope: 'openid profile email',
    state, nonce,
    code_challenge: challenge,
    code_challenge_method: 'S256',
  }).toString();
  return url.toString();
}

// Callback: verify EVERYTHING before trusting anything
export async function handleCallback(req: Request, session: Session) {
  const { code, state } = params(req);
  if (!session.auth || state !== session.auth.state) throw new AuthError('state_mismatch');

  const tokens = await exchangeCode(code, session.auth.verifier); // includes PKCE verifier
  const claims = await verifyIdToken(tokens.id_token, {
    issuer: 'https://idp.example.com',
    audience: process.env.OIDC_CLIENT_ID!,
    algorithms: ['RS256'],                                      // allowlist — never trust the header alone
  });
  if (claims.nonce !== session.auth.nonce) throw new AuthError('nonce_mismatch');

  delete session.auth;                                          // one-time use
  return establishSession(claims.sub, claims.email);
}
```

### Session & Token Architecture Decision Table

| Concern | Opaque server session | Short-lived JWT + rotating refresh |
|---------|----------------------|-------------------------------------|
| Instant revocation | ✅ Delete the row | ⚠️ Wait out access TTL (keep it ≤ 15 min) or run a denylist |
| Horizontal scale | Needs shared store (Redis) | Stateless verification at the edge |
| Best fit | First-party web app, one domain | APIs, mobile clients, service-to-service |
| Refresh handling | Sliding expiry server-side | Rotate on every use; reuse ⇒ revoke token family + alert |
| Storage (browser) | `HttpOnly; Secure; SameSite=Lax` cookie | Same cookie rules — `localStorage` is XSS's favorite gift |

### Enterprise SSO + SCIM: What "SAML Support" Actually Means

```text
Per-tenant identity config, stored and validated per organization:
  ├── SSO: SAML 2.0 (SP-initiated) and/or OIDC
  │     ├── IdP metadata: entity ID, SSO URL, signing certificate (with rotation UI)
  │     ├── Assertions: signature REQUIRED, audience + destination checked,
  │     │   InResponseTo validated, ±3 min clock-skew tolerance, replay cache
  │     ├── Attribute mapping: email / name / groups → app roles (per-tenant map)
  │     └── Enforcement: domain-verified users MUST use SSO (block password fallback)
  ├── Provisioning: SCIM 2.0  (/Users, /Groups)
  │     ├── Create/update: JIT-provision on first SSO login OR pre-provision via SCIM
  │     ├── DEPROVISION is the deal-breaker: active=false ⇒ sessions revoked ≤ 60s
  │     └── Group pushes map to roles — never let SCIM writes escape the tenant scope
  └── Break-glass: org-admin recovery path that works when the IdP is down or misconfigured
```

### Passkeys/WebAuthn Registration (phishing-resistant, standards-only)

```typescript
// Server issues options; browser does the cryptography; server verifies.
import { generateRegistrationOptions, verifyRegistrationResponse } from '@simplewebauthn/server';

const options = await generateRegistrationOptions({
  rpID: 'app.example.com',                       // binds credential to your origin — this is the anti-phishing
  rpName: 'Example App',
  userID: user.id, userName: user.email,
  attestationType: 'none',
  authenticatorSelection: { residentKey: 'preferred', userVerification: 'preferred' },
  excludeCredentials: user.passkeys.map(p => ({ id: p.credentialId, type: 'public-key' })),
});
challengeStore.put(user.id, options.challenge, { ttlSeconds: 300 });

// On response: verify challenge + origin + rpID, then store credentialId,…