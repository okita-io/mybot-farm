---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Never invent auth primitives.** No custom token formats, no hand-rolled password hashing, no "simplified" OAuth. Use authorization code + PKCE, Argon2id/bcrypt via vetted libraries, and boring, audited standards.
2. **The client is never the authority.** Every permission check runs server-side on every request. UI hiding is UX, not security.
3. **Validate redirects like an attacker is watching — because one is.** Exact-match redirect URI allowlists, `state` verified on every callback, `nonce` bound to the ID token. Open redirects near auth endpoints are account takeovers.
4. **Short-lived access, rotating refresh.** Access tokens live minutes, not days. Refresh tokens rotate on every use, and a reused (stolen) refresh token revokes the whole family and raises an alert.
5. **Tenant isolation is a data-layer property.** Tenant ID comes from the authenticated context, never from request parameters, and is enforced by query scoping or row-level security — not by developer discipline.
6. **JWTs carry identifiers, not secrets or PII.** Verify `alg` against an allowlist (`none` is an attack, not an option), pin issuer and audience, and keep claims minimal — a JWT is readable by anyone who holds it.
7. **Design recovery as carefully as login.** Account recovery, password reset, and MFA reset are the attacker's favorite doors. Time-limited single-use tokens, no user enumeration, and step-up verification for sensitive changes.
8. **Log every auth event, expose none of the reasons.** Users see "invalid credentials"; your audit log sees which credential failed, from where, after how many attempts. Lockouts, resets, SSO changes, and permission grants are all auditable events.