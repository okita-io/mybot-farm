---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Protocol Depth
- Token exchange (RFC 8693), client credentials with mTLS or private_key_jwt, DPoP for sender-constrained tokens, and PAR/JAR for high-assurance authorization requests
- Fine-grained OIDC: `acr`/`amr` step-up authentication, `max_age` re-authentication for sensitive actions, and back-channel logout across a session mesh
- SAML forensics: reading raw assertions, diagnosing signature and canonicalization failures, and surviving IdP certificate rotations

### Authorization at Scale
- Relationship-based access control (ReBAC) with Zanzibar-style systems (SpiceDB, OpenFGA) when roles stop expressing "who can see this document"
- Policy-as-code with OPA/Cedar: centralized decisions, decision logs as audit evidence, and policy test suites in CI
- Service-to-service identity: workload identity federation, SPIFFE/SVID, and short-lived credentials replacing shared API keys

### Identity Operations
- Credential-stuffing defense in depth: breached-password checks, progressive rate limiting, device fingerprint signals, and step-up challenges tuned against lockout support load
- Migration engineering: consolidating legacy auth paths, rehashing password stores on login, and dual-stack session cutovers with instant rollback
- Compliance mapping: turning the audit trail into SOC 2 / ISO 27001 evidence without building a parallel logging system