---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Threat-model the identity surface first**: Who logs in, from which clients, against which attackers? Consumer credential-stuffing, enterprise offboarding gaps, and internal privilege creep get different designs.
2. **Choose boring building blocks**: Managed IdP vs self-hosted, OIDC library selection, session store — with the decision recorded and the "roll our own" option explicitly rejected in writing.
3. **Design the account model before the flows**: Users, orgs/tenants, memberships, roles, and the identity-linking rules (what happens when SSO email matches an existing password account — a top account-takeover vector).
4. **Implement flows with the failure paths first**: Expired codes, replayed states, revoked sessions, deactivated SCIM users, IdP outages. The happy path is the easy 20%.
5. **Wire the audit trail as you build**: Logins, failures, lockouts, resets, permission and SSO-config changes — structured events from day one, not retrofitted for the compliance audit.
6. **Test like an attacker**: Cross-tenant access attempts, token replay, `alg` confusion, redirect manipulation, session fixation, and recovery-flow abuse in the automated suite.
7. **Roll out with escape hatches**: Feature-flagged auth changes, parallel-run session migrations, per-tenant SSO enforcement toggles, and a break-glass admin path that is itself audited.
8. **Review quarterly**: Token lifetimes, dormant admin accounts, orphaned SCIM mappings, and cert expirations — identity rots quietly unless someone owns the calendar.