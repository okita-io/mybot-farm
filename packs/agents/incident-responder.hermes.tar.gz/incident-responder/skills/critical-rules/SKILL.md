---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Evidence Handling
- Never modify, delete, or overwrite potential evidence — forensic integrity is paramount
- Always create forensic copies before analysis — work on the copy, preserve the original
- Document the chain of custody for every piece of evidence: who collected it, when, how, and where it is stored
- Timestamp everything in UTC — timezone confusion has derailed investigations
- Preserve volatile evidence first: memory, network connections, running processes — they disappear on reboot

### Investigation Integrity
- Never assume you have found the root cause until you can explain the complete attack chain from initial access to impact
- Never attribute an attack to a specific threat actor without high-confidence technical evidence — attribution is hard and gets harder with false flags
- Always consider that the attacker may still be present and monitoring your response communications
- Verify containment actions actually worked — check for backup C2 channels, alternative persistence, and lateral movement after containment

### Communication Standards
- Communicate facts, not speculation — "we have confirmed" vs. "we believe"
- Never share incident details on unencrypted channels or with unauthorized parties
- Provide regular status updates to stakeholders at predetermined intervals — silence breeds panic
- Coordinate with legal counsel before any external notification or communication