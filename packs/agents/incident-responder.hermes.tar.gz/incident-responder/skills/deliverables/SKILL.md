---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Windows Forensic Triage Script
```powershell
# Windows Incident Response Triage Collection
# Run as Administrator on suspected compromised system
# Collects volatile data FIRST (memory, connections, processes)

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$outDir = "C:\IR-Triage-$timestamp"
New-Item -ItemType Directory -Path $outDir -Force | Out-Null

Write-Host "[*] Starting IR triage collection at $timestamp (UTC: $(Get-Date -Format u))"

# === VOLATILE DATA (collect first — disappears on reboot) ===

Write-Host "[1/8] Capturing running processes with command lines..."
Get-CimInstance Win32_Process |
    Select-Object ProcessId, ParentProcessId, Name, CommandLine,
        ExecutablePath, CreationDate, @{N='Owner';E={
            $owner = Invoke-CimMethod -InputObject $_ -MethodName GetOwner
            "$($owner.Domain)\$($owner.User)"
        }} |
    Export-Csv "$outDir\processes.csv" -NoTypeInformation

Write-Host "[2/8] Capturing network connections..."
Get-NetTCPConnection |
    Select-Object LocalAddress, LocalPort, RemoteAddress, RemotePort,
        State, OwningProcess, CreationTime,
        @{N='ProcessName';E={(Get-Process -Id $_.OwningProcess -ErrorAction SilentlyContinue).ProcessName}} |
    Export-Csv "$outDir\network-connections.csv" -NoTypeInformation

Write-Host "[3/8] Capturing DNS cache..."
Get-DnsClientCache |
    Export-Csv "$outDir\dns-cache.csv" -NoTypeInformation

Write-Host "[4/8] Capturing logged-on users and sessions..."
query user 2>$null | Out-File "$outDir\logged-on-users.txt"
Get-CimInstance Win32_LogonSession |
    Export-Csv "$outDir\logon-sessions.csv" -NoTypeInformation

# === PERSISTENCE MECHANISMS ===

Write-Host "[5/8] Enumerating persistence mechanisms..."
# … truncated for farm planting — see upstream for the full sample
```

### Linux Forensic Triage Script
```bash
#!/bin/bash
# Linux Incident Response Triage Collection
# Run as root on suspected compromised system

TIMESTAMP=$(date -u +"%Y%m%d-%H%M%S")
OUTDIR="/tmp/ir-triage-${HOSTNAME}-${TIMESTAMP}"
mkdir -p "$OUTDIR"

echo "[*] Starting Linux IR triage at ${TIMESTAMP} UTC"

# === VOLATILE DATA ===
echo "[1/7] Capturing processes..."
ps auxwwf > "$OUTDIR/ps-tree.txt"
ls -la /proc/*/exe 2>/dev/null > "$OUTDIR/proc-exe-links.txt"
cat /proc/*/cmdline 2>/dev/null | tr '\0' ' ' > "$OUTDIR/proc-cmdline.txt"

echo "[2/7] Capturing network state..."
ss -tlnp > "$OUTDIR/listening-ports.txt"
ss -tnp > "$OUTDIR/established-connections.txt"
ip addr > "$OUTDIR/ip-addresses.txt"
ip route > "$OUTDIR/routing-table.txt"
iptables -L -n -v > "$OUTDIR/firewall-rules.txt" 2>/dev/null

echo "[3/7] Capturing user activity..."
w > "$OUTDIR/logged-in-users.txt"
last -50 > "$OUTDIR/last-logins.txt"
lastb -50 > "$OUTDIR/failed-logins.txt" 2>/dev/null

# === PERSISTENCE ===
echo "[4/7] Enumerating persistence mechanisms..."
# Cron jobs (all users)
for user in $(cut -f1 -d: /etc/passwd); do
    crontab -l -u "$user" 2>/dev/null | grep -v '^#' |
        sed "s/^/${user}: /" >> "$OUTDIR/crontabs.txt"
done
ls -la /etc/cron.* > "$OUTDIR/cron-dirs.txt" 2>/dev/null

# Systemd services (non-vendor)
systemctl list-unit-files --type=service --state=enabled |
    grep -v '/usr/lib/systemd' > "$OUTDIR/enabled-services.txt"
# … truncated for farm planting — see upstream for the full sample
```

### Incident Severity Classification Framework
```markdown
# Incident Severity Matrix

## SEV1 — Critical (Response: Immediate, 24/7)
**Criteria**: Active data exfiltration, ransomware deployment in progress,
compromised domain controller, breach of PII/PHI/PCI data confirmed.

| Action              | Timeline     | Owner        |
|---------------------|-------------|--------------|
| War room activation | 0-15 min    | IR Lead      |
| Initial containment | 0-30 min    | IR + IT Ops  |
| Exec notification   | 0-1 hour    | CISO         |
| Legal notification  | 0-2 hours   | General Counsel |
| External IR retainer| 0-4 hours   | CISO         |
| Regulatory assess   | 0-24 hours  | Legal + Privacy |

## SEV2 — High (Response: Same business day)
**Criteria**: Confirmed compromise of single system, successful phishing
with credential harvesting, malware execution detected and contained,
unauthorized access to sensitive system.

| Action              | Timeline     | Owner        |
|---------------------|-------------|--------------|
| IR team activation  | 0-1 hour    | IR Lead      |
| Containment         | 0-4 hours   | IR + IT Ops  |…