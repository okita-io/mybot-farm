---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Detection & Triage (First 30 Minutes)
- Receive alert from SIEM, EDR, user report, or external notification (law enforcement, threat intel provider)
- Perform initial triage: is this a true positive? What is the scope? Is it active?
- Classify severity using the incident matrix and activate the appropriate response level
- Assemble the response team: IR lead, forensic analyst, IT operations, communications, legal (for SEV1-2)
- Open the incident ticket and begin the timeline — every action gets logged from this point

### Step 2: Containment (First 4 Hours for SEV1)
- Implement immediate containment to stop the spread: network isolation, account disable, firewall rules
- Preserve evidence before containment actions — image memory, capture network traffic, snapshot VMs
- Identify and block IOCs across the environment: malicious IPs, domains, file hashes, process names
- Verify containment effectiveness — check for alternative C2 channels, backup persistence, lateral movement after containment
- Communicate containment status to stakeholders at the predetermined interval

### Step 3: Investigation & Forensics (Hours to Days)
- Reconstruct the complete attack timeline: initial access, execution, persistence, lateral movement, exfiltration
- Identify all compromised systems, accounts, and data through log analysis, forensic imaging, and EDR telemetry
- Determine the root cause and all contributing factors — what failed, what was missing, what was ignored
- Collect and preserve evidence with forensic rigor — this may become a legal matter

### Step 4: Eradication & Recovery (Days)
- Remove all attacker persistence mechanisms, backdoors, and malicious artifacts
- Reset compromised credentials and revoke active sessions — assume every credential the attacker touched is burned
- Rebuild compromised systems from known-good images — patching a rootkitted system is not remediation
- Restore from verified clean backups with integrity validation
- Monitor recovered systems intensively for 30-90 days — attackers often return

### Step 5: Post-Incident (1-2 Weeks After)
- Write the post-mortem: timeline, root cause, impact, what worked, what failed, and specific recommendations
- Conduct a blameless retrospective with all involved teams — focus on systems and processes, not individuals
- Track remediation actions with owners and deadlines — post-mortems without follow-through are fiction
- Update detection rules, runbooks, and playbooks based on lessons learned
- Brief leadership on the incident and the plan to prevent recurrence