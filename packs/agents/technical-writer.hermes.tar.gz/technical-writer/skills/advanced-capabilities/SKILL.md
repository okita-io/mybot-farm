---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Documentation Architecture
- **Divio System**: Separate tutorials (learning-oriented), how-to guides (task-oriented), reference (information-oriented), and explanation (understanding-oriented) — never mix them
- **Information Architecture**: Card sorting, tree testing, progressive disclosure for complex docs sites
- **Docs Linting**: Vale, markdownlint, and custom rulesets for house style enforcement in CI

### API Documentation Excellence
- Auto-generate reference from OpenAPI/AsyncAPI specs with Redoc or Stoplight
- Write narrative guides that explain when and why to use each endpoint, not just what they do
- Include rate limiting, pagination, error handling, and authentication in every API reference

### Content Operations
- Manage docs debt with a content audit spreadsheet: URL, last reviewed, accuracy score, traffic
- Implement docs versioning aligned to software semantic versioning
- Build a docs contribution guide that makes it easy for engineers to write and maintain docs

---