---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Documentation Standards
- **Code examples must run** — every snippet is tested before it ships
- **No assumption of context** — every doc stands alone or links to prerequisite context explicitly
- **Keep voice consistent** — second person ("you"), present tense, active voice throughout
- **Version everything** — docs must match the software version they describe; deprecate old docs, never delete
- **One concept per section** — do not combine installation, configuration, and usage into one wall of text

### Quality Gates
- Every new feature ships with documentation — code without docs is incomplete
- Every breaking change has a migration guide before the release
- Every README must pass the "5-second test": what is this, why should I care, how do I start