---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

High-Quality README Template
```markdown
# Project Name

> One-sentence description of what this does and why it matters.

[![npm version](https://badge.fury.io/js/your-package.svg)](https://badge.fury.io/js/your-package)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Why This Exists

<!-- 2-3 sentences: the problem this solves. Not features — the pain. -->

## Quick Start

<!-- Shortest possible path to working. No theory. -->

```bash
npm install your-package
```

```javascript
import { doTheThing } from 'your-package';

const result = await doTheThing({ input: 'hello' });
console.log(result); // "hello world"
```

## Installation

<!-- Full install instructions including prerequisites -->

**Prerequisites**: Node.js 18+, npm 9+

```bash
npm install your-package
# or
yarn add your-package
```

## Usage

### Basic Example

<!-- Most common use case, fully working -->

### Configuration

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `timeout` | `number` | `5000` | Request timeout in milliseconds |
| `retries` | `number` | `3` | Number of retry attempts on failure |

### Advanced Usage

<!-- Second most common use case -->

## API Reference

See [full API reference →](https://docs.yourproject.com/api)

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md)

## License

MIT © [Your Name](https://github.com/yourname)
```

### OpenAPI Documentation Example
```yaml
# openapi.yml - documentation-first API design
openapi: 3.1.0
info:
  title: Orders API
  version: 2.0.0
  description: |
    The Orders API allows you to create, retrieve, update, and cancel orders.

    ## Authentication
    All requests require a Bearer token in the `Authorization` header.
    Get your API key from [the dashboard](https://app.example.com/settings/api).

    ## Rate Limiting
    Requests are limited to 100/minute per API key. Rate limit headers are
    included in every response. See [Rate Limiting guide](https://docs.example.com/rate-limits).

    ## Versioning
    This is v2 of the API. See the [migration guide](https://docs.example.com/v1-to-v2)
    if upgrading from v1.

paths:
  /orders:
    post:
      summary: Create an order
      description: |
        Creates a new order. The order is placed in `pending` status until
        payment is confirmed. Subscribe to the `order.confirmed` webhook to
        be notified when the order is ready to fulfill.
      operationId: createOrder
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CreateOrderRequest'
            examples:
              standard_order:
                summary: Standard product order
                value:
                  customer_id: "cust_abc123"
# … truncated for farm planting — see upstream for the full sample
```

### Tutorial Structure Template
```markdown
# Tutorial: [What They'll Build] in [Time Estimate]

**What you'll build**: A brief description of the end result with a screenshot or demo link.

**What you'll learn**:
- Concept A
- Concept B
- Concept C

**Prerequisites**:
- [ ] [Tool X](link) installed (version Y+)
- [ ] Basic knowledge of [concept]
- [ ] An account at [service] ([sign up free](link))

---

## Step 1: Set Up Your Project

<!-- Tell them WHAT they're doing and WHY before the HOW -->
First, create a new project directory and initialize it. We'll use a separate directory
to keep things clean and easy to remove later.

```bash
mkdir my-project && cd my-project
npm init -y
```

You should see output like:
```
Wrote to /path/to/my-project/package.json: { ... }
```

> **Tip**: If you see `EACCES` errors, [fix npm permissions](https://link) or use `npx`.

## Step 2: Install Dependencies

<!-- Keep steps atomic — one concern per step -->

## Step N: What You Built

<!-- Celebrate! Summarize what they accomplished. -->

You built a [description]. Here's what you learned:
- **Concept A**: How it works and when to use it
- **Concept B**: The key insight

## Next Steps

- [Advanced tutorial: Add authentication](link)
- [Reference: Full API docs](link)
- [Example: Production-ready version](link)
```

### Docusaurus Configuration
```javascript
// docusaurus.config.js
const config = {
  title: 'Project Docs',
  tagline: 'Everything you need to build with Project',
  url: 'https://docs.yourproject.com',
  baseUrl: '/',
  trailingSlash: false,…