---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Drupal Commerce Architecture

- **Commerce Core**: Order, Product, Price, Store, Payment, Promotion, Tax, and Checkout submodules and their entity model
- **Entity & Field API**: product/variation entities, `commerce_price` fields, attribute entities, and bundle architecture
- **Price Chain**: `PriceResolverInterface`, price lists, currency resolution, and the `Calculator`/`Price` value objects
- **Checkout System**: checkout flows, checkout panes, the `CheckoutPaneInterface`, and order refresh/processing events
- **Payment API**: `PaymentGatewayInterface`, on-site vs. off-site gateways, payment methods, and the SupportsRefunds/SupportsVoids capability interfaces
- **Order Workflow**: the State Machine module, order states, transitions, guards, and transition events
- **Inventory**: Commerce Stock module, stock providers, and atomic decrement strategies

### Platform & Stack

- **Drupal 10 / 11**: core APIs, recipes, configuration management, and the Symfony foundation (services, events, dependency injection)
- **Composer Workflow**: managing Commerce and contrib modules, patches, and version constraints
- **Drush**: `updatedb`, `config:import/export`, `cache:rebuild`, and commerce-specific commands
- **Theming**: Twig for product/cart/checkout templates, render arrays, and cache metadata/contexts
- **Hosting**: Pantheon, Acquia, Platform.sh — and the deployment pipelines and environment config they imply

### Payment Gateways

- **Stripe**: Commerce Stripe — on-site Payment Element/Intents, SCA/3DS, webhooks, and tokenization
- **PayPal**: Commerce PayPal — Checkout (off-site) and on-site flows, IPN/webhooks
- **Braintree, Authorize.Net, Square**: contrib gateway modules and their capture/refund/void semantics
- **PCI Scope**: SAQ A (redirect) vs. SAQ A-EP (on-site fields), and how integration choice changes compliance burden

### Standards & Operations

- **PCI-DSS**: scope minimization, never storing PANs, and tokenization
- **Order Reconciliation**: matching Commerce payments to gateway settlement reports
- **Accessibility**: WCAG-compliant checkout forms and error messaging
- **Performance**: Big Pipe, render caching, and the uncacheable nature of cart/checkout

---