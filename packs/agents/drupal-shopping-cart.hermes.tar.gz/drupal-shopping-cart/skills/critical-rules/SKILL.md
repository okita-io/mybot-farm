---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Never compute prices in the cart or theme layer — use price resolvers.** Pricing logic belongs in `PriceResolverInterface` implementations and the Commerce price chain, not in Twig templates or cart event subscribers. A price shown to the customer must be the same price charged at checkout, resolved through the same code path.
2. **Money is `commerce_price` (amount + currency), never a float.** Currency amounts are stored and computed as decimal strings with their currency code. Never cast a price to a PHP float for arithmetic — rounding errors become real money lost or overcharged. Use the `Calculator` and `Price` value objects.
3. **Payment gateway credentials never live in code or config that's committed.** API keys, secrets, and webhook signing keys belong in environment variables or a secrets manager, referenced via `settings.php` or config overrides. A committed secret is a breach waiting to happen — and a PCI finding.
4. **Test mode and live mode must be unmistakable.** Never deploy a gateway in test mode to production, or live mode to a staging environment. Make the active mode visible to admins and gate live-mode deploys behind an explicit checklist.
5. **Webhooks must be verified, idempotent, and logged.** Validate the gateway's signature on every IPN/webhook, handle duplicate deliveries without double-processing, and log every payment notification. A payment state must never depend solely on the customer's browser returning to the success URL.
6. **Never delete orders or payments — transition them.** Orders and payments are financial records. Use order workflow transitions (cancel, void, refund) rather than deletion. Deleting an order destroys the audit trail and breaks reconciliation.
7. **Stock decrements must be race-safe.** When inventory matters, decrement stock atomically at the correct point in the order workflow (typically on payment, not on add-to-cart). Two customers buying the last unit simultaneously must not both succeed.
8. **Checkout customizations must degrade safely.** A custom checkout pane that throws must not block the customer from completing their order. Validate defensively, catch and log exceptions, and never let a non-critical pane fail the whole checkout.
9. **Tax and promotion logic must be configuration-driven and testable.** Hard-coded tax rates or discount math in custom code will be wrong the moment a rate changes. Use Commerce's tax and promotion systems so the logic is configurable, auditable, and covered by tests.
10. **Every commerce deployment runs config import, database updates, and cache rebuild in order.** `drush updatedb`, `drush config:import`, `drush cache:rebuild` — in the correct sequence — with a tested rollback. A botched commerce deploy can take a store offline during its highest-traffic hour.

---