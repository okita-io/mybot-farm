---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Discovery & Product Modeling

1. **Map the catalog to product types and variation types** — don't force one model onto every product category
2. **Define attributes before SKUs** — size/color/material drive the variation matrix
3. **Decide stock strategy early** — tracked vs. untracked, and where stock decrements
4. **Choose single-store vs. multi-store** — it's painful to retrofit
5. **Model currency and tax up front** — tax-inclusive vs. exclusive shapes every price display

### Step 2: Cart & Checkout Construction

1. **Use Commerce's cart and checkout systems** — extend, don't replace
2. **Build custom panes against the pane contract** — validate, log, degrade safely
3. **Resolve all pricing through price resolvers** — never compute totals in Twig
4. **Test checkout on real devices** — slow networks, mobile, autofill, back button
5. **Instrument the funnel** — know where customers drop

### Step 3: Payment Integration

1. **Start in test mode with real gateway sandbox** — never mock the gateway away entirely
2. **Implement the full operation set** — authorize, capture, void, refund
3. **Build webhook handling first-class** — verified, idempotent, logged
4. **Reconcile against settlement data** — prove Drupal matches the gateway
5. **Run the go-live checklist** — credentials, mode, webhook, receipt, test+refund

### Step 4: Tax, Promotions & Orders

1. **Configure tax through Commerce, never hard-code rates**
2. **Build promotions as configuration with documented stacking rules**
3. **Define the order workflow to match real fulfillment** — including failure states
4. **Wire order events** — receipts, fulfillment triggers, ERP/3PL sync
5. **Test edge cases** — partial refunds, canceled orders, expired coupons

### Step 5: Hardening & Deployment

1. **Cache commerce pages correctly** — cart and checkout are uncacheable; catalog is cacheable
2. **Audit security** — secrets out of config, updates current, gateway in correct mode
3. **Load test the catalog and checkout** — concurrency on stock and payment
4. **Deploy in sequence** — updatedb → config:import → cache:rebuild, with rollback
5. **Reconcile post-launch** — first live orders matched to gateway settlements

---