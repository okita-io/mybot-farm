---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

Technical Proposal Outline Template

```markdown
# [Project Name] Technical Proposal

## Chapter 1: Project Overview
### 1.1 Project Background
- Policy background (aligned with national/provincial/municipal policy documents)
- Business background (core problems facing the client)
- Construction objectives (quantifiable target metrics)

### 1.2 Scope of Construction
- Overall construction content summary table
- Relationship with the client's existing systems

### 1.3 Construction Principles
- Coordinated planning, intensive construction
- Secure and controllable, independently reliable (Xinchuang requirements)
- Open sharing, collaborative linkage
- People-oriented, convenient and efficient

## Chapter 2: Overall Design
### 2.1 Overall Architecture
- Technical architecture diagram (layered: infrastructure / data / platform / application / presentation)
- Business architecture diagram (process perspective)
- Data architecture diagram (data flow perspective)

### 2.2 Technology Roadmap
- Technology selection and rationale
- Xinchuang adaptation plan
- Integration plan with existing systems

## Chapter 3: Detailed Design
### 3.1 [Subsystem 1] Detailed Design
- Feature list
- Business processes
- Interface design
- Data model
### 3.2 [Subsystem 2] Detailed Design
(Same structure as above)

## Chapter 4: Security Assurance Plan
### 4.1 Security Architecture Design
# … truncated for farm planting — see upstream for the full sample
```

### Bid Document Checklist

```markdown
# Bid Document Checklist

## Qualifications (Disqualification Items — verify each one)
- [ ] Business license (scope of operations covers bid requirements)
- [ ] Relevant certifications (CMMI, ITSS, system integration qualifications, etc.)
- [ ] Dengbao assessment qualifications (if the bidder must hold them)
- [ ] Xinchuang adaptation certification / compatibility reports
- [ ] Financial audit reports for the past 3 years
- [ ] Declaration of no major legal violations
- [ ] Social insurance / tax payment certificates
- [ ] Power of attorney (if not signed by the legal representative)
- [ ] Consortium agreement (if bidding as a consortium)

## Technical Proposal
- [ ] Does it respond point-by-point to the bid document's technical requirements?
- [ ] Are architecture diagrams complete and clear (overall / network topology / deployment)?
- [ ] Does the Xinchuang plan specify product models and compatibility details?
- [ ] Are Dengbao/Miping designs covered in a dedicated chapter?
- [ ] Does the implementation plan include a Gantt chart and milestones?
- [ ] Does the project team section include personnel resumes and certifications?
- [ ] Are case studies supported by contracts / acceptance reports?

## Commercial
- [ ] Is the quoted price within the budget control limit?
- [ ] Does the pricing breakdown match the bill of materials in the technical proposal?
- [ ] Do payment terms respond to the bid document's requirements?
- [ ] Does the warranty period meet requirements?
- [ ] Is there risk of unreasonably low pricing?

## Formatting
- [ ] Continuous page numbering, table of contents matches content
- [ ] All signatures and stamps are complete (including spine stamps)
- [ ] Correct number of originals / copies
- [ ] Sealing meets requirements
- [ ] Bid bond has been paid
- [ ] Electronic version matches the print version
```

### Dengbao & Xinchuang Compliance Matrix

```markdown
# Compliance Check Matrix

## Dengbao 2.0 Level 3 Key Controls
| Security Domain | Control Requirement | Proposed Measure | Product/Component | Status |
|-----------------|-------------------|------------------|-------------------|--------|
| Secure Communications | Network architecture security | Security zone segmentation, VLAN isolation | Firewall / switches | |
| Secure Communications | Transmission security | SM4 encrypted transmission | Guomi VPN gateway | |
| Secure Boundary | Boundary protection | Access control policies | Next-gen firewall | |
| Secure Boundary | Intrusion prevention | IDS/IPS deployment | Intrusion detection system | |
| Secure Computing | Identity authentication | Two-factor authentication | Guomi CA + dynamic token | |
| Secure Computing | Data integrity | SM3 checksum verification | Guomi middleware | |
| Secure Computing | Data backup & recovery | Local + offsite backup | Backup appliance | |
| Security Mgmt Center | Centralized management | Unified security management platform | SIEM/SOC platform | |…