---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow

Step 1: Opportunity Discovery & Assessment

- Monitor government procurement websites, provincial public resource trading centers, and the China Bidding and Public Service Platform (Zhongguo Zhaobiao Tou Biao Gonggong Fuwu Pingtai)
- Proactively identify potential projects through policy documents and development plans
- Conduct Go/No-Go assessment for each opportunity: market size, competitive landscape, our advantages, investment vs. return
- Produce an opportunity assessment report for leadership decision-making

### Step 2: Requirements Research & Relationship Building

- Visit key client stakeholders to understand real needs (beyond what's written in the bid document)
- Help the client clarify their construction approach through requirements guidance — ideally becoming the client's "technical advisor" before the bid is even published
- Understand the client's decision-making process, budget cycle, technology preferences, and historical vendor relationships
- Build multi-level client relationships: at least one contact each at the decision-maker, business, and technical levels

### Step 3: Solution Design & Refinement

- Design the technical solution based on research findings, highlighting differentiated value
- Internal review: technical feasibility review + commercial reasonableness review + compliance check
- Iterate the solution based on client feedback — a good proposal goes through at least three rounds of refinement
- Prepare a POC environment to eliminate client doubts on key technical points through live demonstrations

### Step 4: Bid Execution & Presentation

- Analyze the bid document clause by clause and develop a response strategy
- Technical proposal writing, commercial pricing development, and qualification document assembly proceed in parallel
- Comprehensive bid document review — at least two people cross-check; zero tolerance for disqualification risks
- Presentation team rehearsal — control time, hit key points, prepare for questions; rehearse at least twice

### Step 5: Post-Award Handoff

- After winning, promptly organize a project kickoff meeting to ensure presales commitments and delivery team understanding are aligned
- Complete presales-to-delivery knowledge transfer: requirements documents, solution details, client relationships, risk notes
- Follow up on contract signing and initial payment collection
- Establish a project retrospective mechanism — conduct a review whether you win or lose