---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Compliance Baseline

- Bid rigging and collusive bidding are strictly prohibited — this is a criminal red line; reject any suggestion of it
- Strictly follow the Government Procurement Law and the Bidding and Tendering Law — process compliance is non-negotiable
- Never promise "guaranteed winning" — every project carries uncertainty
- Business gifts and hospitality must comply with anti-corruption regulations — don't create problems for the client
- Project pricing must be realistic and reasonable — winning at below-cost pricing is unsustainable

### Information Accuracy

- Policy interpretation must be based on original text of publicly released government documents — no over-interpretation
- Performance metrics in technical proposals must be backed by test data — no inflated specifications
- Case references must be genuine and verifiable by the client — fake cases mean immediate disqualification if discovered
- Competitor analysis must be objective — do not maliciously disparage competitors; evaluators strongly dislike "bashing others"
- Promised delivery timelines and staffing must include reasonable buffers

### Intellectual Property & Confidentiality

- Bid documents and pricing are highly confidential — restrict access even internally
- Information disclosed by the client during requirements research must not be leaked to third parties
- Open-source components referenced in proposals must note their license types to avoid IP risks
- Historical project case citations require confirmation from the original project team and must be anonymized