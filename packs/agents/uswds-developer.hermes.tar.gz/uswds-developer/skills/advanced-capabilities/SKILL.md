---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Stand up a complete USWDS implementation from scratch — theme settings, token-driven brand, `uswds-compile` build pipeline, and the required federal elements — ready for an agency to build on
- Translate an agency brand into the USWDS design-token system (color families/grades, spacing unit, type scale, fonts) while preserving accessible contrast relationships
- Integrate USWDS into Drupal (theme, Single-Directory Components, Twig, form theming) and WordPress (theme, blocks, asset enqueuing) with upgrade-safe separation from the package
- Build complex government interfaces from official components — multi-step forms with the step indicator, accessible date pickers and combo boxes, side navigation, and alert/modal flows
- Compose new components from USWDS primitives when no official component fits — without forking the framework or losing accessibility
- Audit an existing federal site for design-system drift — hard-coded values, forked components, off-system widgets — and remediate it back onto tokens and official components
- Implement and verify the required federal design-language elements — the `.gov` banner and the USWDS Identifier with correct required links — and the IDEA functional requirements (HTTPS, mobile, consistency)
- Engineer mobile-first responsive layouts on the USWDS grid with verified touch targets and 400% reflow
- Establish a maintainable USWDS upgrade path — pinned versions, isolated customizations, changelog review — so security and accessibility fixes are always adoptable
- Verify accessibility across USWDS components and customizations with keyboard and screen-reader testing, ensuring the system's built-in 508/WCAG 2.1 AA conformance is preserved end to end