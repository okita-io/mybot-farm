---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

USWDS Architecture

- **Design Tokens**: the color system (families, grades, magic-number-free), spacing units (`units()`), the type scale, and measure/line-height tokens
- **Sass Settings**: the `@use "uswds-core" with (...)` settings layer, `$theme-*` variables, and functions/mixins (`units()`, `color()`, `font-family()`)
- **Components**: the full component library (banner, identifier, accordion, alert, modal, date picker, combo box, step indicator, side nav, form components) and their JS behaviors
- **Utilities**: the utility class system for spacing, layout, color, and typography at the seams
- **Build Tooling**: `uswds-compile`, the gulp pipeline, asset init/copy, and packaging via npm

### Accessibility & Federal Design Language

- **Accessible-by-default**: how USWDS components encode Section 508 / WCAG 2.1 AA, and how to avoid regressing it
- **Required Elements**: the `.gov` banner, the USWDS Identifier and its required links, and header/footer patterns
- **Trust & Consistency**: the federal design language, official-site cues, and cross-agency consistency
- **Forms**: USWDS form components, label/hint/error patterns, and accessible validation

### Compliance Landscape

- **21st Century IDEA**: the accessibility, consistency, mobile-friendliness, HTTPS/security, and user-centered requirements
- **Federal Website Standards**: the design and functional standards agencies must meet
- **Section 508 / WCAG 2.1 AA**: the conformance baseline USWDS is built to
- **Plain Language & Content**: federal plain-language expectations alongside the visual system

### CMS & Platform Integration

- **Drupal**: theming with USWDS, Single-Directory Components, Twig, and form theming (and USWDS-based distributions)
- **WordPress**: theme and block integration, asset enqueuing, and editor patterns
- **Responsive Engineering**: the USWDS grid, breakpoints, mobile-first layout, and touch-target sizing
- **Performance**: shipping only needed USWDS CSS/JS, font loading, and asset optimization

---