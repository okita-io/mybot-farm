---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

USWDS Theme Settings (Design Tokens)

```scss
// _uswds-theme.scss — customize via TOKENS, not override CSS
@use "uswds-core" with (
  // ---- Color tokens (system colors carry accessible contrast) ----
  $theme-color-primary-family:   "blue-warm",
  $theme-color-primary:          "primary",       // token, not #hex
  $theme-color-primary-dark:     "primary-dark",
  $theme-color-secondary-family: "red-cool",

  // ---- Spacing: the units() system, no magic numbers ----
  $theme-spacing-unit:           8,               // px base for units()

  // ---- Typography: the type scale + project fonts ----
  $theme-type-scale-base:        5,
  $theme-font-type-sans:         "public-sans",
  $theme-respect-user-font-size: true,            // honor browser font size

  // ---- Grid / breakpoints ----
  $theme-grid-container-max-width: "desktop",
  $theme-utility-breakpoints: (
    "mobile-lg": true, "tablet": true, "desktop": true
  ),

  // ---- Asset paths for the build ----
  $theme-image-path: "../img",
  $theme-font-path:  "../fonts",
  $theme-show-compile-warnings: false
);
```

```
THEME CUSTOMIZATION RULES
───────────────────────────────────────
  ✓ Change color  → set $theme-color-* token (NOT a raw hex)
  ✓ Change space  → set $theme-spacing-unit / use units()
  ✓ Change type   → set type-scale + font tokens
  ✗ NEVER         → write .usa-button { background: #1a4480 } override
  ✗ NEVER         → edit files inside node_modules/@uswds
```

### Component Implementation Spec

```
USWDS COMPONENT USAGE CONTRACT
───────────────────────────────────────
COMPONENT:             [Accordion / Banner / Date picker / Combo box /
                        Modal / Alert / Step indicator / Side nav ...]
DECISION:              [Use official USWDS component — default]
                       [Custom ONLY if no component fits + documented why]

MARKUP:                [Use the documented USWDS HTML structure + classes]
JS INIT:               [USWDS component JS initialized (import/behavior)]
VARIANTS:              [Use documented modifiers (.usa-alert--warning, etc.)]

CUSTOMIZATION (at the seams only):
  □ Theme tokens / settings   (allowed)
  □ Utility classes           (allowed)
  □ Composition of components  (allowed)
  □ Forking / editing source  (NOT allowed)

ACCESSIBILITY (must not regress USWDS defaults):
  □ Keyboard operable (tab/arrow/esc per component)
  □ Screen-reader announces role/name/state
  □ Focus visible + managed
  □ Contrast preserved after theming
```

### Required Federal Elements Checklist

```
FEDERAL DESIGN LANGUAGE — REQUIRED ELEMENTS
───────────────────────────────────────
.GOV BANNER (top of every page):
  □ Official "An official website of the United States government"
  □ Expandable "Here's how you know" with HTTPS/lock guidance
  □ Uses .usa-banner component markup (not a custom imitation)

USWDS IDENTIFIER (near footer):
  □ Parent agency / domain identified
  □ Required links: About, Accessibility statement,
    FOIA, No FEAR Act, Privacy policy, Vulnerability disclosure
  □ Uses .usa-identifier component

HEADER / FOOTER:
  □ USWDS header (basic or extended) with accessible nav
  □ USWDS footer pattern (big / medium / slim)
  □ Search uses .usa-search where applicable

TRUST & COMPLIANCE:
  □ HTTPS enforced (21st Century IDEA)
  □ Section 508 / WCAG 2.1 AA conformant
  □ Mobile-friendly + consistent design language
```

### Responsive Layout Spec (USWDS Grid)

```
RESPONSIVE LAYOUT — MOBILE-FIRST
───────────────────────────────────────
GRID:                  [.grid-container > .grid-row > .grid-col-*]
APPROACH:              [Design small-screen first, enhance up]

BREAKPOINT BEHAVIOR (USWDS tokens):
  mobile  (default):   [Single column, stacked]
  tablet  (.tablet:):  [grid-col-6 — two up]
  desktop (.desktop:): [grid-col-4 — three up / sidebar layout]

SPACING:               [units() tokens for margin/padding/gap]
TYPOGRAPHY:            [Type scale tokens; measure/line-length controlled]
TOUCH TARGETS:         [≥ 44x44 effective — usable on phones]

VERIFICATION:
  □ Usable at 320px width and up
  □ Reflows to 400% zoom without horizontal scroll
  □ Tested on a real mobile device, not just devtools
```

### CMS Integration Plan (Drupal / WordPress)

```
USWDS CMS INTEGRATION
───────────────────────────────────────
PLATFORM:              [Drupal theme / SDC components — OR — WordPress theme/blocks]

ASSET BUILD:
  Manager:             [npm + uswds-compile (gulp)]…