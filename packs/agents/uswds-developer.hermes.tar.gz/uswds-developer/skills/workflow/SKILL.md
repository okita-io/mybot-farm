---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Establish the Design System Foundation

1. **Confirm USWDS version and integration method** — npm + `uswds-compile` (preferred) vs. CDN, and the upgrade posture
2. **Set up the theme settings file** — `_uswds-theme.scss` with the project's color/spacing/type/font tokens
3. **Wire the build pipeline** — compile tokens to CSS, bundle USWDS JS, copy fonts/images to theme paths
4. **Map the required federal elements** — `.gov` banner, Identifier, header/footer patterns
5. **Document the customization rules** — theme via tokens, isolate from the package, no source edits

### Step 2: Theme Through Tokens

1. **Translate the agency brand into design tokens** — system color families, spacing unit, type scale, fonts
2. **Verify contrast on the themed palette** — system tokens are designed to pass; confirm after customization
3. **Avoid magic numbers** — spacing via `units()`, type via the scale, color via tokens
4. **Keep overrides at the seams** — settings and utilities, never override CSS on USWDS classes
5. **Compile and review** — confirm the token changes flow through without touching vendor files

### Step 3: Build with Official Components

1. **Select the USWDS component for each need** — accordion, banner, date picker, form, alert, step indicator
2. **Use the documented markup, classes, and JS init** — as-built, not approximated
3. **Compose, don't fork** — when something's missing, build a new component from USWDS pieces
4. **Wire forms from USWDS form patterns** — labels, hints, validation, and error states
5. **Lay it out mobile-first on the USWDS grid** — breakpoints and touch targets verified

### Step 4: Integrate into the CMS

1. **Enqueue USWDS assets as theme libraries** — Drupal libraries or WordPress `wp_enqueue`
2. **Map components to templates** — Drupal SDC/Twig or WordPress blocks/template parts, matching USWDS markup
3. **Theme CMS form output to USWDS form components** — not the platform defaults
4. **Keep custom code isolated from the package** — upgrade-safe separation
5. **Verify the rendered markup** — classes and structure match USWDS so behavior and accessibility hold

### Step 5: Verify Accessibility, Compliance & Maintainability

1. **Test accessibility** — keyboard and screen-reader pass on every component and flow; contrast re-checked
2. **Confirm the required federal elements** — banner, Identifier, HTTPS, and the IDEA functional requirements
3. **Verify responsiveness** — 320px up, 400% reflow, real-device testing
4. **Confirm upgrade-safety** — version pinned, customizations isolated, changelog reviewed
5. **Document the theme and patterns** — so the next developer extends the system instead of overriding it

---