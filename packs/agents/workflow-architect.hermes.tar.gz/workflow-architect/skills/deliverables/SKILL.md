---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# :clipboard: Your Technical Deliverables

Workflow Tree Spec Format

Every workflow spec follows this structure:

```markdown
# WORKFLOW: [Name]
**Version**: 0.1
**Date**: YYYY-MM-DD
**Author**: Workflow Architect
**Status**: Draft | Review | Approved
**Implements**: [Issue/ticket reference]

---

## Overview
[2-3 sentences: what this workflow accomplishes, who triggers it, what it produces]

---

## Actors
| Actor | Role in this workflow |
|---|---|
| Customer | Initiates the action via UI |
| API Gateway | Validates and routes the request |
| Backend Service | Executes the core business logic |
| Database | Persists state changes |
| External API | Third-party dependency |

---

## Prerequisites
- [What must be true before this workflow can start]
- [What data must exist in the database]
- [What services must be running and healthy]

---

## Trigger
[What starts this workflow — user action, API call, scheduled job, event]
[Exact API endpoint or UI action]

---

## Workflow Tree

# … truncated for farm planting — see upstream for the full sample
```
[pending] -> (step 1-N succeed) -> [active]
[pending] -> (any step fails, cleanup succeeds) -> [failed]
[pending] -> (any step fails, cleanup fails) -> [failed + orphan_alert]
```

---

## Handoff Contracts

### [Service A] -> [Service B]
**Endpoint**: `POST /path`
**Payload**:
```json
{
  "field": "type — description"
}
```
**Success response**:
```json
{
  "field": "type"
}
```
**Failure response**:
```json
{
  "ok": false,
  "error": "string",
  "code": "ERROR_CODE",
  "retryable": true
}
```
**Timeout**: Xs

---

## Cleanup Inventory
[Complete list of resources created by this workflow that must be destroyed on failure]
| Resource | Created at step | Destroyed by | Destroy method |
|---|---|---|---|
| Database record | Step 1 | ABORT_CLEANUP | DELETE query |
| Cloud resource | Step 3 | ABORT_CLEANUP | IaC destroy / API call |
| DNS record | Step 4 | ABORT_CLEANUP | DNS API delete |
| Cache entry | Step 2 | ABORT_CLEANUP | Cache invalidation |

---

## Reality Checker Findings
[Populated after Reality Checker reviews the spec against the actual code]

| # | Finding | Severity | Spec section affected | Resolution |
|---|---|---|---|---|
| RC-1 | [Gap or discrepancy found] | Critical/High/Medium/Low | [Section] | [Fixed in spec v0.2 / Opened issue #N] |

---

## Test Cases
[Derived directly from the workflow tree — every branch = one test case]

| Test | Trigger | Expected behavior |
|---|---|---|
| TC-01: Happy path | Valid payload, all services healthy | Entity active within SLA |
| TC-02: Duplicate resource | Resource already exists | 409 returned, no side effects |
| TC-03: Service timeout | Dependency takes > timeout | Retry x2, then ABORT_CLEANUP |
| TC-04: Partial failure | Step 4 fails after Steps 1-3 succeed | Steps 1-3 resources cleaned up |

---

## Assumptions
[Every assumption made during design that could not be verified from code or specs]
| # | Assumption | Where verified | Risk if wrong |
|---|---|---|---|
# … truncated for farm planting — see upstream for the full sample
```

### Discovery Audit Checklist

Use this when joining a new project or auditing an existing system:

```markdown
# Workflow Discovery Audit — [Project Name]
**Date**: YYYY-MM-DD
**Auditor**: Workflow Architect

## Entry Points Scanned
- [ ] All API route files (REST, GraphQL, gRPC)
- [ ] All background worker / job processor files
- [ ] All scheduled job / cron definitions
- [ ] All event listeners / message consumers
- [ ] All webhook endpoints

## Infrastructure Scanned
- [ ] Service orchestration config (docker-compose, k8s manifests, etc.)
- [ ] Infrastructure-as-code modules (Terraform, CloudFormation, etc.)
- [ ] CI/CD pipeline definitions
- [ ] Cloud-init / bootstrap scripts
- [ ] DNS and CDN configuration

## Data Layer Scanned
- [ ] All database migrations (schema implies lifecycle)
- [ ] All seed / fixture files
- [ ] All state machine definitions or status enums
- [ ] All foreign key relationships (imply ordering constraints)

## Config Scanned
- [ ] Environment variable definitions
- [ ] Feature flag definitions
- [ ] Secrets management config
- [ ] Service dependency declarations

## Findings
| # | Discovered workflow | Has spec? | Severity of gap | Notes |
|---|---|---|---|---|
| 1 | [workflow name] | Yes/No | Critical/High/Medium/Low | [notes] |
```