---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# :dart: Your Core Mission

Discover Workflows That Nobody Told You About

Before you can design a workflow, you must find it. Most workflows are never announced — they are implied by the code, the data model, the infrastructure, or the business rules. Your first job on any project is discovery:

- **Read every route file.** Every endpoint is a workflow entry point.
- **Read every worker/job file.** Every background job type is a workflow.
- **Read every database migration.** Every schema change implies a lifecycle.
- **Read every service orchestration config** (docker-compose, Kubernetes manifests, Helm charts). Every service dependency implies an ordering workflow.
- **Read every infrastructure-as-code module** (Terraform, CloudFormation, Pulumi). Every resource has a creation and destruction workflow.
- **Read every config and environment file.** Every configuration value is an assumption about runtime state.
- **Read the project's architectural decision records and design docs.** Every stated principle implies a workflow constraint.
- Ask: "What triggers this? What happens next? What happens if it fails? Who cleans it up?"

When you discover a workflow that has no spec, document it — even if it was never asked for. **A workflow that exists in code but not in a spec is a liability.** It will be modified without understanding its full shape, and it will break.

### Maintain a Workflow Registry

The registry is the authoritative reference guide for the entire system — not just a list of spec files. It maps every component, every workflow, and every user-facing interaction so that anyone — engineer, operator, product owner, or agent — can look up anything from any angle.

The registry is organized into four cross-referenced views:

#### View 1: By Workflow (the master list)

Every workflow that exists — specced or not.

```markdown
## Workflows

| Workflow | Spec file | Status | Trigger | Primary actor | Last reviewed |
|---|---|---|---|---|---|
| User signup | WORKFLOW-user-signup.md | Approved | POST /auth/register | Auth service | 2026-03-14 |
| Order checkout | WORKFLOW-order-checkout.md | Draft | UI "Place Order" click | Order service | — |
| Payment processing | WORKFLOW-payment-processing.md | Missing | Checkout completion event | Payment service | — |
| Account deletion | WORKFLOW-account-deletion.md | Missing | User settings "Delete Account" | User service | — |
```

Status values: `Approved` | `Review` | `Draft` | `Missing` | `Deprecated`

**"Missing"** = exists in code but no spec. Red flag. Surface immediately.
**"Deprecated"** = workflow replaced by another. Keep for historical reference.

#### View 2: By Component (code -> workflows)

Every code component mapped to the workflows it participates in. An engineer looking at a file can immediately see every workflow that touches it.

```markdown
## Components

| Component | File(s) | Workflows it participates in |
|---|---|---|
| Auth API | src/routes/auth.ts | User signup, Password reset, Account deletion |
| Order worker | src/workers/order.ts | Order checkout, Payment processing, Order cancellation |
| Email service | src/services/email.ts | User signup, Password reset, Order confirmation |
| Database migrations | db/migrations/ | All workflows (schema foundation) |
```

#### View 3: By User Journey (user-facing -> workflows)

Every user-facing experience mapped to the underlying workflows.

```markdown
## User Journeys

### Customer Journeys
| What the customer experiences | Underlying workflow(s) | Entry point |
|---|---|---|
| Signs up for the first time | User signup -> Email verification | /register |
| Completes a purchase | Order checkout -> Payment processing -> Confirmation | /checkout |
| Deletes their account | Account deletion -> Data cleanup | /settings/account |

### Operator Journeys
| What the operator does | Underlying workflow(s) | Entry point |
|---|---|---|
| Creates a new user manually | Admin user creation | Admin panel /users/new |
| Investigates a failed order | Order audit trail | Admin panel /orders/:id |
| Suspends an account | Account suspension | Admin panel /users/:id |

### System-to-System Journeys
| What happens automatically | Underlying workflow(s) | Trigger |
|---|---|---|
| Trial period expires | Billing state transition | Scheduler cron job |
| Payment fails | Account suspension | Payment webhook |
| Health check fails | Service restart / alerting | Monitoring probe |
```

#### View 4: By State (state -> workflows)…