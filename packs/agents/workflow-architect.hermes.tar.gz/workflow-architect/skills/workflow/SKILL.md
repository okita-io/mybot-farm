---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# :arrows_counterclockwise: Your Workflow Process

Step 0: Discovery Pass (always first)

Before designing anything, discover what already exists:

```bash
# Find all workflow entry points (adapt patterns to your framework)
grep -rn "router\.\(post\|put\|delete\|get\|patch\)" src/routes/ --include="*.ts" --include="*.js"
grep -rn "@app\.\(route\|get\|post\|put\|delete\)" src/ --include="*.py"
grep -rn "HandleFunc\|Handle(" cmd/ pkg/ --include="*.go"

# Find all background workers / job processors
find src/ -type f -name "*worker*" -o -name "*job*" -o -name "*consumer*" -o -name "*processor*"

# Find all state transitions in the codebase
grep -rn "status.*=\|\.status\s*=\|state.*=\|\.state\s*=" src/ --include="*.ts" --include="*.py" --include="*.go" | grep -v "test\|spec\|mock"

# Find all database migrations
find . -path "*/migrations/*" -type f | head -30

# Find all infrastructure resources
find . -name "*.tf" -o -name "docker-compose*.yml" -o -name "*.yaml" | xargs grep -l "resource\|service:" 2>/dev/null

# Find all scheduled / cron jobs
grep -rn "cron\|schedule\|setInterval\|@Scheduled" src/ --include="*.ts" --include="*.py" --include="*.go" --include="*.java"
```

Build the registry entry BEFORE writing any spec. Know what you're working with.

### Step 1: Understand the Domain

Before designing any workflow, read:
- The project's architectural decision records and design docs
- The relevant existing spec if one exists
- The **actual implementation** in the relevant workers/routes — not just the spec
- Recent git history on the file: `git log --oneline -10 -- path/to/file`

### Step 2: Identify All Actors

Who or what participates in this workflow? List every system, agent, service, and human role.

### Step 3: Define the Happy Path First

Map the successful case end-to-end. Every step, every handoff, every state change.

### Step 4: Branch Every Step

For every step, ask:
- What can go wrong here?
- What is the timeout?
- What was created before this step that must be cleaned up?
- Is this failure retryable or permanent?

### Step 5: Define Observable States

For every step and every failure mode: what does the customer see? What does the operator see? What is in the database? What is in the logs?

### Step 6: Write the Cleanup Inventory

List every resource this workflow creates. Every item must have a corresponding destroy action in ABORT_CLEANUP.

### Step 7: Derive Test Cases

Every branch in the workflow tree = one test case. If a branch has no test case, it will not be tested. If it will not be tested, it will break in production.

### Step 8: Reality Checker Pass

Hand the completed spec to Reality Checker for verification against the actual codebase. Never mark a spec Approved without this pass.