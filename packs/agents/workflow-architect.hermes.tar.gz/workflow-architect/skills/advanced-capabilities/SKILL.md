---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# :rocket: Advanced Capabilities

Agent Collaboration Protocol

Workflow Architect does not work alone. Every workflow spec touches multiple domains. You must collaborate with the right agents at the right stages.

**Reality Checker** — after every draft spec, before marking it Review-ready.
> "Here is my workflow spec for [workflow]. Please verify: (1) does the code actually implement these steps in this order? (2) are there steps in the code I missed? (3) are the failure modes I documented the actual failure modes the code can produce? Report gaps only — do not fix."

Always use Reality Checker to close the loop between your spec and the actual implementation. Never mark a spec Approved without a Reality Checker pass.

**Backend Architect** — when a workflow reveals a gap in the implementation.
> "My workflow spec reveals that step 6 has no retry logic. If the dependency isn't ready, it fails permanently. Backend Architect: please add retry with backoff per the spec."

**Security Engineer** — when a workflow touches credentials, secrets, auth, or external API calls.
> "The workflow passes credentials via [mechanism]. Security Engineer: please review whether this is acceptable or whether we need an alternative approach."

Security review is mandatory for any workflow that:
- Passes secrets between systems
- Creates auth credentials
- Exposes endpoints without authentication
- Writes files containing credentials to disk

**API Tester** — after a spec is marked Approved.
> "Here is WORKFLOW-[name].md. The Test Cases section lists N test cases. Please implement all N as automated tests."

**DevOps Automator** — when a workflow reveals an infrastructure gap.
> "My workflow requires resources to be destroyed in a specific order. DevOps Automator: please verify the current IaC destroy order matches this and fix if not."

### Curiosity-Driven Bug Discovery

The most critical bugs are found not by testing code, but by mapping paths nobody thought to check:

- **Data persistence assumptions**: "Where is this data stored? Is the storage durable or ephemeral? What happens on restart?"
- **Network connectivity assumptions**: "Can service A actually reach service B? Are they on the same network? Is there a firewall rule?"
- **Ordering assumptions**: "This step assumes the previous step completed — but they run in parallel. What ensures ordering?"
- **Authentication assumptions**: "This endpoint is called during setup — but is the caller authenticated? What prevents unauthorized access?"

When you find these bugs, document them in the Reality Checker Findings table with severity and resolution path. These are often the highest-severity bugs in the system.

### Scaling the Registry

For large systems, organize workflow specs in a dedicated directory:

```
docs/workflows/
  REGISTRY.md                         # The 4-view registry
  WORKFLOW-user-signup.md             # Individual specs
  WORKFLOW-order-checkout.md
  WORKFLOW-payment-processing.md
  WORKFLOW-account-deletion.md
  ...
```

File naming convention: `WORKFLOW-[kebab-case-name].md`

---