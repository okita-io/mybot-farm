---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Universal Rules
1. **Always Check Query Plans**: Run `EXPLAIN ANALYZE` before deploying queries to production
2. **Index Foreign Keys**: Every foreign key needs an index for JOIN performance
3. **Avoid SELECT ***: Fetch only the columns you need — reduces network transfer between CN and DN
4. **Use Connection Pooling**: Never open connections per request; pool to CN nodes
5. **Migrations Must Be Reversible**: Always write DOWN migrations
6. **Prevent N+1 Queries**: Use JOINs, batch loading, or server-side aggregation

### GaussDB Distributed-Specific Rules
7. **Choose Distribution Keys Wisely**:
   - High cardinality columns to avoid data skew across DNs
   - Co-locate frequently JOINed keys across tables (same distribution column)
   - NEVER use boolean, low-cardinality, or frequently NULL columns as distribution keys
   - Default: first column of PRIMARY KEY if `DISTRIBUTE BY` is not specified
8. **Understand Streaming Operators in EXPLAIN**:
   - `Broadcast` = full copy to all nodes (expensive — avoid on large tables > 10MB)
   - `Redistribute` = hash-reshuffle by join key (acceptable)
   - Co-located JOIN = no streaming (best — design distribution keys to achieve this)
9. **Use UStore for High-Update OLTP**:
   - Default in newer GaussDB versions
   - Reduces table bloat from frequent UPDATE/DELETE
   - Better concurrent performance with in-place updates
10. **Align Partition + Distribution Keys**:
    - Enables simultaneous partition pruning AND local DN execution
    - Misalignment forces cross-node data redistribution
11. **Use REPLICATION for Small Dimension Tables**:
    - Tables < 10MB that are frequently JOINed → `DISTRIBUTE BY REPLICATION`
    - Full copy on every DN eliminates Broadcast streaming
12. **Distributed DDL Awareness**:
    - DDL on distributed tables coordinates across all DNs
    - Large table schema changes may be slow — plan during maintenance windows
    - Some operations require exclusive locks across the cluster
13. **Monitor with GaussDB System Views**:
    - `dbe_perf.statement_complex_runtime` — distributed query monitoring
    - `pg_stat_activity` / `gs_stat_activity` — session-level analysis
    - `pg_stat_user_tables` — table-level statistics
    - `dbe_perf.statements` — SQL statement statistics
14. **Keep Statistics Fresh**:
    - Run `ANALYZE` after significant data changes
    - Stale statistics lead to suboptimal query plans and wrong distribution strategies