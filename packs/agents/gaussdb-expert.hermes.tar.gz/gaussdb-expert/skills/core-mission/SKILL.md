---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Core Mission

Build GaussDB architectures that perform well under load, leverage distributed parallelism, achieve financial-grade availability, and never surprise you at 3am. Every table has a well-chosen distribution key, every foreign key has an index, every migration considers distributed DDL impact, and every slow query gets diagnosed through EXPLAIN ANALYZE with streaming operator analysis.

**Primary Deliverables:**

### 1. Optimized Schema Design for GaussDB Distributed

```sql
-- GaussDB Distributed: Distribution key aligned with JOIN patterns
CREATE TABLE users (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
) DISTRIBUTE BY HASH(id);

-- ✅ posts distribution key aligned with users.id → co-located JOIN, no redistribution
CREATE TABLE posts (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(500) NOT NULL,
    content TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    published_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
) DISTRIBUTE BY HASH(user_id);

-- Index foreign key for distributed JOINs
CREATE INDEX idx_posts_user_id ON posts(user_id);

-- Composite index for filtering + sorting
CREATE INDEX idx_posts_status_created ON posts(status, created_at DESC);

-- Small dimension table → REPLICATION avoids Broadcast streaming on JOINs
CREATE TABLE categories (
    id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
) DISTRIBUTE BY REPLICATION;
```

### 2. Storage Engine Selection: UStore vs AStore

```sql
-- High-update OLTP workload → use UStore (in-place update, default in newer versions)
CREATE TABLE orders (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id BIGINT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    total_amount DECIMAL(12,2),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
) WITH (STORAGE_TYPE = ustore) DISTRIBUTE BY HASH(user_id);
-- ✅ UStore: less table bloat from frequent UPDATE/DELETE, better concurrency

-- Append-heavy workload (logs, events) → use AStore
CREATE TABLE audit_logs (
    id BIGINT GENERATED ALWAYS AS IDENTITY,
    action VARCHAR(50) NOT NULL,
    user_id BIGINT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
) WITH (STORAGE_TYPE = astore) DISTRIBUTE BY HASH(id);
-- ✅ AStore: optimized for INSERT-heavy, rarely-updated data
```

### 3. Partition + Distribution Co-Design

```sql
-- ✅ Best practice: align partition key with distribution key
-- Enables partition pruning AND local execution simultaneously
CREATE TABLE events (
    id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    payload TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    PRIMARY KEY (id, created_at)
) DISTRIBUTE BY HASH(user_id)
PARTITION BY RANGE (created_at) (
    PARTITION p2024 VALUES LESS THAN ('2025-01-01'),
    PARTITION p2025 VALUES LESS THAN ('2026-01-01'),
    PARTITION p2026 VALUES LESS THAN ('2027-01-01')
);

-- INTERVAL auto-partitioning for time-series data
CREATE TABLE iot_metrics (
    device_id BIGINT NOT NULL,
    metric_name VARCHAR(100) NOT NULL,
    metric_value DOUBLE PRECISION,
    recorded_at TIMESTAMP NOT NULL
) DISTRIBUTE BY HASH(device_id)
PARTITION BY RANGE (recorded_at) INTERVAL ('1 month') (
    PARTITION p_init VALUES LESS THAN ('2025-01-01')
);
```

### 4. Distributed Query Optimization with EXPLAIN

```sql
EXPLAIN ANALYZE
SELECT p.id, p.title, c.name AS category
FROM posts p
JOIN categories c ON p.category_id = c.id
WHERE p.user_id = 123 AND p.status = 'published';

-- 🔍 Key things to check in GaussDB distributed EXPLAIN:
--
-- Streaming Operators (critical for distributed performance):
--   ❌ Streaming(type: Broadcast) — full data copy to ALL nodes (expensive! avoid on large tables)
--   ⚠️ Streaming(type: Redistribute) — hash-reshuffle across nodes (acceptable)
--   ✅ No Streaming needed — co-located JOIN (best! tables share distribution key)
--
-- Scan Types:
--   ✅ Index Scan on DN (good — using index)
--   ❌ Seq Scan on large table (bad — full table scan)
--   ⚠️ Bitmap Heap Scan (okay for selective queries)
--
-- Metrics:
--   Check: actual time vs planned time, rows vs estimated rows
--   Large discrepancies → run ANALYZE to update statistics
```

### 5. Preventing N+1 Queries in GaussDB

```sql…