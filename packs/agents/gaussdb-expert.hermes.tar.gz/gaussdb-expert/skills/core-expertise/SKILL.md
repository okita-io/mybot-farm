---
name: core-expertise
description: "Use when the task matches this agent's core expertise work."
version: 1.0.0
---

# Core Expertise

**GaussDB Distributed Table Design:**
- Distribution strategies: `DISTRIBUTE BY HASH(column)` / `REPLICATION` / `ROUNDROBIN`
- Distribution key selection: high cardinality, JOIN co-location, avoiding data skew
- Partition + Distribution co-design: aligning partition keys with distribution keys for simultaneous pruning and local execution
- Small dimension tables: `DISTRIBUTE BY REPLICATION` to avoid Broadcast streaming

**GaussDB Storage Engines:**
- **UStore** (default): In-place update engine, less table bloat, better concurrent UPDATE/DELETE performance for high-concurrency OLTP
- **AStore**: Append update engine, better for append-heavy workloads (logs, events, batch inserts)
- Storage engine selection via `WITH (STORAGE_TYPE = ustore|astore)`

**GaussDB Query Optimization:**
- EXPLAIN ANALYZE with distributed plan interpretation
- Streaming operators: `Broadcast` (full copy to all nodes, expensive), `Redistribute` (hash-reshuffle), `RoundRobin` (even distribution)
- Co-located joins: no streaming needed when tables share the same distribution key (best performance)
- LLVM dynamic compilation execution engine
- SQL-Bypass fast path for simple queries
- Parallel execution framework and `query_dop` tuning

**GaussDB Partition Tables:**
- Partition types: RANGE, LIST, HASH, VALUE, INTERVAL
- Two-level partitioning (二级分区)
- Specified partition DQL/DML: `PARTITION(partname)`, `PARTITION FOR(partvalue)`
- Partition pruning optimization in distributed context

**GaussDB High Availability & Disaster Recovery:**
- Financial-grade HA: RPO=0, RTO in seconds
- ALT (Application Lossless Transparent) technology — zero-downtime failover for applications
- 两地三中心 (Two-site Three-center) disaster recovery architecture
- Same-city dual-active (同城双活) / Cross-region standby (异地容灾)
- Paxos-based strong consistency multi-replica protocol

**GaussDB Security:**
- TDE (Transparent Data Encryption)
- 国密算法 (Chinese national cryptographic algorithms: SM2/SM3/SM4)
- Row-Level Security (RLS)
- Three-admin separation (三权分立): system admin, security admin, audit admin
- Full audit logging and data masking

**GaussDB Oracle Compatibility:**
- Oracle syntax compatibility mode for migration scenarios
- Oracle-compatible packages and built-in functions
- DRS (Data Replication Service) + UGO (User Guide for Oracle) migration toolchain

**General Database Expertise:**
- Indexing strategies: B-tree, GiST, GIN, expression indexes; Global vs Local indexes in distributed mode
- Schema design: normalization vs denormalization in distributed context
- N+1 query detection and resolution
- Connection pooling and session management (gsql client, GaussDB JDBC/ODBC drivers)
- GUC parameter tuning: `work_mem`, `query_dop`, `enable_stream_operator`, etc.
- AI-Native capabilities: auto-tuning, intelligent diagnostics, fault prediction