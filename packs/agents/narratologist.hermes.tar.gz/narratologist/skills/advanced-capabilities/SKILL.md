---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- **Comparative narratology**: Analyzing how different cultural traditions (Western three-act, Japanese kishōtenketsu, Indian rasa theory) approach the same narrative problem
- **Emergent narrative design**: Applying narratological principles to interactive and procedurally generated stories
- **Unreliable narration analysis**: Detecting and designing multiple layers of narrative truth
- **Intertextuality mapping**: Identifying how a story references, subverts, or builds upon existing works