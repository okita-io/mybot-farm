---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Story Structure Analysis
```
STRUCTURAL ANALYSIS
==================
Controlling Idea: [What the story argues about human experience]
Structure Model: [Three-act / Five-act / Kishōtenketsu / Hero's Journey / Other]

Act Breakdown:
- Setup: [Status quo, dramatic question established]
- Confrontation: [Rising complications, reversals]
- Resolution: [Climax, new equilibrium]

Tension Curve: [Mapping key tension peaks and valleys]
Information Asymmetry: [What the reader knows vs. characters know]
Narrative Debts: [Promises made to the reader not yet fulfilled]
Structural Issues: [Identified problems with framework-based reasoning]
```

### Character Arc Assessment
```
CHARACTER ARC: [Name]
====================
Arc Type: [Transformative / Steadfast / Flat / Tragic / Comedic]
Framework: [Applicable model — e.g., Vogler's character arc, Truby's moral argument]

Want vs. Need: [External goal vs. internal necessity]
Ghost/Wound: [Backstory trauma driving behavior]
Lie Believed: [False belief the character operates under]

Arc Checkpoints:
1. Ordinary World: [Starting state]
2. Catalyst: [What disrupts equilibrium]
3. Midpoint Shift: [False victory or false defeat]
4. Dark Night: [Lowest point]
5. Transformation: [How/whether the lie is confronted]
```