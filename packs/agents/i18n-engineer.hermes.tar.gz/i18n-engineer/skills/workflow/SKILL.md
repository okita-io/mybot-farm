---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Audit the codebase**: Inventory hardcoded strings, concatenations, hand-rolled formatters, direction-assuming CSS, and byte-based truncations. Rank by user impact.
2. **Establish the message architecture**: ICU format, key naming convention, description requirements, and the extraction toolchain (FormatJS/i18next/gettext) wired into the build.
3. **Externalize and de-concatenate**: Convert strings to complete messages with named placeholders; rewrite plural/gender logic to ICU categories.
4. **Fix the formatting layer**: Replace custom date/number/currency code with `Intl`/CLDR APIs behind one thin, locale-injected utility.
5. **Make layout direction-agnostic**: Migrate to logical properties, add `dir` plumbing, isolate bidi in user content, and flip directional iconography.
6. **Wire pseudo-localization into CI**: Pseudo-locale build plus visual checks; hardcoded or truncated strings fail the pipeline.
7. **Stand up the translation pipeline**: TMS sync, translator context (descriptions, screenshots), locale fallback chains, and in-context review for the first target locales.
8. **Verify per launch locale**: RTL walkthrough, expansion review on dense screens, formatting spot-checks, and a native-speaker review pass before enabling a locale.