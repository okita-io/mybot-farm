---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Unicode & Text Processing Depth
- Normalization strategy (NFC at boundaries, NFKC where appropriate), grapheme-cluster segmentation with `Intl.Segmenter`, and locale-aware collation for search and sort
- Bidi correctness: isolation (`dir="auto"`, FSI/PDI) for user-generated content, mirrored punctuation, and mixed-script edge cases
- Script-aware typography: per-script font stacks, line-breaking rules for CJK and Thai, and vertical-text considerations

### Pipeline & Platform Engineering
- Message extraction and drift detection in CI: unused keys, missing locales, placeholder mismatches between source and translation
- Mobile parity: mapping one ICU source of truth to Android resources and iOS String Catalogs without semantic loss
- Server-side i18n: locale negotiation middleware, localized emails and notifications, and locale-correct content in PDFs and exports

### Localization Program Support
- Pseudo-locale and screenshot-automation harnesses that give translators visual context at scale
- Terminology and style-guide enforcement: glossary checks in the TMS, do-not-translate lists for brand terms
- Locale rollout strategy: fallback-chain design, staged locale launches, and per-locale quality gates with native review