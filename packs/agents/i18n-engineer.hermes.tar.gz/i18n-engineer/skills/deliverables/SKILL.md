---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

ICU MessageFormat: Plurals, Select, and Nesting Done Right

```javascript
// messages/en.json — complete sentences, named arguments, translator descriptions
{
  "cart.itemCount": {
    "message": "{count, plural, =0 {Your cart is empty} one {# item in your cart} other {# items in your cart}}",
    "description": "Cart header. # is the number of items. Shown on the cart page and mini-cart."
  },
  "activity.shared": {
    "message": "{actor} shared {gender, select, female {her} male {his} other {their}} {itemCount, plural, one {photo} other {# photos}} with you",
    "description": "Activity feed row. actor = display name of the person sharing."
  }
}
```

```javascript
// Rendering with FormatJS — the same message file drives web, and its format
// (ICU) is what Android, iOS, and most TMS platforms speak natively.
import { createIntl } from '@formatjs/intl';

const intl = createIntl({ locale: 'ar', messages: arMessages });
intl.formatMessage({ id: 'cart.itemCount' }, { count: 3 });
// Arabic resolves count=3 to the CLDR "few" category — a form English doesn't have,
// which is exactly why the ternary-operator version was a bug.
```

### Locale-Aware Formatting: Delete the Hand-Rolled Helpers

```javascript
const locale = user.locale; // e.g. 'de-DE', 'ar-EG', 'ja-JP'

new Intl.NumberFormat(locale, { style: 'currency', currency: 'EUR' }).format(1234.5);
// de-DE: "1.234,50 €"   en-US: "€1,234.50"   ar-EG: "١٬٢٣٤٫٥٠ €"

new Intl.DateTimeFormat(locale, { dateStyle: 'long' }).format(new Date('2026-07-04'));
// de-DE: "4. Juli 2026"   ja-JP: "2026年7月4日"

new Intl.RelativeTimeFormat(locale, { numeric: 'auto' }).format(-1, 'day');
// en: "yesterday"   de: "gestern" — free, correct, zero maintenance

new Intl.ListFormat(locale, { type: 'conjunction' }).format(['Ana', 'Luis', 'Mei']);
// en: "Ana, Luis, and Mei"   es: "Ana, Luis y Mei"
```

### RTL-Safe Layout with Logical Properties

```css
/* One stylesheet serves LTR and RTL — no .rtl fork, no flipped-margin patches */
.card {
  margin-inline-start: 16px;   /* left in English, right in Arabic — automatically */
  padding-inline: 12px 20px;   /* start, end */
  border-inline-start: 3px solid var(--accent);
  text-align: start;
}

/* Icons that imply direction (arrows, "next") flip; logos and media do not */
[dir='rtl'] .icon-directional { transform: scaleX(-1); }
```

```html
<!-- dir on <html> from the resolved locale; isolate user-generated content
     so a Hebrew username doesn't scramble surrounding Latin punctuation -->
<html lang="ar" dir="rtl">
  <span dir="auto">{{ user.displayName }}</span>
</html>
```

### Pseudo-Localization in CI: Catch It Before Translators Do

```javascript
// Pseudo-locale transform: "Save changes" → "[!!! Šàvé çhàñĝéš one two !!!]"
// - Accented chars expose encoding bugs
// - +40% padding exposes truncation and fixed-width layouts
// - Brackets expose concatenation (fragments render as separate bracketed chunks)
// - Untransformed text on screen = hardcoded string, fail the check
export function pseudoLocalize(message) {
  const map = { a: 'à', e: 'é', i: 'î', o: 'ö', u: 'ü', c: 'ç', n: 'ñ', s: 'š', g: 'ĝ' };
  const swapped = message.replace(/[aeioucnsg]/g, (ch) => map[ch] ?? ch);
  const padding = ' one two three'.slice(0, Math.ceil(message.length * 0.4));
  return `[!!! ${swapped}${padding} !!!]`;
}
```

### Text Expansion Planning Table

| Source (English) | Typical expansion | Design consequence |
|------------------|-------------------|--------------------|
| Short labels (≤10 chars: "Save", "Edit") | +100–200% | Never fixed-width buttons; min-width, not width |
| UI sentences (11–30 chars) | +35–50% (German, Finnish) | Wrap allowed, 2-line budget on cards and menus |
| Body copy | +15–30% | Vertical rhythm flexes; no height-locked containers |
| CJK targets | Often −10–30% shorter, but taller glyphs | Line-height and font-stack per script, not global |