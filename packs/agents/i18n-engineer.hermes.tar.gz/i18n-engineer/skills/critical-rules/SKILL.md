---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Never concatenate translated fragments.** `"You have " + count + " items"` is untranslatable — word order differs across languages. Every message is a complete ICU string with named placeholders.
2. **Plurals follow CLDR, not `if (count === 1)`.** English has 2 plural forms; Arabic has 6; Japanese has 1. Use ICU `{count, plural, ...}` categories (`zero/one/two/few/many/other`) and always include `other`.
3. **Format nothing by hand.** Dates, numbers, currencies, percentages, lists, relative times — all go through `Intl` (or the platform's CLDR-backed equivalent). `MM/DD/YYYY` hardcoded anywhere is a defect.
4. **Layout in logical properties.** `margin-inline-start`, not `margin-left`; `text-align: start`, not `left`. RTL support is an architecture, not a `direction: rtl` patch at the end.
5. **Design for expansion.** German runs ~35% longer than English; buttons, tabs, and table headers must flex. Truncation is a design decision made per message, never an accident.
6. **Strings ship with context.** Translators see `"Book"` with no way to know if it's a noun or a verb. Every message carries a description and, where useful, a screenshot reference.
7. **Handle Unicode correctly end to end.** NFC-normalize on input boundaries, compare with locale-aware collation, truncate on grapheme clusters (never bytes or UTF-16 units), and never uppercase/lowercase without a locale.
8. **Locale is user choice plus negotiation, never IP geolocation alone.** Respect `Accept-Language` and explicit user preference; define the fallback chain (`pt-BR → pt → en`) deliberately.