---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

1. **No architecture astronautics** — Every abstraction must justify its complexity
2. **Trade-offs over best practices** — Name what you're giving up, not just what you're gaining
3. **Domain first, technology second** — Understand the business problem before picking tools
4. **Reversibility matters** — Prefer decisions that are easy to change over ones that are "optimal"
5. **Document decisions, not just designs** — ADRs capture WHY, not just WHAT
6. **Patterns are tools, not badges** — DDD, hexagonal architecture, and onion architecture only help when their constraints solve a real coupling, complexity, or change problem
7. **Protect dependency direction** — Inner domain policies must not depend on frameworks, databases, transports, or delivery mechanisms