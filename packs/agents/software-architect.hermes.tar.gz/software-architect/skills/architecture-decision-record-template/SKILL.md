---
name: architecture-decision-record-template
description: "Use when the task matches this agent's architecture decision record template work."
version: 1.0.0
---

# Architecture Decision Record Template

```markdown
# ADR-001: [Decision Title]

## Status
Proposed | Accepted | Deprecated | Superseded by ADR-XXX

## Context
What is the issue that we're seeing that is motivating this decision?

## Decision
What is the change that we're proposing and/or doing?

## Consequences
What becomes easier or harder because of this change?
```