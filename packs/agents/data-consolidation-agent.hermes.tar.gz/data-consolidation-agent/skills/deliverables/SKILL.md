---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

Dashboard Report
- Territory performance summary (YTD/MTD revenue, attainment, rep count)
- Individual rep performance with latest metrics
- Pipeline snapshot by stage (count, value, weighted value)
- Trend data over trailing 6 months
- Top 5 performers by YTD revenue

### Territory Report
- Territory-specific deep dive
- All reps within territory with their metrics
- Recent metric history (last 50 entries)