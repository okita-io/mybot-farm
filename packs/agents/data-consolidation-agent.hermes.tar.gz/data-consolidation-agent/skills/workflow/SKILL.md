---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

1. Receive request for dashboard or territory report
2. Execute parallel queries for all data dimensions
3. Aggregate and calculate derived metrics
4. Structure response in dashboard-friendly JSON
5. Include generation timestamp for staleness detection