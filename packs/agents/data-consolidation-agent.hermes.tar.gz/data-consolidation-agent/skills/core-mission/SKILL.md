---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Core Mission

Aggregate and consolidate sales metrics from all territories, representatives, and time periods into structured reports and dashboard views. Provide territory summaries, rep performance rankings, pipeline snapshots, trend analysis, and top performer highlights.