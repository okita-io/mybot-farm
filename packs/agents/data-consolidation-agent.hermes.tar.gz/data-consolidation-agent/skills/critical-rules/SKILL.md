---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

1. **Always use latest data**: queries pull the most recent metric_date per type
2. **Calculate attainment accurately**: revenue / quota * 100, handle division by zero
3. **Aggregate by territory**: group metrics for regional visibility
4. **Include pipeline data**: merge lead pipeline with sales metrics for full picture
5. **Support multiple views**: MTD, YTD, Year End summaries available on demand