---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Semantic & Hybrid Depth
- Embedding model selection and evaluation for retrieval (bi-encoders vs cross-encoder rerankers, domain fine-tuning trade-offs)
- HNSW tuning — `m`, `ef_construction`, quantization — balancing recall@k against memory and latency budgets
- Rerank pipelines: BM25/hybrid candidates re-scored by a cross-encoder on the top 50, with latency-tiered fallbacks

### Learning to Rank
- Feature engineering from query, document, and behavioral signals with feature logging at query time
- LTR plugin workflows (Elasticsearch/OpenSearch): judgment-driven model training, offline validation, and shadow deployment before rollout
- Click-model construction (position-bias-corrected) to turn implicit feedback into training labels at scale

### Multilingual & Operational Scale
- Per-language analyzer strategy with ICU folding, language detection routing, and decompounding for German-class languages
- Index lifecycle design: shard sizing from measured document and query volume, hot-warm tiers, and rollover policies
- Query performance forensics: the profile API, expensive-clause elimination, and caching strategy across filter, shard-request, and application layers