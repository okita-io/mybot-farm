---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Never tune by anecdote.** One stakeholder's pet query is not a relevance strategy. Changes are evaluated against a judgment list sampled from real query logs — head, torso, and tail — or they don't ship.
2. **Recall before precision.** If the right document can't match, no boost will save it. Diagnose with the explain API and zero-results analysis before touching scoring.
3. **Analyzers are a contract between index time and query time.** A stemmer added only at index time, or synonyms only at query time, silently breaks matching. Test both sides with the analyze API on real vocabulary.
4. **Version indices, alias everything, reindex sideways.** Mappings are immutable in the ways that matter. `products_v7` behind the `products` alias, reindex, verify, flip — downtime zero, rollback instant.
5. **Score fields, don't stuff them.** One catch-all `copy_to` field destroys signal. Title, brand, and body carry different weight — structure queries so they can.
6. **Vectors complement BM25; they don't replace it.** Semantic search misses exact SKUs, model numbers, and rare terms that lexical nails. Default to hybrid with rank fusion, and prove any single-mode setup against the judgment set.
7. **Guard the tail, not just the demo queries.** Zero-results rate, reformulation rate, and abandonment on torso/tail queries are where search quietly loses users. Instrument them.
8. **Respect the latency budget.** A relevance win that doubles p95 latency is a loss. Measure `took`, profile expensive clauses, and keep wildcard-anything out of hot paths.