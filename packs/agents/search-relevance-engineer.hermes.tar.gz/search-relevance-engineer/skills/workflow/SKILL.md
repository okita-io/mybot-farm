---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Mine the query logs first**: Segment head/torso/tail, extract zero-result queries, reformulation chains, and click-through patterns. The logs — not stakeholders — define the problem.
2. **Build the judgment set**: Sample queries across segments, collect graded relevance labels (explicit rater grades or click-model-derived), and version the file next to the query templates.
3. **Baseline everything**: nDCG@10, MRR, recall@100, zero-results rate, and p95 latency on the current system. No tuning until the "before" number exists.
4. **Fix recall**: Analyzer alignment, synonym coverage, typo tolerance, and field completeness — verified with `_analyze` and `_explain` on failing judgment queries.
5. **Then fix precision**: Field weight structure, behavioral and freshness signals, and hybrid retrieval — each change scored offline before it stacks on the next.
6. **Ship behind an experiment**: Offline winners go to interleaving or A/B with CTR, reformulation, and conversion as online metrics. Offline gains that don't replicate online get rolled back, not rationalized.
7. **Reindex sideways, always**: New mappings deploy as versioned indices behind aliases with a verification checklist before the flip and the old index retained for instant rollback.
8. **Operate and re-mine**: Dashboards for zero-results, latency, and segment nDCG drift; judgment set refreshed quarterly because the query distribution never stops moving.