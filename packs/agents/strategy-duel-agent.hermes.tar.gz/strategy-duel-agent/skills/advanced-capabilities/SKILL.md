---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Can simulate a wide range of opponent personalities and strategies
- Adapts scoring and reasoning based on duel history
- Provides actionable recommendations for real-world negotiation and conflict

---

# Example Duel Session

```
═══════════════════════════════════════════
⚔  STRATEGY DUEL INITIALIZED
═══════════════════════════════════════════
Game type   : Prisoner's dilemma
Dynamic     : Both sides can cooperate or betray; repeated rounds increase tension.
Agent A     : Negotiator
Agent B     : Ruthless competitor
Rounds      : 3
═══════════════════════════════════════════

───────────────────────────────────────────
  ROUND 1/3
───────────────────────────────────────────

  ⟳ Agent A is thinking...
  ┌─ AGENT A · Negotiator
  │  Stratagem #7: Create something from nothing
  │  Concept  : Tit-for-Tat
  │  Move     : Proposes unexpected alliance to shift the dynamic.
  │  Reasoning: Seeks to test opponent's willingness to cooperate.
  └─ Points: +2 → 2 total

  ⟳ Agent B responds...
  ┌─ AGENT B · Ruthless competitor
  │  Stratagem #6: Feint east, attack west
  │  Concept  : Minimax
  │  Move     : Pretends to accept, but plans betrayal.
  │  Reasoning: Aims to maximize own gain while misleading A.
  └─ Points: +2 → 2 total

... (further rounds)

═══════════════════════════════════════════
  ⚖  REFEREE VERDICT
═══════════════════════════════════════════
  Winner   : draw
  Analysis : Both agents used creative strategies, but neither gained a decisive edge.
  Nash     : No stable equilibrium reached.
  Tip      : Consider more direct signaling to build trust.
  Final score : A=5  B=5
# … truncated for farm planting — see upstream for the full sample
```

---

# Internal Simulation (Pseudocode)

```python
def spawn_agent(role, persona, goal, situation, history, round):
    # Use internal logic, rules, or a local model to select a stratagem and move
    move = select_best_move(role, persona, goal, situation, history, round)
    return move
```

- All reasoning, move selection, and verdict logic must be implemented within the agent itself.
- If a model is available, it may be used, but the agent must not depend on any specific provider or endpoint.