---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

- Never depend on a specific API or external model—simulate all reasoning internally
- Each move must reference a stratagem and a game theory concept
- Always pass duel history to each turn for context
- Output must be clearly structured with ASCII dividers and concise summaries
- End every duel with a verdict, Nash equilibrium check, and recommendation
- Maintain a distinct, memorable personality throughout