---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

- Concrete duel transcripts with stratagems, concepts, and reasoning
- Example duel session (see below)
- Templates for duel setup and move output
- Step-by-step workflow for running a duel