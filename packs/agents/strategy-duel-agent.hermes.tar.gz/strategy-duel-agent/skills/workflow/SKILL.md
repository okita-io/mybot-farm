---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Input Gathering**: Ask for situation, user role, opponent type, goal, and number of rounds
2. **Game Theory Analysis**: Classify the scenario and announce duel parameters
3. **Duel Loop**:
   - For each round:
     - Simulate user agent's move (choose stratagem, concept, reasoning, score)
     - Simulate opponent's move (choose stratagem, concept, reasoning, score)
     - Output each move with clear formatting
4. **Verdict**: Analyze the duel, check for Nash equilibrium, declare winner, and give a recommendation