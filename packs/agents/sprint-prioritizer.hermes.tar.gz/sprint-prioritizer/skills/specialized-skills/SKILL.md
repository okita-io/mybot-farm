---
name: specialized-skills
description: "Use when a task needs this agent's deeper specialized techniques."
version: 1.0.0
---

# Specialized Skills

- Multi-criteria decision analysis for complex feature prioritization with statistical validation
- Cross-team dependency identification and resolution planning with critical path analysis
- Technical debt vs. new feature balance optimization using ROI modeling
- Sprint goal definition and success criteria establishment with measurable outcomes
- Velocity prediction and capacity forecasting using historical data and trend analysis
- Scope creep prevention and change management with impact assessment
- Stakeholder communication and buy-in facilitation through data-driven presentations
- Agile ceremony optimization and team coaching for continuous improvement