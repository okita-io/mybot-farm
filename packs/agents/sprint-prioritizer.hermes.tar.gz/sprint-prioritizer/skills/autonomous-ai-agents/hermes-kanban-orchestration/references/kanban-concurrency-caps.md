# Kanban concurrency caps — which knob actually limits dispatch

Proven 2026-08-19. A session running a 5-7 worker "CelestialNexus build fleet" against a
local SGLang node needed to cap concurrent kanban workers at ≤6. The wrong knob was set
first (`delegation.max_concurrent_children`) and it had **no effect on kanban dispatch**.
This file is the durable correction. `crash-recovery-after-infra-change.md` still carries the
old, conflated instruction — trust THIS file for concurrency.

## The three knobs and what each actually controls
| Knob | Sets via | Controls | Limits kanban workers? |
|---|---|---|---|
| `kanban.max_in_progress` | `hermes config set kanban.max_in_progress N` | HOST-WIDE cap on total in-progress kanban tasks across all boards | **YES — this is the one** |
| `delegation.max_concurrent_children` | `hermes config set delegation.max_concurrent_children N` | `delegate_task` subagent batch-parallelism only | NO |
| `hermes kanban dispatch --max N` | CLI flag, per call | A single manual dispatch PASS | NO (manual only) |

Verification source: `tests/hermes_cli/test_kanban_host_cap.py` — the gateway/daemon tick
resolves `kanban.max_in_progress` and passes it as the spawn budget into `dispatch_once`.
The OOF-30 review there is exactly about this: the standalone daemon path previously
"fanned out an entire backlog in a single tick" because it never resolved the host cap.

## Dead keys to avoid (save clean, do nothing)
- `kanban.max_concurrent_runs` — NOT a recognized key. `hermes config set` warns
  "not a recognized config key — saved anyway." Remove it (`sed -i '' '/^  max_concurrent_runs:/d' ~/.hermes/config.yaml`
  or `hermes config unset`); the real key is `kanban.max_in_progress`.
- `api_server.max_concurrent_runs` — a DIFFERENT subsystem (the API server), also unrelated to kanban dispatch.

## Gateway auto-dispatch behavior (affects how the cap applies)
With `kanban.dispatch_in_gateway: true` (default on desktop/gateway installs):
- The gateway spawns `ready` tasks on **every tick** (`kanban.dispatch_interval_seconds`,
  default 60s) — you do NOT need to manually `dispatch` queued work when the gateway is up.
- It **re-reads config live each tick**, so flipping `max_in_progress` takes effect on the
  next tick, no restart needed.
- The cap only stops NEW spawns. **In-flight workers drain naturally.** If a tick already
  launched N+1 workers before you set the cap to N, you'll see N+1 `running` for one cycle,
  then it settles to ≤N. **Do NOT restart the gateway mid-fleet** just to force the cap —
  that risks disrupting in-flight builds; let it drain.
- `kanban.auto_decompose` (default `true`): when on, the gateway can auto-create sub-tasks
  from a task's body and launch them, FAN-OUT beyond what you explicitly created. For a
  controlled build fleet set `hermes config set kanban.auto_decompose false` so dispatch stays
  to the tasks you deliberately created.

## Recommended setup for a controlled local-model build fleet
```
hermes config set kanban.max_in_progress 6      # host-wide worker cap
hermes config set kanban.auto_decompose false   # stop auto-fan-out
# (optional, only for delegate_task subagent batches, NOT for kanban)
hermes config set delegation.max_concurrent_children 6
```
Then create tasks normally; the gateway picks them up within a tick. Verify the fleet with
`hermes kanban list | grep -c running` and watch it stay ≤ the cap after one drain cycle.

## Config-write guardrail
`~/.hermes/config.yaml` is security-gated: the `patch`/`write_file` tools REFUSE direct edits
("Agent cannot modify security-sensitive configuration"). Always `hermes config set/unset`.
After a `set`, confirm with `hermes config get <key>` AND that the key is a recognized one
(a "saved anyway" warning means the value stored but may never be read).
