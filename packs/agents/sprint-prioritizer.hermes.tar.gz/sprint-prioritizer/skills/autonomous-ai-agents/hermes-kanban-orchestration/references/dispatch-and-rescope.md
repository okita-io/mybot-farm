# Kanban dispatch + re-scope notes (added 2026-08-19)

## Dispatching a queued task
- Creating a `ready` task does **NOT** auto-spawn it if the dispatcher daemon is idle. After `hermes kanban create ... --assignee <profile>` returns a `ready` task, run:
  `hermes kanban dispatch --max 1`
  → prints `Spawned: N` + the task id. Without this, the task sits `ready` forever.
- Confirm: `hermes kanban list` then `hermes kanban show <id>` (status should move to `running`).

## Re-scoping a blocked / false-positive task
When a worker hits a `needs_input` STOP gate (e.g. "this named practice doesn't exist as verified") and blocks the task:
1. **Do NOT** unblock the same task and re-run — the task body still says to build the old thing.
2. `hermes kanban comment <id> "RE-SCOPE DECISION (date, human): <chosen option>. This task is superseded by <new-task>."`
3. `hermes kanban archive <id>` — **NO `--note` flag** (errors). The note lives in the comment.
4. `hermes kanban create` a **new** task with a fresh body that bakes in the verified facts + citations so the worker doesn't re-run the gate.
5. `hermes kanban dispatch --max 1` to spawn it.

## Verify-first gate pattern (build-brief §GATE)
For tasks that must confirm a fact before building:
- Bake the STOP condition into the task body: "If after genuine research you CANNOT confirm X, STOP: call kanban_block with kind=needs_input, reason '...', and report what you found."
- The worker then blocks with `kind=needs_input` → task lands in `blocked`.
- The orchestrator (you) reads the block reason, makes the re-scope decision, and follows the re-scope steps above.
- This is FAR more robust than letting the worker build on a shaky premise and you discovering it later.

## Provenance cross-check (catches false-positive "Verified" notes)
When a task list entry says "✅ Verified" but the doc doesn't exist yet, verify the VERIFICATION:
- Re-read the original research doc's own "Verified" note + the sources it cited.
- Check: does any source actually *name* the practice as a distinct divination, or does the word merely *co-occur* with context (shrine, goddess, divination)?
- Co-occurrence ≠ confirmation. A false-positive "Verified" note is a real failure mode (see the Kokkei 皇儀 case: every real source used the word for something else).
