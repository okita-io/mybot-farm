# Recovering crashed / auto-blocked workers after an infra change

Proven 2026-08-19: a model/endpoint migration (LM Studio :1234 → SGLang :8888) killed four
celestial-agent kanban workers; each hit the default `failure_limit` of 2 and auto-blocked
with diagnostic `Agent crash x2: pid N not alive`.

## Symptoms
- `hermes kanban list` shows `⊘ blocked` tasks that were `running` before the migration.
- `hermes kanban show <id>` Diagnostics: `Agent crash x2: ... consecutive_failures=2 |
  most_recent_outcome=crashed | failure_limit=2`.

## Root-cause pattern (most common)
The assignee profile's `model.base_url` / model id points at the OLD, now-dead endpoint,
or the new endpoint reports a smaller context window than Hermes' 64K minimum.
The crash log tells the real story:
- `hermes kanban log <id> | tail -30` — endpoint URL + error at the tail:
  - `applyPromptTemplate request returned 500` / `connect ... refused` → dead endpoint
  - `context window of 8,192 tokens, below the minimum 64,000` → endpoint reports a small
    n_ctx; fix via `model.context_length` in the profile config OR load with more context
  - `Model qwen/qwen3.8-27b does not exist` → model id drifted (SGLang uses bare ids)
- NOTE: `hermes kanban tail <id>` can HANG for minutes; use `log`, not `tail`.

## Recovery recipe
1. `hermes kanban list` — collect the blocked task ids.
2. `hermes kanban show <id>` — confirm the diagnostic.
3. `hermes kanban log <id> | tail -30` — capture the actual API error.
4. Live-endpoint smoke test before re-dispatching anything:
   - `curl -s <base_url>/v1/models` (expect 200 + expected model id + `max_model_len`)
   - 20-token chat completion: `curl -s <base_url>/v1/chat/completions -d '{"model":"<id>","messages":[{"role":"user","content":"Reply with exactly: READY"}],"max_tokens":20}'`
   - Verify the assignee profile's config matches: `python3 -c "import yaml; print(yaml.safe_load(open('/Users/<u>/.hermes/profiles/<profile>/config.yaml')).get('model'))"`
5. `hermes kanban unblock <id1> <id2> ... --reason "root cause fixed: <endpoint/model now live, smoke-tested>"` — batch all ids in ONE call.
6. `hermes kanban dispatch --dry-run --max N` → confirm exact spawn set → `hermes kanban dispatch --max N`.
7. `sleep 20; hermes kanban list` — every recovered task must be `● running`.

## Concurrency cap (shared local model)
When the LAN node serves the agent's own model (the node IS the brain), concurrent kanban
workers share its session limit. Cap:
- `hermes config set delegation.max_concurrent_children <N>`
- `hermes kanban dispatch --max <N>` for the current pass.
Config files (`~/.hermes/config.yaml`) are security-gated: the `patch`/`write_file` tools
REFUSE direct writes ("Agent cannot modify security-sensitive configuration") — always use
`hermes config set`. Watch for "not a recognized config key — saved anyway" warnings: verify
with `hermes config get` and check nesting before trusting the key is read.

## Anti-patterns
- Do NOT `hermes kanban complete` a crashed task just to clear the board — the work didn't land.
- Do NOT re-dispatch without re-verifying the endpoint: a second crash re-blocks instantly
  (failure_limit=2 means one miss after unblock and you're back where you started).
