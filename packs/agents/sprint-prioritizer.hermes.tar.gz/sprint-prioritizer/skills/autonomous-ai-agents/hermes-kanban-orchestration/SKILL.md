---
name: hermes-kanban-orchestration
description: "Manage Hermes kanban tasks: create, gate, queue, close."
version: 1.0.0
author: hermes
license: MIT
metadata:
  hermes:
    tags: [hermes, kanban, orchestration, multi-agent]
    related_skills: [lmstudio-local-provider]
---

# Hermes Kanban Orchestration

Drive the durable SQLite task board shared across Hermes profiles. Use this when you are
assigning work to other agent profiles (e.g. a `celestial-agent` building docs), sequencing
tasks that must not run in parallel, or diagnosing why a worker started / stopped / did
nothing.

## When to use
- Creating a task for another profile and force-loading a skill onto it.
- Queuing a follow-up task that must wait for a prerequisite doc/task to finish.
- Closing out a task a worker left `blocked` because it crashed before the terminal call.
- Figuring out what a "running" background agent has actually been doing (stdout hidden).

## The state machine (this is the part that bites)
```
triage → todo → scheduled → ready → running → done | archived
                          ↘ blocked / review
```
Key non-obvious facts (verified in `hermes_cli/kanban_db.py`):
- **`scheduled` is a deliberate NON-dispatchable holding state.** "scheduled tasks are
  intentionally not dispatchable; an external cron … promotes it." This is the right place
  to park a task you want queued but NOT started right now (e.g. wait for a sibling doc).
- **`block` only accepts tasks in `ready` or `running`.** You CANNOT `block` a `scheduled`
  task ("cannot block / not in running/ready"). Don't waste calls trying.
- **`block --kind dependency`** does not sit in `blocked`; it routes to **`todo`** so the
  parent-gating / `recompute_ready` machinery auto-promotes it once its parents finish.
  `--kind needs_input|capability` routes to `blocked` (human). Repeated re-blocks trip a
  loop breaker and escalate to `triage`.
- The dispatcher auto-promotes `scheduled`/`todo` → `ready` when gating clears.

## Canonical commands
- **Create** (title is POSITIONAL, not `--title`):
  `hermes kanban create "Title" --assignee <profile> --skill <skill> --created-by default --body "$BODY" --initial-status {blocked,running} --idempotency-key <key> --json`
  - Read `--body` from a file: `BODY=$(cat /path/body.txt)` — **do NOT inline a large body**
    (oversized inline payloads get hard-blocked by the command parser; write to a file first).
  - `--idempotency-key` dedupes: returns the existing task id instead of creating a clone.
  - `--initial-status blocked` = create but don't let it run yet.
- **Complete** (NO `--json` here — unlike create):
  `hermes kanban complete <id> --result "one-line outcome"`
- **Schedule / hold**: `hermes kanban schedule <id> "reason note"`
- **Promote** (force start now): `hermes kanban promote <id> "reason"`
- **Unblock**: `hermes kanban unblock <id> --reason "..."`
- **Runs**: `hermes kanban runs <id> --json` (bare `hermes kanban runs` with NO id ERRORS).
- **Show / list / assignees**: `hermes kanban show <id>` · `hermes kanban list` · `hermes kanban assignees`
- **Comment** (how you attach a gate): `hermes kanban comment <id> "GATE — ..."`

## The gate-comment pattern (make a queued task self-park)
To queue task B that must not start until prerequisite A (a sibling doc/task) is done, and you
want B to hold ITSELF rather than run in parallel and clobber the shared model/vault:
1. `hermes kanban create "B" ... --body "$BODY"` (assignee + skill + body from file).
2. `hermes kanban comment <B_id> "GATE — do not start until <A> is complete. First action: open <state-file> and confirm <A> is under 'What exists'. If it is NOT done, call kanban_block with reason 'waiting on <A> to finish' and STOP. Only proceed once <A> is confirmed done."`
3. `hermes kanban schedule <B_id> "Queue for after <A> completes"` (lands it non-dispatchable).
The worker, on start, reads the gate, sees A is unfinished, and blocks itself — exactly the
behavior you want. This is far more robust than hoping the dispatcher orders them.

## Close a task a worker abandoned
A worker that crashed before its terminal `kanban_complete`/`kanban_block` leaves the task
`blocked` with a "protocol violation" diagnostic. If the artifact verifiably landed (check the
vault: `wc -l`, `grep -n '^## '`), close it yourself: `hermes kanban complete <id> --result "..."`.
Do NOT re-run it.

## Diagnose what a worker is actually doing
Background `hermes -p <profile> chat ...` hides stdout (especially if you piped it to `head`).
Read the profile's session store directly:
- DB: `~/.hermes/profiles/<profile>/state.db` (tables: `sessions`, `messages`).
- `sessions`: `id, title, message_count, tool_call_count, ended_at, end_reason, last_activity_at, input_tokens, output_tokens`.
- `messages`: `role, tool_name, content, timestamp` — pull the last N ordered by `id DESC` to see the live action.
- `end_reason` is gold: `ws_orphan_reap` (reaped, not finished), `cli_close`, `none` (still live).
- A long-uptime process with the target file UNCHANGED = the agent is stuck/looping, not working.
  Cross-check file `ls -la` mtime + `grep -cE '^### [0-9]+\. '` against the session's last messages.

## Dispatching agent work in the background
`hermes -p <profile> chat --in ~ -c "<chat>" --create-if-missing -Q -q "<message>"` run as a
background process. **Do NOT pipe to `head -5`** — it truncates what you can see and hides
progress. Use `process` poll/log, or read `state.db`, to observe.

## Pitfalls
- Positional title vs `--title` (create); positional id for complete/schedule/block/promote.
- `complete` has no `--json`; `create` does. `runs` REQUIRES an id.
- `block` a `scheduled` task → fails; use `--kind dependency` (→ todo) or `promote`/`unblock`.
- Large inline `--body` → hard-blocked by the command parser; write to a file, `$(cat)`.
- `scheduled` is a HOLDING state, not "will run imminently" — the dispatcher only promotes on gate clear.
- Two workers on one local model = contention; gate them so they run sequentially.
- Frontmatter: a description containing a colon MUST be quoted in YAML, or the skill
  create/patch fails with a parse error.
