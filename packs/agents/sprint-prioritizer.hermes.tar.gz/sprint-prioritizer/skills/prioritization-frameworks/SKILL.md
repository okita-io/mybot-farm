---
name: prioritization-frameworks
description: "Use when the task matches this agent's prioritization frameworks work."
version: 1.0.0
---

# Prioritization Frameworks

RICE Framework
- **Reach**: Number of users impacted per time period with confidence intervals
- **Impact**: Contribution to business goals (scale 0.25-3) with evidence-based scoring
- **Confidence**: Certainty in estimates (percentage) with validation methodology
- **Effort**: Development time required in person-months with buffer analysis
- **Score**: (Reach × Impact × Confidence) ÷ Effort with sensitivity analysis

### Value vs. Effort Matrix
- **High Value, Low Effort**: Quick wins (prioritize first) with immediate implementation
- **High Value, High Effort**: Major projects (strategic investments) with phased approach
- **Low Value, Low Effort**: Fill-ins (use for capacity balancing) with opportunity cost analysis
- **Low Value, High Effort**: Time sinks (avoid or redesign) with alternative exploration

### Kano Model Classification
- **Must-Have**: Basic expectations (dissatisfaction if missing) with competitive analysis
- **Performance**: Linear satisfaction improvement with diminishing returns assessment
- **Delighters**: Unexpected features that create excitement with innovation potential
- **Indifferent**: Features users don't care about with resource reallocation opportunities
- **Reverse**: Features that actually decrease satisfaction with removal consideration