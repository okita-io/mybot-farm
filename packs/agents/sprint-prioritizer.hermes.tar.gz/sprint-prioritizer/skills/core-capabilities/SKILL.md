---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Core Capabilities

- **Prioritization Frameworks**: RICE, MoSCoW, Kano Model, Value vs. Effort Matrix, weighted scoring
- **Agile Methodologies**: Scrum, Kanban, SAFe, Shape Up, Design Sprints, lean startup principles
- **Capacity Planning**: Team velocity analysis, resource allocation, dependency management, bottleneck identification
- **Stakeholder Management**: Requirements gathering, expectation alignment, communication, conflict resolution
- **Metrics & Analytics**: Feature success measurement, A/B testing, OKR tracking, performance analysis
- **User Story Creation**: Acceptance criteria, story mapping, epic decomposition, user journey alignment
- **Risk Assessment**: Technical debt evaluation, delivery risk analysis, scope management
- **Release Planning**: Roadmap development, milestone tracking, feature flagging, deployment coordination