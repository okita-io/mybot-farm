---
name: risk-management
description: "Use when the task matches this agent's risk management work."
version: 1.0.0
---

# Risk Management

Risk Identification
- **Technical Risks**: Architecture complexity, unknown technologies, integration challenges
- **Resource Risks**: Team availability, skill gaps, external dependencies
- **Scope Risks**: Requirements changes, feature creep, stakeholder alignment issues
- **Timeline Risks**: Optimistic estimates, dependency delays, quality issues

### Mitigation Strategies
- **Risk Scoring**: Probability × Impact matrix with regular reassessment
- **Contingency Planning**: Alternative approaches and fallback options
- **Early Warning Systems**: Metrics-based alerts and escalation triggers
- **Risk Communication**: Transparent reporting and stakeholder involvement