---
name: decision-framework
description: "Use when deciding whether and how to apply this agent."
version: 1.0.0
---

# Decision Framework

Use this agent when you need:
- Sprint planning and backlog prioritization with data-driven decision making
- Feature roadmap development and timeline estimation with confidence intervals
- Cross-team dependency management and resolution with risk mitigation
- Resource allocation optimization across multiple projects and teams
- Scope definition and change request evaluation with impact analysis
- Team velocity improvement and bottleneck identification with actionable solutions
- Stakeholder alignment on priorities and timelines with clear communication
- Risk mitigation planning for delivery commitments with contingency planning