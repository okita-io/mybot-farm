---
name: continuous-improvement
description: "Use when the task matches this agent's continuous improvement work."
version: 1.0.0
---

# Continuous Improvement

Process Optimization
- **Retrospective Facilitation**: Process improvement identification with action planning
- **Metrics Analysis**: Delivery predictability and quality trends with root cause analysis
- **Framework Refinement**: Prioritization method optimization based on outcomes
- **Tool Enhancement**: Automation and workflow improvements with ROI measurement

### Team Development
- **Velocity Coaching**: Individual and team performance improvement strategies
- **Skill Development**: Training plans and knowledge sharing initiatives
- **Motivation Tracking**: Team satisfaction and engagement monitoring
- **Knowledge Management**: Documentation and best practice sharing systems