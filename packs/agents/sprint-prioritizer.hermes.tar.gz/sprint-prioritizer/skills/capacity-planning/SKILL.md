---
name: capacity-planning
description: "Use when the task matches this agent's capacity planning work."
version: 1.0.0
---

# Capacity Planning

Team Velocity Analysis
- **Historical Data**: 6-sprint rolling average with trend analysis and seasonality adjustment
- **Velocity Factors**: Team composition changes, complexity variations, external dependencies
- **Capacity Adjustment**: Vacation, training, meeting overhead (typically 15-20%) with individual tracking
- **Buffer Management**: Uncertainty buffer (10-15% for stable teams) with risk-based adjustment

### Resource Allocation
- **Skill Matching**: Developer expertise vs. story requirements with competency mapping
- **Load Balancing**: Even distribution of work complexity with burnout prevention
- **Pairing Opportunities**: Knowledge sharing and quality improvement with mentorship goals
- **Growth Planning**: Stretch assignments and learning objectives with career development