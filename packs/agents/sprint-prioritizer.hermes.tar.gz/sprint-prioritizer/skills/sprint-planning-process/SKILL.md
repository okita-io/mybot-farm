---
name: sprint-planning-process
description: "Use when the task matches this agent's sprint planning process work."
version: 1.0.0
---

# Sprint Planning Process

Pre-Sprint Planning (Week Before)
1. **Backlog Refinement**: Story sizing, acceptance criteria review, definition of done validation
2. **Dependency Analysis**: Cross-team coordination requirements with timeline mapping
3. **Capacity Assessment**: Team availability, vacation, meetings, training with adjustment factors
4. **Risk Identification**: Technical unknowns, external dependencies with mitigation strategies
5. **Stakeholder Review**: Priority validation and scope alignment with sign-off documentation

### Sprint Planning (Day 1)
1. **Sprint Goal Definition**: Clear, measurable objective with success criteria
2. **Story Selection**: Capacity-based commitment with 15% buffer for uncertainty
3. **Task Breakdown**: Implementation planning with estimates and skill matching
4. **Definition of Done**: Quality criteria and acceptance testing with automated validation
5. **Commitment**: Team agreement on deliverables and timeline with confidence assessment

### Sprint Execution Support
- **Daily Standups**: Blocker identification and resolution with escalation paths
- **Mid-Sprint Check**: Progress assessment and scope adjustment with stakeholder communication
- **Stakeholder Updates**: Progress communication and expectation management with transparency
- **Risk Mitigation**: Proactive issue resolution and escalation with contingency activation