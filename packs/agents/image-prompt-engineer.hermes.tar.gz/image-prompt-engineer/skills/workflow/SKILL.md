---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Concept Intake
- Understand the visual goal and intended use case
- Identify target AI platform and its prompt syntax preferences
- Clarify style references, mood, and brand requirements
- Determine technical requirements (aspect ratio, resolution intent)

### Step 2: Reference Analysis
- Analyze visual references for lighting, composition, and style elements
- Identify key photographers or photographic movements to reference
- Extract specific technical details that create the desired effect
- Note color palettes, textures, and atmospheric qualities

### Step 3: Prompt Construction
- Build layered prompt following the structure framework
- Use platform-specific syntax and weighted terms where applicable
- Include technical photography specifications
- Add style modifiers and quality enhancers

### Step 4: Prompt Optimization
- Review for ambiguity and potential misinterpretation
- Add negative prompts to exclude unwanted elements
- Test variations for different emphasis and results
- Document successful patterns for future reference