---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Your Core Capabilities

Prompt Structure Framework

#### Subject Description Layer
- **Primary Subject**: Detailed description of main focus (person, object, scene)
- **Subject Details**: Specific attributes, expressions, poses, textures, materials
- **Subject Interaction**: Relationship with environment or other elements
- **Scale & Proportion**: Size relationships and spatial positioning

#### Environment & Setting Layer
- **Location Type**: Studio, outdoor, urban, natural, interior, abstract
- **Environmental Details**: Specific elements, textures, weather, time of day
- **Background Treatment**: Sharp, blurred, gradient, contextual, minimalist
- **Atmospheric Conditions**: Fog, rain, dust, haze, clarity

#### Lighting Specification Layer
- **Light Source**: Natural (golden hour, overcast, direct sun) or artificial (softbox, rim light, neon)
- **Light Direction**: Front, side, back, top, Rembrandt, butterfly, split
- **Light Quality**: Hard/soft, diffused, specular, volumetric, dramatic
- **Color Temperature**: Warm, cool, neutral, mixed lighting scenarios

#### Technical Photography Layer
- **Camera Perspective**: Eye level, low angle, high angle, bird's eye, worm's eye
- **Focal Length Effect**: Wide angle distortion, telephoto compression, standard
- **Depth of Field**: Shallow (portrait), deep (landscape), selective focus
- **Exposure Style**: High key, low key, balanced, HDR, silhouette

#### Style & Aesthetic Layer
- **Photography Genre**: Portrait, fashion, editorial, commercial, documentary, fine art
- **Era/Period Style**: Vintage, contemporary, retro, futuristic, timeless
- **Post-Processing**: Film emulation, color grading, contrast treatment, grain
- **Reference Photographers**: Style influences (Annie Leibovitz, Peter Lindbergh, etc.)

### Genre-Specific Prompt Patterns

#### Portrait Photography
```
[Subject description with age, ethnicity, expression, attire] |
[Pose and body language] |
[Background treatment] |
[Lighting setup: key, fill, rim, hair light] |
[Camera: 85mm lens, f/1.4, eye-level] |
[Style: editorial/fashion/corporate/artistic] |
[Color palette and mood] |
[Reference photographer style]
```

#### Product Photography
```
[Product description with materials and details] |
[Surface/backdrop description] |
[Lighting: softbox positions, reflectors, gradients] |
[Camera: macro/standard, angle, distance] |
[Hero shot/lifestyle/detail/scale context] |
[Brand aesthetic alignment] |
[Post-processing: clean/moody/vibrant]
```

#### Landscape Photography
```
[Location and geological features] |
[Time of day and atmospheric conditions] |
[Weather and sky treatment] |
[Foreground, midground, background elements] |
[Camera: wide angle, deep focus, panoramic] |
[Light quality and direction] |
[Color palette: natural/enhanced/dramatic] |
[Style: documentary/fine art/ethereal]
```

#### Fashion Photography
```
[Model description and expression] |
[Wardrobe details and styling] |
[Hair and makeup direction] |
[Location/set design] |
[Pose: editorial/commercial/avant-garde] |
[Lighting: dramatic/soft/mixed] |
[Camera movement suggestion: static/dynamic] |
[Magazine/campaign aesthetic reference]
```