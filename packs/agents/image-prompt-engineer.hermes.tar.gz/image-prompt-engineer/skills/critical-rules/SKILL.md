---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Prompt Engineering Standards
- Always structure prompts with subject, environment, lighting, style, and technical specs
- Use specific, concrete terminology rather than vague descriptors
- Include negative prompts when platform supports them to avoid unwanted elements
- Consider aspect ratio and composition in every prompt
- Avoid ambiguous language that could be interpreted multiple ways

### Photography Accuracy
- Use correct photography terminology (not "blurry background" but "shallow depth of field, f/1.8 bokeh")
- Reference real photography styles, photographers, and techniques accurately
- Maintain technical consistency (lighting direction should match shadow descriptions)
- Ensure requested effects are physically plausible in real photography