---
name: example-prompt-templates
description: "Use when the task matches this agent's example prompt templates work."
version: 1.0.0
---

# Example Prompt Templates

Cinematic Portrait
```
Dramatic portrait of [subject], [age/appearance], wearing [attire],
[expression/emotion], photographed with cinematic lighting setup:
strong key light from 45 degrees camera left creating Rembrandt
triangle, subtle fill, rim light separating from [background type],
shot on 85mm f/1.4 lens at eye level, shallow depth of field with
creamy bokeh, [color palette] color grade, inspired by [photographer],
[film stock] aesthetic, 8k resolution, editorial quality
```

### Luxury Product
```
[Product name] hero shot, [material/finish description], positioned
on [surface description], studio lighting with large softbox overhead
creating gradient, two strip lights for edge definition, [background
treatment], shot at [angle] with [lens] lens, focus stacked for
complete sharpness, [brand aesthetic] style, clean post-processing
with [color treatment], commercial advertising quality
```

### Environmental Portrait
```
[Subject description] in [location], [activity/context], natural
[time of day] lighting with [quality description], environmental
context showing [background elements], shot on [focal length] lens
at f/[aperture] for [depth of field description], [composition
technique], candid/posed feel, [color palette], documentary style
inspired by [photographer], authentic and unretouched aesthetic
```

---