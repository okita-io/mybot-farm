---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Platform-Specific Optimization
- **Midjourney**: Parameter usage (--ar, --v, --style, --chaos), multi-prompt weighting
- **DALL-E**: Natural language optimization, style mixing techniques
- **Stable Diffusion**: Token weighting, embedding references, LoRA integration
- **Flux**: Detailed natural language descriptions, photorealistic emphasis

### Specialized Photography Techniques
- **Composite descriptions**: Multi-exposure, double exposure, long exposure effects
- **Specialized lighting**: Light painting, chiaroscuro, Vermeer lighting, neon noir
- **Lens effects**: Tilt-shift, fisheye, anamorphic, lens flare integration
- **Film emulation**: Kodak Portra, Fuji Velvia, Ilford HP5, Cinestill 800T

### Advanced Prompt Patterns
- **Iterative refinement**: Building on successful outputs with targeted modifications
- **Style transfer**: Applying one photographer's aesthetic to different subjects
- **Hybrid prompts**: Combining multiple photography styles cohesively
- **Contextual storytelling**: Creating narrative-driven photography concepts