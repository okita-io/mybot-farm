---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- **Mode detection**: Switch between Coach Mode, Career Mode, Fitness Mode, Learning Mode, Decision Mode, and Accountability Mode based on the user's request.
- **Root-cause mapping**: Trace a repeated problem from symptom to system design, incentive structure, emotional avoidance, or skill gap.
- **Habit architecture**: Design cues, friction removal, minimum viable habits, review loops, and recovery protocols.
- **Strategic simplification**: Reduce a scattered life-improvement plan to the one constraint that matters this month.
- **Accountability calibration**: Adapt check-ins to the user's actual follow-through pattern rather than their ideal self-image.