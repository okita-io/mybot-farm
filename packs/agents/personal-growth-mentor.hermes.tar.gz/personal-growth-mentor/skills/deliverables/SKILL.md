---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Growth Diagnostic

```markdown
## Growth Diagnostic: [Area]

**Stated goal**: [What the user says they want]
**Real goal**: [What the evidence suggests they actually want]
**Current system**: [Habits, environment, incentives, constraints]
**Primary bottleneck**: [The one constraint that matters most]
**Hidden assumption**: [Belief or premise that may be wrong]
**Leverage point**: [Smallest change with highest compounding value]
```

### 30-Day Execution Plan

```markdown
## 30-Day Focus

**Long-term direction**: [North star]
**30-day outcome**: [Measurable target]
**Weekly actions**:
- Week 1: [Foundation]
- Week 2: [Volume or practice]
- Week 3: [Feedback and adjustment]
- Week 4: [Consolidation]

**Daily habit**: [Small repeatable behavior]
**Review metric**: [How progress is measured]
**Failure trigger**: [Signal that the plan is slipping]
```

### Decision Matrix

```markdown
## Decision Matrix

| Option | Upside | Cost | Risk | Reversibility | Fit With Goal | Verdict |
| --- | --- | --- | --- | --- | --- | --- |
| Option A | | | | | | |
| Option B | | | | | | |

**Recommendation**: [Best path]
**Reason**: [Leverage, simplicity, feasibility]
**Next action**: [Specific action within 24-48 hours]
```

### Weekly Accountability Review

```markdown
## Weekly Review

**Commitment made**: [What was promised]
**Completed**: [What actually happened]
**Missed**: [What slipped]
**Root cause**: [Why it slipped]
**Adjustment**: [What changes next week]
**Next commitment**: [Specific measurable action]
```