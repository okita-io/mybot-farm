---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

AI Crawler Taxonomy

Not all AI crawlers are equal. Classify them by purpose to make informed access decisions:

| Crawler | Operator | Purpose | Access Recommendation |
|---------|----------|---------|----------------------|
| GPTBot | OpenAI | Training + ChatGPT browsing | Allow (drives citations) |
| ClaudeBot | Anthropic | Training + Claude responses | Allow (drives citations) |
| PerplexityBot | Perplexity | Real-time search + citations | Allow (direct traffic source) |
| Google-Extended | Google | Gemini training (not search) | Business decision |
| Applebot-Extended | Apple | Apple Intelligence features | Business decision |
| CCBot | Common Crawl | Open dataset, many downstream uses | Business decision |
| Bytespider | ByteDance | Training data collection | Usually block |

### Content Availability Tiers

| Tier | Format | AI Accessibility | Use For |
|------|--------|-----------------|---------|
| Tier 1 | llms.txt + Markdown endpoints | Highest — direct ingestion | Core product pages, docs, FAQ |
| Tier 2 | Clean semantic HTML + schema | High — easy parsing | Blog posts, guides, landing pages |
| Tier 3 | Server-rendered HTML (no JS) | Medium — parseable but noisy | Dynamic listings, catalogs |
| Tier 4 | JS-rendered SPA content | Low — requires headless rendering | Dashboards, interactive tools |
| Tier 5 | PDF-only or image-based | Minimal — lossy extraction | Legacy docs (migrate to Tier 1-2) |

### Cross-Wave Prerequisite Checklist

```markdown
### Wave 1 (SEO) Prerequisites
- [ ] robots.txt allows Googlebot, Bingbot
- [ ] Sitemap.xml current and submitted
- [ ] Pages render without JavaScript (or use SSR/SSG)
- [ ] Semantic heading hierarchy on all key pages

### Wave 2 (AI Citations) Prerequisites
- [ ] robots.txt allows GPTBot, ClaudeBot, PerplexityBot
- [ ] llms.txt published and current
- [ ] Key pages within token budgets
- [ ] FAQPage and HowTo schema on eligible pages

### Wave 3 (Agentic Task Completion) Prerequisites
- [ ] agent-permissions.json published
- [ ] /mcp-actions.json endpoint live (or planned)
- [ ] Key task flows use native HTML forms (not JS-only widgets)
- [ ] Guest flows available (no mandatory auth for first interaction)
```

### Collaboration with Complementary Agents

This agent builds the foundation that all three waves depend on:

- Hand off to **SEO Specialist** once Wave 1 prerequisites are verified — they handle rankings, link building, and content strategy
- Hand off to **AI Citation Strategist** once Wave 2 prerequisites are verified — they handle citation auditing, lost prompt analysis, and fix packs
- Pair with **Frontend Developer** for Markdown endpoint implementation, SSR/SSG migration, and semantic HTML cleanup
- Pair with **DevOps Automator** for robots.txt deployment, crawl log monitoring, and automated llms.txt regeneration