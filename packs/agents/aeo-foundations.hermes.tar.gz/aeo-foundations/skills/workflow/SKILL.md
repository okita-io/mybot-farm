---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

1. **Foundation Audit**
   - Fetch robots.txt — check for AI crawler directives (GPTBot, ClaudeBot, PerplexityBot, Google-Extended, Applebot-Extended)
   - Check for llms.txt and llms-full.txt at site root
   - Check for AGENTS.md, agent-permissions.json, and /mcp-actions.json
   - Review server access logs for AI crawler activity and blocked requests
   - Score the Discovery Layer (0-6 points)

2. **Parsability Assessment**
   - Test key pages with JavaScript disabled — is core content still visible?
   - Estimate token counts for the 10-20 most important pages
   - Verify heading hierarchy (H1 → H6) is semantic, not decorative
   - Check for Markdown or clean-HTML alternatives to JS-rendered content
   - Verify schema markup (FAQPage, HowTo, Article, Product) on target pages
   - Score the Parsability Layer (0-6 points)

3. **Capability Check**
   - Verify if agent-permissions.json declares available actions
   - Check if WebMCP discovery endpoint exists (for Wave 3 readiness)
   - Review whether key task flows are declared in machine-readable format
   - Score the Capability Layer (0-3 points)

4. **Fix Implementation**
   - Phase 1 (Day 1-3): robots.txt AI crawler rules — immediate, zero-risk
   - Phase 2 (Day 3-7): llms.txt and llms-full.txt — curate site map for AI consumption
   - Phase 3 (Day 7-14): Token budget compliance — split, chunk, or summarize over-budget content
   - Phase 4 (Day 14-21): Schema markup and structured content — FAQPage, HowTo, clean HTML
   - Phase 5 (Day 21-30): agent-permissions.json and capability declarations

5. **Verify & Maintain**
   - Re-run foundation audit after implementation — target 75%+ score
   - Query AI systems (ChatGPT, Claude, Perplexity) to verify content is being ingested
   - Check crawl logs weekly for new AI user agents
   - Schedule quarterly llms.txt review to keep discovery file current
   - Monitor for new discovery standards and adopt when they reach meaningful adoption