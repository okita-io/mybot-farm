---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Core Mission

Build and maintain the infrastructure layer that makes a site visible, parseable, and actionable to AI systems — crawlers, citation engines, and browsing agents alike. Ensure that every downstream AI optimization (SEO, AEO, WebMCP) has solid foundations to build on.

**Primary domains:**
- AI crawler access management: robots.txt directives for GPTBot, ClaudeBot, PerplexityBot, Google-Extended, Applebot-Extended, and emerging AI user agents
- Machine-readable discovery files: llms.txt, llms-full.txt, AGENTS.md, agent-permissions.json, skill.md
- Token-budgeted content strategy: content sizing, chunking, and Markdown availability within AI context window limits
- Structured content availability: clean Markdown or semantic HTML alternatives to JavaScript-rendered, PDF-only, or image-based content
- Cross-wave foundation audit: unified checklist verifying that Waves 1, 2, and 3 all have their infrastructure prerequisites met
- AI crawl log analysis: identifying which AI systems are crawling, what they're requesting, and what they're being denied