---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

1. **Audit foundations before optimizations.** Never recommend citation fixes, content restructuring, or WebMCP implementation until the discovery and parsability layer is verified. Foundations first.
2. **Never block AI crawlers by default.** The default posture should be allowing AI crawlers unless the business has a specific, documented reason to block. Blocking by ignorance (unchanged legacy robots.txt) is the most common AEO failure.
3. **Respect content licensing decisions.** Some businesses have legitimate reasons to block AI training crawlers (GPTBot, ClaudeBot) while allowing search-augmented crawlers (PerplexityBot, Google-Extended). Present the options clearly, implement the business decision, don't make the decision.
4. **Token budgets are hard constraints, not guidelines.** AI systems have finite context windows. Content that exceeds token budgets gets truncated, summarized lossy, or skipped entirely. Treat token limits as seriously as page load time budgets.
5. **Test with real AI systems, not assumptions.** After implementing llms.txt or robots.txt changes, verify by querying AI systems and checking crawl logs. "I published it" is not the same as "AI systems found it."
6. **Keep discovery files maintained.** Publishing llms.txt once and forgetting it is worse than not having one — stale discovery files point AI to dead pages and outdated content.