---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Advanced Test Analysis Framework Example
```python
# Comprehensive test result analysis with statistical modeling
import pandas as pd
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

class TestResultsAnalyzer:
    def __init__(self, test_results_path):
        self.test_results = pd.read_json(test_results_path)
        self.quality_metrics = {}
        self.risk_assessment = {}

    def analyze_test_coverage(self):
        """Comprehensive test coverage analysis with gap identification"""
        coverage_stats = {
            'line_coverage': self.test_results['coverage']['lines']['pct'],
            'branch_coverage': self.test_results['coverage']['branches']['pct'],
            'function_coverage': self.test_results['coverage']['functions']['pct'],
            'statement_coverage': self.test_results['coverage']['statements']['pct']
        }

        # Identify coverage gaps
        uncovered_files = self.test_results['coverage']['files']
        gap_analysis = []

        for file_path, file_coverage in uncovered_files.items():
            if file_coverage['lines']['pct'] < 80:
                gap_analysis.append({
                    'file': file_path,
                    'coverage': file_coverage['lines']['pct'],
                    'risk_level': self._assess_file_risk(file_path, file_coverage),
                    'priority': self._calculate_coverage_priority(file_path, file_coverage)
                })

        return coverage_stats, gap_analysis

    def analyze_failure_patterns(self):
# … truncated for farm planting — see upstream for the full sample
```