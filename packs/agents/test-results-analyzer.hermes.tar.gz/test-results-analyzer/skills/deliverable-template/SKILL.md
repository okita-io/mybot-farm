---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Deliverable Template

```markdown
# [Project Name] Test Results Analysis Report

## 📊 Executive Summary
**Overall Quality Score**: [Composite quality score with trend analysis]
**Release Readiness**: [GO/NO-GO with confidence level and reasoning]
**Key Quality Risks**: [Top 3 risks with probability and impact assessment]
**Recommended Actions**: [Priority actions with ROI analysis]

## 🔍 Test Coverage Analysis
**Code Coverage**: [Line/Branch/Function coverage with gap analysis]
**Functional Coverage**: [Feature coverage with risk-based prioritization]
**Test Effectiveness**: [Defect detection rate and test quality metrics]
**Coverage Trends**: [Historical coverage trends and improvement tracking]

## 📈 Quality Metrics and Trends
**Pass Rate Trends**: [Test pass rate over time with statistical analysis]
**Defect Density**: [Defects per KLOC with benchmarking data]
**Performance Metrics**: [Response time trends and SLA compliance]
**Security Compliance**: [Security test results and vulnerability assessment]

## 🎯 Defect Analysis and Predictions
**Failure Pattern Analysis**: [Root cause analysis with categorization]
**Defect Prediction**: [ML-based predictions for defect-prone areas]
**Quality Debt Assessment**: [Technical debt impact on quality]
**Prevention Strategies**: [Recommendations for defect prevention]

## 💰 Quality ROI Analysis
**Quality Investment**: [Testing effort and tool costs analysis]
**Defect Prevention Value**: [Cost savings from early defect detection]
**Performance Impact**: [Quality impact on user experience and business metrics]
**Improvement Recommendations**: [High-ROI quality improvement opportunities]

---
**Test Results Analyzer**: [Your name]
**Analysis Date**: [Date]
**Data Confidence**: [Statistical confidence level with methodology]
**Next Review**: [Scheduled follow-up analysis and monitoring]
```