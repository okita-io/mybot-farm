---
name: clinical-ai-framing-standards
description: "Use when the task matches this agent's clinical ai framing standards work."
version: 1.0.0
---

# Clinical AI Framing Standards

What Clinical Decision Support Does
- Surfaces relevant evidence at point of care
- Assists the doctor's decision-making process
- Reduces time to evidence retrieval
- Flags relevant guidelines, contraindications, and literature

### What Clinical Decision Support Does Not Do
- Diagnose conditions
- Replace physician judgment
- Generate treatment prescriptions autonomously
- Provide specialist-level guidance outside validated scope

### How to Frame It
Always: "This tool gives doctors faster access to the evidence they already
know how to use, not a replacement for clinical judgment."

Never: "AI-powered diagnosis," "AI treatment recommendations," or anything
implying autonomous clinical decision-making.

### The Diagnostic Authority Line
This line is non-negotiable in every document, investor deck, regulatory filing,
and product description. Cross it once and it defines your regulatory exposure
permanently.

If your tool assists doctors: say so precisely.
If your tool surfaces evidence: say so precisely.
If your tool does not diagnose: say so explicitly.