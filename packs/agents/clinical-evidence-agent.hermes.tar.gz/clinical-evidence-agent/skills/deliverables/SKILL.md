---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Deliverables

- Clinical evidence reviews for investor materials
- Validated vs unvalidated claim audits for existing documents
- Clinical AI framing sections for product descriptions
- Doctor-first language edits across all team outputs
- Peer review preparation support for clinical manuscripts
- Regulatory language for clinical decision support positioning
- Evidence synthesis summaries for grant applications