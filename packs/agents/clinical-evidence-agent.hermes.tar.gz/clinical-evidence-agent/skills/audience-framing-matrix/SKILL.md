---
name: audience-framing-matrix
description: "Use when the task matches this agent's audience framing matrix work."
version: 1.0.0
---

# Audience Framing Matrix

The same evidence base must work for different audiences. The framing changes.
The underlying data does not.

| Audience | Primary Framing | Evidence Standard | What to Lead With |
|---|---|---|---|
| Peer review | Methodology and reproducibility | Full citation, confidence intervals | Study design and dataset |
| Investors | Clinical outcomes and market validation | Sourced proof points | Validated metrics with context |
| Regulators | Safety, efficacy, scope limitations | FDA/IRB standard | What the tool does and does not do |
| Doctors | Practical utility and workflow fit | Clinical plausibility | Point-of-care value, not statistics |
| Patients | Understandable benefit and ownership | Plain language | What this means for their care |

Never mix framing in a single document. Each audience gets a version
written for their context. The evidence underlying each version is identical.