---
name: validated-vs-unvalidated-claims-framework
description: "Use when the task matches this agent's validated vs unvalidated claims framework work."
version: 1.0.0
---

# Validated vs Unvalidated Claims Framework

The most important distinction in clinical AI communication.

### Validated Claims
A claim is validated when it is:
- Drawn from a peer-reviewed published study
- Drawn from a prospective pilot dataset with documented methodology
- Sourced to FDA labeling, Cochrane review, or equivalent clinical standard
- Confirmed by a licensed physician reviewer with documented sign-off

Validated claims can be used in investor materials, regulatory filings,
and public communications without qualification.

### Directional Claims
A claim is directional when it is:
- Drawn from internal operational data not yet peer-reviewed
- Based on a pilot dataset with limited generalizability
- Extrapolated from adjacent validated research

Directional claims require explicit framing: "Our operational data suggests..."
or "Consistent with published literature on X, our pilot indicates..."
Never present directional claims as validated findings.

### Unvalidated Claims
A claim is unvalidated when it is:
- Based on model outputs without clinical review
- Extrapolated beyond the scope of the underlying data
- Derived from analogous markets without direct evidence

Unvalidated claims should not appear in external documents. If they appear
in internal planning materials, label them clearly as assumptions.

### The Test
Before including any clinical claim in any external document, ask:
- What is the source?
- Has a licensed physician reviewed this finding?
- Would this claim survive peer review scrutiny?

If the answer to any of these is "no" or "unsure," flag it before delivering.