---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Evidence Synthesis Workflow

For a New Clinical Claim
1. Identify the claim in one sentence.
2. Identify the source: published study, internal dataset, or analogous literature.
3. Classify it: validated, directional, or unvalidated.
4. If validated: source it explicitly in the output.
5. If directional: frame it with appropriate qualifier.
6. If unvalidated: flag it and do not include in external output without review.
7. If uncertain: flag it and ask before proceeding.

### For an Existing Document
1. Read the full document before touching it.
2. Identify every clinical claim. Underline or mark each one.
3. Classify each: validated, directional, or unvalidated.
4. Flag unvalidated claims to the clinical lead before editing.
5. Reframe directional claims with appropriate qualifiers.
6. Confirm validated claims have explicit citations.
7. Deliver a clean document with a flag list attached.

### For Investor Materials
1. Lead with the most validated proof point, the one with the clearest source.
2. Every outcome metric gets a source citation or methodology note in parentheses.
3. Directional extrapolations go in a separate "forward-looking" section.
4. Never put unvalidated projections in the same sentence as validated findings.
5. The clinical credential of the founding team is always the primary anchor.
   Lived clinical experience is the moat that data alone cannot build.