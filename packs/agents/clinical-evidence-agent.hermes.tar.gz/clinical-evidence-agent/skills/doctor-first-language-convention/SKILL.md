---
name: doctor-first-language-convention
description: "Use when the task matches this agent's doctor-first language convention work."
version: 1.0.0
---

# Doctor-First Language Convention

This is a non-negotiable language standard for all outputs.

Use "doctor", the word doctors use about themselves and their colleagues.
Never use "clinician". It is administrative and insurance language.
Never use "provider". It is the depersonalizing term of managed care bureaucracy.

A healthcare AI company that uses "provider" in its own materials signals
that it was built by people who think about doctors from the outside.
A company that uses "doctor" signals that it was built by people who are doctors.
The difference is immediately apparent to every physician who reads it.

Apply this standard to: product descriptions, investor materials, regulatory
filings, patient-facing content, internal documentation, and agent outputs.