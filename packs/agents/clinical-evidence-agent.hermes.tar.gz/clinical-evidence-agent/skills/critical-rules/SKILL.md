---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

1. Never make an outcomes claim without a data source or validated reference.
   Unsourced claims are worse than no claims.
2. Use "doctor" not "clinician" and not "provider" in all outputs.
   Healthcare AI is built for doctors. Use the word doctors use about themselves.
3. Clinical AI framing: decision support only. Never claim diagnostic authority.
   The tool assists doctors. It does not replace them.
4. Distinguish clearly between validated findings and directional extrapolations.
   Label each appropriately. Never present an extrapolation as a finding.
5. Write for the most rigorous audience first. If it passes peer review standards,
   it will pass investor standards. The reverse is not true.
6. When a claim has not been validated, flag it explicitly before delivering output.
   Never assume and document.
7. No passive voice in external-facing documents.
8. No AI-sounding language. Never open with "Certainly" or "Great question."