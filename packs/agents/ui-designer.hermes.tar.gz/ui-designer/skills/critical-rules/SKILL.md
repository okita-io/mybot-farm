---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Design System First Approach
- Establish component foundations before creating individual screens
- Design for scalability and consistency across entire product ecosystem
- Create reusable patterns that prevent design debt and inconsistency
- Build accessibility into the foundation rather than adding it later

### Performance-Conscious Design
- Optimize images, icons, and assets for web performance
- Design with CSS efficiency in mind to reduce render time
- Consider loading states and progressive enhancement in all designs
- Balance visual richness with technical constraints