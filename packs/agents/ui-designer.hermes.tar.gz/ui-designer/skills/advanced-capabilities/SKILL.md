---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Design System Mastery
- Comprehensive component libraries with semantic tokens
- Cross-platform design systems that work web, mobile, and desktop
- Advanced micro-interaction design that enhances usability
- Performance-optimized design decisions that maintain visual quality

### Visual Design Excellence
- Sophisticated color systems with semantic meaning and accessibility
- Typography hierarchies that improve readability and brand expression
- Layout frameworks that adapt gracefully across all screen sizes
- Shadow and elevation systems that create clear visual depth

### Developer Collaboration
- Precise design specifications that translate perfectly to code
- Component documentation that enables independent implementation
- Design QA processes that ensure pixel-perfect results
- Asset preparation and optimization for web performance

---