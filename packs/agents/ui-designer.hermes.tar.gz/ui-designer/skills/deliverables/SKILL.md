---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Design System Deliverables

Component Library Architecture
```css
/* Design Token System */
:root {
  /* Color Tokens */
  --color-primary-100: #f0f9ff;
  --color-primary-500: #3b82f6;
  --color-primary-900: #1e3a8a;

  --color-secondary-100: #f3f4f6;
  --color-secondary-500: #6b7280;
  --color-secondary-900: #111827;

  --color-success: #10b981;
  --color-warning: #f59e0b;
  --color-error: #ef4444;
  --color-info: #3b82f6;

  /* Typography Tokens */
  --font-family-primary: 'Inter', system-ui, sans-serif;
  --font-family-secondary: 'JetBrains Mono', monospace;

  --font-size-xs: 0.75rem;    /* 12px */
  --font-size-sm: 0.875rem;   /* 14px */
  --font-size-base: 1rem;     /* 16px */
  --font-size-lg: 1.125rem;   /* 18px */
  --font-size-xl: 1.25rem;    /* 20px */
  --font-size-2xl: 1.5rem;    /* 24px */
  --font-size-3xl: 1.875rem;  /* 30px */
  --font-size-4xl: 2.25rem;   /* 36px */

  /* Spacing Tokens */
  --space-1: 0.25rem;   /* 4px */
  --space-2: 0.5rem;    /* 8px */
  --space-3: 0.75rem;   /* 12px */
  --space-4: 1rem;      /* 16px */
  --space-6: 1.5rem;    /* 24px */
  --space-8: 2rem;      /* 32px */
  --space-12: 3rem;     /* 48px */
  --space-16: 4rem;     /* 64px */

  /* Shadow Tokens */
# … truncated for farm planting — see upstream for the full sample
```

### Responsive Design Framework
```css
/* Mobile First Approach */
.container {
  width: 100%;
  margin-left: auto;
  margin-right: auto;
  padding-left: var(--space-4);
  padding-right: var(--space-4);
}

/* Small devices (640px and up) */
@media (min-width: 640px) {
  .container { max-width: 640px; }
  .sm\\:grid-cols-2 { grid-template-columns: repeat(2, 1fr); }
}

/* Medium devices (768px and up) */
@media (min-width: 768px) {
  .container { max-width: 768px; }
  .md\\:grid-cols-3 { grid-template-columns: repeat(3, 1fr); }
}

/* Large devices (1024px and up) */
@media (min-width: 1024px) {
  .container {
    max-width: 1024px;
    padding-left: var(--space-6);
    padding-right: var(--space-6);
  }
  .lg\\:grid-cols-4 { grid-template-columns: repeat(4, 1fr); }
}

/* Extra large devices (1280px and up) */
@media (min-width: 1280px) {
  .container {
    max-width: 1280px;
    padding-left: var(--space-8);
    padding-right: var(--space-8);
  }
}
```