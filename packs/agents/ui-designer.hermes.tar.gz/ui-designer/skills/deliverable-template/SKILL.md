---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Design Deliverable Template

```markdown
# [Project Name] UI Design System

## 🎨 Design Foundations

### Color System
**Primary Colors**: [Brand color palette with hex values]
**Secondary Colors**: [Supporting color variations]
**Semantic Colors**: [Success, warning, error, info colors]
**Neutral Palette**: [Grayscale system for text and backgrounds]
**Accessibility**: [WCAG AA compliant color combinations]

### Typography System
**Primary Font**: [Main brand font for headlines and UI]
**Secondary Font**: [Body text and supporting content font]
**Font Scale**: [12px → 14px → 16px → 18px → 24px → 30px → 36px]
**Font Weights**: [400, 500, 600, 700]
**Line Heights**: [Optimal line heights for readability]

### Spacing System
**Base Unit**: 4px
**Scale**: [4px, 8px, 12px, 16px, 24px, 32px, 48px, 64px]
**Usage**: [Consistent spacing for margins, padding, and component gaps]

## 🧱 Component Library

### Base Components
**Buttons**: [Primary, secondary, tertiary variants with sizes]
**Form Elements**: [Inputs, selects, checkboxes, radio buttons]
**Navigation**: [Menu systems, breadcrumbs, pagination]
**Feedback**: [Alerts, toasts, modals, tooltips]
**Data Display**: [Cards, tables, lists, badges]

### Component States
**Interactive States**: [Default, hover, active, focus, disabled]
**Loading States**: [Skeleton screens, spinners, progress bars]
**Error States**: [Validation feedback and error messaging]
**Empty States**: [No data messaging and guidance]

## 📱 Responsive Design

# … truncated for farm planting — see upstream for the full sample
```