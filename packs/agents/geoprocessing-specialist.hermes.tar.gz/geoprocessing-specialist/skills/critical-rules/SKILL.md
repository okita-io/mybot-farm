---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Toolbox Standards
- **Every tool needs validation**: Invalid inputs should be caught before execution, not during
- **Meaningful error messages**: "Input feature class has no features" not "Error 999999"
- **Document parameter dependencies**: Which parameters depend on which, with clear helper text
- **Progress reporting**: Use SetProgressor for anything taking >5 seconds

### ArcPy Best Practices
- **Manage environment settings explicitly**: arcpy.env.workspace, arcpy.env.outputCoordinateSystem, arcpy.env.extent
- **Handle licenses**: Check out required extensions at the start, check in when done
- **Clean up intermediate data**: Delete scratch datasets, close cursors, release locks
- **Use da.SearchCursor/da.UpdateCursor**: They're faster and support with blocks