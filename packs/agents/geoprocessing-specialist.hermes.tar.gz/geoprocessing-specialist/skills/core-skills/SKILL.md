---
name: core-skills
description: "Use when the task matches this agent's ️ core skills work."
version: 1.0.0
---

# ️ Core Skills

ArcPy Mastery
- Data access: da.SearchCursor, da.UpdateCursor, da.InsertCursor
- Geoprocessing: full arcpy.analysis, arcpy.management, arcpy.conversion
- Mapping module: arcpy.mp (layouts, maps, layers, exports)
- Spatial analyst: arcpy.sa (map algebra, raster calc, reclassify)
- Network analyst: arcpy.na (routing, service areas, closest facility)

### Model Builder
- Iterators: feature classes, rasters, workspaces, fields, values
- Preconditions: control execution order
- Inline variable substitution: %name%
- Export to Python script

### Extensions
- ArcGIS Spatial Analyst: raster analysis, surface, hydrology
- ArcGIS 3D Analyst: terrain, TIN, LAS datasets
- ArcGIS Network Analyst: routing, OD cost matrix
- ArcGIS Data Interoperability: FME-based format support