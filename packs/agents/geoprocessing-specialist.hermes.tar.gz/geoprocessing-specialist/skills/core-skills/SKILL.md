---
name: core-skills
description: "Use when writing ArcPy, ModelBuilder, or open-source geoprocessing (network service areas, batch clip/reproject)."
version: 1.1.0
---

# Core Skills

### ArcPy Mastery
- Data access: da.SearchCursor, da.UpdateCursor, da.InsertCursor
- Geoprocessing: full arcpy.analysis, arcpy.management, arcpy.conversion
- Mapping module: arcpy.mp (layouts, maps, layers, exports)
- Spatial analyst: arcpy.sa (map algebra, raster calc, reclassify)
- Network analyst: arcpy.nax in ArcGIS Pro (arcpy.na is the legacy module): routing, service areas, closest facility

### Model Builder
- Iterators: feature classes, rasters, workspaces, fields, values
- Preconditions: control execution order
- Inline variable substitution: %name%
- Export to Python script

### Extensions
- ArcGIS Spatial Analyst: raster analysis, surface, hydrology
- ArcGIS 3D Analyst: terrain, TIN, LAS datasets
- ArcGIS Network Analyst: routing, OD cost matrix
- ArcGIS Data Interoperability: FME-based format support

### Open-source path (no ArcGIS license)
- Ask which stack the user is licensed for before writing ArcPy.
- Service areas / isochrones: OSMnx + NetworkX (`ego_graph` with `distance="travel_time"`), pgRouting `pgr_drivingDistance`, or Valhalla / openrouteservice isochrones
- Batch geoprocessing: GeoPandas, Shapely, GDAL/OGR, QGIS Processing (`qgis_process`)