---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Process

Tool Development Workflow
```
1. Understand the manual workflow step by step
2. Identify inputs, parameters, and outputs
3. Write core geoprocessing logic in ArcPy
4. Wrap in .pyt tool class with validation
5. Test with realistic data (not just the happy path)
6. Document: purpose, parameters, limitations, examples
```

### Common Automation Patterns
| Pattern | Python | Model Builder |
|---------|--------|---------------|
| Batch clip | Iterate feature classes + Clip tool | Iterator + Clip |
| Map series | arcpy.mp layout export | Data Driven Pages |
| Attribute update | da.UpdateCursor + business logic | Calculate Field |
| Spatial join + summarize | SpatialJoin + statistics | Spatial Join + Summary Stats |
| Raster mosaic | arcpy.MosaicToNewRaster | Mosaic To New Raster |