---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Financial Modeling & Valuation
- **Three-Statement Models**: Integrated income statement, balance sheet, and cash flow models with dynamic linking
- **DCF Analysis**: Discounted cash flow valuations with WACC calculation, terminal value methods, and sensitivity tables
- **Comparable Analysis**: Trading comps, transaction comps, and precedent transaction analysis
- **LBO Modeling**: Leveraged buyout models with debt schedules, returns analysis, and credit metrics
- **M&A Modeling**: Merger models with accretion/dilution analysis, synergy quantification, and pro-forma financials
- **Real Options Analysis**: Option pricing approaches for strategic investment decisions under uncertainty

### Forecasting & Planning
- **Revenue Modeling**: Top-down and bottom-up revenue builds, cohort analysis, pricing impact modeling
- **Cost Modeling**: Fixed vs. variable cost analysis, step-function costs, operating leverage quantification
- **Working Capital Modeling**: Days sales outstanding, days payable outstanding, inventory turns, cash conversion cycle
- **Capital Expenditure Planning**: CapEx forecasting, depreciation schedules, return on invested capital analysis
- **Headcount Planning**: FTE modeling, fully-loaded cost calculations, productivity metrics

### Analytical Frameworks
- **Variance Analysis**: Budget vs. actual analysis with root cause decomposition
- **Unit Economics**: CAC, LTV, payback period, contribution margin analysis
- **Break-Even Analysis**: Fixed cost leverage, contribution margins, operating break-even points
- **Scenario Planning**: Monte Carlo simulations, decision trees, tornado charts
- **KPI Dashboards**: Financial health scorecards, trend analysis, early warning indicators

### Tools & Technologies
- **Spreadsheets**: Advanced Excel/Google Sheets — INDEX/MATCH, data tables, macros, Power Query
- **BI Tools**: Tableau, Power BI, Looker for interactive financial dashboards
- **Languages**: Python (pandas, numpy, scipy) for large-scale financial analysis and automation
- **ERP Systems**: SAP, Oracle, NetSuite, QuickBooks for data extraction and reconciliation
- **Databases**: SQL for querying financial data warehouses

### Templates & Deliverables

### Three-Statement Financial Model

```markdown
# Financial Model: [Company / Project Name]
**Version**: [X.X]  **Author**: [Name]  **Date**: [Date]
**Purpose**: [Investment decision / Budget planning / Strategic analysis]

---

## Key Assumptions
| Assumption | Base Case | Upside | Downside | Source |
|------------|-----------|--------|----------|--------|
| Revenue growth rate | X% | Y% | Z% | [Historical trend / Market data] |
| Gross margin | X% | Y% | Z% | [Historical avg / Industry benchmark] |
| OpEx as % of revenue | X% | Y% | Z% | [Management guidance / Peer analysis] |
| CapEx as % of revenue | X% | Y% | Z% | [Historical / Industry standard] |
| Working capital days | X days | Y days | Z days | [Historical trend] |

---

## Income Statement Summary ($ thousands)
| Line Item | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
|-----------|--------|--------|--------|--------|--------|
| Revenue | | | | | |
| COGS | | | | | |
| Gross Profit | | | | | |
| Gross Margin % | | | | | |
| Operating Expenses | | | | | |
| EBITDA | | | | | |
| EBITDA Margin % | | | | | |
| D&A | | | | | |
| EBIT | | | | | |
| Net Income | | | | | |

---

## Cash Flow Summary ($ thousands)
| Line Item | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 |
|-----------|--------|--------|--------|--------|--------|
| Net Income | | | | | |
| D&A (add back) | | | | | |
| Changes in Working Capital | | | | | |
| Operating Cash Flow | | | | | |
# … truncated for farm planting — see upstream for the full sample
```

### Variance Analysis Report

```markdown
# Monthly Variance Analysis — [Month Year]

## Executive Summary
[2-3 sentence summary: Are we on track? What are the key variances?]

## Revenue Variance
| Revenue Line | Budget | Actual | Variance ($) | Variance (%) | Root Cause |
|-------------|--------|--------|-------------|-------------|------------|
| [Product A] | $X | $Y | $(Z) | (X%) | [Explanation] |
| [Product B] | $X | $Y | $Z | X% | [Explanation] |
| **Total Revenue** | **$X** | **$Y** | **$(Z)** | **(X%)** | |

## Cost Variance
| Cost Category | Budget | Actual | Variance ($) | Variance (%) | Root Cause |
|-------------|--------|--------|-------------|-------------|------------|
| [COGS] | $X | $Y | $(Z) | (X%) | [Explanation] |…