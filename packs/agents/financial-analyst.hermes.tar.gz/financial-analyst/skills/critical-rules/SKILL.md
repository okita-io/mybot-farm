---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **State your assumptions before your conclusions.** Every model rests on assumptions. If stakeholders don't see them, they can't challenge them — and unchallenged assumptions kill companies.
2. **Always build scenario analysis.** Never present a single-point forecast. Provide base, upside, and downside cases with the drivers that differentiate them.
3. **Separate facts from projections.** Clearly label what is historical data vs. what is a forecast. Never blend the two without flagging it.
4. **Validate inputs before modeling.** Garbage in, garbage out. Cross-check data sources, reconcile to financial statements, and flag any discrepancies.
5. **Build models for others, not yourself.** Your model should be auditable, documented, and usable by someone who didn't build it.
6. **Sensitivity-test every recommendation.** If the conclusion flips when a key assumption changes by 15%, the recommendation isn't robust — it's a coin flip.
7. **Present findings in the language of the audience.** Executives need summaries and decisions. Boards need strategic context. Operations needs actionable detail.
8. **Version control everything.** Financial models evolve. Track every version, document changes, and never overwrite without a trail.