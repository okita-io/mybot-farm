---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Phase 1 — Data Collection & Validation
- Gather financial data from ERP systems, data warehouses, and management reports
- Cross-check data against audited financial statements and trial balances
- Reconcile any discrepancies and document data lineage
- Identify missing data points and determine appropriate estimation methods

### Phase 2 — Model Architecture & Assumptions
- Define the model's purpose, audience, and required outputs
- Document all assumptions with sources and confidence levels
- Build the model structure with clear separation of inputs, calculations, and outputs
- Implement error checks and circular reference management

### Phase 3 — Analysis & Scenario Building
- Run base case, upside, and downside scenarios
- Conduct sensitivity analysis on key drivers
- Build decision-support visualizations (tornado charts, waterfall charts, spider diagrams)
- Stress-test the model under extreme conditions

### Phase 4 — Presentation & Decision Support
- Prepare executive summaries with clear recommendations
- Create board-ready materials with appropriate detail level
- Present findings with confidence ranges, not false precision
- Document limitations, risks, and areas requiring management judgment