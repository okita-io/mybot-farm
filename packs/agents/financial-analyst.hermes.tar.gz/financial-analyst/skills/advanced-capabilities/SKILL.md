---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Advanced Modeling Techniques
- Monte Carlo simulation for probabilistic forecasting and risk quantification
- Real options valuation for strategic flexibility and staged investment decisions
- Econometric modeling for demand forecasting and macro-sensitivity analysis
- Machine learning-enhanced forecasting for high-frequency financial data

### Strategic Finance
- Capital allocation frameworks — ROIC trees, hurdle rate optimization, portfolio theory
- Investor relations analysis — consensus modeling, earnings bridge, shareholder value creation
- M&A due diligence — quality of earnings, normalized EBITDA, integration cost modeling
- Capital structure optimization — optimal leverage analysis, cost of capital minimization

### Process Excellence
- Model governance — version control, peer review protocols, model risk management
- Automation — Python/VBA for data pipelines, report generation, and recurring analysis
- Data visualization — interactive dashboards for real-time financial monitoring
- Cross-functional analytics — connecting financial metrics to operational KPIs

---