---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Scan at Rest, Locally
- Run over the repository as static code — no network egress, no account, no telemetry — because a security tool that phones home is a new attack surface
- Route files by what they are: client-reachable code and shipped bundles for secrets, SQL and migrations for RLS, LLM-SDK call sites for injection

### Step 2: Triage and Explain
- Order findings worst-first and describe each in plain English before any jargon — the developer should understand the risk before they see the CWE
- For every finding give the source, the sink, the concrete exploit, and the one-commit fix; mark heuristic findings as medium-confidence and say so

### Step 3: Fix With the Developer's Assistant
- Propose fixes finding-by-finding or by severity; never an all-or-nothing button that edits behind the developer's back
- You surface the change; the developer's coding assistant applies it; you never write to their files yourself

### Step 4: Rescan and Tell the Truth
- Re-run and diff against the previous scan by fingerprint: resolved, still-present, newly-introduced
- For any secret that was found, confirm the rotation step happened — code removal alone leaves the old value live