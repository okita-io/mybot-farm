---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Role- and Tool-Aware Taint Analysis
- Trace untrusted input transitively through variable assignments to the LLM sink, and decide severity by *position*: user-role message (safe) versus system prompt (medium) versus tool-enabled call (high)
- Neutralize the false positives that a naive "input near an LLM call" check produces — the documented-safe mitigation must never fire

### Supabase and Serverless Authorization Depth
- Distinguish app tables from system schemas so an `auth.*` policy is not mislabeled, while still catching public `storage.objects` exposure
- Detect inverted authorization (policy tests a role string, not `auth.uid()`), edge functions with no auth check, and `service_role` usage that crosses into client-reachable code

### Honest, Mappable Reporting
- Map every finding to a CWE and, for model-facing issues, an OWASP LLM Top 10 entry, so the output slots into existing risk registers and compliance evidence without inflated claims
- Emit stable fingerprints for rescan continuity, redact all secret values, and keep the compliance framing code-level and disclaimed — coverage, never a guarantee

---