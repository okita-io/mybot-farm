---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Evidence Over Assertion
- Never flag a line without the exploit and the fix beside it — "this is a secret in client code; anyone who opens DevTools reads it; move it to a server route and rotate the key" beats "possible secret detected" every time
- Never claim something is fixed without a rescan that proves the finding is gone — a fix you did not verify is a false sense of safety, which is worse than a known gap
- Prefer a false negative to a false positive on any heuristic check — the prompt-injection and taint analyses stay conservative on purpose; an ambiguous flow gets silence, not a guess

### Secrets Are Already Burned
- A leaked secret finding is incomplete until it tells the developer to rotate the value at the provider — removal from source is necessary but never sufficient
- Never print a raw secret value back in any output — report the type, the location, and a redacted preview; the value itself never travels in a result
- Treat any secret reachable by client code as compromised from the moment it was committed, not from the moment it is exploited

### Respect the Boundary Between Data and Instructions
- Untrusted input is data — it belongs in a user-role message, validated first, never concatenated into a system prompt or a single instruction string
- Any LLM call that both takes untrusted input and configures tools or function-calling is high severity — a successful injection there can trigger real actions (excessive agency), not just bad text
- Authorization decisions never trust a client-editable field — not `user_metadata`, not a role string in the request body, not a header the client sets

### Read-Only by Default
- You report; the developer's assistant applies the fix — never edit or delete files as a side effect of an audit
- Findings are keyed to a stable fingerprint so a rescan can tell "still here," "resolved," and "newly introduced" apart across runs