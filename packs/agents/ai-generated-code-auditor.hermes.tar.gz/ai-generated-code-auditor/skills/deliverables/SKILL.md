---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

The AI-Generated-Code Failure Modes (with fixes)

```typescript
// === Hardcoded secret reaching the client (CWE-798) ===
// VULNERABLE: assistant inlined the key so the example would run.
// In a Next.js client component this ships to every browser.
"use client";
const openai = new OpenAI({ [REDACTED]" }); // burned the moment it committed

// SECURE: the secret lives only in a server route; the client calls your API.
// app/api/chat/route.ts (server, never bundled to the client)
import OpenAI from "openai";
const openai = new OpenAI({ [REDACTED] }); // server-only env, no NEXT_PUBLIC_
export async function POST(req: Request) { /* proxy the call server-side */ }
// ...and rotate sk-proj-REALKEYVALUE at the provider — it is already compromised.


// === Secret behind a client-exposed env prefix (CWE-798) ===
// VULNERABLE: NEXT_PUBLIC_ is inlined into the client bundle by design.
const key = process.env.NEXT_PUBLIC_OPENAI_KEY; // public prefix = public value

// SAFE, and must NOT be flagged: publishable/anon keys are meant to be public.
const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY; // fine — RLS is the real gate
```

```sql
-- === Row-level security that only looks enabled (CWE-862 / CWE-863) ===
-- VULNERABLE: RLS "on", policy allows the whole world.
alter table public.orders enable row level security;
create policy "read" on public.orders for select using ( true );  -- everyone reads every row

-- VULNERABLE: public table, no RLS at all — the anon key reads everything.
create table public.profiles ( id uuid primary key, email text, ssn text );
-- (no enable row level security, no policy)

-- SECURE: RLS on, policy scoped to the authenticated user's identity.
alter table public.orders enable row level security;
create policy "owner reads own orders" on public.orders
  for select using ( auth.uid() = user_id );  -- identity, not a client-settable role
```

```typescript
// === Prompt-injection sink (CWE-1426, OWASP LLM01; +LLM06 with tools) ===
// VULNERABLE: untrusted input concatenated into the system prompt AND tools attached.
const { instruction } = await req.json();
await openai.chat.completions.create({
  model: "gpt-4o",
  messages: [{ role: "system", content: `You are support. ${instruction}` }], // injection point
  tools: [{ type: "function", function: { name: "issueRefund" } }],            // excessive agency
});

// SAFE, and must NOT be flagged: untrusted text in its own user-role message, no tools.
await openai.chat.completions.create({
  model: "gpt-4o",
  messages: [
    { role: "system", content: "You are support." },
    { role: "user", content: userMessage }, // data stays data
  ],
});
```

### Audit Triage Output (worst-first, honest, actionable)

```markdown
## Scan: 7 findings (1 critical, 2 high, 3 medium, 1 low) — local, nothing sent out

1. [CRITICAL] service_role key in client-reachable code — app/lib/supabase.ts:4 (CWE-798)
   Why: the service_role key bypasses RLS entirely; in the client it hands every row to anyone.
   Fix: move to a server route; use the anon key on the client. ROTATE the key in the Supabase dashboard.
2. [HIGH] Public storage bucket — supabase/migrations/0002_avatars.sql:11 (CWE-863)
   Why: `USING (true)` on storage.objects exposes every uploaded file.
   Fix: scope the policy to `auth.uid() = owner`.
3. [MEDIUM] Potential prompt-injection sink — app/api/agent/route.ts:22 (CWE-1426, LLM01+LLM06)
   Why: request input reaches the system prompt on a tool-enabled call. Heuristic — verify manually.
   Fix: move input to a user-role message; gate the tool behind confirmation.
...
Rescan after fixes to confirm what is resolved, what remains, and what is new.
```