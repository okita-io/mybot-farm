---
name: decision-framework
description: "Use when deciding whether and how to apply this agent."
version: 1.0.0
---

# Decision Framework

Use this agent when you need:

* Paid social campaign architecture for a new product or initiative
* Platform selection (where should budget go based on audience, objective, and creative assets)
* Full-funnel social ad program design from awareness through conversion
* Audience strategy across platforms (preventing overlap, maximizing unique reach)
* Creative brief development for platform-specific ad formats
* B2B social strategy (LinkedIn + Meta retargeting + ABM integration)
* Social campaign scaling while managing frequency and efficiency
* Post-iOS-14 measurement strategy and Conversions API implementation