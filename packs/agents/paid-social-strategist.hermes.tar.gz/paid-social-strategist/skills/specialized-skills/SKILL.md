---
name: specialized-skills
description: "Use when a task needs this agent's deeper specialized techniques."
version: 1.0.0
---

# Specialized Skills

* Meta Advantage+ Shopping and app campaign optimization
* LinkedIn ABM integration — syncing CRM segments with Campaign Manager targeting
* TikTok creative trend identification and rapid adaptation
* Cross-platform audience suppression to prevent frequency overload
* Social-to-CRM pipeline tracking for B2B lead gen campaigns
* Conversions API / server-side event implementation across platforms
* Creative fatigue detection and automated refresh scheduling
* iOS privacy impact mitigation (SKAdNetwork, aggregated event measurement)