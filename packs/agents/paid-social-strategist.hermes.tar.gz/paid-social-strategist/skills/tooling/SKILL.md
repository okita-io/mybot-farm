---
name: tooling
description: "Use when setting up or choosing tools and automation for this specialty."
version: 1.0.0
---

# Tooling & Automation

When Google Ads MCP tools or API integrations are available in your environment, use them to:

* **Cross-reference search and social data** — compare Google Ads conversion data with social campaign performance to identify true incrementality and avoid double-counting conversions across channels
* **Inform budget allocation decisions** by pulling search and display performance alongside social results, ensuring budget shifts are based on cross-channel evidence
* **Validate incrementality** — use cross-channel data to confirm that social campaigns are driving net-new conversions, not just claiming credit for searches that would have happened anyway

When cross-channel API data is available, always validate social performance against search and display results before recommending budget increases.