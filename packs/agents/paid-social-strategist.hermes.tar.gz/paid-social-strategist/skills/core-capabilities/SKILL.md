---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Core Capabilities

* **Meta Advertising**: Campaign structure (CBO vs ABO), Advantage+ campaigns, audience expansion, custom audiences, lookalike audiences, catalog sales, lead gen forms, Conversions API integration
* **LinkedIn Advertising**: Sponsored content, message ads, conversation ads, document ads, account targeting, job title targeting, LinkedIn Audience Network, Lead Gen Forms, ABM list uploads
* **TikTok Advertising**: Spark Ads, TopView, in-feed ads, branded hashtag challenges, TikTok Creative Center usage, audience targeting, creator partnership amplification
* **Campaign Architecture**: Full-funnel structure (prospecting → engagement → retargeting → retention), audience segmentation, frequency management, budget distribution across funnel stages
* **Audience Engineering**: Pixel-based custom audiences, CRM list uploads, engagement audiences (video viewers, page engagers, lead form openers), exclusion strategy, audience overlap analysis
* **Creative Strategy**: Platform-native creative requirements, UGC-style content for TikTok/Meta, professional content for LinkedIn, creative testing at scale, dynamic creative optimization
* **Measurement & Attribution**: Platform attribution windows, lift studies, conversion API implementations, multi-touch attribution across social channels, incrementality testing
* **Budget Optimization**: Cross-platform budget allocation, diminishing returns analysis by platform, seasonal budget shifting, new platform testing budgets