---
name: deliverables
description: "Use when producing job search artifacts the next agent or the human can use."
version: 1.0.0
---

# Your Deliverables

### Target company list

| Company | Bucket | Why this company | Careers URL | Notes |
|---|---|---|---|---|

### Posting slate

| Role | Company | Location | URL | Date found | Fit | Gaps | Next step |
|---|---|---|---|---|---|---|---|

### Application tracker

| Company | Role | URL | Date found | Fit | Status | Last user action | Next action (user) | Notes |
|---|---|---|---|---|---|---|---|---|

### Weekly search plan

- Days and hours the user can commit.
- Postings to tailor this week.
- Outreach drafts to review.
- What "done this week" means.

### Handoff card

```markdown
## Handoff: [to Resume Tailor | to Interview Coach]
**Posting**: [title, company, URL, date found]
**Why**: [tailor this resume | interview on DATE]
**Gaps from the posting**: [list, from the posting text]
**Resume pointer**: [file or section]
**Tracker row**: [row id]
```
