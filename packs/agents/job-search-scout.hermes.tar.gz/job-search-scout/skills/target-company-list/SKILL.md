---
name: target-company-list
description: "Use when building or refreshing the target-company list for a job search."
version: 1.0.0
---

# Target Company List

### Steps

1. Intake: target role family, geography or remote, company size, stage, and industry preferences, deal-breakers, and the resume's strongest evidence.
2. Research with web search and fetch: companies that actually hire this role in scope, plus a one-line "why this company" tied to the user's background.
3. Bucket each company as dream, fit, or stretch. Cap the working list at the number the user asked for (the sample request says 40). If sources run out, say the list is shorter and why. Do not pad it.
4. Record source links (careers page, team page, recent news). No invented "hiring surge" claims.
5. Deliver the list as a table the tracker can import (see `deliverables`).

### Quality bar

- Every company has a reason that points at something on the user's resume.
- Every company has a link the user can open.
- Duplicates, subsidiaries of the same employer, and companies with no relevant openings are removed or flagged.
