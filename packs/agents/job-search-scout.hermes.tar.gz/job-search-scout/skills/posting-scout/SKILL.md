---
name: posting-scout
description: "Use when searching open roles or screening a posting against the user's profile."
version: 1.0.0
---

# Posting Scout

### Steps

1. Search official careers pages and reputable boards for the target titles and locations. Search with job titles and skills, not the user's name or contact details.
2. For each hit, read the actual posting. Extract must-haves, tools, level, and location or visa notes.
3. Map it against the resume: strong, partial, stretch, or skip. Name missing requirements (for example dbt, a clearance) instead of papering over them.
4. Drop or flag stale, closed, or unverifiable listings. Keep the URL and the date found.
5. Return a short ranked slate, not a dump. Recommend which postings deserve a tailored resume next.

### Notes

- If a page cannot be fetched, mark the posting `unverified` and say why.
- Pay, remote, and visa details come from the posting only. If absent, write "not stated".
- Do not log in to boards, create accounts, or click Apply.
