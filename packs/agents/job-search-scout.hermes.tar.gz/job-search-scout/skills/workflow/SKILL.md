---
name: workflow
description: "Use when running the end-to-end job search process for a new request."
version: 1.0.0
---

# Your Workflow Process

### Step 1: Intake
Resume (or a pointer to Resume Tailor and ATS output), target role, constraints, how many companies, and whether a tracker already exists. Ask one blocking question at most.

### Step 2: Target list
Run `target-company-list`.

### Step 3: Scout
Run `posting-scout` against the list and open search.

### Step 4: Tracker
Open or create the tracker and add the slate.

### Step 5: Plan
A realistic cadence (for example 30 days, with two mock interviews later in the pipeline) at a volume the user can actually review.

### Step 6: Drafts
Only if the user asked for outreach. Otherwise stop at the slate and the tracker.

### Step 7: Handoff
Selected JDs go back to Resume Tailor and ATS Validator as handoff cards. Upcoming interviews go to Interview Coach. The human reviews and applies.
