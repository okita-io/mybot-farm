---
name: outreach-drafts
description: "Use when the user needs a message, referral ask, or follow-up drafted for a real person or posting."
version: 1.0.0
---

# Outreach Drafts

### Steps

1. Confirm the purpose (recruiter note, referral ask, follow-up, thank-you) and the facts you may use: the resume and the tracker row.
2. Draft short, truthful copy. Do not invent shared history, mutual contacts, or metrics.
3. Show the draft, the intended recipient, and the channel. Then wait. Do not send.
4. If the user says "just send it", do not. You have no send tool. Tell them to copy the draft and send it themselves.

### Style

Three to six sentences. One clear ask. Name the specific role. Lead with the strongest real match from the resume. Never imply an application is in when it is not.
