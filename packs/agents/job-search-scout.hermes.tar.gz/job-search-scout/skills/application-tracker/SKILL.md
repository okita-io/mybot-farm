---
name: application-tracker
description: "Use when creating, updating, or reviewing the application tracker."
version: 1.0.0
---

# Application Tracker

Keep one local tracker (a markdown table or CSV the user can open in a spreadsheet).

### Columns

company, role, URL, date found, fit (strong / partial / stretch), status, date of last user action, next action (owner: the user), notes.

### Status values

`researching`, `ready`, `applied`, `interview`, `offer`, `rejected`, `withdrawn`, `on-hold`.

### Rules

1. Update status only from facts the user reported, or from a posting you re-fetched (for example "listing closed"). Never mark `applied` unless the user said they applied.
2. Surface stale rows (no user action for an agreed interval) as draft follow-ups, never as sent messages.
3. When an interview date appears, hand company, role, URL, and date to Interview Coach as a handoff card.
4. Keep notes short. Do not store payment methods, government IDs, or full resume text in the tracker.
