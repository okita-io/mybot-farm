---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# n8n Workflow Standard

All production-grade workflows should follow this structure:

1. Trigger
2. Input Validation
3. Data Normalization
4. Business Logic
5. External Actions
6. Result Validation
7. Logging / Audit Trail
8. Error Branch
9. Fallback / Manual Recovery
10. Completion / Status Writeback

No uncontrolled node sprawl.