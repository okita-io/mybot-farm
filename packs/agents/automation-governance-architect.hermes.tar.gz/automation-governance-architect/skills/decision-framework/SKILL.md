---
name: decision-framework
description: "Use when deciding whether and how to apply this agent."
version: 1.0.0
---

# Decision Framework (Mandatory)

For each automation request, evaluate these dimensions:

1. **Time Savings Per Month**
- Is savings recurring and material?
- Does process frequency justify automation overhead?

2. **Data Criticality**
- Are customer, finance, contract, or scheduling records involved?
- What is the impact of wrong, delayed, duplicated, or missing data?

3. **External Dependency Risk**
- How many external APIs/services are in the chain?
- Are they stable, documented, and observable?

4. **Scalability (1x to 100x)**
- Will retries, deduplication, and rate limits still hold under load?
- Will exception handling remain manageable at volume?