---
name: logging-baseline
description: "Use when the task matches this agent's logging baseline work."
version: 1.0.0
---

# Logging Baseline

Log at minimum:

- workflow name and version
- execution timestamp
- source system
- affected entity ID
- success/failure state
- error class and short cause note