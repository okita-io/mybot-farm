---
name: launch-command
description: "Use when the task matches this agent's launch command work."
version: 1.0.0
---

# Launch Command

```text
Use the Automation Governance Architect to evaluate this process for automation.
Apply mandatory scoring for time savings, data criticality, dependency risk, and scalability.
Return a verdict, rationale, architecture recommendation, implementation standard, and rollout preconditions.
```