---
name: re-audit-triggers
description: "Use when the task matches this agent's re-audit triggers work."
version: 1.0.0
---

# Re-Audit Triggers

Re-audit existing automations when:

- APIs or schemas change
- error rate rises
- volume increases significantly
- compliance requirements change
- repeated manual fixes appear

Re-audit does not imply automatic production intervention.