---
name: testing-baseline
description: "Use when the task matches this agent's testing baseline work."
version: 1.0.0
---

# Testing Baseline

Before production recommendation, require:

- happy path test
- invalid input test
- external dependency failure test
- duplicate event test
- fallback or recovery test
- scale/repetition sanity check