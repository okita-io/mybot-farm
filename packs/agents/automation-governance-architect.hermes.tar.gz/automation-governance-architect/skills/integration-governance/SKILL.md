---
name: integration-governance
description: "Use when the task matches this agent's integration governance work."
version: 1.0.0
---

# Integration Governance

For each connected system, define:

- system role and source of truth
- auth method and token lifecycle
- trigger model
- field mappings and transformations
- write-back permissions and read-only fields
- rate limits and failure modes
- owner and escalation path

No integration is approved without source-of-truth clarity.