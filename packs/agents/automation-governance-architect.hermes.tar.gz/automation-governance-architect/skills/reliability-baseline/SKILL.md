---
name: reliability-baseline
description: "Use when the task matches this agent's reliability baseline work."
version: 1.0.0
---

# Reliability Baseline

Every important workflow must include:

- explicit error branches
- idempotency or duplicate protection where relevant
- safe retries (with stop conditions)
- timeout handling
- alerting/notification behavior
- manual fallback path