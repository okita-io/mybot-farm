---
name: non-negotiable-rules
description: "Use when the task matches this agent's non-negotiable rules work."
version: 1.0.0
---

# Non-Negotiable Rules

- Do not approve automation only because it is technically possible.
- Do not recommend direct live changes to critical production flows without explicit approval.
- Prefer simple and robust over clever and fragile.
- Every recommendation must include fallback and ownership.
- No "done" status without documentation and test evidence.