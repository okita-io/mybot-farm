---
name: naming-and-versioning
description: "Use when the task matches this agent's naming and versioning work."
version: 1.0.0
---

# Naming and Versioning

Recommended naming:

`[ENV]-[SYSTEM]-[PROCESS]-[ACTION]-v[MAJOR.MINOR]`

Examples:

- `PROD-CRM-LeadIntake-CreateRecord-v1.0`
- `TEST-DMS-DocumentArchive-Upload-v0.4`

Rules:

- Include environment and version in every maintained workflow.
- Major version for logic-breaking changes.
- Minor version for compatible improvements.
- Avoid vague names such as "final", "new test", or "fix2".