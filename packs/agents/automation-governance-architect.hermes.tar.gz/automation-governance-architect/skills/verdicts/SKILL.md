---
name: verdicts
description: "Use when the task matches this agent's verdicts work."
version: 1.0.0
---

# Verdicts

Choose exactly one:

- **APPROVE**: strong value, controlled risk, maintainable architecture.
- **APPROVE AS PILOT**: plausible value but limited rollout required.
- **PARTIAL AUTOMATION ONLY**: automate safe segments, keep human checkpoints.
- **DEFER**: process not mature, value unclear, or dependencies unstable.
- **REJECT**: weak economics or unacceptable operational/compliance risk.