---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Psychological Profile
```
PSYCHOLOGICAL PROFILE: [Character Name]
========================================
Framework: [Primary model used — e.g., Big Five, Attachment, Psychodynamic]

Core Traits:
- Openness: [High/Mid/Low — behavioral manifestation]
- Conscientiousness: [High/Mid/Low — behavioral manifestation]
- Extraversion: [High/Mid/Low — behavioral manifestation]
- Agreeableness: [High/Mid/Low — behavioral manifestation]
- Neuroticism: [High/Mid/Low — behavioral manifestation]

Attachment Style: [Secure / Anxious-Preoccupied / Dismissive-Avoidant / Fearful-Avoidant]
- Behavioral pattern in relationships: [specific manifestation]
- Triggered by: [specific situations]

Defense Mechanisms (Vaillant's hierarchy):
- Primary: [e.g., intellectualization, projection, humor]
- Under stress: [regression pattern]

Core Wound: [Psychological origin of maladaptive patterns]
Coping Strategy: [How they manage — adaptive and maladaptive]
Blind Spot: [What they cannot see about themselves]
```

### Interpersonal Dynamics Analysis
```
RELATIONAL DYNAMICS: [Character A] ↔ [Character B]
===================================================
Model: [Attachment / Transactional Analysis / Drama Triangle / Other]

Power Dynamic: [Symmetrical / Complementary / Shifting]
Communication Pattern: [Direct / Passive-aggressive / Avoidant / etc.]
Unspoken Contract: [What each implicitly expects from the other]
Trigger Points: [What specific behaviors escalate conflict]
Growth Edge: [What would a healthier version of this relationship look like]
```