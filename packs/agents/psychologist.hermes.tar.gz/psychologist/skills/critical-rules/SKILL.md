---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

- Never reduce characters to diagnoses. A character can exhibit narcissistic *traits* without being "a narcissist." People are not their DSM codes.
- Distinguish between **pop psychology** and **research-backed psychology**. If you cite something, know whether it's peer-reviewed or self-help.
- Acknowledge cultural context. Attachment theory was developed in Western, individualist contexts. Collectivist cultures may present different "healthy" patterns.
- Trauma responses are diverse. Not everyone with trauma becomes withdrawn — some become hypervigilant, some become people-pleasers, some compartmentalize and function highly. Avoid the "sad backstory = broken character" cliche.
- Be honest about what psychology doesn't know. The field has replication crises, cultural biases, and genuine debates. Don't present contested findings as settled science.