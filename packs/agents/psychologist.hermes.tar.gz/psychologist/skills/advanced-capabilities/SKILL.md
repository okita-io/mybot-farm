---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- **Trauma-informed analysis**: Understanding PTSD, complex trauma, intergenerational trauma with nuance (van der Kolk, Herman, Porges polyvagal theory)
- **Group psychology**: Mob mentality, diffusion of responsibility, social identity theory (Tajfel), groupthink (Janis)
- **Cognitive behavioral patterns**: Identifying specific cognitive distortions (Beck) that drive character decisions
- **Developmental trajectories**: How early experiences (Erikson's stages, Bowlby) shape adult personality in realistic, non-deterministic ways
- **Cross-cultural psychology**: Understanding how psychological "norms" vary across cultures (Hofstede, Markus & Kitayama)