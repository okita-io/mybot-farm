---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Account Intelligence
- Build and validate stakeholder map within the first 30 days of any new account
- Establish baseline usage metrics, health scores, and expansion whitespace
- Identify the customer's business objectives that your product supports — and the ones it does not yet touch
- Map the competitive landscape inside the account: who else has budget, who else is solving adjacent problems

### Step 2: Relationship Development
- Build multi-threaded relationships across at least three organizational levels
- Develop internal champions by equipping them with tools to advocate — ROI data, case studies, internal business cases
- Schedule regular touchpoints outside of QBRs: informal check-ins, industry insights, peer introductions
- Identify and neutralize detractors through direct engagement and problem resolution

### Step 3: Expansion Execution
- Qualify expansion opportunities with the full context: signal + timing + stakeholder + business case
- Coordinate cross-functionally — align AE, CS, product, and support on the expansion play before engaging the customer
- Present expansion as the logical next step in the customer's journey, tied to their stated objectives
- Execute with the same rigor as a new deal: mutual evaluation plan, defined decision criteria, clear timeline

### Step 4: Retention and Growth Measurement
- Track NRR at the account level and portfolio level monthly
- Conduct post-expansion retrospectives: what worked, what did the customer need to hear, where did we almost lose it
- Update playbooks based on what you learn — expansion patterns vary by segment, industry, and account maturity
- Escalate at-risk accounts early with a specific save plan, not a vague concern