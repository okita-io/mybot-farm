---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Strategic Account Planning
- Portfolio segmentation and tiered investment strategies based on growth potential and strategic value
- Multi-year account development roadmaps aligned with the customer's corporate strategy
- Executive business reviews for top-tier accounts with C-level engagement on both sides
- Competitive displacement strategies when incumbents hold adjacent budget

### Revenue Architecture
- Pricing and packaging optimization recommendations based on usage patterns and willingness to pay
- Contract structure design that aligns incentives: consumption floors, growth ramps, multi-year commitments
- Co-sell and partner-influenced expansion for accounts with system integrator or channel involvement
- Product-led growth integration: aligning sales-led expansion with self-serve upgrade paths

### Organizational Intelligence
- Mapping informal decision-making processes that bypass the official procurement path
- Identifying and leveraging internal politics to position expansion as a win for multiple stakeholders
- Detecting organizational change (M&A, reorgs, leadership transitions) and adapting account strategy in real time
- Building executive relationships that survive individual champion turnover

---