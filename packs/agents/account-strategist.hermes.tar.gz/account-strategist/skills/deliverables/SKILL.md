---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Account Expansion Plan
```markdown
# Account Expansion Plan: [Account Name]

## Account Overview
- **Current ARR**: [Annual recurring revenue]
- **Contract Renewal**: [Date and terms]
- **Health Score**: [Green/Yellow/Red with rationale]
- **Products Deployed**: [Current product footprint]
- **Whitespace**: [Products/modules not yet adopted]

## Stakeholder Map
| Name | Title | Role | Influence | Sentiment | Last Contact |
|------|-------|------|-----------|-----------|--------------|
| [Name] | [Title] | Champion | High | Positive | [Date] |
| [Name] | [Title] | Economic Buyer | High | Neutral | [Date] |
| [Name] | [Title] | End User | Medium | Positive | [Date] |
| [Name] | [Title] | Detractor | Medium | Negative | [Date] |

## Expansion Opportunities
| Opportunity | Trigger Signal | Business Case | Timing | Owner | Stage |
|------------|----------------|---------------|--------|-------|-------|
| [Upsell/Cross-sell] | [Usage data, request, event] | [Customer value] | [Q#] | [Rep] | [Discovery/Proposal/Negotiation] |

## RACI Matrix
| Activity | Responsible | Accountable | Consulted | Informed |
|----------|-------------|-------------|-----------|----------|
| Champion enablement | AE | Account Strategist | CS | Sales Mgmt |
| Usage monitoring | CS | Account Strategist | Product | AE |
| QBR facilitation | Account Strategist | AE | CS, Product | Exec Sponsor |
| Contract negotiation | AE | Sales Mgmt | Legal | Account Strategist |

## Mutual Action Plan
| Action Item | Owner (Us) | Owner (Customer) | Due Date | Status |
|-------------|-----------|-------------------|----------|--------|
| [Action] | [Name] | [Name] | [Date] | [Status] |
```

### QBR Preparation Framework
```markdown
# QBR Preparation: [Account Name] — [Quarter]

## Pre-QBR Research
- **Usage Trends**: [Key metrics, adoption curves, capacity utilization]
- **Support History**: [Ticket volume, CSAT, escalations, resolution themes]
- **ROI Data**: [Quantified value delivered — specific numbers, not estimates]
- **Industry Context**: [Customer's market conditions, competitive pressures, strategic shifts]

## Agenda (60 minutes)
1. **Value Delivered** (15 min): ROI recap with hard numbers
2. **Their Roadmap** (20 min): Where is the business going? What challenges are ahead?
3. **Product Alignment** (15 min): How we evolve together — tied to their priorities
4. **Mutual Action Plan** (10 min): Commitments, owners, next steps

## Questions to Ask
- "What are the top three business priorities for the next two quarters?"
- "Where are you spending time on manual work that should be automated?"
- "Who else in the organization is trying to solve similar problems?"
- "What would make you confident enough to expand our partnership?"

## Stakeholder Validation
- **Attending**: [Confirm attendees and roles]
- **Missing**: [Who should be there but isn't — and why]
- **New Faces**: [Anyone new to map and develop]
```

### Churn Prevention Playbook
```markdown
# Churn Prevention: [Account Name]

## Early Warning Signals
| Signal | Current State | Threshold | Severity |
|--------|--------------|-----------|----------|
| Monthly active users | [#] | <[#] = risk | [High/Med/Low] |
| Feature adoption (core) | [%] | <50% = risk | [High/Med/Low] |
| Executive sponsor engagement | [Last contact] | >60 days = risk | [High/Med/Low] |
| Support ticket sentiment | [Score] | <3.5 = risk | [High/Med/Low] |
| Champion status | [Active/At risk/Departed] | Departed = critical | [High/Med/Low] |

## Intervention Plan
- **Immediate** (this week): [Specific actions to stabilize]
- **Short-term** (30 days): [Rebuild engagement and demonstrate value]
- **Medium-term** (90 days): [Re-establish strategic alignment and growth path]

## Risk Assessment
- **Probability of churn**: [%] with rationale
- **Revenue at risk**: [$]
- **Save difficulty**: [Low/Medium/High]
- **Recommended investment to save**: [Hours, resources, executive involvement]
```