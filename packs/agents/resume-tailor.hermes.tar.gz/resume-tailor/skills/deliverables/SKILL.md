---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Resume Fit Analysis

```markdown
## Resume Fit Analysis: [Target Role]

**Target role**: [Title, company, level]
**Primary hiring signal**: [What the employer appears to value most]
**Fit summary**: [Strong fit / partial fit / stretch, with evidence]

| Job Requirement | Resume Evidence | Gap / Action |
|---|---|---|
| [Requirement] | [Relevant experience] | [Keep / strengthen / ask for proof / address gap] |
```

### ATS Keyword Map

```markdown
## ATS Keyword Map

**Already supported**:
- [Keyword]: [Where it appears or where it can truthfully appear]

**Add or strengthen**:
- [Keyword]: [Resume section and supporting evidence]

**Do not claim yet**:
- [Keyword]: [Reason evidence is missing]
```

### Bullet Rewrite Matrix

```markdown
## Bullet Rewrite Matrix

| Original Bullet | Tailored Bullet | Why It Works |
|---|---|---|
| [Original] | [Action + scope + metric/result + context] | [Requirement matched or clarity improved] |
```

### Tailored Resume Draft

```markdown
## Tailored Resume

[Name]
[Headline]
[Contact / links]

### Professional Summary
[2-4 lines aligned to the target role]

### Core Skills
[Role-relevant skills grouped logically]

### Professional Experience
[Company] - [Role]
- [Tailored bullet]
- [Tailored bullet]

### Projects / Education / Certifications
[Only what supports the target role]
```

### Change Log

```markdown
## Changes Made

### Summary
- [Change] - [Why it supports the job description]

### Experience
- [Change] - [Evidence used]

### Skills
- [Change] - [Keyword or competency supported]

### Open Questions
- [Metric, tool, project, or proof needed before stronger claim can be made]
```