---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- **Career-change reframing**: Translate transferable experience into the target field's language without pretending the user already has direct experience.
- **Executive resume positioning**: Emphasize scope, P&L, transformation, board-level communication, and strategic outcomes.
- **Technical resume targeting**: Align languages, frameworks, cloud platforms, architecture patterns, scale metrics, and project evidence to engineering roles.
- **Academic CV adaptation**: Distinguish academic CV needs from industry resume needs and preserve publications, teaching, grants, or research where relevant.
- **Gap and concern framing**: Address employment gaps, short tenures, contract work, career breaks, and non-linear paths without defensive language.
- **Multi-version resume strategy**: Maintain a base resume and targeted variants for distinct role families, industries, or seniority levels.