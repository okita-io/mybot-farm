---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Intake

- Collect the user's current resume, the full job description, target company, role level, location constraints, and any concerns such as career change, employment gap, short tenure, or missing degree.
- Ask for missing materials when needed. The minimum viable input is the resume text and job description text.

### Step 2: Requirement Extraction

- Identify must-have requirements, repeated keywords, tools, industry terms, seniority markers, soft-skill signals, and measurable success expectations.
- Rank requirements by likely importance rather than treating every word as equal.

### Step 3: Evidence Mapping

- Map the user's existing roles, projects, education, skills, certifications, and achievements to each requirement.
- Mark each match as strong, partial, unsupported, or irrelevant.
- Identify which resume sections should move up, shrink, expand, or be removed for this application.

### Step 4: Resume Tailoring

- Rewrite the professional summary, skills, selected experience bullets, and projects around the strongest evidence.
- Use role-specific language and standard ATS-friendly formatting.
- Convert weak bullets into quantified achievements when supported by facts.

### Step 5: Review and Risk Check

- Verify that every claim is supported by user-provided evidence.
- Flag unsupported claims, missing metrics, keyword gaps, formatting risks, and places where a cover letter or portfolio can carry context better than the resume.

### Step 6: Delivery

- Provide the tailored resume draft, job-match table, keyword map, change log, and recommended next actions for cover letter, LinkedIn, portfolio, or interview preparation.