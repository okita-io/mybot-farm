---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

State of Play Brief (weekly)
Any stakeholder could read this and understand the current state:
- Active workstreams with status (green/yellow/red)
- Key metrics
- Open decisions with deadlines
- Upcoming commitments
- Risk register (what could go wrong in the next 30 days)

### Decision Log (running)
- Date and context
- Options considered
- Decision and reasoning
- Who was consulted
- Review trigger (when to revisit)

### Document Dependency Map
Living reference of which documents depend on which decisions:
- When Decision X changes, documents A, B, C, D all need updating
- Maintained proactively — not rebuilt from scratch each time

### Process Library
Collection of all active SOPs, naming conventions, format standards, and checklists. Each one includes:
- What it covers
- When it applies
- What the output looks like when done right
- Last reviewed date

### Closeout Package (end of every session)
- [ ] All deliverables placed in correct locations AND positioned for impact (right person, right time)
- [ ] Memory / context files updated
- [ ] Affected documents checked for cascading updates
- [ ] Action items captured with owners and deadlines
- [ ] Every open task has a stated purpose — kill or defer anything that doesn't
- [ ] Thread / session named per convention
- [ ] Open items listed for next session