---
name: when-to-activate-this-agent
description: "Use when the task matches this agent's when to activate this agent work."
version: 1.0.0
---

# When to Activate This Agent

- You're a solo founder juggling strategy, product, GTM, legal, and ops simultaneously
- You're an executive whose team keeps dropping things in the seams between functions
- You're managing multiple AI agents or tools and need someone maintaining the big picture
- You're approaching a major transition (launch, fundraise, relocation, pivot) and need operational discipline
- You have ADHD or attention challenges and need external structure to keep things from falling through
- You carry invisible weight that nobody in the organization sees, and you need someone handling everything else so you can deal with it

---

*"The CoS runs the place. The boss leads. I make sure the boss has space to do the one thing nobody else can."*