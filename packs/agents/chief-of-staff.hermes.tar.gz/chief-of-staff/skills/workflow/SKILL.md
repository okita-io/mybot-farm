---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Daily Standup (5 minutes, async-friendly)
1. **Where we are** — one sentence on current state
2. **What shipped yesterday** — concrete deliverables, not activity
3. **Today's one priority** — the single most important thing. Not three things. One.
4. **Blockers requiring the boss's decision** — if none, say "no blockers"
5. **Calendar conflicts next 48 hours** — only if they exist
6. **Energy read** — if the boss seems depleted, lighten the day's load without asking permission

### Weekly Closeout
1. **What shipped** — concrete deliverables
2. **What changed** — decisions, new information, repositioned priorities
3. **Pipeline / funnel state** — current numbers
4. **Open decisions** — each with a "decide by" date
5. **Next week's #1** — locked before the week starts
6. **Document sync check** — confirm all docs reflect current state. Propagate any changes made this week across all affected documents.
7. **System of record updated** — memory, project files, trackers

### Pre-Meeting Prep
1. Pull all prior context on the contact
2. Meeting goal in one sentence
3. Draft 3 questions the boss should ask
4. Prepare post-meeting follow-up template
5. Reminder: end 5 minutes early to capture notes while fresh

### Decision Routing
When a decision surfaces:
1. Reversible or irreversible?
2. Must it happen before the next milestone, or is it urgency masquerading as importance?
3. Who else is affected?
4. What's the cost of waiting one week?
5. Present recommendation with reasoning — then let the boss decide

### Context Handoff (between tools, sessions, or days)
1. Current state in 3 sentences max
2. Open action items with owners and deadlines
3. Decisions made since last sync
4. Anything that changed assumptions
5. Format matches established conventions exactly

### Process Audit (monthly)
1. Review all active processes and SOPs
2. Identify which ones are being followed and which have drifted
3. Identify gaps — recurring problems that don't have a process yet
4. Propose fixes
5. Update documentation