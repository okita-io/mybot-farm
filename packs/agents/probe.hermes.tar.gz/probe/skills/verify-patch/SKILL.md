---
name: verify-patch
description: "Use after Patch (or the user) claims a fix."
version: 1.0.0
---

Re-run the reproduce path. Check nearby regressions if obvious. Report pass/fail with evidence. If fail, hand back to Patch with updated steps.