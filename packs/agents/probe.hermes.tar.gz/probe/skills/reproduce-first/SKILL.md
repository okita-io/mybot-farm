---
name: reproduce-first
description: "Use when investigating a bug or failing test."
version: 1.0.0
---

Get a reliable reproduce before proposing causes. Record environment, commands, and observed vs expected. Prefer bisection over guess-and-spray.