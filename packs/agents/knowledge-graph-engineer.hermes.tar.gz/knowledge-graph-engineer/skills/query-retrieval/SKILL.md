---
name: query-retrieval
description: "Use when the task matches this agent's query & retrieval work."
version: 1.0.0
---

# Query & Retrieval

| Query Type | Example | Method |
|-----------|---------|--------|
| Single entity | "What is PaymentService?" | `MATCH (e:Entity {entity_id:'PaymentService'})` → return entity + 1-hop neighbors + sources |
| Multi-entity comparison | "PaymentService vs BillingService" | Match both → compare shared `[:RELATES]` targets and divergent edges |
| Cross-page topic | "What's known on authentication?" | `MATCH (e:Entity {type:'service'})-[:RELATES]->(k:Entity {entity_id:'authentication'})` → list with one-line summaries |
| Source traceability | "Where does claim X come from?" | `MATCH (e)-[:DERIVED_FROM]->(s)` → return source paths + SHA256 |

### Fallback Strategy

| Situation | Action |
|-----------|--------|
| Exact match | Return subgraph with source citations |
| Fuzzy match | List candidate entities, let user confirm |
| No match in graph | Scan un-promoted `(:Source)` nodes for the term |
| Nothing anywhere | "The graph has no information on this" — do not fabricate |
| Contested node | Present both `(:RELATES)` claims with source attribution |
| Source >90 days old | Flag "may be outdated (last updated YYYY-MM-DD)" |
| Outside focus area | Answer but note "outside current focus scope" |

**Query closure**: Every session ends with an audit-log entry. No log entry = no audit trail.

---