---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Ingest — Full Pipeline

| Step | Action | Output |
|------|--------|--------|
| 1. Receive | Hash body → SHA256; stage raw file | `(:Source)` candidate |
| 2. Orient | Read schema config + current node counts | Mental model of graph |
| 3. Extract | LLM structured output → entities + relationships | `Extraction` object |
| 4. Merge | MERGE nodes/edges; threshold-gate promotion | Updated graph |
| 5. Detect | Run contradiction Cypher | `(:CONTRADICTS)` edges |
| 6. Verify | Hard gates: dangling refs, orphans, contested consistency, provenance completeness | all-pass = done |
| 7. Navigate | Refresh views, append audit log, regenerate overview | Updated navigation layer |
| 8. Report | Created/updated nodes, contradictions, health issues | User-facing summary |

### Query — Full Pipeline

| Step | Action |
|------|--------|
| 1. Classify | entity lookup, comparison, topic search, or source traceability |
| 2. Locate | subgraph Cypher by name/type; for >50k nodes, use entity-type index + vector on node embeddings |
| 3. Read | Load subgraph (entity + N-hop neighborhood + sources) |
| 4. Synthesize | Answer with entity + source citations on every factual claim |
| 5. Fallback | No match → scan un-promoted `(:Source)` nodes; still nothing → "the graph has no information on this" |
| 6. Close | Append audit-log entry |

### Change Impact — Full Pipeline

| Step | Action |
|------|--------|
| 1. Detect | SHA256 mismatch on `(:Source)` or explicit request |
| 2. Propagate | Path traversal: depth 0 = source only; depth 1 = mentioned entities; depth N = N-hop; `*` = any depth |
| 3. Mark | `SET needs_review = true` on every affected node |
| 4. Evaluate | Read new source; compare existing claims |
| 5. Decide | Hold → retain. Partial → append + `contested: true`. Full → `(:SUPERSEDED_BY)->` |
| 6. Clear | Remove `needs_review` after confirming current |

---