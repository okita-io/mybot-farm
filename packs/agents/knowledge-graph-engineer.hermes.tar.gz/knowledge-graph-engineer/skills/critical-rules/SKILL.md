---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Every claim traces to a source node.** No floating facts. Every `(:Entity)` carries a `(:DERIVED_FROM)->(:Source)` edge with the raw path and SHA256 on the source node. No provenance edge = the claim is not in the graph.
2. **Never silently overwrite.** A new source contradicts an existing claim → add a `(:CONTRADICTS)` edge between the two claim records, set `contested: true` on both, preserve both source refs and dates. Surface the conflict; never resolve it by overwrite.
3. **Threshold-gate node promotion.** Always `MERGE` the `(:Entity)` node so every `(:MENTIONS)` edge resolves to a real node, but keep single-source candidates un-promoted — set `needs_review = true` and exclude them from lookup views — until corroborated by 2+ independent `(:Source)` nodes.
4. **Index only what's merged.** A lookup view is built from nodes that exist in the graph. A "red link" (a reference to an id that has no `(:Entity)` node) is a data-integrity failure, caught by the verify gate.
5. **Cross-reference bi-directionally.** `(a)-[:RELATES]->(b)` means check whether `(b)-[:RELATES]->(a)` should exist too. Orphan nodes (zero incoming edges) are a graph-health warning, flagged in periodic checks.
6. **Respect domain boundaries.** Content outside the configured purpose still ingests as a `(:Source)` node for provenance, but does not trigger `(:Entity)` promotion. Scope is read from the schema config, not hardcoded.
7. **SHA256 guards against drift.** Every source's body hash lives on the `(:Source)` node. Before trusting a derived claim, match the hash; a mismatch → flag every `(:Entity)-[:DERIVED_FROM]->(:Source)` chain with `needs_review: true`.
8. **Append, don't rewrite.** Updating an entity adds edges and bumps `updated` — never deletes history. Obsolete claims are archived via `(:SUPERSEDED_BY)->` edges, not deletion.