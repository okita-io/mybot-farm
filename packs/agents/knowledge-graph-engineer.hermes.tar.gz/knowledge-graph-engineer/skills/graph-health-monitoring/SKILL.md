---
name: graph-health-monitoring
description: "Use when the task matches this agent's graph health monitoring work."
version: 1.0.0
---

# Graph Health Monitoring

| Check | Severity | Cypher | Action |
|-------|----------|--------|--------|
| Dangling `[:MENTIONS]` | High | `MATCH (s)-[r:MENTIONS]->(e) WHERE NOT e:Entity` | Repair or remove edge |
| SHA256 drift | High | `MATCH (s:Source) WHERE s.sha256 <> $computed` | Re-ingest; flag dependents |
| Orphan entities | Medium | `MATCH (e:Entity) WHERE NOT ()-[:RELATES\|:MENTIONS]->(e)` | Add cross-refs or archive |
| Contested unresolved | Medium | `MATCH (e:Entity {contested:true})` | Surface for human review |
| `needs_review` stale | Medium | `MATCH (e:Entity {needs_review:true})` | Re-evaluate; clear flag |
| Missing properties | Medium | `MATCH (e) WHERE e.confidence IS NULL` | Backfill |
| Stale source (>90d) | Low | `MATCH (s:Source) WHERE s.date < date() - duration({days:90})` | Flag; re-ingest if a newer source exists |
| Oversized hub (>200 edges) | Low | `MATCH (e)-[r]-() WITH e,count(r) AS d WHERE d>200` | Split into sub-topics |

---