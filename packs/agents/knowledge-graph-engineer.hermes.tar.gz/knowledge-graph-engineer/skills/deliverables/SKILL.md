---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# ️ Your Technical Deliverables

Neo4j Graph Schema

```cypher
// Uniqueness constraints (also serve as lookup indexes)
CREATE CONSTRAINT entity_unique IF NOT EXISTS
FOR (e:Entity) REQUIRE e.entity_id IS UNIQUE;

CREATE CONSTRAINT source_unique IF NOT EXISTS
FOR (s:Source) REQUIRE s.sha256 IS UNIQUE;

// Filter indexes for common query patterns
CREATE INDEX entity_type       IF NOT EXISTS FOR (e:Entity) ON (e.type);
CREATE INDEX entity_confidence IF NOT EXISTS FOR (e:Entity) ON (e.confidence);
CREATE INDEX source_date       IF NOT EXISTS FOR (s:Source) ON (s.date);
```

Node model:
- `(:Entity {entity_id, name, type, confidence, contested, needs_review, created, updated, source_count})`
- `(:Source {sha256, title, url, date, raw_path})`

Relationship model:
- `(:Source)-[:MENTIONS {confidence}]->(:Entity)` — extraction edge
- `(:Entity)-[:RELATES {type, confidence, claim, source_sha, created}]->(:Entity)` — typed relationship
- `(:Entity)-[:CONTRADICTS {sources, claims, detected}]->(:Entity)` — flagged conflict
- `(:Entity)-[:SUPPORTS]->(:Entity)` — corroboration
- `(:Entity)-[:DERIVED_FROM]->(:Source)` — provenance
- `(:Entity)-[:SUPERSEDED_BY]->(:Entity)` — append-only history (the superseded node is preserved)

### Entity & Relationship Extraction (Langchain structured output)

```python
from pydantic import BaseModel, Field
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate

class Extraction(BaseModel):
    entities: list[dict] = Field(description="name, type, confidence 0..1")
    relationships: list[dict] = Field(description="subject, object, type, confidence, claim")

llm = ChatOpenAI(model="gpt-4o-mini")
extractor = llm.with_structured_output(Extraction)

prompt = ChatPromptTemplate.from_messages([
    ("system", "Extract entities and typed relationships from the text. "
               "Assign confidence 0..1 based on how explicitly the text supports each claim. "
               "Only extract claims the text directly states — never infer."),
    ("human", "{text}"),
])
extract_chain = prompt | extractor
```

### MERGE Ingestion with Provenance (append-only)

```python
from neo4j import AsyncGraphDatabase

async def ingest(extraction: Extraction, source: dict, driver):
    """MERGE entities, source, and typed edges — append-only, never overwrite."""
    rels = [{**r, "source_sha": source["sha256"]} for r in extraction.relationships]
    async with driver.session() as s:
        # Threshold-gated entity promotion: always MERGE entity, flag single-source
        await s.run("""
            MERGE (src:Source {sha256: $source.sha256})
              ON CREATE SET src.title=$source.title, src.date=$source.date,
                            src.url=$source.url, src.raw_path=$source.raw_path
            UNWIND $entities AS ent
            MERGE (e:Entity {entity_id: ent.name})
              ON CREATE SET e.type=ent.type, e.confidence=ent.confidence,
                            e.contested=false, e.needs_review=false,
                            e.created=date(), e.updated=date(), e.source_count=1
              ON MATCH  SET e.source_count=e.source_count+1,
                            e.confidence=CASE WHEN ent.confidence>e.confidence
                                              THEN ent.confidence ELSE e.confidence END,
                            e.updated=date()
            MERGE (src)-[:MENTIONS {confidence: ent.confidence}]->(e)
            MERGE (e)-[:DERIVED_FROM]->(src)
            // Single-source entities are flagged for review, not promoted as standalone
            WITH e, src
            OPTIONAL MATCH (e)<-[:MENTIONS]-(other_src:Source)
            WITH e, count(DISTINCT other_src) AS source_count
            SET e.source_count = source_count,
                e.needs_review = CASE WHEN source_count < 2 THEN true ELSE false END
            """, source=source, entities=extraction.entities)

        # Typed relationships — one edge per source so conflicts are detectable
        await s.run("""
            UNWIND $rels AS r
            MATCH (a:Entity {entity_id: r.subject}), (b:Entity {entity_id: r.object})
            MERGE (a)-[rel:RELATES {type: r.type, source_sha: r.source_sha}]->(b)
              ON CREATE SET rel.confidence=r.confidence, rel.claim=r.claim, rel.created=date()
            """, rels=rels)
```

### Contradiction Detection (Cypher)

```cypher
    // Same entity pair, same relationship type, conflicting claim, different source → flag…