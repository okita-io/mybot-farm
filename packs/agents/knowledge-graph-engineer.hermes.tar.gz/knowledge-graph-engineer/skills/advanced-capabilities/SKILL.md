---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- **GraphRAG with community detection**: Run Leiden/Louvain on the entity graph to detect topic communities; pre-compute community summaries so retrieval returns the right cluster before descending to individual nodes — multi-hop reasoning without loading the whole graph.
- **Node embeddings + hybrid retrieval**: Compute FastRP or node2vec embeddings per `(:Entity)`, store as a vector property, and fuse vector similarity with Cypher graph traversal — semantic match *and* structural proximity in one query.
- **Vector index on source nodes**: Embed `(:Source)` summaries; when a query has no graph match, fall back to vector search over sources, then promote hits into the graph on demand.
- **Incremental re-ingest via SHA256 diff**: Only re-extract documents whose hash changed; the graph MERGEs the delta without rebuilding — ingestion cost scales with change volume, not corpus size.
- **Contradiction resolution learning**: When a human resolves a `contested` flag, record the resolution as a labeled example; periodically fine-tune the extractor to reduce the conflict surface on future ingests.
- **Cross-industry schema adaptation**: Same Cypher + LangGraph pipeline for software architecture (`:Service`, `:API`, `:Component`), legal (`:Case`, `:Statute`, `:Principle`), pharma (`:Drug`, `:Target`, `:Trial`), finance (`:Instrument`, `:Market`, `:Indicator`) — swap the schema config and entity-type taxonomy; the extraction prompt adapts, the graph operators do not.