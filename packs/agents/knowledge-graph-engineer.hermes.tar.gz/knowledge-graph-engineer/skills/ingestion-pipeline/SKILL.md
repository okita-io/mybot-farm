---
name: ingestion-pipeline
description: "Use when the task matches this agent's ingestion pipeline work."
version: 1.0.0
---

# Ingestion Pipeline

Phase 1 — Orient
Read graph config before touching a document: schema (entity types, tag taxonomy, thresholds), purpose (focus areas, exclusions), and current node counts by type (`MATCH (e:Entity) RETURN e.type, count(*)`). Skipping orient = duplicate nodes and schema violations.

### Phase 2 — Analyze
For each candidate: (1) compute the source SHA256 — never trust a pre-supplied path; (2) run LLM structured extraction → entities and relationships with type, confidence, claim text; (3) for every existing entity, read the current node and explicitly compare — "New says X. Existing says Y. Consistent or contradictory?"; (4) assess domain relevance — out-of-scope content still ingests as a `(:Source)` node.

### Phase 3 — Merge
MERGE entities, MERGE the source node, MERGE `(:MENTIONS)`/`(:RELATES)`/`(:DERIVED_FROM)` edges. Single-source candidates are MERGE'd as `(:Entity)` nodes (so `(:MENTIONS)` resolves to a real node) but flagged `needs_review = true` and excluded from lookup views until corroborated. Contradictions → add `(:CONTRADICTS)` edge, set `contested: true`, preserve both source refs.

### Phase 4 — Verify
Hard gates (Cypher): (1) source node count = candidate count; (2) zero dangling references — every `[:MENTIONS]` target resolves to a real node; (3) every `(:Entity)` has ≥1 `(:DERIVED_FROM)` edge; (4) no unflagged orphan entity with zero incoming edges; (5) `contested` is set wherever a `(:CONTRADICTS)` edge exists; (6) audit-log entry written. Any failure → fix and re-run until all pass.

### Phase 5 — Navigate
Refresh lookup views (entity index by type), append a timestamped entry to the audit log, regenerate the overview (recent additions, active contradictions, knowledge gaps = entity types with zero corroborated nodes).

---