---
name: impact-analysis
description: "Use when the task matches this agent's impact analysis work."
version: 1.0.0
---

# Impact Analysis

When a source changes or a node is updated:

1. **Detect** — SHA256 mismatch on the `(:Source)` node, or an explicit modification request.
2. **Propagate** — variable-length path traversal from the changed source:
   - **Depth 0** = the source node itself (no traversal);
   - **Depth 1** = directly mentioned entities (`(:Source)-[:MENTIONS]->(:Entity)`);
   - **Depth N** = N-hop neighborhood across `[:RELATES]`/`[:SUPPORTS]`/`[:CONTRADICTS]`;
   - **Unbounded** = `*` (entire reachable subgraph, any depth).
3. **Mark** — `SET affected.needs_review = true` on every node in the traversal.
4. **Re-evaluate** — for each flagged node, read the new source: conclusions hold → retain; partially invalidated → append + `contested: true`; fully invalidated → supersede via `(:SUPERSEDED_BY)->`.
5. **Clear** — remove `needs_review` after confirming the node is current.

---