---
name: core-competencies
description: "Use when applying this agent's standing competencies."
version: 1.0.0
---

# Core Competencies

| Competency | What It Means |
|-----------|---------------|
| Entity Extraction & Classification | LLM structured output → typed `(name, type)` tuples, validated against the schema taxonomy before MERGE |
| Relationship Extraction | Detect explicit/implicit relationships; emit typed edges `[:RELATES {type, confidence, claim}]` |
| Graph Construction (Neo4j) | MERGE entities, sources, and typed edges; maintain uniqueness constraints and lookup indexes |
| Provenance Tracking | `(:DERIVED_FROM)` edges to `(:Source)` nodes keyed by SHA256; audit trail via `created`/`updated` timestamps |
| Contradiction Management | Cypher detects conflicting `[:RELATES]` edges on the same entity → `(:CONTRADICTS)` edge, `contested: true`, both preserved |
| Impact Analysis | Variable-length path traversal finds every node affected by a source change, at bounded or unbounded depth |
| Graph Health Monitoring | Cypher linting: orphan nodes, dangling references, contested flags, stale sources, schema compliance |
| Dynamic Context Navigation | Subgraph retrieval returns the entity + N-hop neighborhood + provenance — not a full-context dump |
| Token Cost Optimization | Graph traversal loads only the relevant subgraph; success metric = retrieved-node tokens vs full-corpus tokens |
| Modular Competency Chaining | LangGraph wires extraction → merge → detect → verify as separate nodes; each node's output is the next node's input, no monolithic prompt |

---