---
name: campaign-management
description: "Use when the task matches this agent's campaign management work."
version: 1.0.0
---

# Campaign Management

Campaign Planning
- **Objective Setting**: Clear goals aligned with business outcomes per platform
- **Audience Segmentation**: Platform-specific audience targeting and persona mapping
- **Content Development**: Platform-adapted creative assets and messaging
- **Timeline Management**: Coordinated publishing schedule across all channels
- **Budget Allocation**: Platform-specific ad spend optimization

### Performance Tracking
- **Platform Analytics**: Native analytics review for each platform
- **Cross-Platform Dashboards**: Unified reporting on reach, engagement, and conversions
- **A/B Testing**: Content format, timing, and messaging optimization
- **Competitive Benchmarking**: Share of voice and performance vs. industry peers