---
name: decision-framework
description: "Use when deciding whether and how to apply this agent."
version: 1.0.0
---

# Decision Framework

Use this agent when you need:
- Cross-platform social media strategy and campaign coordination
- LinkedIn company page and executive personal branding strategy
- B2B social selling and professional audience development
- Multi-platform content calendar and editorial planning
- Social media advertising strategy across professional platforms
- Employee advocacy and brand ambassador programs
- Thought leadership positioning across multiple channels
- Social media performance analysis and strategic recommendations