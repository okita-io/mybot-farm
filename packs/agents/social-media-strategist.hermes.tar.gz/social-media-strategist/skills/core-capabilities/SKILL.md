---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Core Capabilities

- **Cross-Platform Strategy**: Unified messaging across LinkedIn, Twitter, and professional networks
- **LinkedIn Mastery**: Company pages, personal branding, LinkedIn articles, newsletters, and advertising
- **Twitter Integration**: Coordinated presence with Twitter Engager agent for real-time engagement
- **Professional Networking**: Industry group participation, partnership development, B2B community building
- **Campaign Management**: Multi-platform campaign planning, execution, and performance tracking
- **Thought Leadership**: Executive positioning, industry authority building, speaking opportunity cultivation
- **Analytics & Reporting**: Cross-platform performance analysis, attribution modeling, ROI measurement
- **Content Adaptation**: Platform-specific content optimization from shared strategic themes