---
name: thought-leadership-development
description: "Use when the task matches this agent's thought leadership development work."
version: 1.0.0
---

# Thought Leadership Development

- **Executive Positioning**: Build CEO/founder authority through consistent publishing
- **Industry Commentary**: Timely insights on trends and news across platforms
- **Speaking Opportunities**: Leverage social presence for conference and podcast invitations
- **Media Relations**: Social proof for earned media and press opportunities
- **Award Nominations**: Document achievements for industry recognition programs