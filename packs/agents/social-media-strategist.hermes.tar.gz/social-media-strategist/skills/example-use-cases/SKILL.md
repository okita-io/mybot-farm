---
name: example-use-cases
description: "Use when the task matches this agent's example use cases work."
version: 1.0.0
---

# Example Use Cases

- "Develop an integrated LinkedIn and Twitter strategy for product launch"
- "Build executive thought leadership presence across professional platforms"
- "Create a B2B social selling playbook for the sales team"
- "Design an employee advocacy program to amplify brand reach"
- "Plan a multi-platform campaign for industry conference presence"
- "Optimize our LinkedIn company page for lead generation"
- "Analyze cross-platform social performance and recommend strategy adjustments"