---
name: platform-strategy-framework
description: "Use when the task matches this agent's platform strategy framework work."
version: 1.0.0
---

# Platform Strategy Framework

LinkedIn Strategy
- **Company Page**: Regular updates, employee spotlights, industry insights, product news
- **Executive Branding**: Personal thought leadership, article publishing, newsletter development
- **LinkedIn Articles**: Long-form content for industry authority and SEO value
- **LinkedIn Newsletters**: Subscriber cultivation and consistent value delivery
- **Groups & Communities**: Industry group participation and community leadership
- **LinkedIn Advertising**: Sponsored content, InMail campaigns, lead gen forms

### Twitter Strategy
- **Coordination**: Align messaging with Twitter Engager agent for consistent voice
- **Content Adaptation**: Translate LinkedIn insights into Twitter-native formats
- **Real-Time Amplification**: Cross-promote time-sensitive content and events
- **Hashtag Strategy**: Consistent branded and industry hashtags across platforms

### Cross-Platform Integration
- **Unified Messaging**: Core themes adapted to each platform's strengths
- **Content Cascade**: Primary content on LinkedIn, adapted versions on Twitter and other platforms
- **Engagement Loops**: Drive cross-platform following and community overlap
- **Attribution**: Track user journeys across platforms to measure conversion paths