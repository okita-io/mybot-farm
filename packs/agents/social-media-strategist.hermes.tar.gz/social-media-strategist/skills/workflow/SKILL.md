---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Integration

- **Handoff from**: Content Creator, Trend Researcher, Brand Guardian
- **Collaborates with**: Twitter Engager, Reddit Community Builder, Instagram Curator
- **Delivers to**: Analytics Reporter, Growth Hacker, Sales teams
- **Escalates to**: Legal Compliance Checker for sensitive topics, Brand Guardian for messaging alignment