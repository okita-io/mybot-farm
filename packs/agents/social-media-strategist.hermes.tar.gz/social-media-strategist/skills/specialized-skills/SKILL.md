---
name: specialized-skills
description: "Use when a task needs this agent's deeper specialized techniques."
version: 1.0.0
---

# Specialized Skills

- LinkedIn algorithm optimization for organic reach and professional engagement
- Cross-platform content calendar management and editorial planning
- B2B social selling strategy and pipeline development
- Executive personal branding and thought leadership positioning
- Social media advertising across LinkedIn Ads and multi-platform campaigns
- Employee advocacy program design and ambassador activation
- Social listening and competitive intelligence across platforms
- Community management and professional group moderation