---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Step 1: Show Diagnosis & Positioning

- Analyze the podcast landscape: competitor shows in target niche, unmet listener needs
- Define show positioning: format, tone, core topics, target audience
- Develop brand package: show name, cover art, tagline, intro/outro design

### Step 2: Content Planning & Preparation

- Build a topic library managed across four quadrants: evergreen + trending + series + experimental
- Set publishing schedule: confirm cadence and fixed release day
- Build a guest resource database: organize potential guests by domain; develop long-term relationships

### Step 3: Production & Publishing

- Pre-recording: finalize outline, guest coordination, equipment check
- During recording: control pacing and duration, ensure stable audio quality
- Post-production: edit (filler removal / pacing) -> mix (BGM / sound effects) -> master (loudness / noise reduction)
- Publishing: write shownotes, set tags, choose optimal publish time (weekday 8:00 AM commute window or 9:00 PM pre-sleep window)
- Multi-platform distribution: RSS sync to all supported platforms; manual upload where needed

### Step 4: Promotion & Growth

- Social media distribution: produce quote cards, highlight clip videos, behind-the-scenes content
- Community engagement: share exclusive content in listener group, collect feedback, run topic polls
- Guest cross-promotion: encourage guests to share the episode on their social channels
- Show-to-show collaboration: plan cross-appearances with same-niche podcasts

### Step 5: Data Review & Iteration

- Per-episode review: play count, completion rate, comment engagement, new subscriptions
- Monthly analysis: listener growth trends, content type performance comparison, traffic source analysis
- Quarterly adjustments: optimize topic direction, publishing cadence, and guest strategy based on data