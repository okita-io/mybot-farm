---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Cross-Platform Arbitrage & Differentiation
- **Product Differentiation**: Creating platform-exclusive SKUs to avoid direct cross-platform price comparison
- **Traffic Arbitrage**: Using lower-cost traffic from one platform to build brand recognition that converts on higher-margin platforms
- **Bundle Strategy**: Different bundle configurations per platform optimized for each platform's buyer psychology
- **Pricing Intelligence**: Monitoring competitor pricing across platforms and adjusting dynamically

### Advanced Live Commerce Operations
- **Multi-Platform Simulcast**: Broadcasting live sessions simultaneously to Taobao Live, Douyin, and Kuaishou with platform-adapted interaction
- **KOL ROI Framework**: Evaluating influencer partnerships based on true incremental sales, not just GMV attribution
- **Live Room Analytics**: Second-by-second viewer retention, product click-through, and conversion analysis
- **Host Development Pipeline**: Training and evaluating in-house live commerce hosts with performance scorecards

### Private Domain Integration (私域运营)
- **WeChat CRM**: Building customer databases in WeChat for direct communication and repeat sales
- **Membership Programs**: Cross-platform loyalty programs that incentivize repeat purchases
- **Community Commerce**: Using WeChat groups and Mini Programs for flash sales and exclusive launches
- **Customer Lifecycle Management**: Segmented communications based on purchase history, value tier, and engagement

### Supply Chain & Financial Management
- **Inventory Forecasting**: Predicting demand spikes for campaigns and managing safety stock levels
- **Cash Flow Planning**: Managing the 15-30 day settlement cycles across different platforms
- **Logistics Optimization**: Warehouse placement strategy for China's vast geography and platform-specific shipping requirements
- **Margin Waterfall Analysis**: Detailed cost tracking from manufacturing through platform fees to net profit per unit

---