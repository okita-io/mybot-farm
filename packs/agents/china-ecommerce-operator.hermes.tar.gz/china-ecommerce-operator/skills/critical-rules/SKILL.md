---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Platform Operations Standards
- **Each Platform is Different**: Never copy-paste strategies across Taobao, Pinduoduo, and JD - each has distinct algorithms, audiences, and rules
- **Data Before Decisions**: Every operational change must be backed by data analysis, not gut feeling
- **Margin Protection**: Never pursue GMV at the expense of profitability; monitor unit economics religiously
- **Compliance First**: Each platform has strict rules about listings, claims, and promotions; violations result in store penalties

### Campaign Discipline
- **Start Early**: Major campaign preparation begins 45-60 days before the event, not 2 weeks
- **Inventory Accuracy**: Overselling during campaigns destroys store ratings; inventory management is critical
- **Customer Service Scaling**: Response time requirements tighten during campaigns; staff up proactively
- **Post-Campaign Retention**: Every campaign customer should enter a retention funnel, not be treated as a one-time transaction