---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Multi-Platform Store Operations Dashboard
```markdown
# [Brand] China E-Commerce Operations Report

## 平台概览 (Platform Overview)
| Metric              | Taobao/Tmall | Pinduoduo  | JD         | Douyin Shop |
|---------------------|-------------|------------|------------|-------------|
| Monthly GMV         | ¥___        | ¥___       | ¥___       | ¥___        |
| Order Volume        | ___         | ___        | ___        | ___         |
| Avg Order Value     | ¥___        | ¥___       | ¥___       | ¥___        |
| Conversion Rate     | ___%        | ___%       | ___%       | ___%        |
| Store Rating        | ___/5.0     | ___/5.0    | ___/5.0    | ___/5.0     |
| Ad Spend (ROI)      | ¥___ (_:1)  | ¥___ (_:1) | ¥___ (_:1) | ¥___ (_:1)  |
| Return Rate         | ___%        | ___%       | ___%       | ___%        |

## 流量结构 (Traffic Breakdown)
- Organic Search: ___%
- Paid Search (直通车/搜索推广): ___%
- Recommendation Feed: ___%
- Live Commerce: ___%
- Content/Short Video: ___%
- External Traffic: ___%
- Repeat Customers: ___%
```

### Product Listing Optimization Framework
```markdown
# Product Listing Optimization Checklist

## 标题优化 (Title Optimization) - Platform Specific
### Taobao/Tmall (60 characters max)
- Formula: [Brand] + [Core Keyword] + [Attribute] + [Selling Point] + [Scenario]
- Example: [品牌]保温杯女士316不锈钢大容量便携学生上班族2024新款
- Use 生意参谋 for keyword search volume and competition data
- Rotate long-tail keywords based on seasonal search trends

### Pinduoduo (60 characters max)
- Formula: [Core Keyword] + [Price Anchor] + [Value Proposition] + [Social Proof]
- Pinduoduo users are price-sensitive; emphasize value in title
- Use 多多搜索 keyword tool for PDD-specific search data

### JD (45 characters recommended)
- Formula: [Brand] + [Product Name] + [Key Specification] + [Use Scenario]
- JD users trust specifications and brand; be precise and factual
- Optimize for JD's search algorithm which weights brand authority heavily

## 主图优化 (Main Image Strategy) - 5 Image Slots
| Slot | Purpose                    | Best Practice                          |
|------|----------------------------|----------------------------------------|
| 1    | Hero shot (搜索展示图)       | Clean product on white, mobile-readable|
| 2    | Key selling point           | Single benefit, large text overlay      |
| 3    | Usage scenario              | Product in real-life context            |
| 4    | Social proof / data         | Sales volume, awards, certifications   |
| 5    | Promotion / CTA             | Current offer, urgency element         |

## 详情页 (Detail Page) Structure
1. Core value proposition banner (3 seconds to hook)
2. Problem/solution framework with lifestyle imagery
3. Product specifications and material details
4. Comparison chart vs. competitors (indirect)
5. User reviews and social proof showcase
6. Usage instructions and care guide
7. Brand story and trust signals
8. FAQ addressing top 5 purchase objections
```

### 618 / Double 11 Campaign Battle Plan
```markdown
# [Campaign Name] Operations Battle Plan

## T-60 Days: Strategic Planning
- [ ] Set GMV target and work backwards to traffic/conversion requirements
- [ ] Negotiate platform resource slots (会场坑位) with category managers
- [ ] Plan product lineup: 引流款 (traffic drivers), 利润款 (profit items), 活动款 (promo items)
- [ ] Design campaign pricing architecture with margin analysis per SKU
- [ ] Confirm inventory requirements and place production orders

## T-30 Days: Preparation Phase
- [ ] Finalize creative assets: main images, detail pages, video content
- [ ] Set up campaign mechanics: 预售 (pre-sale), 定金膨胀 (deposit multiplier), 满减 (spend thresholds)
- [ ] Configure advertising campaigns: 直通车 keywords, 万相台 targeting, 超级推荐 creatives
- [ ] Brief live commerce hosts and finalize live session schedule
- [ ] Coordinate influencer seeding and KOL content publication
- [ ] Staff up customer service team and prepare FAQ scripts

## T-7 Days: Warm-Up Phase (蓄水期)
- [ ] Activate pre-sale listings and deposit collection
- [ ] Ramp up advertising spend to build momentum
- [ ] Publish teaser content on social platforms (Weibo, Xiaohongshu, Douyin)
- [ ] Push CRM messages to existing customers: membership benefits, early access
- [ ] Monitor competitor pricing and adjust positioning if needed

## T-Day: Campaign Execution (爆发期)
- [ ] War room setup: real-time GMV dashboard, inventory monitor, CS queue
- [ ] Execute hourly advertising bid adjustments based on real-time data…