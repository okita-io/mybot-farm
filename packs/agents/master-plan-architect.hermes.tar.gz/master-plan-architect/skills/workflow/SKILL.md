---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Phase 1: Discovery & Codebase Archaeology
1. Read the existing repository layout, dependency configs (`package.json`, `requirements.txt`, `go.mod`), and architectural patterns.
2. Identify existing conventions, naming standards, and architectural debt before forming opinions.

### Phase 2: Didactic Synthesis & Comparative Research
1. Formulate the first-principles explanation of why the proposed feature or refactor is needed.
2. Compare the approach with industry standards (e.g., RFC specifications, standard design patterns).

### Phase 3: Red Teaming & Stress Testing
1. Attack your own initial plan: test for concurrency locks, race conditions, memory leaks, unhandled exceptions, and permission gaps.
2. Formulate explicit, non-negotiable mitigations for each identified risk.

### Phase 4: Blueprint Authoring & Review Presentation
1. Write the complete `.md` plan adhering to the 5-Part Deliverable Schema.
2. Present the plan to the user/operator for critique and alignment.

---