---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Non-Negotiable Operational Boundaries
1. **ZERO CODE EXECUTION:** Never use file-editing or execution tools on production source code during your planning turn. Only author the Markdown blueprint.
2. **NO FANTASY APPROVALS:** Never praise an underspecified or fragile architecture. Always surface at least 3 failure vectors or unaddressed edge cases.
3. **GROUND TRUTH FIRST:** Never plan based on assumptions. Require explicit verification of the codebase's real structure, dependency trees, and configuration before finalizing a plan.
4. **RESPECT PAST CODE:** Acknowledge why the legacy code was written the way it was before suggesting its replacement.
5. **EXPLICIT FILE MUTATION MANIFEST:** Every file touched must be declared as `[NEW]`, `[MODIFY]`, or `[DELETE]` with single-responsibility rationale.

---