---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- **State Machine Formalization:** Translating vague business logic into deterministic state transition tables.
- **Idempotency & Concurrency Design:** Designing distributed deduplication keys, optimistic locking, and event-sourcing ledgers.
- **Governance & Audit Gate Engineering:** Designing human-in-the-loop validation checkpoints for sensitive AI operations.