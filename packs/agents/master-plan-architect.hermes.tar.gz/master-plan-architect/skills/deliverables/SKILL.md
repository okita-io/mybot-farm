---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

The 5-Part Standard Implementation Plan Schema (`.md`)

```markdown
# 🏛️ [Project/Module Name] — Architectural Blueprint & Governance Plan

## 1. 🎓 Conceptual Masterclass: Philosophy, First Principles & Landscape
- **The Core Problem:** Fundamental bottleneck, state conflict, or friction being resolved.
- **Theoretical Foundations:** Core design patterns applied (e.g., CQRS, Event-Driven, Clean Architecture, State Machine, Idempotency).
- **Comparative Precedents:** How established battle-tested software solved this (lessons and dignity of past solutions).
- **Harmonic Efficiency:** How this design maximizes outcome while minimizing runtime waste and cognitive overload.

## 2. 🔍 Surgical Critique & Red Teaming (What Could Break?)
- **Fragile Assumptions:** Implicit dependencies or environmental assumptions that could fail in production.
- **Regression Blast Radius:** Existing endpoints, database models, or workflows at risk of side effects.
- **Anti-Scope Creep Filter:** Explicit list of features/refactors forbidden in this iteration.
- **Security & Operational Boundaries:** Rate limits, permission boundaries, and required human confirmation gates.

## 3. 🗺️ Implementation Plan Blueprint (File Map & State Contracts)
```mermaid
graph TD
    Client[Client / Operator] -->|Authenticated Intent| Gateway[API Gateway / Ingress]
    Gateway -->|Validated State| Core[Core Domain Logic]
    Core -->|Idempotent Write| DB[(Persistent Storage)]
    Core -->|Audit Log| Audit[Governance Audit Trail]
```

### File Mutation Manifest
- `[NEW]` `src/modules/example/service.ts`: Single responsibility description.
- `[MODIFY]` `src/core/router.ts`: Route registration and boundary checks.
- `[DELETE]` `src/legacy/temp_adapter.ts`: Deprecated adapter cleanup.

## 4. 🧪 Validation Protocol & Ground Truth Verification
- **Automated Tests:** Unit test matrix and integration suites to execute after building.
- **Edge Cases:** Boundary values, network timeouts, concurrent race conditions, payload limits.
- **Manual Verification Steps:** Step-by-step human acceptance testing procedure.

## 5. 🔄 Rollback Strategy & Failure Containment
- **Instant Rollback Path:** Steps to revert changes in under 60 seconds without data loss.
- **Circuit Breakers:** Degradation mode if downstream dependencies fail.
```

---