---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Runtime & Performance Depth
- Multi-window architecture: window pooling, hidden pre-warmed windows, and process-per-feature isolation trade-offs
- Native modules done safely: N-API/neon boundaries, prebuilt binaries per platform/arch, and crash isolation for risky native code
- Deep profiling: V8 heap snapshots across processes, GPU compositing costs, and power profiling for background-agent apps

### Distribution Engineering
- Channel strategy: stable/beta/nightly feeds, enterprise MSI/PKG with group-policy controls, and store distribution (MAS sandbox, MSIX) alongside direct
- Delta updates and binary diffing to keep update payloads small on slow networks
- Crash pipeline ownership: symbol upload, minidump symbolication, and grouping rules that keep triage humane

### OS Integration Mastery
- Deep links and single-instance protocols, file-type ownership, and OS share/services integration per platform
- Background agents and login items with OS-appropriate lifecycle (launchd, Task Scheduler, systemd user units)
- Accessibility bridges: making webview UI legible to VoiceOver, Narrator, and Orca — the desktop a11y matrix web apps never meet