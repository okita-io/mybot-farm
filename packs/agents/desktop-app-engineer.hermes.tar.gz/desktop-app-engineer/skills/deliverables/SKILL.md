---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Electron: Locked-Down Window + Typed IPC

```typescript
// main.ts — the only process that touches the OS
const win = new BrowserWindow({
  webPreferences: {
    contextIsolation: true,        // renderer gets a bridge, not your internals
    nodeIntegration: false,        // no require() in web content — ever
    sandbox: true,                 // Chromium OS-level sandbox
    preload: path.join(__dirname, 'preload.js'),
  },
});

// IPC: narrow verbs, validated input, no generic filesystem/shell passthrough
import { z } from 'zod';
const ExportRequest = z.object({
  format: z.enum(['csv', 'json']),
  projectId: z.string().uuid(),
});

ipcMain.handle('project:export', async (event, raw) => {
  const req = ExportRequest.parse(raw);                    // reject garbage at the boundary
  const dest = await dialog.showSaveDialog(win, {          // user picks the path — app never
    defaultPath: `export.${req.format}`,                   // takes arbitrary paths from the renderer
  });
  if (dest.canceled) return { ok: false };
  await exportProject(req.projectId, req.format, dest.filePath);
  return { ok: true };
});
```

```typescript
// preload.ts — the entire API the renderer will ever see
import { contextBridge, ipcRenderer } from 'electron';
contextBridge.exposeInMainWorld('app', {
  exportProject: (req: unknown) => ipcRenderer.invoke('project:export', req),
  onUpdateReady: (cb: () => void) => ipcRenderer.on('update:ready', cb),
});
```

### Tauri: Capability-Scoped Commands (deny by default)

```rust
// src-tauri/src/main.rs — commands are the whole attack surface; keep them narrow
#[tauri::command]
async fn export_project(project_id: String, format: String, state: tauri::State<'_, Db>)
    -> Result<ExportReceipt, String> {
    let format = Format::parse(&format).map_err(|e| e.to_string())?;   // validate
    let id = Uuid::parse_str(&project_id).map_err(|_| "bad id")?;      // everything
    exporter::run(&state, id, format).await.map_err(|e| e.to_string())
}
```

```json
// src-tauri/capabilities/main.json — the frontend gets exactly this, nothing more
{
  "identifier": "main-window",
  "windows": ["main"],
  "permissions": [
    "core:default",
    "dialog:allow-save",
    { "identifier": "fs:allow-write-file", "allow": [{ "path": "$APPDATA/exports/*" }] }
  ]
}
```

### Release Pipeline: Sign, Notarize, Stage, Roll Back

```yaml
# release.yml — the gauntlet every build runs before any user sees it
jobs:
  build-sign:
    strategy:
      matrix: { os: [macos-14, windows-2022, ubuntu-22.04] }
    steps:
      - run: npm run build && npm run package
      - name: Sign (Windows)                       # EV/OV cert via cloud HSM — no cert files in CI
        if: runner.os == 'Windows'
        run: azuresigntool sign -kvu $VAULT_URI -kvc $CERT_NAME -tr http://timestamp.digicert.com out/*.exe
      - name: Sign + notarize (macOS)              # hardened runtime is required for notarization
        if: runner.os == 'macOS'
        run: |
          codesign --deep --options runtime --entitlements entitlements.plist --sign "$IDENTITY" out/App.app
          xcrun notarytool submit out/App.dmg --keychain-profile ci --wait
          xcrun stapler staple out/App.dmg
  publish:
    needs: build-sign
    steps:
      - run: node scripts/publish-update.js --channel stable --rollout 1
        # 1% for 24h → auto-check crash-free rate ≥ 99.5% → 10% → 100%
        # rollback = republish previous manifest; clients on N+1 downgrade cleanly
```

### Electron vs Tauri Decision Table

| Concern | Electron | Tauri |
|---------|----------|-------|
| Installer size | ~80–150MB (bundled Chromium) | ~3–15MB (system webview) |
| Idle memory | Higher — own Chromium per app | Lower — shared system webview |
| Rendering consistency | Identical everywhere (you ship the browser) | Varies with OS webview (WebView2/WKWebView/WebKitGTK) — test the matrix |
| Privileged-side language | Node.js (huge ecosystem, easy hires) | Rust (memory safety, smaller surface) |
| Ecosystem maturity | Deep: updaters, crash reporting, native modules | Younger, moving fast; verify each plugin need |
| Choose when | Pixel-perfect rendering, heavy native-module needs, team is JS-native | Size/memory budgets matter, Rust is welcome, webview variance is testable |

### Footprint Budget (CI-enforced)

| Metric | Budget | Measured by |
|--------|--------|-------------|…