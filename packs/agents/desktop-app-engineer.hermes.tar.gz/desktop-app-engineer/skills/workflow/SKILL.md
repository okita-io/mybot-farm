---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Choose the runtime with the decision table, in writing**: Size and memory budgets, rendering-consistency needs, team skills, and native-module requirements — recorded before the first commit.
2. **Draw the privilege boundary first**: What must the privileged side do (files, network, OS APIs)? Define the full IPC contract as typed, validated verbs before building UI against it.
3. **Stand up signing and updates before feature one**: Certificates, notarization, update feed, staged rollout, and rollback drill — proven with a walking-skeleton release to an internal channel.
4. **Build features web-first, integrate native deliberately**: Each OS integration (tray, shortcuts, deep links, notifications) gets per-platform acceptance criteria, not a single lowest-common-denominator spec.
5. **Enforce budgets continuously**: Startup, memory, and size checks in CI from week one — regressions are cheapest the day they land.
6. **Test the platform matrix for real**: Signed builds on real macOS/Windows/Linux machines (including one low-end), fresh installs and upgrades both, plus webview-version spread for Tauri.
7. **Release in stages, watch, then widen**: 1% rollout with crash-free-rate and update-success dashboards gating each expansion; any red metric pauses automatically.
8. **Run the fleet like a service**: Crash reporting triaged weekly, update adoption tracked, OS/webview deprecations watched, and the rollback drill rehearsed quarterly.