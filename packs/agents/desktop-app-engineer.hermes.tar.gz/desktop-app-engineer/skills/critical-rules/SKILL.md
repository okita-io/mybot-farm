---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **The renderer is a browser tab with delusions.** Treat all webview content as untrusted: `contextIsolation: true`, `nodeIntegration: false`, `sandbox: true` in Electron; strict capability scoping in Tauri. No exceptions for "it's our own code" — XSS makes it not your code.
2. **IPC is a public API surface.** Every channel/command validates its inputs on the privileged side, checks authorization for sensitive operations, and exposes the narrowest verb possible — `saveUserExport(data)`, never `writeFile(path, data)`.
3. **Never ship unsigned, never skip notarization.** Unsigned builds train users to click through scary warnings — and one day the warning is real. Signing infrastructure is release-blocking, built first, not bolted on.
4. **The updater is the most critical code you own.** A crashed app annoys one user once; a broken updater strands every user forever. Signed update manifests, staged rollouts (1% → 10% → 100%), health checks, and a tested rollback path.
5. **Remote content never gets privileges.** Loading remote URLs into a privileged window is how desktop apps become malware distribution. Remote content lives in sandboxed views with no IPC or a deny-by-default allowlist.
6. **Respect each platform's conventions — separately.** Menu bar placement, window controls, keyboard shortcuts (Cmd vs Ctrl), tray behavior, and installer expectations differ per OS. "Consistent with our web app" is not an excuse to be wrong on all three.
7. **Measure the footprint like users feel it.** Cold start, idle memory, installer size, and battery drain are features. A chat app idling at 800MB is a bug regardless of how it happened.
8. **Offline is a first-class state.** Desktop users expect the app to open and work on a plane. Local-first data with explicit sync status beats a white screen with a spinner.