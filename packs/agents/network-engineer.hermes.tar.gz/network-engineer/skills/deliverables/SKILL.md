---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Cisco IOS/IOS-XE Router and Switch Configuration

```ios
! L3 access switch with user VLAN, OSPF, and eBGP edge handoff
vlan 20
 name USERS
!
interface Vlan20
 description Users default gateway
 ip address 10.20.0.1 255.255.255.0
 ip helper-address 10.0.0.10
 no shutdown
!
interface GigabitEthernet1/0/24
 description User access port
 switchport mode access
 switchport access vlan 20
 spanning-tree portfast
 spanning-tree bpduguard enable
!
interface GigabitEthernet0/0
 description ISP-A handoff
 ip address 203.0.113.2 255.255.255.252
 no shutdown
!
interface GigabitEthernet0/1
 description CORE-1 routed uplink
 no switchport
 ip address 10.0.0.2 255.255.255.252
 no shutdown
!
router ospf 10
 router-id 10.255.255.1
 passive-interface default
 no passive-interface GigabitEthernet0/1
 network 10.0.0.0 0.0.0.3 area 0
 network 10.20.0.0 0.0.0.255 area 0
!
ip prefix-list CUSTOMER-PREFIX seq 10 permit 198.51.100.0/24
!
route-map ISP-A-OUT permit 10
 match ip address prefix-list CUSTOMER-PREFIX
!
# … truncated for farm planting — see upstream for the full sample
```

### Cisco ASA Firewall NAT and ACL

```cisco
object network WEB-PRIVATE
 host 10.20.10.20
 nat (inside,outside) static 203.0.113.20
!
access-list OUTSIDE-IN extended permit tcp any object WEB-PRIVATE eq 443
access-list OUTSIDE-IN extended deny ip any any log
access-group OUTSIDE-IN in interface outside
!
show nat detail
show access-list OUTSIDE-IN
packet-tracer input outside tcp 198.51.100.50 54321 203.0.113.20 443 detailed
```

### Juniper Junos Routing and Control-Plane Filter

```junos
set interfaces ge-0/0/0 unit 0 description ISP-A
set interfaces ge-0/0/0 unit 0 family inet address 203.0.113.2/30
set interfaces ge-0/0/1 vlan-tagging
set interfaces ge-0/0/1 unit 20 description USERS
set interfaces ge-0/0/1 unit 20 vlan-id 20
set interfaces ge-0/0/1 unit 20 family inet address 10.20.0.1/24
set interfaces ge-0/0/2 unit 0 description CORE-1
set interfaces ge-0/0/2 unit 0 family inet address 10.0.0.2/30
set protocols ospf area 0.0.0.0 interface ge-0/0/1.20 passive
set protocols ospf area 0.0.0.0 interface ge-0/0/2.0
set protocols bgp group ISP-A type external
set protocols bgp group ISP-A peer-as 65020
set protocols bgp group ISP-A neighbor 203.0.113.1
set policy-options prefix-list CUSTOMER-PREFIX 198.51.100.0/24
set policy-options policy-statement EXPORT-CUSTOMER term allow from prefix-list CUSTOMER-PREFIX
set policy-options policy-statement EXPORT-CUSTOMER term allow then accept
set policy-options policy-statement EXPORT-CUSTOMER then reject
set protocols bgp group ISP-A export EXPORT-CUSTOMER
set firewall family inet filter PROTECT-RE term allow-ssh from source-address 10.0.0.0/8
set firewall family inet filter PROTECT-RE term allow-ssh from protocol tcp
set firewall family inet filter PROTECT-RE term allow-ssh from destination-port ssh
set firewall family inet filter PROTECT-RE term allow-ssh then accept
set firewall family inet filter PROTECT-RE term drop-rest then discard
set interfaces lo0 unit 0 family inet filter input PROTECT-RE
```

### Palo Alto PAN-OS Security Policy and Routing

```panos
set network interface ethernet ethernet1/1 layer3 ip 203.0.113.2/30
set network interface ethernet ethernet1/2 layer3 ip 10.20.10.1/24
set zone untrust network layer3 ethernet1/1
set zone dmz network layer3 ethernet1/2
set network virtual-router default interface ethernet1/1
set network virtual-router default interface ethernet1/2
set network virtual-router default routing-table ip static-route default-route destination 0.0.0.0/0
set network virtual-router default routing-table ip static-route default-route nexthop ip-address 203.0.113.1
set network virtual-router default routing-table ip static-route default-route interface ethernet1/1
set rulebase security rules Allow-Web from untrust to dmz source any destination 10.20.10.20 application ssl service application-default action allow
set rulebase security rules Allow-Web log-start no log-end yes
commit
```

### Troubleshooting Command Playbooks

| Platform | Baseline state | Routing | Switching/interfaces | Firewall/session |
|----------|----------------|---------|----------------------|------------------|…