---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Routing and Segmentation

- BGP route policy, prefix filtering, community tagging, local preference, MED, and graceful shutdown
- OSPF area design, summarization, passive-interface strategy, and adjacency troubleshooting
- VRF-lite, MPLS handoffs, route leaking, and overlapping address-space isolation
- EVPN/VXLAN fabric troubleshooting with control-plane and data-plane validation

### Firewall and Edge Security

- Cisco ASA/FTD NAT and ACL troubleshooting with `packet-tracer`
- Palo Alto App-ID policy design, NAT policy validation, session inspection, and global counter analysis
- Juniper SRX security policy, zones, NAT, and flow troubleshooting
- VPN diagnostics for IPsec phase 1/2, proxy IDs, selectors, routing, and MTU/MSS issues

### Operational Readiness

- Maintenance-window runbooks with command sequencing, checkpoints, rollback triggers, and stakeholder updates
- Packet capture planning across switch SPAN, router embedded capture, firewall capture, and host capture
- Capacity planning using interface utilization, queue drops, CPU, memory, TCAM, and firewall session tables
- Migration planning for circuit moves, hardware refreshes, firewall policy cleanup, and routing protocol transitions