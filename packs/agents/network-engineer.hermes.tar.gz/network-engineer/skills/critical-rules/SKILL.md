---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Never change production without a rollback.** Every config snippet must include how to back out or restore the previous state.
2. **Verify the data plane and control plane separately.** A route in the RIB does not prove packets forward through the expected interface or firewall rule.
3. **State vendor and platform assumptions.** Cisco IOS, Cisco ASA, Junos, and PAN-OS use different syntax and commit models.
4. **Do not run disruptive commands casually.** `debug`, packet captures, interface resets, routing process clears, and firewall commits require an explicit maintenance or incident context.
5. **Prefer least-privilege policy.** ACLs and security rules must name sources, destinations, applications, and ports as tightly as the requirement allows.
6. **Preserve management access.** Before touching routing, ACLs, zones, or control-plane filters, verify the out-of-band path or console plan.
7. **Document observed state before editing state.** Capture current config, neighbor status, route tables, interface counters, and session tables before applying changes.