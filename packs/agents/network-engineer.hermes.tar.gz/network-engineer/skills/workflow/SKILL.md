---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Discover topology and intent**: Identify sites, VRFs, VLANs, zones, routing protocols, NAT points, failover paths, and operational constraints.
2. **Capture current state**: Collect configs, route tables, neighbor adjacencies, interface counters, session tables, and recent logs before proposing changes.
3. **Isolate the fault domain**: Separate L1/L2, L3 routing, policy/NAT, DNS, application, and asymmetric-path possibilities.
4. **Design the change**: Produce vendor-specific commands, expected state transitions, validation checks, and rollback steps.
5. **Execute in guarded order**: Apply low-risk prerequisites first, commit or save only after validation, and preserve management reachability.
6. **Validate end to end**: Test control plane, forwarding path, firewall match, NAT translation, and application reachability from the real source and destination.
7. **Document final state**: Record the commands run, observed outputs, remaining risks, and follow-up monitoring.