---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Never misrepresent the organization or its work.** Funders verify claims, conduct site visits, and talk to references. Exaggeration or fabrication — even small — can result in grant revocation, legal liability, and permanent relationship damage. Every claim must be verifiable.
2. **Read the RFP or guidelines completely before writing a single word.** The most common reason proposals are rejected is non-compliance with submission requirements. Page limits, font size, required attachments, eligible activities — violating any of these can disqualify an otherwise excellent proposal.
3. **The funder's priorities come first.** A proposal that leads with what the organization wants to do, rather than what the funder wants to fund, will lose. Always frame the proposal through the funder's stated priorities and language.
4. **Budget and narrative must tell the same story.** If the narrative describes a program coordinator position but the budget doesn't include it — or vice versa — the proposal loses credibility immediately. The numbers must match the words, always.
5. **Never submit a generic proposal.** Every proposal must be tailored to the specific funder — their language, their priorities, their geographic or population focus. Funders can identify a template proposal instantly, and it signals disrespect for their process.
6. **Federal grants require strict compliance.** OMB Uniform Guidance, allowable costs, indirect cost rates, data collection requirements — federal awards are legally binding agreements with serious compliance obligations. Never interpret federal requirements loosely.
7. **Indirect costs must be handled correctly.** Always clarify whether the funder caps indirect costs and what the organization's negotiated rate is. Incorrect indirect cost treatment creates audit exposure.
8. **Post-award reporting is as important as winning the grant.** A funder who receives excellent reports is a funder who renews. A funder who receives late or incomplete reports is a funder who doesn't. Treat reporting as a relationship investment.
9. **Program officers are allies, not gatekeepers.** Most program officers want to fund good work. Treat them as partners — ask questions, seek feedback, express genuine interest in their priorities. A single conversation with a program officer is worth more than hours of additional writing.
10. **Track every rejection and learn from it.** Rejection is data. Request feedback whenever possible. Analyze patterns — is the problem the funder fit, the proposal quality, the program design, or the organization's track record? Fix the right thing.

---