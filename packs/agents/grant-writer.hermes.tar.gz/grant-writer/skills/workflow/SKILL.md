---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Prospect Research & Prioritization

1. **Identify aligned funders** — use Foundation Directory, GrantStation, or agency databases
2. **Analyze fit** — mission, geography, population, grant size, eligibility, and relationship history
3. **Prioritize by ROI** — likelihood of success × grant size × relationship strength
4. **Track deadlines** — build a 12-month grant calendar with all deadlines and required materials
5. **Assign cultivation actions** — which funders need relationship building before applying?

### Step 2: Funder Cultivation

1. **Research the program officer** — understand their background and priorities
2. **Make contact before applying** — email or call to confirm fit and ask questions
3. **Attend funder briefings or informational webinars** — shows engagement
4. **Invite to program or site visit** — builds connection to the work
5. **Document every interaction** — build a relationship history for institutional memory

### Step 3: Proposal Development

1. **Read the RFP/guidelines completely** — highlight requirements, restrictions, and evaluation criteria
2. **Develop the outline** — map narrative sections to required structure
3. **Gather data and organizational materials** — financials, program stats, staff bios, letters of support
4. **Write the narrative** — funder's priorities first, organization's strengths second
5. **Develop the budget** — with program leadership, not after the narrative is written
6. **Internal review** — Executive Director, program staff, Finance, Legal (for federal)
7. **Final compliance check** — page count, attachments, portal submission requirements
8. **Submit early** — never rely on a portal working perfectly on deadline day

### Step 4: Post-Submission Follow-Up

1. **Confirm receipt** — most portals send confirmation; follow up if not received
2. **Respond to questions promptly** — program officers may request clarification
3. **Track decision timeline** — most funders communicate a decision date
4. **Prepare for site visit or interview** — some funders conduct these before awarding

### Step 5: Post-Award Management

1. **Celebrate internally** — recognition matters for team morale
2. **Read the award letter carefully** — special conditions, reporting requirements, restrictions
3. **Set up grant file** — all award documents, correspondence, financial records
4. **Brief program staff** — they need to know what was promised and what's required
5. **Build reporting deadlines into the grant calendar**
6. **Maintain relationship with program officer** — periodic updates, not just at report time

---