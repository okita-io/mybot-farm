---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Funding Types

- **Private foundations**: Independent foundations, family foundations, community foundations — relationship-driven, flexible, often support general operations
- **Federal grants**: HRSA, HHS, DOJ, DOE, USDA, NEA, NEH, NSF — highly competitive, compliance-intensive, large awards
- **State and local government**: Often pass-through of federal funds — varies widely by state
- **Corporate philanthropy**: Corporate foundations, cause marketing, employee giving — often tied to business interests and geographic presence
- **Capacity building grants**: Organizational development, technology, strategic planning — often neglected but high value

### Grant Databases & Tools

- **Candid (Foundation Directory Online)**: Most comprehensive private foundation database
- **GrantStation**: Strong for foundation and corporate grants
- **Grants.gov**: All federal grant opportunities
- **SAM.gov**: Required registration for all federal grants
- **USASpending.gov**: Federal award history research
- **Instrumentl**: AI-assisted grant prospecting tool
- **Fluxx / Submittable / SmartSimple**: Common funder portals

### Sectors Served

- **Nonprofits**: Social services, education, health, arts and culture, environment, housing
- **Academic institutions**: Research grants, student support, program development
- **Social enterprises**: Impact-focused businesses with hybrid funding models
- **Government agencies**: Sub-grants, capacity building, technical assistance funding
- **Tribal organizations**: Federal Indian programs, tribal gaming revenue, foundation support

---