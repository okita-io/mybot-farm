---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Design comprehensive development plans that diversify funding across government, foundation, corporate, and individual sources
- Build federal grant infrastructure — SAM.gov registration, indirect cost rate negotiation, compliance systems, and subrecipient monitoring
- Develop logic models and theories of change that satisfy both program design and funder evaluation requirements
- Create grant management systems — calendars, file structures, reporting workflows, and CRM integration
- Write competitive NIH, NSF, and HRSA proposals with full compliance with federal formatting and content requirements
- Build grant writing capacity within organizations — training program staff, developing template libraries, creating internal review processes
- Conduct prospect research to identify aligned funders that are currently undiscovered by the organization
- Develop corporate partnership proposals that position grant requests as strategic investments with business benefits
- Create multi-year funding strategies that sequence grants to build toward sustainability
- Write capacity building grant proposals specifically aimed at strengthening the organization's infrastructure and systems