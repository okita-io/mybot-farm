---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Prospect Research Framework

```
FUNDER RESEARCH TEMPLATE
───────────────────────────────────────
Funder Name:        [Foundation / Agency / Corporation]
Funder Type:        [ ] Private Foundation  [ ] Community Foundation
                    [ ] Federal Agency  [ ] State/Local Government
                    [ ] Corporate Foundation  [ ] Family Foundation

GIVING PROFILE
───────────────────────────────────────
Total annual giving:        $___________
Average grant size:         $___________
Range:                      $_______ to $_______
Geographic focus:           [Local / Regional / National / International]
Population focus:           [Who they prioritize serving]
Program areas funded:       [List]
What they WON'T fund:       [Exclusions — critical to review]

ALIGNMENT ASSESSMENT
───────────────────────────────────────
Mission alignment:          High / Medium / Low
Program fit:                High / Medium / Low
Geographic fit:             Yes / No / Partial
Organizational fit:         [Budget size, org type, track record requirements]
Overall fit rating:         Strong / Moderate / Weak — pursue / pass

RELATIONSHIP STATUS
───────────────────────────────────────
Prior relationship:         Yes / No
Prior grants received:      [List with amounts and years]
Program officer contact:    [Name, email, phone]
Last contact date:          [Date and nature of contact]
Cultivation needed:         [What relationship-building is required before applying]

LOGISTICS
───────────────────────────────────────
Application portal:         [URL and login]
Deadline(s):                [Rolling / Specific date(s)]
LOI required:               Yes / No — due: [date]
Invitation required:        Yes / No
Typical grant period:       [1 year / Multi-year]
# … truncated for farm planting — see upstream for the full sample
```

### Letter of Inquiry (LOI) Framework

```
LOI STRUCTURE (typically 1-3 pages)
───────────────────────────────────────
Para 1 — THE HOOK (what problem you're solving)
  Lead with the problem or need — not the organization.
  Use data to establish the scale and urgency of the issue.
  Connect the problem to the funder's stated priorities.
  Example: "Each year in [geography], [X number] of [population]
  face [specific problem], resulting in [consequence]. Despite
  [existing resources], [gap] remains unaddressed."

Para 2 — YOUR SOLUTION (what you do and why it works)
  Describe the program or project in plain language.
  Explain what makes your approach distinctive or effective.
  Reference any evidence base, model, or proven practice.
  "Our [program name] addresses this gap by [approach].
  Unlike existing services, we [distinctive element].
  This approach is grounded in [evidence/model/practice]."

Para 3 — YOUR TRACK RECORD (why you can do this)
  Establish organizational credibility — years of experience,
  population served, prior outcomes, relevant expertise.
  "Over [X] years, [Organization] has [accomplishment].
  Our team includes [relevant expertise]. Last year, we
  served [X people] with [Y outcome]."

Para 4 — THE REQUEST (what you're asking for)
  State the funding amount and grant period clearly.
  Name the specific use of funds at a high level.
  Connect the investment to measurable outcomes.
  "We are requesting $[amount] over [period] to [purpose].
  This investment will enable us to [outcome] for [population]."

Para 5 — THE CLOSE (why this funder, why now)
  Reference alignment with the funder's priorities specifically.
  Express genuine interest in partnership.
  Invite dialogue.
  "Given [Funder]'s commitment to [stated priority], we believe
  there is strong alignment with our work. We welcome the
  opportunity to discuss how this partnership might advance
  our shared goals."
# … truncated for farm planting — see upstream for the full sample
```

### Full Proposal Framework

```
PROPOSAL NARRATIVE STRUCTURE
───────────────────────────────────────
SECTION 1 — EXECUTIVE SUMMARY (1 page)
  Write this last.
  □ Organization name and mission (1 sentence)
  □ The problem being addressed (2 sentences)
  □ The proposed solution (2-3 sentences)
  □ The funding request ($X over Y period)
  □ Expected outcomes (2-3 bullets)
  □ Geographic scope and target population

SECTION 2 — STATEMENT OF NEED
  □ Define the problem with current, credible data
  □ Local data is more compelling than national statistics
  □ Describe who is affected and how
  □ Explain why existing resources are insufficient…