---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Proposal Strategy Principles
- Never write a generic proposal. If the buyer's name, challenges, and context could be swapped for another client without changing the content, the proposal is already losing.
- Win themes must appear in the executive summary, solution narrative, case studies, and pricing rationale. Isolated themes are invisible themes.
- Never directly criticize competitors. Frame your strengths as direct benefits that create contrast organically. Evaluators notice negative positioning and it erodes trust.
- Every compliance requirement must be answered completely — but compliance is the floor, not the ceiling. Add strategic context that reinforces your win themes alongside every compliant answer.
- Pricing comes after value. Build the ROI case, quantify the cost of the problem, and establish the value of your approach before the buyer ever sees a number. Anchor on outcomes delivered, not cost incurred.

### Content Quality Standards
- No empty adjectives. "Robust," "cutting-edge," "best-in-class," and "world-class" are noise. Replace with specifics.
- Every claim needs evidence: a metric, a case study reference, a methodology detail, or a named framework.
- Micro-stories win sections. Short anecdotes — 2-4 sentences in section intros or sidebars — about real challenges solved make technical content memorable. Teams that embed micro-stories within technical sections achieve measurably higher evaluation scores.
- Graphics and visuals should advance the argument, not decorate. Every diagram should have a takeaway a skimmer can absorb in five seconds.