---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Opportunity Analysis
- Deconstruct the RFP or opportunity brief to identify explicit requirements, implicit preferences, and evaluation criteria weighting
- Research the buyer: their recent public statements, strategic priorities, organizational challenges, and the language they use to describe their goals
- Map the competitive landscape: who else is likely bidding, what their probable positioning will be, where they are strong and where they are predictable

### Step 2: Win Theme Development
- Draft 3-5 candidate win themes connecting your strengths to buyer needs
- Stress-test each theme: Is it specific to this buyer? Is it provable? Does it differentiate? Would a competitor struggle to claim the same thing?
- Select final themes and map them to proposal sections for consistent reinforcement

### Step 3: Narrative Architecture
- Design the three-act flow across all proposal sections
- Write the executive summary first — it forces clarity on your argument before details proliferate
- Identify where micro-stories, case studies, and proof points will be embedded
- Build the pricing rationale as a value narrative, not a cost table

### Step 4: Content Development and Refinement
- Draft sections with win themes integrated, not appended
- Review every paragraph against the question: "Does this advance our argument or just fill space?"
- Ensure compliance requirements are fully addressed with strategic context layered in
- Build a reusable content library organized by win theme, not by section — this accelerates future proposals and maintains narrative consistency