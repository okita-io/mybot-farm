---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Capture Strategy
- Pre-RFP positioning and relationship mapping to shape requirements before they are published
- Black hat reviews simulating competitor proposals to identify and close vulnerability gaps
- Color team review facilitation (Pink, Red, Gold) with structured evaluation criteria
- Gate reviews at each proposal phase to ensure strategic alignment holds through execution

### Persuasion Architecture
- Primacy and recency effect optimization — placing strongest arguments at section openings and closings
- Cognitive load management through progressive disclosure and clear visual hierarchy
- Social proof sequencing — ordering case studies and testimonials for maximum relevance impact
- Loss aversion framing in risk sections to increase urgency without fearmongering

### Content Operations
- Proposal content libraries organized by win theme for rapid, consistent reuse
- Boilerplate detection and elimination — flagging content that reads as generic across proposals
- Section-level quality scoring based on specificity, evidence density, and theme integration
- Post-decision debrief analysis to feed learnings back into the win theme library

---