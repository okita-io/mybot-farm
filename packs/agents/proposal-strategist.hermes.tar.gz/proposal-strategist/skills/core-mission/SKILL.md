---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Win Theme Development
Every proposal needs 3-5 win themes: compelling, client-centric statements that connect your solution directly to the buyer's most urgent needs. Win themes are not slogans. They are the narrative backbone woven through every section of the document.

A strong win theme:
- Names the buyer's specific challenge, not a generic industry problem
- Connects a concrete capability to a measurable outcome
- Differentiates without needing to mention a competitor
- Is provable with evidence, case studies, or methodology

Example of weak vs. strong:
- **Weak**: "We have deep experience in digital transformation"
- **Strong**: "Our migration framework reduces cutover risk by staging critical workloads in parallel — the same approach that kept [similar client] at 99.97% uptime during a 14-month platform transition"

### Three-Act Proposal Narrative
Winning proposals follow a narrative arc, not a checklist:

**Act I — Understanding the Challenge**: Demonstrate that you understand the buyer's world better than they expected. Reflect their language, their constraints, their political landscape. This is where trust is built. Most losing proposals skip this act entirely or fill it with boilerplate.

**Act II — The Solution Journey**: Walk the evaluator through your approach as a guided experience, not a feature dump. Each capability maps to a challenge raised in Act I. Methodology is explained as a sequence of decisions, not a wall of process diagrams. This is where win themes do their heaviest work.

**Act III — The Transformed State**: Paint a specific picture of the buyer's future. Quantified outcomes, timeline milestones, risk reduction metrics. The evaluator should finish this section thinking about implementation, not evaluation.

### Executive Summary Craft
The executive summary is the most critical section. Many evaluators — especially senior stakeholders — read only this. It is not a summary of the proposal. It is the proposal's closing argument, placed first.

Structure for a winning executive summary:
1. **Mirror the buyer's situation** in their own language (2-3 sentences proving you listened)
2. **Introduce the central tension** — the cost of inaction or the opportunity at risk
3. **Present your thesis** — how your approach resolves the tension (win themes appear here)
4. **Offer proof** — one or two concrete evidence points (metrics, similar engagements, differentiators)
5. **Close with the transformed state** — the specific outcome they can expect

Keep it to one page. Every sentence must earn its place.