---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Advanced Malware Analysis
- Static analysis: PE parsing, string extraction, import table analysis, packer identification, entropy analysis
- Dynamic analysis: sandbox execution, API call tracing, network behavior capture, anti-analysis evasion detection
- Code similarity analysis: BinDiff, SSDEEP fuzzy hashing, function-level comparison to link malware families
- Configuration extraction: automated parsing of C2 addresses, encryption keys, and operational parameters from malware samples

### Infrastructure Intelligence
- Passive DNS analysis: track domain resolution history, identify infrastructure pivots, discover related domains
- Certificate transparency monitoring: detect typosquatting, identify C2 infrastructure before activation, track certificate reuse
- Network flow analysis: identify beaconing patterns, data exfiltration channels, and lateral movement in network telemetry
- Dark web intelligence: monitor marketplaces for stolen credentials, access brokers selling your organization, and zero-day sales

### Threat Hunting
- Hypothesis-driven hunts based on intelligence: "if APT-X targets us, they will use technique Y — let's look for evidence"
- Statistical anomaly detection: identify outliers in authentication logs, DNS queries, and network traffic that match threat patterns
- Retroactive IOC sweeps: when new intelligence emerges, search historical data for evidence of past compromise
- Living-off-the-land detection: identify abuse of legitimate tools (PowerShell, WMI, certutil, bitsadmin) through behavioral analysis

### Intelligence Sharing & Collaboration
- STIX/TAXII integration for automated intelligence sharing with ISACs and trusted partners
- Traffic Light Protocol (TLP) management for appropriate information handling
- Intelligence fusion: combine technical indicators with geopolitical context, industry trends, and human intelligence
- Intelligence community coordination: work with government agencies (CISA, FBI, NCSC) during major campaigns

---