---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

YARA Rule Development
```yara
/*
   YARA Rule: Cobalt Strike Beacon Payload Detection
   Author: Threat Intelligence Analyst
   Description: Detects Cobalt Strike Beacon payloads in memory or on disk
   by identifying characteristic strings, configuration patterns, and
   shellcode stagers common across Cobalt Strike versions 4.x.
   Confidence: HIGH — tested against 50+ known Cobalt Strike samples
   False Positive Rate: LOW — markers are specific to CS framework
*/

rule CobaltStrike_Beacon_Generic {
    meta:
        description = "Detects Cobalt Strike Beacon v4.x payloads"
        author = "Threat Intelligence Analyst"
        date = "2024-01-15"
        tlp = "WHITE"
        mitre_attack = "T1071.001, T1059.003, T1055"
        confidence = "high"
        hash_sample_1 = "a1b2c3d4e5f6..."
        hash_sample_2 = "f6e5d4c3b2a1..."

    strings:
        // Beacon configuration markers
        $config_header = { 00 01 00 01 00 02 ?? ?? 00 02 00 01 00 02 }
        $config_xor = { 69 68 69 68 69 }  // Default XOR key 0x69

        // Named pipe patterns (default and common custom)
        $pipe_default = "\\\\.\\pipe\\msagent_" ascii wide
        $pipe_post = "\\\\.\\pipe\\postex_" ascii wide
        $pipe_ssh = "\\\\.\\pipe\\postex_ssh_" ascii wide

        // Reflective loader markers
        $reflective_loader = { 4D 5A 41 52 55 48 89 E5 }  // MZ + ARUH mov rbp,rsp
        $reflective_pe = "ReflectiveLoader" ascii

        // HTTP C2 communication patterns
        $http_get = "/activity" ascii
        $http_post = "/submit.php" ascii
        $http_cookie = "SESSIONID=" ascii

# … truncated for farm planting — see upstream for the full sample
```

### Sigma Detection Rules
```yaml
# Sigma Rule: Kerberoasting via Service Ticket Request
# Detects mass TGS requests indicative of Kerberoasting attacks

title: Potential Kerberoasting Activity
id: a3f5b2d1-4e7c-8a9b-1234-567890abcdef
status: stable
level: high
description: |
  Detects when a single user requests an unusually high number of Kerberos
  service tickets (TGS) with RC4 encryption within a short time window.
  This pattern is characteristic of Kerberoasting, where an attacker
  requests service tickets to crack service account passwords offline.
author: Threat Intelligence Analyst
date: 2024/01/15
modified: 2024/06/01
references:
  - https://attack.mitre.org/techniques/T1558/003/
tags:
  - attack.credential_access
  - attack.t1558.003
logsource:
  product: windows
  service: security
detection:
  selection:
    EventID: 4769              # Kerberos Service Ticket Operation
    TicketEncryptionType: '0x17'  # RC4-HMAC (weak, targeted by Kerberoasting)
    Status: '0x0'              # Success
  filter_machine_accounts:
    ServiceName|endswith: '$'   # Exclude machine account tickets
  filter_krbtgt:
    ServiceName: 'krbtgt'       # Exclude TGT renewals
  condition: selection and not filter_machine_accounts and not filter_krbtgt | count(ServiceName) by TargetUserName > 10
  timeframe: 5m
falsepositives:
  - Vulnerability scanners that enumerate SPNs
  - Monitoring tools that query multiple services
  - Service account health checks (should use AES, not RC4)

---
# … truncated for farm planting — see upstream for the full sample
```

### Threat Actor Profile Template
```markdown
# Threat Actor Profile: [Name / Tracking ID]

## Attribution & Aliases
| Organization | Tracking Name   |
|-------------|-----------------|
| [Your org]  | [Internal ID]   |
| Mandiant    | [APTxx / UNCxxxx] |
| CrowdStrike | [Animal name]   |
| Microsoft   | [Weather name]  |

**Confidence in attribution**: [Low / Medium / High]
**Basis**: [Infrastructure overlap, code reuse, TTPs, operational patterns, HUMINT]

## Overview
[2-3 paragraph summary: who they are, what they want, how they operate]

## Targeting
| Dimension    | Details                          |
|-------------|----------------------------------|
| Industries  | [Primary targets by sector]      |
| Geography   | [Targeted regions/countries]     |
| Motivation  | [Espionage / Financial / Hacktivism / Sabotage] |
| Active since| [First observed date]            |
| Last seen   | [Most recent confirmed activity] |

## ATT&CK TTP Summary

### Initial Access
| Technique | ID | Details |
|-----------|----|---------|
| Spearphishing | T1566.001 | [Specific tradecraft: lure themes, delivery method] |

### Execution
| Technique | ID | Details |
|-----------|----|---------|…