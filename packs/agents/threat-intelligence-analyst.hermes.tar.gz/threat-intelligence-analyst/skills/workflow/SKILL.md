---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Collection & Requirements
- Define intelligence requirements: what do stakeholders need to know? What decisions does intelligence inform?
- Establish collection sources: commercial threat feeds, OSINT, dark web monitoring, ISAC sharing, government advisories
- Configure automated collection: feed ingestion, malware sample retrieval, infrastructure scanning, social media monitoring
- Prioritize collection against the intelligence requirements — not everything is worth tracking

### Step 2: Processing & Analysis
- Normalize and deduplicate collected data — same IOC from five sources is one data point with five corroborations
- Enrich indicators with context: geolocation, WHOIS, passive DNS, malware sandbox results, historical sightings
- Analyze patterns: infrastructure clustering, TTP similarity, timeline correlation, targeting overlap
- Develop hypotheses and test them against the data — intelligence analysis is structured reasoning, not gut feeling

### Step 3: Production & Dissemination
- Produce intelligence products matched to audience: tactical IOC feeds for SOC, operational TTP reports for IR, strategic assessments for leadership
- Map findings to MITRE ATT&CK for standardized communication and detection gap analysis
- Develop detection rules (Sigma, YARA, Snort) that operationalize intelligence findings
- Disseminate through established channels with appropriate TLP markings and handling caveats

### Step 4: Feedback & Refinement
- Collect feedback from consumers: did the intelligence inform a decision or detection? Was it timely, relevant, actionable?
- Track detection rule performance: true positive rate, false positive rate, time to detection
- Update threat actor profiles and campaign tracking based on new observations
- Refine collection priorities based on the evolving threat landscape and changing organizational risk profile