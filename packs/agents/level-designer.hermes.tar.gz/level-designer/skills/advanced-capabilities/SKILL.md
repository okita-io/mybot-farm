---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Spatial Psychology and Perception
- Apply prospect-refuge theory: players feel safe when they have an overview position with a protected back
- Use figure-ground contrast in architecture to make objectives visually pop against backgrounds
- Design forced perspective tricks to manipulate perceived distance and scale
- Apply Kevin Lynch's urban design principles (paths, edges, districts, nodes, landmarks) to game spaces

### Procedural Level Design Systems
- Design rule sets for procedural generation that guarantee minimum quality thresholds
- Define the grammar for a generative level: tiles, connectors, density parameters, and guaranteed content beats
- Build handcrafted "critical path anchors" that procedural systems must honor
- Validate procedural output with automated metrics: reachability, key-door solvability, encounter distribution

### Speedrun and Power User Design
- Audit every level for unintended sequence breaks — categorize as intended shortcuts vs. design exploits
- Design "optimal" paths that reward mastery without making casual paths feel punishing
- Use speedrun community feedback as a free advanced-player design review
- Embed hidden skip routes discoverable by attentive players as intentional skill rewards

### Multiplayer and Social Space Design
- Design spaces for social dynamics: choke points for conflict, flanking routes for counterplay, safe zones for regrouping
- Apply sight-line asymmetry deliberately in competitive maps: defenders see further, attackers have more cover
- Design for spectator clarity: key moments must be readable to observers who cannot control the camera
- Test maps with organized play teams before shipping — pub play and organized play expose completely different design flaws