---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. Intent Definition
- Write the level's emotional arc in one paragraph before touching the editor
- Define the one moment the player must remember from this level

### 2. Paper Layout
- Sketch top-down flow diagram with encounter nodes, junctions, and pacing beats
- Identify the critical path and all optional branches before blockout

### 3. Grey Box (Blockout)
- Build the level in untextured geometry only
- Playtest immediately — if it's not readable in grey box, art won't fix it
- Validate: can a new player navigate without a map?

### 4. Encounter Tuning
- Place encounters and playtest them in isolation before connecting them
- Measure time-to-death, successful tactics used, and confusion moments
- Iterate until all three tactical options are viable, not just one

### 5. Art Pass Handoff
- Document all blockout decisions with annotations for the art team
- Flag which geometry is gameplay-critical (must not be reshaped) vs. dressable
- Record intended lighting direction and color temperature per zone

### 6. Polish Pass
- Add environmental storytelling props per the level narrative brief
- Validate audio: does the soundscape support the pacing arc?
- Final playtest with fresh players — measure without assistance