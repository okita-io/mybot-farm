---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Level Design Document
```markdown
# Level: [Name/ID]

## Intent
**Player Fantasy**: [What the player should feel in this level]
**Pacing Arc**: Tension → Release → Escalation → Climax → Resolution
**New Mechanic Introduced**: [If any — how is it taught spatially?]
**Narrative Beat**: [What story moment does this level carry?]

## Layout Specification
**Shape Language**: [Linear / Hub / Open / Labyrinth]
**Estimated Playtime**: [X–Y minutes]
**Critical Path Length**: [Meters or node count]
**Optional Areas**: [List with rewards]

## Encounter List
| ID  | Type     | Enemy Count | Tactical Options | Fallback Position |
|-----|----------|-------------|------------------|-------------------|
| E01 | Ambush   | 4           | Flank / Suppress | Door archway      |
| E02 | Arena    | 8           | 3 cover positions| Elevated platform |

## Flow Diagram
[Entry] → [Tutorial beat] → [First encounter] → [Exploration fork]
                                                        ↓           ↓
                                               [Optional loot]  [Critical path]
                                                        ↓           ↓
                                                   [Merge] → [Boss/Exit]
```

### Pacing Chart
```
Time    | Activity Type  | Tension Level | Notes
--------|---------------|---------------|---------------------------
0:00    | Exploration    | Low           | Environmental story intro
1:30    | Combat (small) | Medium        | Teach mechanic X
3:00    | Exploration    | Low           | Reward + world-building
4:30    | Combat (large) | High          | Apply mechanic X under pressure
6:00    | Resolution     | Low           | Breathing room + exit
```

### Blockout Specification
```markdown
## Room: [ID] — [Name]

**Dimensions**: ~[W]m × [D]m × [H]m
**Primary Function**: [Combat / Traversal / Story / Reward]

**Cover Objects**:
- 2× low cover (waist height) — center cluster
- 1× destructible pillar — left flank
- 1× elevated position — rear right (accessible via crate stack)

**Lighting**:
- Primary: warm directional from [direction] — guides eye toward exit
- Secondary: cool fill from windows — contrast for readability
- Accent: flickering [color] on objective marker

**Entry/Exit**:
- Entry: [Door type, visibility on entry]
- Exit: [Visible from entry? Y/N — if N, why?]

**Environmental Story Beat**:
[What does this room's prop placement tell the player about the world?]
```

### Navigation Affordance Checklist
```markdown
## Readability Review

Critical Path
- [ ] Exit visible within 3 seconds of entering room
- [ ] Critical path lit brighter than optional paths
- [ ] No dead ends that look like exits

Combat
- [ ] All enemies visible before player enters engagement range
- [ ] At least 2 tactical options from entry position
- [ ] Fallback position exists and is spatially obvious

Exploration
- [ ] Optional areas marked by distinct lighting or color
- [ ] Reward visible from the choice point (temptation design)
- [ ] No navigation ambiguity at junctions
```