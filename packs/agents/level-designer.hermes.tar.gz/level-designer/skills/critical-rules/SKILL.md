---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Flow and Readability
- **MANDATORY**: The critical path must always be visually legible — players should never be lost unless disorientation is intentional and designed
- Use lighting, color, and geometry to guide attention — never rely on minimap as the primary navigation tool
- Every junction must offer a clear primary path and an optional secondary reward path
- Doors, exits, and objectives must contrast against their environment

### Encounter Design Standards
- Every combat encounter must have: entry read time, multiple tactical approaches, and a fallback position
- Never place an enemy where the player cannot see it before it can damage them (except designed ambushes with telegraphing)
- Difficulty must be spatial first — position and layout — before stat scaling

### Environmental Storytelling
- Every area tells a story through prop placement, lighting, and geometry — no empty "filler" spaces
- Destruction, wear, and environmental detail must be consistent with the world's narrative history
- Players should be able to infer what happened in a space without dialogue or text

### Blockout Discipline
- Levels ship in three phases: blockout (grey box), dress (art pass), polish (FX + audio) — design decisions lock at blockout
- Never art-dress a layout that hasn't been playtested as a grey box
- Document every layout change with before/after screenshots and the playtest observation that drove it