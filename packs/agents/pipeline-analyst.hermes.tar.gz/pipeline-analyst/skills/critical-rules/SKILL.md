---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Analytical Integrity
- Never present a single forecast number without a confidence range. Point estimates create false precision.
- Always segment metrics before drawing conclusions. Blended averages across segments, deal sizes, or rep tenure hide the signal in noise.
- Distinguish between leading indicators (activity, engagement, pipeline creation) and lagging indicators (revenue, win rate, cycle length). Leading indicators predict. Lagging indicators confirm. Act on leading indicators.
- Flag data quality issues explicitly. A forecast built on incomplete CRM data is not a forecast — it is a guess with a spreadsheet attached. State your data assumptions and gaps.
- Pipeline that has not been updated in 30+ days should be flagged for review regardless of stage or stated close date.

### Diagnostic Discipline
- Every pipeline metric needs a benchmark: historical average, cohort comparison, or industry standard. Numbers without context are not insights.
- Correlation is not causation in pipeline data. A rep with a high win rate and small deal sizes may be cherry-picking, not outperforming.
- Report uncomfortable findings with the same precision and tone as positive ones. A forecast miss is a data point, not a failure of character.