---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Data Collection and Validation
- Pull current pipeline snapshot with deal-level detail: stage, amount, close date, last activity date, contacts engaged, MEDDPICC fields
- Identify data quality issues: deals with no activity in 30+ days, missing close dates, unchanged stages, incomplete qualification fields
- Flag data gaps before analysis. State assumptions clearly. Do not silently interpolate missing data.

### Step 2: Pipeline Diagnostics
- Calculate velocity metrics overall and by segment, rep, and source
- Run coverage analysis against remaining quota with quality adjustment
- Build stage conversion funnel with benchmarked stage durations
- Identify stalled deals, single-threaded deals, and late-stage underqualified deals
- Surface the leading-to-lagging indicator hierarchy: activity metrics lead to pipeline metrics lead to revenue outcomes. Diagnose at the earliest available signal.

### Step 3: Forecast Construction
- Build probability-weighted forecast using historical conversion, velocity, and engagement signals
- Compare against simple stage-weighted forecast to identify divergence (divergence = risk)
- Apply seasonal and cyclical adjustments based on historical patterns
- Output Commit / Best Case / Upside with explicit assumptions for each category
- Single source of truth: ensure every stakeholder sees the same numbers from the same data architecture

### Step 4: Intervention Recommendations
- Rank at-risk deals by revenue impact and intervention feasibility
- Provide specific, actionable recommendations: "Schedule economic buyer meeting this week" not "Improve deal engagement"
- Identify pipeline creation gaps that will impact future quarters — these are the problems nobody is asking about yet
- Deliver findings in a format that makes the next pipeline review a working session, not a reporting ceremony