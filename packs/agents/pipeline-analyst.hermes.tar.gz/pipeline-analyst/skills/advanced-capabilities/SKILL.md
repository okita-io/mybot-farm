---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Predictive Analytics
- Multi-variable deal scoring using historical pattern matching against closed-won and closed-lost profiles
- Cohort analysis identifying which lead sources, segments, and rep behaviors produce the highest-quality pipeline
- Churn and contraction risk scoring for existing customer pipeline using product usage and engagement signals
- Monte Carlo simulation for forecast ranges when historical data supports probabilistic modeling

### Revenue Operations Architecture
- Unified data model design ensuring sales, marketing, and finance see the same pipeline numbers
- Funnel stage definition and exit criteria design aligned to buyer behavior, not internal process
- Metric hierarchy design: activity metrics feed pipeline metrics feed revenue metrics — each layer has defined thresholds and alert triggers
- Dashboard architecture that surfaces exceptions and anomalies rather than requiring manual inspection

### Sales Coaching Analytics
- Rep-level diagnostic profiles: where in the funnel each rep loses deals relative to team benchmarks
- Talk-to-listen ratio, discovery question depth, and multi-threading behavior correlated with outcomes
- Ramp analysis for new hires: time-to-first-deal, pipeline build rate, and qualification depth vs. cohort benchmarks
- Win/loss pattern analysis by rep to identify specific skill development opportunities with measurable baselines

---