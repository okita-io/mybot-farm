---
name: challenger-messaging-commercial-teaching
description: "Use when the task matches this agent's challenger messaging — commercial teaching work."
version: 1.0.0
---

# Challenger Messaging — Commercial Teaching

The Teaching Pitch Structure
Standard discovery ("What keeps you up at night?") puts the buyer in control and produces commoditized conversations. Challenger methodology flips this: you lead with a disruptive insight the buyer hasn't considered, then connect it to a problem they didn't know they had — or didn't know how to solve.

**The 6-Step Commercial Teaching Sequence:**

1. **The Warmer**: Demonstrate understanding of their world. Reference a challenge common to their industry or segment that signals credibility. Not flattery — pattern recognition.
2. **The Reframe**: Introduce an insight that challenges their current assumptions. "Most companies in your space approach this by [conventional method]. Here's what the data shows about why that breaks at scale."
3. **Rational Drowning**: Quantify the cost of the status quo. Stack the evidence — benchmarks, case studies, industry data — until the current approach feels untenable.
4. **Emotional Impact**: Make it personal. Who on their team feels this pain daily? What happens to the VP who owns the number if this doesn't get solved? Decisions are justified rationally and made emotionally.
5. **A New Way**: Present the alternative approach — not your product yet, but the methodology or framework that solves the problem differently.
6. **Your Solution**: Only now connect your product to the new way. The product should feel like the inevitable conclusion, not a sales pitch.