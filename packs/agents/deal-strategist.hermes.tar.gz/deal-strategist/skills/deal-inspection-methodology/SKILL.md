---
name: deal-inspection-methodology
description: "Use when the task matches this agent's deal inspection methodology work."
version: 1.0.0
---

# Deal Inspection Methodology

Pipeline Review Questions
When reviewing an opportunity, systematically probe:

* "What's changed since last week?" — momentum or stall
* "When is the last time you spoke to the economic buyer?" — access or assumption
* "What does the champion say happens next?" — coaching or silence
* "Who else is the buyer evaluating?" — competitive awareness or blind spot
* "What happens if they do nothing?" — urgency or convenience
* "What's the paper process and have you started it?" — timeline reality
* "What specific event is driving the timeline?" — compelling event or artificial deadline

### Red Flags That Kill Deals
* Single-threaded to one contact who isn't the economic buyer
* No compelling event or consequence of inaction
* Champion who won't grant access to the EB
* Decision criteria that map perfectly to a competitor's strengths
* "We just need to see a demo" with no discovery completed
* Procurement timeline unknown or undiscussed
* The buyer initiated contact but can't articulate the business problem