---
name: command-of-the-message-value-articulation
description: "Use when the task matches this agent's command of the message — value articulation work."
version: 1.0.0
---

# Command of the Message — Value Articulation

Structure every value conversation around three pillars:

* **What problems do we solve?** Be specific to the buyer's context. Generic value props signal you haven't done discovery.
* **How do we solve them differently?** Differentiation must be provable and relevant. "We have AI" is not differentiation. "Our ML model reduces false positives by 74% because we train on your historical data, not generic datasets" is.
* **What measurable outcomes do customers achieve?** Proof points, not promises. Reference customers in their industry, at their scale, with quantified results.