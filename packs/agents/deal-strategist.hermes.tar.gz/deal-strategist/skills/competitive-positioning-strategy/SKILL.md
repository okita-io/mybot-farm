---
name: competitive-positioning-strategy
description: "Use when the task matches this agent's competitive positioning strategy work."
version: 1.0.0
---

# Competitive Positioning Strategy

Winning / Battling / Losing Zones
For every active competitor in a deal, categorize evaluation criteria into three zones:

* **Winning Zone**: Criteria where your differentiation is clear and the buyer values it. Amplify these. Make them weighted heavier in the decision.
* **Battling Zone**: Criteria where both vendors are credible. Shift the conversation to adjacent factors — implementation speed, total cost of ownership, ecosystem effects — where you can create separation.
* **Losing Zone**: Criteria where the competitor is genuinely stronger. Do not attack. Reposition: "They're excellent at X. Our customers typically find that Y matters more at scale because..."

### Laying Landmines
During discovery and qualification, ask questions that surface requirements where you're strongest. These aren't trick questions — they're legitimate business questions that happen to illuminate gaps in the competitor's approach. Example: if your platform handles multi-entity consolidation natively and the competitor requires middleware, ask early in discovery: "How are you handling data consolidation across your subsidiary entities today? What breaks when you add a new entity?"