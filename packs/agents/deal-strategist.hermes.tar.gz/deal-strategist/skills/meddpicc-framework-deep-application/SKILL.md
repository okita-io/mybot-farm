---
name: meddpicc-framework-deep-application
description: "Use when the task matches this agent's meddpicc framework — deep application work."
version: 1.0.0
---

# MEDDPICC Framework — Deep Application

Every opportunity must be scored against all eight elements. A deal without all eight answered is a deal you don't understand. Organizations fully adopting MEDDPICC report 18% higher win rates and 24% larger deal sizes — but only when it's used as a thinking tool, not a checkbox exercise.

### Metrics
The quantifiable business outcome the buyer needs to achieve. Not "they want better reporting" — that's a feature request. Metrics sound like: "reduce new-hire onboarding from 14 days to 3" or "recover $2.4M annually in revenue leakage from billing errors." If the buyer can't articulate the metric, they haven't built internal justification. Help them find it or qualify out.

### Economic Buyer
The person who controls budget and can say yes when everyone else says no. Not the person who signs the PO — the person who decides the money gets spent. Test: can this person reallocate budget from another initiative to fund this? If no, you haven't found them. Access to the EB is earned through value, not title-matching.

### Decision Criteria
The specific technical, business, and commercial criteria the buyer will use to evaluate options. These must be explicit and documented. If you're guessing at the criteria, the competitor who helped write them is winning. Your job is to influence criteria toward your differentiators early — before the RFP lands.

### Decision Process
The actual sequence of steps from initial evaluation to signed contract, including who is involved at each stage, what approvals are required, and what timeline the buyer is working against. Ask: "Walk me through what happens between choosing a vendor and going live." Map every step. Every unmapped step is a place the deal can die silently.

### Paper Process
Legal review, procurement, security questionnaire, vendor risk assessment, data processing agreements — the operational gauntlet where "verbally won" deals go to die. Identify these requirements early. Ask: "Has your legal team reviewed agreements like ours before? What does security review typically look like?" A 6-week procurement cycle discovered in week 11 kills the quarter.

### Identify Pain
The specific, quantified business problem driving the initiative. Pain is not "we need a better tool." Pain is: "We lost three enterprise deals last quarter because our implementation timeline was 90 days and the buyer chose a competitor who does it in 30." Pain has a cost — in revenue, risk, time, or reputation. If they can't quantify the cost of inaction, the deal has no urgency and will stall.

### Champion
An internal advocate who has power (organizational influence), access (to the economic buyer and decision-making process), and personal motivation (their career benefits from this initiative succeeding). A friendly contact who takes your calls is not a champion. A champion coaches you on internal politics, shares the competitive landscape, and sells internally when you're not in the room. Test your champion: ask them to do something hard. If they won't, they're a coach at best.

### Competition
Every deal has competition — direct competitors, adjacent products expanding scope, internal build teams, or the most dangerous competitor of all: do nothing. Map the competitive field early. Understand where you win (your strengths align with their criteria), where you're battling (both vendors are credible), and where you're losing (their strengths align with criteria you can't match). The winning move on losing zones is to shrink their importance, not to lie about your capabilities.