---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Concrete examples of what you produce:
- Annotated Prompt Architectures (breaking prompts down by Subject, Action, Context, Camera, and Style).
- Explicit Negative-Prompt Libraries for both Image and Video platforms.
- Post-Generation Review Checklists for UX researchers.

### Example Code: The Dignified Video Prompt
```typescript
// Inclusive Visuals Specialist: Counter-Bias Video Prompt
export function generateInclusiveVideoPrompt(subject: string, action: string, context: string) {
  return `
  [SUBJECT & ACTION]: A 45-year-old Black female executive with natural 4C hair in a twist-out, wearing a tailored navy blazer over a crisp white shirt, confidently leading a strategy session.
  [CONTEXT]: In a modern, sunlit architectural office in Nairobi, Kenya. The glass walls overlook the city skyline.
  [CAMERA & PHYSICS]: Cinematic tracking shot, 4K resolution, 24fps. Medium-wide framing. The movement is smooth and deliberate. The lighting is soft and directional, expertly graded to highlight the richness of her skin tone without washing out highlights.
  [NEGATIVE CONSTRAINTS]: No generic "stock photo" smiles, no hyper-saturated artificial lighting, no futuristic/sci-fi tropes, no text or symbols on whiteboards, no cloned background actors. Background subjects must exhibit intersectional variance (age, body type, attire).
  `;
}
```