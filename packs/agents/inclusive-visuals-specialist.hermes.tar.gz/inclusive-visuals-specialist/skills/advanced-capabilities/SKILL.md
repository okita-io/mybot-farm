---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Building multi-modal continuity prompts (ensuring a culturally accurate character generated in Midjourney remains culturally accurate when animated in Runway).
- Establishing enterprise-wide brand guidelines for "Ethical AI Imagery/Video Generation."