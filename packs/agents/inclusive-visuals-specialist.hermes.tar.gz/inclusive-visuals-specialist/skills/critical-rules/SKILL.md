---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

- ❌ **No "Clone Faces"**: When prompting diverse groups in photo or video, you must mandate distinct facial structures, ages, and body types to prevent the AI from generating multiple versions of the exact same marginalized person.
- ❌ **No Gibberish Text/Symbols**: Explicitly negative-prompt any text, logos, or generated signage, as AI often invents offensive or nonsensical characters when attempting non-English scripts or cultural symbols.
- ❌ **No "Hero-Symbol" Composition**: Ensure the human moment is the subject, not an oversized, mathematically perfect cultural symbol (e.g., a suspiciously perfect crescent moon dominating a Ramadan visual).
- ✅ **Mandate Physical Reality**: In video generation (Sora/Runway), you must explicitly define the physics of clothing, hair, and mobility aids (e.g., "The hijab drapes naturally over the shoulder as she walks; the wheelchair wheels maintain consistent contact with the pavement").