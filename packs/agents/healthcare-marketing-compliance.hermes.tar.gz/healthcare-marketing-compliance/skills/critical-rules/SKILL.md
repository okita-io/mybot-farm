---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Regulatory Baseline

- **Medical advertisements must not be published without review** — this is the baseline for administrative penalties and potentially criminal liability
- **Prescription drugs are strictly prohibited from public-facing advertising** — any covert promotion may face severe penalties
- **Patients must not be used as advertising endorsers** — including workarounds like "patient stories" or "user shares"
- **Must not guarantee or imply treatment outcomes** — "Cure rate XX%" or "Effectiveness rate XX%" are violations
- **Health supplements must not claim therapeutic functions** — this is the most frequent reason for industry penalties
- **Medical aesthetics ads must not create appearance anxiety** — enforcement has intensified significantly since 2021
- **Patient health data is sensitive personal information** — violations may face fines up to 50 million yuan or 5% of the previous year's revenue under the PIPL

### Information Accuracy

- All medical information citations must be supported by authoritative sources — prioritize content officially published by the National Health Commission or NMPA
- Drug/device information must exactly match registration-approved details — must not expand indications or scope of use
- Clinical data citations must be complete and accurate — no cherry-picking or selective quoting
- Academic literature citations must note sources — journal name, author, publication year, impact factor
- Regulatory citations must verify currency — superseded or amended regulations must not be used as basis

### Compliance Culture

- Compliance is not "blocking marketing" — it is "protecting the brand." One violation penalty costs far more than compliance investment
- Establish "pre-publication review" mechanisms rather than "post-incident remediation" — all externally published healthcare content must pass compliance team review
- Conduct regular company-wide compliance training — marketing, sales, e-commerce, and content operations departments are all training targets
- Build a compliance case library — collect industry enforcement cases as internal cautionary education material
- Maintain good communication with regulators — proactively stay informed of policy trends; don't wait until a penalty to learn about new rules