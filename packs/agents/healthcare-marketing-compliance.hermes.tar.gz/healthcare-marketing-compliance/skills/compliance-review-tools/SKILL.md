---
name: compliance-review-tools
description: "Use when the task matches this agent's compliance review tools work."
version: 1.0.0
---

# Compliance Review Tools

Healthcare Marketing Content Review Checklist

```markdown
# Healthcare Marketing Content Compliance Review Form

## Basic Information
- Content type: (Advertisement / Health education / Patient education / Academic promotion / Brand publicity)
- Publishing channel: (TV / Newspaper / Official account / Douyin / Xiaohongshu / Website / Offline materials)
- Product category involved: (Drug / Device / Medical aesthetics procedure / Health supplement / Medical service)
- Review date:
- Reviewer:

## Qualification Compliance (Disqualification Items — verify each one)
- [ ] Is the advertising review certificate / approval number valid?
- [ ] Does the publishing entity have complete qualifications (Medical Institution Practice License, Drug Business License, etc.)?
- [ ] Has platform industry certification been completed?
- [ ] For physician appearances, have the Medical Practitioner Qualification Certificate and Practice Certificate been verified?

## Content Compliance
- [ ] Any absolute claims ("best," "complete cure," "100%")?
- [ ] Any guarantee promises ("refund if ineffective," "guaranteed cure")?
- [ ] Any improper comparisons (efficacy comparison with competitors, before-and-after comparison)?
- [ ] Any patient endorsements/testimonials?
- [ ] Do indications/scope of use match the registration certificate?
- [ ] Is prescription drug information limited to professional channels?
- [ ] Does health supplement content include required declaration statements?
- [ ] Any "appearance anxiety" language (medical aesthetics)?
- [ ] Are clinical data citations complete, accurate, and sourced?
- [ ] Are advisory statements / risk disclosures complete?

## Data Privacy Compliance
- [ ] Does it involve patient personal information — if so, has separate consent been obtained?
- [ ] Have patient cases been sufficiently de-identified?
- [ ] Does it involve health data collection — if so, does it follow the minimum necessary principle?
- [ ] Does data storage and processing meet security requirements?

## Review Conclusion
- Review result: (Approved / Approved with modifications / Rejected)
- Modification notes:
- Final approver:
```

### Common Violations & Compliant Alternatives

```markdown
# Violation Expression Reference Table

## Drugs / Medical Services
| Violation | Reason | Compliant Alternative |
|-----------|--------|----------------------|
| "Completely cures XX disease" | Absolute claim | "Indicated for the treatment of XX disease" (per package insert) |
| "Refund if ineffective" | Guarantees efficacy | "Please consult your doctor or pharmacist for details" |
| "Celebrity X uses it too" | Celebrity endorsement | Display product information only, without celebrity association |
| "Cure rate reaches 95%" | Unverified data promise | "Clinical studies showed an effectiveness rate of XX% (cite source)" |
| "Green therapy, no side effects" | False safety claim | "See package insert for adverse reactions" |
| "New method to replace surgery" | Misleading comparison | "Provides additional treatment options for patients" |

## Medical Aesthetics
| Violation | Reason | Compliant Alternative |
|-----------|--------|----------------------|
| "Start your beauty journey now" | Creates appearance anxiety | Introduce procedure principles and technical features |
| "Before-and-after comparison photos" | Explicitly prohibited | Display technical principle diagrams |
| "Celebrity-inspired nose" | Celebrity effect exploitation | Introduce procedure characteristics and suitable candidates |
| "Limited-time sale on double eyelid surgery" | Price promotion inducement | Showcase facility qualifications and physician team |

## Health Supplements
| Violation | Reason | Compliant Alternative |
|-----------|--------|----------------------|
| "Lowers blood pressure" | Claims therapeutic function | "Assists in lowering blood pressure" (must be within approved functions) |
| "Treats insomnia" | Claims therapeutic function | "Improves sleep" (must be within approved functions) |
| "All natural, no side effects" | False safety claim | "This product cannot replace medication" |
| "Anti-cancer / cancer prevention" | Exceeds approved function scope | Only promote within approved health functions |
```

### Healthcare Marketing Compliance Risk Rating Matrix

```markdown
# Compliance Risk Rating Matrix

| Risk Level | Violation Type | Potential Consequences | Recommended Action |
|------------|---------------|----------------------|-------------------|…