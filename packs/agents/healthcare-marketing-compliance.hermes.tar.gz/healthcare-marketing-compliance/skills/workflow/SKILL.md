---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow

Step 1: Compliance Environment Scanning

- Continuously track healthcare marketing regulatory updates: National Health Commission, NMPA, SAMR, Cyberspace Administration of China (CAC) official announcements
- Monitor landmark industry enforcement cases: Analyze violation causes, penalty severity, enforcement trends
- Track content review rule changes on each platform (Douyin, Xiaohongshu, WeChat)
- Establish a regulatory change notification mechanism: Notify relevant departments within 24 hours of key regulatory changes

### Step 2: Pre-Publication Compliance Review

- All healthcare-related marketing content must undergo compliance review before going live
- Tiered review mechanism: Low-risk content reviewed by compliance specialists; medium-to-high-risk content reviewed by compliance managers; major marketing campaigns reviewed by General Counsel
- Review covers all channels: Online ads, offline materials, social media content, KOL collaboration scripts, livestream talking points
- Issue written review opinions and retain review records for audit

### Step 3: Post-Publication Monitoring & Early Warning

- Continuous monitoring after content publication: Ad complaints, platform warnings, public sentiment monitoring
- Build a keyword monitoring library: Auto-detect violation keywords in published content
- Competitor compliance monitoring: Track competitor marketing compliance activity to avoid industry spillover risk
- Preparedness plan for 12315 hotline complaints and whistleblower reports

### Step 4: Violation Emergency Response

- Violation content discovered: Take down within 2 hours -> Issue remediation report within 24 hours -> Complete comprehensive audit within 72 hours
- Regulatory notice received: Immediately activate emergency plan -> Legal leads the response -> Cooperate with investigation and proactively remediate
- Media exposure / public sentiment crisis: Compliance + PR + Legal three-way coordination, unified messaging, rapid response
- Post-incident review: Root cause analysis, process improvement, review checklist update, company-wide notification

### Step 5: Compliance Capability Building

- Quarterly compliance training: Cover all customer-facing departments — marketing, sales, e-commerce, content operations
- Annual compliance audit: Comprehensive review of all active marketing materials for compliance
- Compliance case library updates: Continuously collect industry enforcement cases and internal violation incidents
- Compliance policy iteration: Continuously refine internal compliance policies based on regulatory changes and operational experience