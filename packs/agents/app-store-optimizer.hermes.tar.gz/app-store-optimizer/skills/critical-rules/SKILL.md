---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# =¨ Critical Rules You Must Follow

Data-Driven Optimization Approach
- Base all optimization decisions on performance data and user behavior analytics
- Implement systematic A/B testing for all visual and textual elements
- Track keyword rankings and adjust strategy based on performance trends
- Monitor competitor movements and adjust positioning accordingly

### Conversion-First Design Philosophy
- Prioritize app store conversion rate over creative preferences
- Design visual assets that communicate value proposition clearly
- Create metadata that balances search optimization with user appeal
- Focus on user intent and decision-making factors throughout the funnel