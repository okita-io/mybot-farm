---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# =Ë Your Technical Deliverables

ASO Strategy Framework
```markdown
# App Store Optimization Strategy

## Keyword Research and Analysis
### Primary Keywords (High Volume, High Relevance)
- [Primary Keyword 1]: Search Volume: X, Competition: Medium, Relevance: 9/10
- [Primary Keyword 2]: Search Volume: Y, Competition: Low, Relevance: 8/10
- [Primary Keyword 3]: Search Volume: Z, Competition: High, Relevance: 10/10

### Long-tail Keywords (Lower Volume, Higher Intent)
- "[Long-tail phrase 1]": Specific use case targeting
- "[Long-tail phrase 2]": Problem-solution focused
- "[Long-tail phrase 3]": Feature-specific searches

### Competitive Keyword Gaps
- Opportunity 1: Keywords competitors rank for but we don't
- Opportunity 2: Underutilized keywords with growth potential
- Opportunity 3: Emerging terms with low competition

## Metadata Optimization
### App Title Structure
**iOS**: [Primary Keyword] - [Value Proposition]
**Android**: [Primary Keyword]: [Secondary Keyword] [Benefit]

### Subtitle/Short Description
**iOS Subtitle**: [Key Feature] + [Primary Benefit] + [Target Audience]
**Android Short Description**: Hook + Primary Value Prop + CTA

### Long Description Structure
1. Hook (Problem/Solution statement)
2. Key Features & Benefits (bulleted)
3. Social Proof (ratings, downloads, awards)
4. Use Cases and Target Audience
5. Call to Action
6. Keyword Integration (natural placement)
```

### Visual Asset Optimization Framework
```markdown
# Visual Asset Strategy

## App Icon Design Principles
### Design Requirements
- Instantly recognizable at small sizes (16x16px)
- Clear differentiation from competitors in category
- Brand alignment without sacrificing discoverability
- Platform-specific design conventions compliance

### A/B Testing Variables
- Color schemes (primary brand vs. category-optimized)
- Icon complexity (minimal vs. detailed)
- Text inclusion (none vs. abbreviated brand name)
- Symbol vs. literal representation approach

## Screenshot Sequence Strategy
### Screenshot 1 (Hero Shot)
**Purpose**: Immediate value proposition communication
**Elements**: Key feature demo + benefit headline + visual appeal

### Screenshots 2-3 (Core Features)
**Purpose**: Primary use case demonstration
**Elements**: Feature walkthrough + user benefit copy + social proof

### Screenshots 4-5 (Supporting Features)
**Purpose**: Feature depth and versatility showcase
**Elements**: Secondary features + use case variety + competitive advantages

### Localization Strategy
- Market-specific screenshots for major markets
- Cultural adaptation of imagery and messaging
- Local language integration in screenshot text
- Region-appropriate user personas and scenarios
```

### App Preview Video Strategy
```markdown
# App Preview Video Optimization

## Video Structure (15-30 seconds)
### Opening Hook (0-3 seconds)
- Problem statement or compelling question
- Visual pattern interrupt or surprising element
- Immediate value proposition preview

### Feature Demonstration (3-20 seconds)
- Core functionality showcase with real user scenarios
- Smooth transitions between key features
- Clear benefit communication for each feature shown

### Closing CTA (20-30 seconds)
- Clear next step instruction
- Value reinforcement or urgency creation
- Brand reinforcement with visual consistency

## Technical Specifications
### iOS Requirements
- Resolution: 1920x1080 (16:9) or 886x1920 (9:16)
- Format: .mp4 or .mov
- Duration: 15-30 seconds
- File size: Maximum 500MB

### Android Requirements
- Resolution: 1080x1920 (9:16) recommended
- Format: .mp4, .mov, .avi
- Duration: 30 seconds maximum
- File size: Maximum 100MB

## Performance Tracking
- Conversion rate impact measurement
- User engagement metrics (completion rate)
- A/B testing different video versions
- Regional performance analysis
```