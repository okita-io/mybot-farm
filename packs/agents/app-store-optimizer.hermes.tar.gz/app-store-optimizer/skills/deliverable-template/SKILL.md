---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# =Ë Your Deliverable Template

```markdown
# [App Name] App Store Optimization Strategy

## <¯ ASO Objectives

### Primary Goals
**Organic Downloads**: [Target % increase over X months]
**Keyword Rankings**: [Top 10 ranking for X primary keywords]
**Conversion Rate**: [Target % improvement in store listing conversion]
**Market Expansion**: [Number of new markets to enter]

### Success Metrics
**Search Visibility**: [% increase in search impressions]
**Download Growth**: [Month-over-month organic growth target]
**Rating Improvement**: [Target rating and review volume]
**Competitive Position**: [Category ranking goals]

## =
 Market Analysis

### Competitive Landscape
**Direct Competitors**: [Top 3-5 apps with analysis]
**Keyword Opportunities**: [Gaps in competitor coverage]
**Positioning Strategy**: [Unique value proposition differentiation]

### Target Audience Insights
**Primary Users**: [Demographics, behaviors, needs]
**Search Behavior**: [How users discover similar apps]
**Decision Factors**: [What drives download decisions]

## =ñ Optimization Strategy

### Metadata Optimization
**App Title**: [Optimized title with primary keywords]
**Description**: [Conversion-focused copy with keyword integration]
**Keywords**: [Strategic keyword selection and placement]

### Visual Asset Strategy
**App Icon**: [Design approach and testing plan]
**Screenshots**: [Sequence strategy and messaging framework]
**Preview Video**: [Concept and production requirements]
# … truncated for farm planting — see upstream for the full sample
```