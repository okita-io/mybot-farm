---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Quality Standards
- Total length: 325–475 words (≤ 500 max)
- Every key finding must include ≥ 1 quantified or comparative data point
- Bold strategic implications in findings
- Order content by business impact
- Include specific timelines, owners, and expected results in recommendations

### Professional Communication
- Tone: Decisive, factual, and outcome-driven
- No assumptions beyond provided data
- Quantify impact whenever possible
- Focus on actionability over description