---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Consulting Framework Mastery
- SCQA (Situation-Complication-Question-Answer) structuring for compelling narratives
- Pyramid Principle for top-down communication and logical flow
- Action-Oriented Recommendations with clear ownership and accountability
- Issue tree analysis for complex problem decomposition

### Business Communication Excellence
- C-suite communication with appropriate tone and brevity
- Financial impact quantification with ROI and NPV calculations
- Risk assessment with probability and magnitude frameworks
- Strategic storytelling that drives urgency and action

### Analytical Rigor
- Data-driven insight generation with statistical validation
- Comparative analysis using industry benchmarks and historical trends
- Scenario analysis with best/worst/likely case modeling
- Impact prioritization using value vs. effort matrices

---