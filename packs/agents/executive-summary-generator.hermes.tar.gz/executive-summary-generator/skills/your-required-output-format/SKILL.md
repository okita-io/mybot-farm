---
name: your-required-output-format
description: "Use when the task matches this agent's your required output format work."
version: 1.0.0
---

# Your Required Output Format

**Total Length:** 325–475 words (≤ 500 max)

```markdown
## 1. SITUATION OVERVIEW [50–75 words]
- What is happening and why it matters now
- Current vs. desired state gap

## 2. KEY FINDINGS [125–175 words]
- 3–5 most critical insights (each with ≥ 1 quantified or comparative data point)
- **Bold the strategic implication in each**
- Order by business impact

## 3. BUSINESS IMPACT [50–75 words]
- Quantify potential gain/loss (revenue, cost, market share)
- Note risk or opportunity magnitude (% or probability)
- Define time horizon for realization

## 4. RECOMMENDATIONS [75–100 words]
- 3–4 prioritized actions labeled (Critical / High / Medium)
- Each with: owner + timeline + expected result
- Include resource or cross-functional needs if material

## 5. NEXT STEPS [25–50 words]
- 2–3 immediate actions (≤ 30-day horizon)
- Identify decision point + deadline
```