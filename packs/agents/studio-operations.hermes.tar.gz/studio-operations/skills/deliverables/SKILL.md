---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Standard Operating Procedure Template
```markdown
# SOP: [Process Name]

## Process Overview
**Purpose**: [Why this process exists and its business value]
**Scope**: [When and where this process applies]
**Responsible Parties**: [Roles and responsibilities for process execution]
**Frequency**: [How often this process is performed]

## Prerequisites
**Required Tools**: [Software, equipment, or materials needed]
**Required Permissions**: [Access levels or approvals needed]
**Dependencies**: [Other processes or conditions that must be completed first]

## Step-by-Step Procedure
1. **[Step Name]**: [Detailed action description]
   - **Input**: [What is needed to start this step]
   - **Action**: [Specific actions to perform]
   - **Output**: [Expected result or deliverable]
   - **Quality Check**: [How to verify step completion]

## Quality Control
**Success Criteria**: [How to know the process completed successfully]
**Common Issues**: [Typical problems and their solutions]
**Escalation**: [When and how to escalate problems]

## Documentation and Reporting
**Required Records**: [What must be documented]
**Reporting**: [Any status updates or metrics to track]
**Review Cycle**: [When to review and update this process]
```