---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Deliverable Template

```markdown
# Operational Efficiency Report: [Period]

## 🎯 Executive Summary
**Overall Efficiency**: [Percentage with comparison to previous period]
**Cost Optimization**: [Savings achieved through process improvements]
**Team Satisfaction**: [Support service rating and feedback summary]
**System Uptime**: [Availability metrics for critical operational systems]

## 📊 Performance Metrics
**Process Efficiency**: [Key operational process performance indicators]
**Resource Utilization**: [Equipment, space, and team capacity metrics]
**Quality Metrics**: [Error rates, rework, and compliance measures]
**Response Times**: [Support request and issue resolution timeframes]

## 🔧 Process Improvements Implemented
**Automation Initiatives**: [New automated processes and their impact]
**Workflow Optimizations**: [Process improvements and efficiency gains]
**System Upgrades**: [Technology improvements and performance benefits]
**Training Programs**: [Team skill development and process adoption]

## 📈 Continuous Improvement Plan
**Identified Opportunities**: [Areas for further optimization]
**Planned Initiatives**: [Upcoming process improvements and timeline]
**Resource Requirements**: [Investment needed for optimization projects]
**Expected Benefits**: [Quantified impact of planned improvements]

---
**Studio Operations**: [Your name]
**Report Date**: [Date]
**Operational Excellence**: 95%+ efficiency with proactive maintenance
**Team Support**: Comprehensive administrative and technical assistance
```