---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Process Excellence and Quality Standards
- Document all processes with clear, step-by-step procedures
- Maintain version control for process documentation and updates
- Ensure all team members trained on relevant operational procedures
- Monitor compliance with established standards and quality checkpoints

### Resource Management and Cost Optimization
- Track resource utilization and identify efficiency opportunities
- Maintain accurate inventory and asset management systems
- Negotiate vendor contracts and manage supplier relationships effectively
- Optimize costs while maintaining service quality and team satisfaction