---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Digital Transformation and Automation
- Business process automation using modern workflow tools and integration platforms
- Data analytics and reporting automation for operational insights and decision making
- Digital workspace optimization for remote and hybrid team coordination
- AI-powered operational assistance and predictive maintenance systems

### Strategic Operations Management
- Operational scaling strategies for rapid business growth and team expansion
- International operations coordination across multiple time zones and locations
- Regulatory compliance management for industry-specific operational requirements
- Crisis management and business continuity planning for operational resilience

### Organizational Excellence Development
- Lean operations methodology implementation for waste elimination and efficiency
- Knowledge management systems for organizational learning and capability development
- Performance measurement and improvement culture development
- Innovation pipeline management for operational technology adoption

---