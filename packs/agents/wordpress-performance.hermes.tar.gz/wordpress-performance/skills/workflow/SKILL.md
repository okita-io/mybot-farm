---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Measure & Establish the Baseline

1. **Run Query Monitor on key templates** — capture query count, query time, slow queries, and hooked plugins
2. **Run Lighthouse on throttled mobile** — capture LCP, INP, CLS, and the perf score
3. **Audit the autoload** — size of autoloaded options and which plugins are bloating it
4. **Inventory the caching stack** — object cache hitting? page cache configured? dynamic pages excluded?
5. **Record everything** — you can't prove an improvement you didn't baseline

### Step 2: Cut Database & Query Waste (Biggest Wins)

1. **Bound and index the worst queries** — `posts_per_page`, `no_found_rows`, indexed `meta_query`/`tax_query`
2. **Kill N+1 patterns and `posts_per_page => -1`** on anything user-facing
3. **Trim the autoload** — flip large uncached options to `autoload = no`, remove orphans
4. **Wrap expensive computed data in transients** — backed by a persistent object cache
5. **Re-measure with Query Monitor** — query count and time, before vs. after

### Step 3: Tame Plugin & Theme Bloat

1. **Profile each plugin's real per-request cost** — query count and PHP time
2. **Cut or replace the worst offenders** — a single heavy plugin often dominates the request
3. **Dequeue assets plugins load where they aren't used** — page-builder CSS off the blog, etc.
4. **Replace heavy patterns with lean ones** — native queries over bloated "feature" plugins
5. **Re-profile** — confirm the per-request cost actually dropped

### Step 4: Layer Caching Correctly

1. **Stand up a persistent object cache** — Redis/Memcached drop-in, verified hitting
2. **Configure page caching for anonymous HTML** — with dynamic pages explicitly excluded
3. **Add a CDN** — static assets on long TTL, edge HTML for anonymous only
4. **Verify dynamic-page safety at the edge** — cart/checkout/account/logged-in never cached publicly
5. **Confirm cache hit rates** — measured, not assumed

### Step 5: Trim the Front End, Tune Infra, Verify & Hand Off

1. **Minify and defer assets, inline critical CSS** — then verify render and interactivity intact
2. **Fix every image** — sized derivatives, WebP/AVIF, explicit dimensions, lazy below the fold, LCP preloaded
3. **Tune opcache and PHP-FPM** — sized to the codebase and the host, slow log on
4. **Re-baseline against Step 1 numbers** — every metric, before vs. after, on mobile
5. **Document what changed and why** — so the next person doesn't undo it with a "speed" plugin

---