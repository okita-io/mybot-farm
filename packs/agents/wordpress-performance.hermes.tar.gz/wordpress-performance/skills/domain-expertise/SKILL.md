---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

WordPress Caching System

- **Object Caching**: the `WP_Object_Cache`, the `object-cache.php` drop-in, Redis/Memcached backends, and cache groups
- **Transients API**: `set_transient`/`get_transient`, expiration strategy, object-cache backing vs. options-table fallback, and stampede avoidance
- **Page Caching**: plugin-based and host-level full-page caching, bypass/exclusion rules, and purge-on-update
- **CDN & Edge**: static asset offload, edge HTML caching for anonymous traffic, and dynamic-page bypass correctness

### Database & Query Optimization

- **WP_Query Mechanics**: `posts_per_page`, `no_found_rows`, `fields => 'ids'`, and the cost of `meta_query`/`tax_query`
- **Indexing**: indexing `postmeta`/`termmeta` columns used in filters and sorts, and reading `EXPLAIN`
- **Autoload Hygiene**: `wp_options` autoload weight, `autoload = no` for large uncached values, and orphan cleanup
- **Profiling**: Query Monitor, the MySQL slow query log, and identifying N+1 and unbounded queries

### Front-End Performance

- **Asset Pipeline**: `wp_enqueue_script/style`, dependency-safe deferral, dequeuing plugin assets, minification, and critical CSS
- **Core Web Vitals**: LCP, INP, CLS — their causes in WordPress themes/page builders and how to fix them
- **Images & Media**: registered image sizes, `srcset`/`sizes`, WebP/AVIF, native lazy loading, and LCP-image prioritization
- **Third-Party Scripts**: gating analytics/chat/pixels, and reducing main-thread blocking from external embeds

### Infrastructure & Tooling

- **PHP Runtime**: opcache sizing, `validate_timestamps`, JIT evaluation, and PHP-FPM pool tuning
- **Hosting**: shared vs. VPS vs. managed (Kinsta, WP Engine, Pressable, Cloudways) and their built-in caching layers
- **Cache Backends**: Redis/Memcached configuration, eviction policy, and persistence
- **Measurement Tooling**: Lighthouse/PageSpeed Insights, WebPageTest, field (CrUX) vs. lab data, and Query Monitor

---