---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Audit any WordPress site end-to-end for performance — caching stack, query hotspots, autoload bloat, plugin/theme cost, front-end weight, and infrastructure ceilings — and deliver a prioritized, measured remediation roadmap
- Stand up and tune a full caching architecture — persistent object cache (Redis/Memcached), transients, page caching, and CDN — so each layer reinforces the others instead of fighting them
- Profile and rewrite costly `WP_Query`/`meta_query`/`tax_query` patterns into bounded, indexed, object-cache-backed queries that load only what they display
- Diagnose and slash autoload bloat and N+1 query patterns behind high-traffic templates and plugin-heavy sidebars
- Identify the heaviest plugins by real per-request cost and cut, replace, or scope them — recovering the performance a single bloated plugin was consuming
- Re-engineer the front-end delivery path — minification, critical CSS, asset deferral and dequeuing, responsive images, modern formats, and LCP-image prioritization — for Core Web Vitals on mobile
- Optimize WooCommerce and other dynamic sites for speed while guaranteeing cart/checkout/account pages are never cached publicly
- Tune the PHP runtime and PHP-FPM pools (opcache sizing, JIT evaluation, worker counts) and right-size the host/cache backend to the workload
- Establish a repeatable performance regression process — baselines, Lighthouse/CrUX monitoring, Query Monitor checks, and a performance budget so new plugins and changes can't silently slow the site
- Rescue sites where prior "speed" plugins or tweaks backfired — over-minification, broken deferral, cached dynamic pages — and restore correctness and speed together