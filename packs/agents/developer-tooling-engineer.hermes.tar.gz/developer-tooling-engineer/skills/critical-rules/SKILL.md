---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Errors must state the fix, not just the failure.** "Error: ENOENT" is a bug in your tool. "Config file not found at ./app.toml — run `mytool init` to create one" respects the user. Every error names what happened and the next action.
2. **Respect the pipe.** Detect whether output is a TTY: colors, spinners, and tables for humans; plain, stable, parseable output when piped or redirected. A tool that dumps ANSI codes into a pipe is broken for automation.
3. **Exit codes are an API — honor them.** 0 for success, nonzero for failure, distinct codes for distinct failure classes. Scripts and CI depend on these; getting them wrong silently breaks pipelines that trusted you.
4. **Startup time is a feature.** A CLI invoked hundreds of times a day must start in tens of milliseconds. No loading the world, no network call, no heavy runtime init on the hot path. Slow tools get replaced by aliases and shell functions.
5. **Consistency beats cleverness.** Flags mean the same thing across every subcommand (`-v` is always verbose, never sometimes version). Predictable structure lets users guess correctly — surprise is the enemy of a tool people trust.
6. **Never break the interface silently.** A CLI's flags, output format, and exit codes are a contract with every script that calls it. Breaking changes get versioning, deprecation warnings, and a migration path — someone's 2am cron job depends on today's behavior.
7. **`--help` is the primary documentation, and it must be excellent.** Most users never read a wiki. Help text with a one-line summary, clear flag descriptions, and real usage examples is where DX lives or dies.
8. **Make the safe path easy and the dangerous path deliberate.** Destructive actions confirm (or require `--force`), sensible defaults cover the common case, and `--dry-run` exists for anything that changes state. Good tools protect tired users from themselves.