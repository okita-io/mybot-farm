---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Command Design + Human/Machine Dual Output

```text
Command hierarchy — verb-noun, consistent, guessable:
  mytool deploy start --env prod          mytool config get <key>
  mytool deploy status                    mytool config set <key> <value>
  mytool deploy rollback --to <version>   mytool config list --json

Global flags mean the SAME thing everywhere:
  -v/--verbose   more detail        --json     machine-readable output
  -q/--quiet     errors only        --no-color force plain (also auto when piped)
  --dry-run      show, don't do     -h/--help  teach this command

Dual output — the tool detects the pipe:
  $ mytool deploy status              # TTY: a colored table a human reads
    ✔ prod    v1.4.2   healthy   2m ago
  $ mytool deploy status --json | jq  # piped: stable, parseable, no ANSI
    {"env":"prod","version":"1.4.2","health":"healthy","age_seconds":120}
```

### Error Messages That Respect the User

```text
✗ BAD  (a bug wearing an error's clothes):
    Error: request failed with status 403

✓ GOOD (what, why, and the fix):
    Error: deploy to 'prod' was denied (403 Forbidden)
      You're authenticated as dev@corp.com, which lacks the 'deploy:prod' role.
      Fix: request access with `mytool auth request-role deploy:prod`
           or deploy to staging: `mytool deploy start --env staging`
    (run with --verbose for the full request trace)

Rule: an error a user can't act on is a defect. Name the cause, name the fix,
and hide the stack trace behind --verbose where debuggers can find it.
```

### DX Checklist for Any CLI (the difference between tolerated and loved)

| Dimension | Bar to clear |
|-----------|--------------|
| Discoverability | `--help` at every level; `mytool` with no args shows a useful overview, not an error |
| Startup speed | < 100ms cold start; measured, budgeted, and regression-tested in CI |
| Errors | Every failure names the fix; stack traces only behind `--verbose` |
| Scriptability | `--json` / plain output, stable exit codes, `--quiet`, reads stdin where sensible |
| Shell integration | Completions for bash/zsh/fish; respects `NO_COLOR`, `$PAGER`, standard env vars |
| Distribution | Single binary or one-line install; `--version`; self-update or clear upgrade path |
| Safety | Destructive ops confirm or need `--force`; `--dry-run` for state changes |
| Config | Sensible defaults; flag > env var > config file precedence, documented |

### Startup-Time Discipline

```text
A CLI run 300x/day at 900ms wastes 4.5 minutes/engineer/day. At 30ms: 9 seconds.
Where the time goes, and the fixes:
  · Heavy runtime/interpreter init  → prefer a compiled single binary for hot-path tools
  · Loading all subcommands upfront → lazy-load the command that was actually invoked
  · Network/auth call on every run  → cache credentials/config; never phone home on the hot path
  · Parsing huge config eagerly     → parse lazily, only what the command needs
Budget it: add a startup-time assertion to CI so a dependency can't silently regress it.
```