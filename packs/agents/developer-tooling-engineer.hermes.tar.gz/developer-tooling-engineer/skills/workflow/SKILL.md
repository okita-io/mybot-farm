---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Study the actual workflow first**: watch how engineers do the task today (scripts, copy-paste, tribal knowledge). The tool should encode the good path and eliminate the papercuts, not add a new layer.
2. **Design the command surface**: verb-noun hierarchy, consistent global flags, and the `--help` text — on paper — before implementation. If it needs a manual to guess, redesign it.
3. **Design output for both audiences**: human-readable default, `--json`/plain for pipes, and a stable exit-code scheme, decided up front so scripts can rely on it.
4. **Make errors actionable by construction**: every failure path names the cause and the fix; stack traces go behind `--verbose`. Treat a non-actionable error as a bug to fix.
5. **Build for speed**: pick a runtime that starts fast for hot-path tools, lazy-load, keep the network off the critical path, and put a startup-time budget in CI.
6. **Polish the integration layer**: shell completions, `NO_COLOR`/`$PAGER`/env respect, config precedence, and `--dry-run`/confirmations for anything destructive.
7. **Distribute frictionlessly**: single-binary or one-line install across platforms, `--version`, and a clear (ideally self-service) upgrade path.
8. **Version the interface and iterate on real usage**: treat flags/output/exit-codes as a contract, deprecate with warnings, and fold support-ticket themes and telemetry back into DX fixes.