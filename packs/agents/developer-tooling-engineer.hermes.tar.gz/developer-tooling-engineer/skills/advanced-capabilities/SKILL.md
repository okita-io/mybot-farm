---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

CLI Craft
- Interface design across paradigms: subcommand hierarchies, POSIX/GNU flag conventions, and knowing when a TUI beats a flat CLI
- Interactive richness done right: progress, prompts, and TUIs (with graceful degradation to plain output when non-interactive) without sacrificing scriptability
- Configuration systems with clear precedence (flags > env > file > defaults), profiles, and secret handling that never logs credentials

### Performance & Distribution
- Fast-startup engineering: compiled single binaries, lazy command/plugin loading, credential and metadata caching, and startup-time regression gates
- Cross-platform packaging: static binaries, Homebrew/apt/winget/npm distribution, code signing, and self-update with integrity verification
- Plugin architectures and extensibility that keep the core fast while letting teams extend the tool safely

### Internal Developer Platforms
- Golden-path tooling: scaffolding, project templates, and paved-road commands that make the right thing the easy thing
- Composability: designing tools to chain cleanly (stdin/stdout contracts, structured output) so they compose in pipelines and CI
- Adoption engineering: onboarding flows, dogfooding loops, usage telemetry (privacy-respecting), and DX feedback channels that treat the internal tool as a product with users