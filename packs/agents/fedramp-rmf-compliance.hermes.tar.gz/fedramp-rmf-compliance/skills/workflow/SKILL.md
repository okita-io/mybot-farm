---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Prepare & Categorize

1. **Identify information types and mission** — per NIST SP 800-60, what data the system holds and does
2. **Run the FIPS 199 analysis** — set C/I/A impact levels honestly; take the high-water mark
3. **Determine the FedRAMP impact level and baseline** — Low / Moderate / High (or Li-SaaS/Tailored), on NIST 800-53 Rev 5
4. **Select the authorization pathway** — traditional **Rev5** (agency sponsor + 3PAO control-by-control) vs. **FedRAMP 20x** (KSI-based, no sponsor, automated validation; confirm pilot/public status), and the sponsoring agency where applicable
5. **Establish roles and the risk picture** — system owner, ISSO, AO, the 3PAO engagement, and the OSCAL packaging plan against the 2026/2027 deadlines

### Step 2: Define the Boundary & Select Controls

1. **Draw the authorization boundary** — components, data flows, interconnections, and the diagram
2. **Map inheritance** — what the underlying FedRAMP-authorized platform provides, and the CRM split
3. **Select the control baseline** — the full 800-53 set for the impact level, plus enhancements
4. **Tailor with justification** — any deviations documented with rationale and compensating controls
5. **Assign control responsibility** — service provider, shared, inherited, or customer for each control

### Step 3: Implement & Document

1. **Implement each control for real** — in the system, configuration, and process — not just on paper
2. **Write assessable implementation statements (Rev5) or wire up KSI validations (20x)** — how this system meets each control, with mechanism and role; for 20x, automate the machine-readable evidence each Key Security Indicator requires
3. **Collect evidence as you go** — dated, owned artifacts a 3PAO can verify (or automated validations on 20x), gathered before assessment
4. **Build the supporting plans** — IR plan, contingency plan, configuration management, policies
5. **Assemble the SSP/attachments and the OSCAL machine-readable package** — complete, consistent with the boundary, and assessment-ready against the Sept 2026/2027 OSCAL deadlines

### Step 4: Assess & Authorize

1. **Support the 3PAO's SAP** — scope, test plan, and access to the live system and evidence
2. **Work the assessment** — controls tested against reality; capture findings as they surface
3. **Build the POA&M from the SAR** — every finding with risk, milestones, owner, and date
4. **Compile the ATO package** — SSP, SAP, SAR, POA&M, diagrams, categorization, and plans
5. **Brief the AO for the risk decision** — residual risk and remediation plan presented honestly

### Step 5: Continuously Monitor & Sustain

1. **Run monthly ConMon** — vulnerability scans, POA&M updates, and deliverables to the AO/PMO
2. **Close POA&M items with evidence** — and add newly discovered weaknesses honestly
3. **Gate significant changes** — security impact assessed and approved before deployment
4. **Execute the annual assessment** — a control subset retested; categorization revisited if the system changed
5. **Report incidents on the required timeline** — and feed lessons back into controls and the POA&M

---