---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

FIPS 199 Security Categorization

```
FIPS 199 SECURITY CATEGORIZATION
───────────────────────────────────────
SYSTEM:                [Name / acronym]
INFORMATION TYPES:     [Per NIST SP 800-60 — list each]

IMPACT ANALYSIS (per information type, then system high-water mark):
  CONFIDENTIALITY:     [Low / Moderate / High]  — impact of disclosure
  INTEGRITY:           [Low / Moderate / High]  — impact of modification
  AVAILABILITY:        [Low / Moderate / High]  — impact of disruption

SYSTEM CATEGORIZATION (high-water mark across all types):
  SC = {(C, __), (I, __), (A, __)}  →  OVERALL: [LOW / MODERATE / HIGH]

DRIVES:
  FedRAMP baseline:    [Low / Moderate / High]
  Control count:       [~baseline control + enhancement count]
  Rationale:           [Why each impact level — data + mission, documented]
```

### Pathway Selection & Key Security Indicator (KSI) Map

```
FEDRAMP PATHWAY SELECTION — Rev5 vs 20x
───────────────────────────────────────
DECISION INPUTS:
  Impact level:        [Low / Moderate / High]
  Agency sponsor:      [Have one? Rev5 needs it; 20x does NOT]
  Automation maturity: [Can the system emit machine-readable evidence?]
  Timeline:            [20x in pilot → ~Q3 2026 public; confirm live status]

PATHWAY A — TRADITIONAL Rev5:
  Controls:            [NIST 800-53 Rev 5 (Rev 5.2.0, Aug 2025)]
  Evidence:            [Narrative SSP implementation statements]
  Assessment:          [3PAO, control-by-control]
  Authorization:       [Agency authorization (sponsor required)]
  Packaging:           [OSCAL machine-readable — 9/30/26 initial, 9/30/27 hard]

PATHWAY B — FedRAMP 20x:
  Validation unit:     [Key Security Indicators (KSIs), not narratives]
  Evidence:            [Automated, machine-readable, compliance-as-code]
  Assessment:          [Automated validation + 3PAO attestation of method]
  Authorization:       [No agency sponsor required]
  Status:              [PILOT — targeting public availability ~Q3 2026]

KEY SECURITY INDICATOR MAP (20x):
  KSI:                 [e.g., KSI for cryptographic protection]
  Measures:            [The observable, automatable condition validated]
  Maps to 800-53:      [SC-13, SC-28, SC-8 ... — multiple controls per KSI]
  Validation source:   [API / config scan / IaC state — machine-readable]
  Continuous?:         [Re-validated automatically on the ConMon cadence]

DRIVERS: Executive Order 14028 + the FedRAMP Authorization Act
RULE: A KSI is not a shortcut — the underlying controls must really be met.
```

### Authorization Boundary Diagram (Definition)

```
AUTHORIZATION BOUNDARY DEFINITION
───────────────────────────────────────
INSIDE THE BOUNDARY (assessed + authorized):
  Components:          [App tiers, DBs, services, mgmt plane]
  Data stores:        [Where federal data lives]
  Boundary controls:  [WAF, firewalls, IdP, logging/SIEM]

EXTERNAL SERVICES / INTERCONNECTIONS:
  Inherited platform: [Underlying FedRAMP-authorized IaaS/PaaS + its ATO]
  External services:  [Each + FedRAMP status / risk + ICA/agreement]
  Data flows:         [What crosses the boundary, direction, encryption]

DIAGRAM MUST SHOW:
  □ Every component inside the boundary
  □ All ingress/egress + ports/protocols
  □ Federal data flow paths (encrypted in transit/at rest)
  □ Authentication / identity flows
  □ The line: what is authorized vs. external

RULE: The boundary is set BEFORE the SSP. Scope flows from this diagram.
```

### Control Implementation Statement (SSP excerpt)

```
NIST 800-53 Rev 5 CONTROL IMPLEMENTATION — SSP FORMAT (Rev5 pathway)
───────────────────────────────────────
CONTROL:               [e.g., AC-2 Account Management — 800-53 Rev 5]
BASELINE:              [Moderate — required]  ENHANCEMENTS: [AC-2(1)(2)(3)...]

IMPLEMENTATION STATUS:
  □ Implemented   □ Partially Implemented   □ Planned
  □ Inherited (from: ____)   □ Customer Responsibility

RESPONSIBILITY (origination):
  [Service Provider Corporate / System-Specific / Shared / Inherited / Customer]

IMPLEMENTATION STATEMENT (assessable — HOW this system meets it):
  "Accounts are managed via [mechanism/IdP]. Provisioning requires
   [approval workflow]; access is [RBAC model]; inactive accounts are
   [auto-disabled after N days via X]; reviews occur [cadence] by [role].
   Evidence: [config export / ticket / screenshot / log]."

EVIDENCE / ARTIFACT:
  [Specific, dated, owned proof a 3PAO can verify — NOT a restatement]

ASSESSABLE? □ A 3PAO could test this exactly as written
```

### POA&M Entry…