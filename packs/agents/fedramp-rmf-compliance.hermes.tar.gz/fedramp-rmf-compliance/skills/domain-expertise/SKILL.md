---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

NIST RMF & Standards

- **The RMF Lifecycle**: NIST SP 800-37 — Prepare, Categorize, Select, Implement, Assess, Authorize, Monitor
- **Categorization**: FIPS 199, FIPS 200, NIST SP 800-60 information types, and the CIA high-water mark
- **Control Catalog**: NIST SP 800-53 **Rev 5** control families, enhancements, and the baselines in SP 800-53B — current revision Rev 5.2.0 (released August 2025); the Rev 4 → Rev 5 transition is complete
- **Assessment**: NIST SP 800-53A assessment procedures and how controls map to test methods (examine/interview/test)

### FedRAMP Program & Modernization

- **Dual Authorization Pathways**: the traditional **Rev5** path (narrative SSP, 800-53 Rev 5, agency sponsorship, 3PAO control-by-control) and the modernized **FedRAMP 20x** path (KSI-based, no agency sponsor, automated machine-readable validation, compliance-as-code; in pilot, targeting public availability ~Q3 2026)
- **Key Security Indicators (KSIs)**: measurable, automation-verifiable translations of traditional controls, where each KSI maps to multiple underlying NIST 800-53 controls — and the discipline that a KSI is a validation shortcut in *form*, never in substance
- **OSCAL & Machine-Readable Packages**: the Open Security Controls Assessment Language, machine-readable SSP/SAP/SAR/POA&M, and the FedRAMP OSCAL deadlines (initial September 30, 2026; hard September 30, 2027)
- **Legal & Policy Drivers**: Executive Order 14028 (Improving the Nation's Cybersecurity) and the FedRAMP Authorization Act, and how they drive automation, reuse, and the move beyond the JAB P-ATO model to agency-based and 20x authorization
- **Baselines & Levels**: FedRAMP Low / Moderate / High, Li-SaaS and Tailored
- **Roles & Artifacts**: the 3PAO, PMO, the SSP/SAP/SAR/POA&M package, and FedRAMP templates
- **Inheritance & the CRM**: leveraging authorized IaaS/PaaS, the Customer Responsibility Matrix, and shared controls
- **Continuous Monitoring**: the monthly ConMon deliverables, significant-change process, annual assessment, and continuous automated KSI validation (20x)

### Control Domains

- **Access & Identity**: AC, IA — RBAC/least privilege, MFA, account management, and PIV/derived credentials
- **Audit & Monitoring**: AU, SI, IR — logging, SIEM, integrity monitoring, and incident response
- **Configuration & Risk**: CM, RA, CA, PL — baselines, vulnerability scanning, assessment, and planning
- **Crypto & Protection**: SC, MP, PE — FIPS 140-validated cryptography, boundary protection, media, and physical

### Cloud & Adjacent Frameworks

- **Cloud Security**: securing IaaS/PaaS/SaaS boundaries, shared-responsibility, and infrastructure-as-code evidence
- **Adjacent Regimes**: FISMA, DoD Impact Levels / cloud SRG, CMMC, StateRAMP, and how they relate to FedRAMP
- **Crosswalks**: mapping 800-53 to ISO 27001, SOC 2, and CIS for organizations under multiple regimes
- **Privacy**: privacy controls, PTA/PIA, and handling of PII within the boundary

---