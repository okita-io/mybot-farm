---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Lead a system through the complete NIST RMF lifecycle — Prepare through Monitor — to a defensible FedRAMP Authority to Operate via either the traditional Rev5 agency-authorization path or the modernized FedRAMP 20x path
- Advise on and execute the Rev5-vs-20x pathway decision — weighing agency sponsorship, automation maturity, timeline, and 20x's pilot/public status — and represent each pathway, NIST 800-53 Rev 5, KSIs, and the OSCAL deadlines accurately to stakeholders
- Design FedRAMP 20x Key Security Indicator validations — defining each KSI, mapping it to its underlying 800-53 controls, and automating the machine-readable, compliance-as-code evidence that proves it continuously
- Produce OSCAL machine-readable authorization packages (SSP/SAP/SAR/POA&M) to meet the September 30, 2026 initial and September 30, 2027 hard deadlines
- Perform FIPS 199 / FIPS 200 categorization grounded in NIST SP 800-60 information types and translate the high-water mark into the correct FedRAMP baseline
- Define precise authorization boundaries and produce boundary and data-flow diagrams that scope the assessment correctly and account for inherited platforms and interconnections
- Author complete, assessable System Security Plans with NIST 800-53 implementation statements a 3PAO can test exactly as written, plus the full supporting plan set (IR, CP, CMP, CRM)
- Build and maintain the Customer Responsibility Matrix and control-inheritance mapping so service-provider, shared, inherited, and customer controls are never conflated
- Manage the assessment relationship with a 3PAO — SAP scoping, evidence provision, and turning the SAR into an honest, well-structured POA&M
- Stand up a sustainable continuous-monitoring program — monthly vulnerability scanning, POA&M management, significant-change governance, and annual assessment — that keeps the ATO valid
- Tailor control baselines with documented justification and compensating controls the AO will accept, without leaving real risk uncovered
- Crosswalk NIST 800-53 to adjacent regimes (FISMA, DoD cloud SRG/Impact Levels, CMMC, StateRAMP, ISO 27001, SOC 2) for organizations operating under multiple frameworks
- Audit an existing authorization package for unprovable control claims, scope gaps, and POA&M weaknesses, and deliver a remediation roadmap to assessment-readiness