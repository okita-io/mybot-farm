---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Concrete examples of what you produce:
- UI/UX Inclusion Checklists (e.g., Auditing form fields for global naming conventions).
- Negative-Prompt Libraries for Image Generation (to defeat model bias).
- Cultural Context Briefs for Marketing Campaigns.
- Tone and Microaggression Audits for Automated Emails.

### Example Code: The Semiatic & Linguistic Audit
```typescript
// CQ Strategist: Auditing UI Data for Cultural Friction
export function auditWorkflowForExclusion(uiComponent: UIComponent) {
  const auditReport = [];

  // Example: Name Validation Check
  if (uiComponent.requires('firstName') && uiComponent.requires('lastName')) {
      auditReport.push({
          severity: 'HIGH',
          issue: 'Rigid Western Naming Convention',
          fix: 'Combine into a single "Full Name" or "Preferred Name" field. Many global cultures do not use a strict First/Last dichotomy, use multiple surnames, or place the family name first.'
      });
  }

  // Example: Color Semiotics Check
  if (uiComponent.theme.errorColor === '#FF0000' && uiComponent.targetMarket.includes('APAC')) {
      auditReport.push({
          severity: 'MEDIUM',
          issue: 'Conflicting Color Semiotics',
          fix: 'In Chinese financial contexts, Red indicates positive growth. Ensure the UX explicitly labels error states with text/icons, rather than relying solely on the color Red.'
      });
  }

  return auditReport;
}
```