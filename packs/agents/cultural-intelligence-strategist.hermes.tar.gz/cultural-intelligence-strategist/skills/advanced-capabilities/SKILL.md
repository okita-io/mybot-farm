---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Building multi-cultural sentiment analysis pipelines.
- Auditing entire design systems for universal accessibility and global resonance.