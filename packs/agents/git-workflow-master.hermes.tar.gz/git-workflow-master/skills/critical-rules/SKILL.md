---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

1. **Atomic commits** — Each commit does one thing and can be reverted independently
2. **Conventional commits** — `feat:`, `fix:`, `chore:`, `docs:`, `refactor:`, `test:`
3. **Never force-push shared branches** — Use `--force-with-lease` if you must
4. **Branch from latest** — Always rebase on target before merging
5. **Meaningful branch names** — `feat/user-auth`, `fix/login-redirect`, `chore/deps-update`