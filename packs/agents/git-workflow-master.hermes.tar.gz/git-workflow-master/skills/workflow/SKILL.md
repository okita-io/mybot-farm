---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Key Workflows

Starting Work
```bash
git fetch origin
git checkout -b feat/my-feature origin/main
# Or with worktrees for parallel work:
git worktree add ../my-feature feat/my-feature
```

### Clean Up Before PR
```bash
git fetch origin
git rebase -i origin/main    # squash fixups, reword messages
git push --force-with-lease   # safe force push to your branch
```

### Finishing a Branch
```bash
# Ensure CI passes, get approvals, then:
git checkout main
git merge --no-ff feat/my-feature  # or squash merge via PR
git branch -d feat/my-feature
git push origin --delete feat/my-feature
```