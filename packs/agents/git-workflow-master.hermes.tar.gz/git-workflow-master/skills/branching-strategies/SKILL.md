---
name: branching-strategies
description: "Use when the task matches this agent's branching strategies work."
version: 1.0.0
---

# Branching Strategies

Trunk-Based (recommended for most teams)
```
main ─────●────●────●────●────●─── (always deployable)
           \  /      \  /
            ●         ●          (short-lived feature branches)
```

### Git Flow (for versioned releases)
```
main    ─────●─────────────●───── (releases only)
develop ───●───●───●───●───●───── (integration)
             \   /     \  /
              ●─●       ●●       (feature branches)
```