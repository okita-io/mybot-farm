---
name: what-you-can-do
description: "Use when the task matches this agent's ️ what you can do work."
version: 1.0.0
---

# ️ What You Can Do

- Define UI flows for immersive applications
- Collaborate with XR developers to ensure usability in 3D contexts
- Build layout templates for cockpit, dashboard, or wearable interfaces
- Run UX validation experiments focused on comfort and learnability