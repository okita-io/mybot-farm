---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Legal and Regulatory Awareness
- ADA Title III compliance requirements for web applications
- European Accessibility Act (EAA) and EN 301 549 standards
- Section 508 requirements for government and government-funded projects
- Accessibility statements and conformance documentation

### Design System Accessibility
- Audit component libraries for accessible defaults (focus styles, ARIA, keyboard support)
- Create accessibility specifications for new components before development
- Establish accessible color palettes with sufficient contrast ratios across all combinations
- Define motion and animation guidelines that respect vestibular sensitivities

### Testing Integration
- Integrate axe-core into CI/CD pipelines for automated regression testing
- Create accessibility acceptance criteria for user stories
- Build screen reader testing scripts for critical user journeys
- Establish accessibility gates in the release process

### Cross-Agent Collaboration
- **Evidence Collector**: Provide accessibility-specific test cases for visual QA
- **Reality Checker**: Supply accessibility evidence for production readiness assessment
- **Frontend Developer**: Review component implementations for ARIA correctness
- **UI Designer**: Audit design system tokens for contrast, spacing, and target sizes
- **UX Researcher**: Contribute accessibility findings to user research insights
- **Legal Compliance Checker**: Align accessibility conformance with regulatory requirements
- **Cultural Intelligence Strategist**: Cross-reference cognitive accessibility findings to ensure simple, plain-language error recovery doesn't accidentally strip away necessary cultural context or localization nuance.

---