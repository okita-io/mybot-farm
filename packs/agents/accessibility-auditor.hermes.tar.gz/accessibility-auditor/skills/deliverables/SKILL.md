---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Audit Deliverables

Accessibility Audit Report Template
```markdown
# Accessibility Audit Report

## 📋 Audit Overview
**Product/Feature**: [Name and scope of what was audited]
**Standard**: WCAG 2.2 Level AA
**Date**: [Audit date]
**Auditor**: AccessibilityAuditor
**Tools Used**: [axe-core, Lighthouse, screen reader(s), keyboard testing]

## 🔍 Testing Methodology
**Automated Scanning**: [Tools and pages scanned]
**Screen Reader Testing**: [VoiceOver/NVDA/JAWS — OS and browser versions]
**Keyboard Testing**: [All interactive flows tested keyboard-only]
**Visual Testing**: [Zoom 200%/400%, high contrast, reduced motion]
**Cognitive Review**: [Reading level, error recovery, consistency]

## 📊 Summary
**Total Issues Found**: [Count]
- Critical: [Count] — Blocks access entirely for some users
- Serious: [Count] — Major barriers requiring workarounds
- Moderate: [Count] — Causes difficulty but has workarounds
- Minor: [Count] — Annoyances that reduce usability

**WCAG Conformance**: DOES NOT CONFORM / PARTIALLY CONFORMS / CONFORMS
**Assistive Technology Compatibility**: FAIL / PARTIAL / PASS

## 🚨 Issues Found

### Issue 1: [Descriptive title]
**WCAG Criterion**: [Number — Name] (Level A/AA/AAA)
**Severity**: Critical / Serious / Moderate / Minor
**User Impact**: [Who is affected and how]
**Location**: [Page, component, or element]
**Evidence**: [Screenshot, screen reader transcript, or code snippet]
**Current State**:

    <!-- What exists now -->

**Recommended Fix**:

# … truncated for farm planting — see upstream for the full sample
```

### Screen Reader Testing Protocol
```markdown
# Screen Reader Testing Session

## Setup
**Screen Reader**: [VoiceOver / NVDA / JAWS]
**Browser**: [Safari / Chrome / Firefox]
**OS**: [macOS / Windows / iOS / Android]

## Navigation Testing
**Heading Structure**: [Are headings logical and hierarchical? h1 → h2 → h3?]
**Landmark Regions**: [Are main, nav, banner, contentinfo present and labeled?]
**Skip Links**: [Can users skip to main content?]
**Tab Order**: [Does focus move in a logical sequence?]
**Focus Visibility**: [Is the focus indicator always visible and clear?]

## Interactive Component Testing
**Buttons**: [Announced with role and label? State changes announced?]
**Links**: [Distinguishable from buttons? Destination clear from label?]
**Forms**: [Labels associated? Required fields announced? Errors identified?]
**Modals/Dialogs**: [Focus trapped? Escape closes? Focus returns on close?]
**Custom Widgets**: [Tabs, accordions, menus — proper ARIA roles and keyboard patterns?]

## Dynamic Content Testing
**Live Regions**: [Status messages announced without focus change?]
**Loading States**: [Progress communicated to screen reader users?]
**Error Messages**: [Announced immediately? Associated with the field?]
**Toast/Notifications**: [Announced via aria-live? Dismissible?]

## Findings
| Component | Screen Reader Behavior | Expected Behavior | Status |
|-----------|----------------------|-------------------|--------|
| [Name]    | [What was announced] | [What should be]  | PASS/FAIL |
```

### Keyboard Navigation Audit
```markdown
# Keyboard Navigation Audit

## Global Navigation
- [ ] All interactive elements reachable via Tab
- [ ] Tab order follows visual layout logic
- [ ] Skip navigation link present and functional
- [ ] No keyboard traps (can always Tab away)
- [ ] Focus indicator visible on every interactive element
- [ ] Escape closes modals, dropdowns, and overlays
- [ ] Focus returns to trigger element after modal/overlay closes

## Component-Specific Patterns
### Tabs
- [ ] Tab key moves focus into/out of the tablist and into the active tabpanel content
- [ ] Arrow keys move between tab buttons
- [ ] Home/End move to first/last tab
- [ ] Selected tab indicated via aria-selected

### Menus
- [ ] Arrow keys navigate menu items
- [ ] Enter/Space activates menu item
- [ ] Escape closes menu and returns focus to trigger

### Carousels/Sliders
- [ ] Arrow keys move between slides
- [ ] Pause/stop control available and keyboard accessible
- [ ] Current position announced

### Data Tables
- [ ] Headers associated with cells via scope or headers attributes
- [ ] Caption or aria-label describes table purpose
- [ ] Sortable columns operable via keyboard

## Results
**Total Interactive Elements**: [Count]
**Keyboard Accessible**: [Count] ([Percentage]%)
**Keyboard Traps Found**: [Count]
**Missing Focus Indicators**: [Count]
```