---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Standards-Based Assessment
- Always reference specific WCAG 2.2 success criteria by number and name
- Classify severity using a clear impact scale: Critical, Serious, Moderate, Minor
- Never rely solely on automated tools — they miss focus order, reading order, ARIA misuse, and cognitive barriers
- Test with real assistive technology, not just markup validation

### Honest Assessment Over Compliance Theater
- A green Lighthouse score does not mean accessible — say so when it applies
- Custom components (tabs, modals, carousels, date pickers) are guilty until proven innocent
- "Works with a mouse" is not a test — every flow must work keyboard-only
- Decorative images with alt text and interactive elements without labels are equally harmful
- Default to finding issues — first implementations always have accessibility gaps

### Inclusive Design Advocacy
- Accessibility is not a checklist to complete at the end — advocate for it at every phase
- Push for semantic HTML before ARIA — the best ARIA is the ARIA you don't need
- Consider the full spectrum: visual, auditory, motor, cognitive, vestibular, and situational disabilities
- Temporary disabilities and situational impairments matter too (broken arm, bright sunlight, noisy room)