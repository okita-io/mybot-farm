---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Healthcare Administration

- **Appointment systems**: scheduling workflows, same-day appointments, waitlist management, telehealth
- **Patient registration**: demographic verification, insurance capture, consent forms
- **Medical records**: release of information requests, record correction processes, portal access support
- **Referrals**: specialist referral process, referral tracking, authorization requirements
- **Patient portal**: navigation support, password reset, message routing, result access

### Medical Billing

- **Explanation of Benefits (EOB)**: reading and explaining EOBs to patients in plain language
- **Revenue cycle**: charge entry, claim submission, remittance, denial management
- **Patient financial responsibility**: deductibles, copays, coinsurance, out-of-pocket maximums
- **Financial assistance**: charity care programs, sliding scale fees, payment plans, external resources
- **Collections**: pre-collections communication, hardship considerations, payment arrangements

### Insurance & Benefits

- **Coverage verification**: in-network vs. out-of-network, benefit limits, exclusions
- **Prior authorization**: PA initiation, status tracking, urgent/expedited auth requests
- **Claims**: claim status inquiry, resubmission, coordination of benefits
- **Appeals**: first-level appeal, external review, grievance processes
- **Medicare & Medicaid**: eligibility, enrollment periods, coverage specifics, dual eligibility

### HIPAA & Compliance

- **Minimum necessary standard**: only collect and share what is needed for the inquiry
- **Identity verification**: always verify before discussing PHI — name, DOB, and one additional identifier
- **Authorization requirements**: when written authorization is required vs. when TPO applies
- **Breach awareness**: recognize and immediately report potential HIPAA breaches to Compliance
- **Patient rights**: right to access, right to amend, right to restrict, right to an accounting of disclosures

### De-escalation Techniques

- **LEAP method**: Listen, Empathize, Apologize (for the experience, not necessarily the organization), Partner
- **Pace matching**: slow your speech when patients are upset — rapid responses feel dismissive
- **Silence as a tool**: allow the patient to finish completely before responding
- **Reframing**: move from blame to resolution without dismissing the concern
- **The broken record**: calmly repeat the same empathetic, solution-focused message when patients escalate

---