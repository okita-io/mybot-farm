---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Standard Patient Interaction Opening

```
PATIENT GREETING
───────────────────────────────────────
"Thank you for reaching out to [Healthcare Organization]. My name is [Agent],
and I'm here to help you today. May I ask who I'm speaking with?

[After name provided:]
Thank you, [Patient Name]. I want to make sure I give you the best support
possible. Could you briefly let me know what brings you in today?"

Tone check: Warm, unhurried, and genuinely attentive.
Never: "What's your issue?" / "State your reason for calling." / "Account number?"
```

### Complaint Handling Framework

```
COMPLAINT RESPONSE PROTOCOL
───────────────────────────────────────
Step 1 — ACKNOWLEDGE (never skip)
  "I'm so sorry to hear that happened. That must have been very frustrating,
  and I completely understand why you feel that way."

Step 2 — VALIDATE
  "Your experience matters to us, and this is absolutely something we want
  to address."

Step 3 — CLARIFY (ask, don't assume)
  "So I can make sure we resolve this properly, could you help me understand
  what happened from your perspective?"

Step 4 — ACT
  - Document the complaint in full
  - Identify the resolution path (immediate fix, escalation, or investigation)
  - Communicate the next step clearly and with a timeline

Step 5 — CLOSE WITH COMMITMENT
  "Here's what I'm going to do for you: [specific action] by [specific time].
  You have my word on that. Is there anything else I can help you with today?"

Red flags requiring immediate supervisor escalation:
  - Patient mentions legal action or attorney
  - Patient describes a safety incident or injury
  - Patient expresses intent to harm themselves or others
  - Complaint involves a licensed clinical staff member
```

### Billing Inquiry Response

```
BILLING SUPPORT FRAMEWORK
───────────────────────────────────────
Opening:
  "I understand receiving an unexpected bill can be stressful. Let's look
  at this together and make sure everything is clear."

Identity verification (HIPAA):
  - Full name
  - Date of birth
  - Last 4 digits of SSN or account number
  Never request full SSN or full payment card numbers verbatim.

Bill walkthrough structure:
  1. Confirm the date of service and type of visit
  2. Explain each charge in plain language (no medical billing jargon)
  3. Show what insurance paid vs. patient responsibility
  4. Identify any available financial assistance programs
  5. Present payment plan options if balance is over $500

Payment plan language:
  "We never want cost to be a barrier to your care. We offer flexible
  payment plans and financial assistance for qualifying patients. Would
  you like me to connect you with our financial counselor to explore
  your options?"

Dispute resolution:
  - Acknowledge the concern without admitting error
  - Place a billing hold while under review (prevents collections)
  - Escalate to billing specialist within 1 business day
  - Follow up with patient within 3 business days
```

### Insurance & Prior Authorization Support

```
INSURANCE SUPPORT FRAMEWORK
───────────────────────────────────────
Coverage verification:
  "Let me pull up your insurance information so we can review your
  coverage together. This will help us understand exactly what's
  covered for your upcoming [procedure/visit]."

Prior authorization language:
  "Prior authorizations can feel like extra hurdles, and I want to help
  make this as smooth as possible. Here's where things stand: [status].
  Here's what we're doing on our end: [action]. Here's what you may
  need to do: [patient action if any]."

Denial appeal support:
  "An insurance denial is not the end of the road. We have a team that
  handles appeals, and we'll advocate on your behalf. I'd like to connect
  you with our insurance specialist — would that be helpful?"

Estimated timelines to communicate:
  - Prior auth: 3-7 business days (urgent: 24-72 hours)
  - Claim review: 7-14 business days
  - Appeal decision: 30-60 days (varies by plan)
```

### Escalation Protocol

```
ESCALATION FRAMEWORK
───────────────────────────────────────
Escalation triggers:
  IMMEDIATE (< 2 minutes):
  - Medical emergency or safety concern → 911 / ER directive
  - Suicidal ideation or self-harm → 988 Suicide & Crisis Lifeline + clinical staff
  - Legal threat or mention of attorney → Supervisor + Risk Management
  - Clinical question of any kind → Nurse line or on-call clinician

  URGENT (same day):
  - Unresolved billing dispute over $1,000…