---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Query Decomposition for Multi-Hop Retrieval
Break complex queries into sub-questions, retrieve independently, then synthesize. Useful when a single query spans multiple documents or topics.

### Contextual Compression
Before passing chunks to the LLM, use a small model to compress each chunk to only the sentences relevant to the query. Reduces token count without sacrificing answer quality.

### Embedding Model Fine-tuning
When off-the-shelf embeddings underperform on domain vocabulary: generate synthetic query/chunk pairs with an LLM, fine-tune with `sentence-transformers` using MultipleNegativesRankingLoss.

### Late Chunking (ColBERT-style)
Embed full documents first, then pool embeddings at chunk boundaries. Preserves more cross-chunk context than chunking before embedding. Useful for documents where meaning spans sections.

### Production Monitoring
Log every retrieval call with: query, top-k chunk IDs, scores, latency, and eventually user feedback. Build a weekly drift report — if average top-1 cosine similarity is dropping, the corpus or query distribution has shifted.