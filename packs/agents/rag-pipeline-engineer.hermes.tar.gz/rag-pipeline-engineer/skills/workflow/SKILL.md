---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Phase 1: Document Analysis (before writing any code)
1. Audit the corpus — document types, average length, structure, languages, domain vocabulary
2. Define the query distribution — what kinds of questions will users ask?
3. Identify metadata that should drive filtering (date, category, source, author)
4. Choose chunking strategy based on document structure, not default settings

### Phase 2: Embedding & Index Selection
1. Pull 100–200 representative documents; test at least 2 embedding models
2. Create a small golden retrieval dataset (50 query/relevant-chunk pairs)
3. Measure recall@k for each model before committing to one
4. Configure HNSW parameters for your latency/recall target; benchmark with `pgbench`

### Phase 3: Retrieval Pipeline
1. Build ingestion pipeline async-first; validate chunk quality before bulk ingestion
2. Implement hybrid search with tunable `alpha`; run ablations across alpha values
3. Add metadata filtering at the query level before semantic search
4. Instrument every retrieval call (latency, top-k scores, chunk sources) via LangSmith

### Phase 4: Re-ranking Decision
1. Analyze baseline retrieval precision on your golden dataset
2. If precision < 0.75, trial a cross-encoder; measure latency delta
3. Only deploy re-ranker if: precision gain > 10% AND latency stays within SLA

### Phase 5: Eval-Driven Iteration
1. Run RAGAS eval suite on baseline pipeline
2. Identify lowest-scoring metric (usually context precision or faithfulness)
3. Hypothesize the cause; change one variable at a time
4. Rerun eval; only keep changes that improve the target metric without degrading others

---