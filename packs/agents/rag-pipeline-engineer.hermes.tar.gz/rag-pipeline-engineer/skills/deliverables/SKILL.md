---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Chunking Strategy — Semantic + Structural

```python
from langchain.text_splitter import MarkdownHeaderTextSplitter, RecursiveCharacterTextSplitter

def chunk_document(text: str, doc_type: str) -> list[dict]:
    """
    Use structural chunking for documents with clear headers (markdown, PDFs with sections),
    fall back to semantic chunking for unstructured prose.
    """
    if doc_type in ("markdown", "structured_pdf"):
        # Header-based: preserves document hierarchy as metadata
        header_splitter = MarkdownHeaderTextSplitter(
            headers_to_split_on=[
                ("#", "h1"), ("##", "h2"), ("###", "h3")
            ]
        )
        header_chunks = header_splitter.split_text(text)

        # Second pass: limit chunk size within each header section
        char_splitter = RecursiveCharacterTextSplitter(
            chunk_size=800,
            chunk_overlap=100,
            separators=["\n\n", "\n", ". ", " "]
        )
        chunks = []
        for doc in header_chunks:
            sub_chunks = char_splitter.split_documents([doc])
            chunks.extend(sub_chunks)
        return chunks

    else:
        # Semantic chunking for unstructured text
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=600,
            chunk_overlap=80,
            separators=["\n\n", "\n", ". ", "! ", "? ", " "]
        )
        return splitter.create_documents([text])
```

### pgvector Schema & HNSW Index

```sql
-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Document chunks table with rich metadata for filtering
CREATE TABLE document_chunks (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    content     TEXT NOT NULL,
    embedding   VECTOR(1536),           -- OpenAI text-embedding-3-small
    chunk_index INTEGER NOT NULL,
    metadata    JSONB DEFAULT '{}',     -- {source, section, doc_type, language, created_at}
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- HNSW index: better recall at query time vs. IVFFlat
-- ef_construction=128 and m=16 is a solid default for most workloads
-- Increase ef_construction for higher recall at the cost of index build time
CREATE INDEX ON document_chunks
USING hnsw (embedding vector_cosine_ops)
WITH (m = 16, ef_construction = 128);

-- Index metadata for fast pre-filtering
CREATE INDEX ON document_chunks USING GIN (metadata);
CREATE INDEX ON document_chunks (document_id);
```

### Async Ingestion Pipeline

```python
import asyncio
from openai import AsyncOpenAI
from pgvector.asyncpg import register_vector
import asyncpg

client = AsyncOpenAI()

async def embed_batch(texts: list[str], batch_size: int = 100) -> list[list[float]]:
    """Batch embedding with rate limit handling."""
    all_embeddings = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i + batch_size]
        response = await client.embeddings.create(
            input=batch,
            model="text-embedding-3-small"
        )
        all_embeddings.extend([r.embedding for r in response.data])
    return all_embeddings

async def ingest_document(document_id: str, chunks: list[dict], pool: asyncpg.Pool):
    """
    Async ingest: embed all chunks in parallel batches, then bulk-insert.
    Never ingest one chunk at a time — it's 100x slower.
    """
    texts = [c["content"] for c in chunks]
    embeddings = await embed_batch(texts)

    async with pool.acquire() as conn:
        await register_vector(conn)
        # Bulk insert with executemany for efficiency
        await conn.executemany(
            """
            INSERT INTO document_chunks
                (document_id, content, embedding, chunk_index, metadata)
            VALUES ($1, $2, $3, $4, $5)
            """,
            [
                (document_id, c["content"], emb, idx, c.get("metadata", {}))
                for idx, (c, emb) in enumerate(zip(chunks, embeddings))
            ]
# … truncated for farm planting — see upstream for the full sample
```

### Hybrid Search (Dense + Sparse Fusion)

```python
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

async def hybrid_search(
    query: str,
    query_embedding: list[float],
    db: AsyncSession,
    metadata_filter: dict | None = None,
    top_k: int = 10,
    alpha: float = 0.7,  # weight for semantic vs. keyword; tune per domain
) -> list[dict]:
    """…