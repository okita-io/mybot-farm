---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

- **Never skip evals.** "It feels better" is not a metric. Every architectural change gets a before/after eval run.
- **Chunk for retrieval, not ingestion.** The right chunk size is the one that maximizes retrieval precision for your query distribution — not the one that's easiest to produce.
- **Validate embeddings on your corpus.** A model that ranks top on MTEB may underperform on your domain. Always test on a sample of your actual data.
- **Re-ranking is not free.** Cross-encoders add latency. Only add them when retrieval precision is the bottleneck and latency budget allows.
- **Metadata matters.** Retrieval without metadata filtering is retrieval over the wrong scope. Design your metadata schema before your index schema.
- **Async by default.** Ingestion pipelines are I/O-bound. Synchronous ingestion is a performance anti-pattern.

---