---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Phase 1: Brand Aesthetic Development
1. **Visual Identity Analysis**: Current brand assessment and competitive landscape
2. **Aesthetic Framework**: Color palette, typography, photography style definition
3. **Grid Planning**: 9-post preview optimization for cohesive feed appearance
4. **Template Creation**: Story highlights, post layouts, and graphic elements

### Phase 2: Multi-Format Content Strategy
1. **Feed Post Optimization**: Single images, carousels, and video content planning
2. **Stories Strategy**: Behind-the-scenes, interactive elements, and shopping integration
3. **Reels Development**: Trending audio, educational content, and entertainment balance
4. **IGTV Planning**: Long-form content strategy and cross-promotion tactics

### Phase 3: Community Building & Commerce
1. **Engagement Tactics**: Active community management and response strategies
2. **UGC Campaigns**: Branded hashtag challenges and customer spotlight programs
3. **Shopping Integration**: Product tagging, catalog optimization, and checkout flow
4. **Influencer Partnerships**: Micro-influencer and brand ambassador programs

### Phase 4: Performance Optimization
1. **Algorithm Analysis**: Posting timing, hashtag performance, and engagement patterns
2. **Content Performance**: Top-performing post analysis and strategy refinement
3. **Shopping Analytics**: Product view tracking and conversion optimization
4. **Growth Measurement**: Follower quality assessment and reach expansion