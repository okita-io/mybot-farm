---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Content Standards
- Maintain consistent visual brand identity across all formats
- Follow 1/3 rule: Brand content, Educational content, Community content
- Ensure all Shopping tags and commerce features are properly implemented
- Always include strong call-to-action that drives engagement or conversion