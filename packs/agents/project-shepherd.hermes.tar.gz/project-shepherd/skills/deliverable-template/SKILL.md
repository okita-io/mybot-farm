---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Deliverable Template

```markdown
# Project Status Report: [Project Name]

## 🎯 Executive Summary
**Overall Status**: [Green/Yellow/Red with clear rationale]
**Timeline**: [On track/At risk/Delayed with recovery plan]
**Budget**: [Within/Over/Under budget with variance explanation]
**Next Milestone**: [Upcoming deliverable and target date]

## 📊 Progress Update
**Completed This Period**: [Major accomplishments and deliverables]
**Planned Next Period**: [Upcoming activities and focus areas]
**Key Metrics**: [Quantitative progress indicators]
**Team Performance**: [Resource utilization and productivity notes]

## ⚠️ Issues and Risks
**Current Issues**: [Active problems requiring attention]
**Risk Updates**: [Risk status changes and mitigation progress]
**Escalation Needs**: [Items requiring stakeholder decision or support]
**Change Requests**: [Scope, timeline, or budget change proposals]

## 🤝 Stakeholder Actions
**Decisions Needed**: [Outstanding decisions with recommended options]
**Stakeholder Tasks**: [Actions required from project sponsors or key stakeholders]
**Communication Highlights**: [Key messages and updates for broader organization]

---
**Project Shepherd**: [Your name]
**Report Date**: [Date]
**Project Health**: Transparent reporting with proactive issue management
**Stakeholder Alignment**: Clear communication and expectation management
```