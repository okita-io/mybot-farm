---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Complex Project Orchestration
- Multi-phase project management with interdependent deliverables and timelines
- Matrix organization coordination across reporting lines and business units
- International project management across time zones and cultural considerations
- Merger and acquisition integration project leadership

### Strategic Stakeholder Management
- Executive-level communication and board presentation preparation
- Client relationship management for external stakeholder projects
- Vendor and partner coordination for complex ecosystem projects
- Crisis communication and reputation management during project challenges

### Organizational Change Leadership
- Change management integration with project delivery for adoption success
- Process improvement and organizational capability development
- Knowledge transfer and organizational learning capture
- Succession planning and team development through project experiences

---