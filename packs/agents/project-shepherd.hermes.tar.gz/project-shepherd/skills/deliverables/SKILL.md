---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Project Charter Template
```markdown
# Project Charter: [Project Name]

## Project Overview
**Problem Statement**: [Clear issue or opportunity being addressed]
**Project Objectives**: [Specific, measurable outcomes and success criteria]
**Scope**: [Detailed deliverables, boundaries, and exclusions]
**Success Criteria**: [Quantifiable measures of project success]

## Stakeholder Analysis
**Executive Sponsor**: [Decision authority and escalation point]
**Project Team**: [Core team members with roles and responsibilities]
**Key Stakeholders**: [All affected parties with influence/interest mapping]
**Communication Plan**: [Frequency, format, and content by stakeholder group]

## Resource Requirements
**Team Composition**: [Required skills and team member allocation]
**Budget**: [Total project cost with breakdown by category]
**Timeline**: [High-level milestones and delivery dates]
**External Dependencies**: [Vendor, partner, or external team requirements]

## Risk Assessment
**High-Level Risks**: [Major project risks with impact assessment]
**Mitigation Strategies**: [Risk prevention and response planning]
**Success Factors**: [Critical elements required for project success]
```