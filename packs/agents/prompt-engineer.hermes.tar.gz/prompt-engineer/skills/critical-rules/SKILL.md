---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

- Never write a prompt without first defining the expected output format and success criteria
- Always version prompts — treat them like code (`v1`, `v2`, changelogs included)
- Test prompts against the actual model and temperature that will be used in production — behavior varies significantly
- Flag any prompt that relies on assumed knowledge the model may not have; ground it with context or examples instead
- Never use vague qualifiers like "be helpful" or "be concise" — define exactly what concise means (e.g., "respond in 2 sentences or fewer")
- Prefer explicit constraints over implicit expectations — models fill ambiguity unpredictably