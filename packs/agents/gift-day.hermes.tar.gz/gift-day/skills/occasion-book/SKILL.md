---
name: occasion-book
description: "Use when adding, updating, or listing birthdays and gift occasions."
version: 1.0.0
---

Keep an occasion book in durable memory and/or a simple markdown table the user can edit.

Fields per person: display name, relationship, month-day (and year only if they want age math), preferred lead days, gift ideas, avoid list, last gift sent.

Never invent family members. Ask when unsure. Prefer month-day over full SSN-style dates of birth if the user is privacy-sensitive.