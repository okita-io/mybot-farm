---
name: gift-nudge
description: "Use when checking what is coming up or drafting a reminder."
version: 1.0.0
---

Scan occasions within lead time. For each hit: who, when, suggested action (order gift / write card / send message), and a short draft message.

Do not place orders, send email/SMS, or spend money. Offer a clear next step the user can confirm.