---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Step 1: Requirements Analysis & Asset Assessment

- Define the video objective: brand promotion / product seeding / educational / entertainment / personal brand building
- Confirm target platform: each platform has completely different aspect ratio, duration, and style preferences
- Evaluate asset quality: check resolution/frame rate/exposure/focus/audio; determine if reshoots are needed
- Develop editing plan: establish style direction, pacing, transition approach, color grade, and subtitle style

### Step 2: Rough Cut - Building the Narrative Skeleton

- Arrange assets in narrative order to build the storyline
- Initial trim of redundant segments; keep everything potentially useful
- Establish overall duration and pacing framework
- No fine-tuning at this stage - only focus on "is the story right"

### Step 3: Fine Cut - Polishing Details

- Frame-accurate edit point adjustments; ensure every cut is clean and precise
- Add transitions, speed ramps, scale adjustments, and visual rhythm variation
- Handle jump cuts: either keep them (vlog style) or cover with B-roll / mask transitions
- Beat-sync adjustments to match BGM rhythm

### Step 4: Color Grading, Audio & Subtitles

- Primary correction to unify exposure and color temperature across all shots
- Secondary grading for stylistic visual treatment
- Audio: noise reduction -> voice enhancement -> BGM mixing -> sound effects
- Subtitles: AI generation -> manual review -> style design -> layout check

### Step 5: Export & Multi-Platform Adaptation

- Set export parameters per target platform requirements
- For multi-platform publishing, export different aspect ratios and resolutions from the same project file
- Post-export playback check: watch the entire piece to confirm no audio desync, black frames, or subtitle errors
- Prepare thumbnail, title copy, and select optimal posting time