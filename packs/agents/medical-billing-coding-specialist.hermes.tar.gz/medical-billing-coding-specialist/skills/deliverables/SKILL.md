---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Coding Reference Framework

```
ICD-10-CM CODING PROTOCOL
───────────────────────────────────────
Step 1 — IDENTIFY THE REASON FOR THE VISIT
  What brought the patient in today?
  For outpatient: code the condition to the highest degree of certainty
  For inpatient: code the principal diagnosis (condition after study)

Step 2 — ACHIEVE MAXIMUM SPECIFICITY
  ICD-10 hierarchy: Category → Subcategory → Code
  Always code to the most specific level documented
  Add 7th character extensions where required (trauma, obstetrics)

Step 3 — CODE ADDITIONAL DIAGNOSES
  Chronic conditions actively managed during the visit
  Conditions that affect treatment or management
  External cause codes (V00-Y99) for injuries
  Status codes (Z codes) for factors affecting health status

Step 4 — SEQUENCE CORRECTLY
  Principal/first-listed diagnosis leads
  Follow Official Guidelines for Coding and Reporting (OGCR)
  Etiology/manifestation convention: code underlying condition first

COMMON CODING PITFALLS BY SPECIALTY:
  Primary Care:
    ❌ Coding "rule out" conditions as confirmed diagnoses
    ❌ Using unspecified diabetes codes when type is documented
    ❌ Missing Z-code opportunities (preventive care, screenings)

  Orthopedics:
    ❌ Missing laterality (right vs. left)
    ❌ Missing encounter type (initial / subsequent / sequela)
    ❌ Incomplete fracture coding (type, location, displaced/nondisplaced)

  Cardiology:
    ❌ Unspecified chest pain when etiology is documented
    ❌ Missing combination codes for heart failure + COPD
    ❌ Hypertension without specifying stage or type

  Mental Health:
# … truncated for farm planting — see upstream for the full sample
```

```
CPT CODING PROTOCOL
───────────────────────────────────────
E/M CODING (Office Visits — 2021 Guidelines):
  Medical Decision Making (MDM) — preferred method:
    Level    Problems      Data           Risk
    ───────────────────────────────────────────
    99202/12 Straightforward  Minimal     Minimal
    99203/13 Low complexity   Limited     Low
    99204/14 Moderate         Moderate    Moderate
    99205/15 High complexity  Extensive   High

  Total Time (alternative method):
    99202: 15-29 min | 99203: 30-44 min | 99204: 45-59 min
    99205: 60-74 min | 99212: 10-19 min | 99213: 20-29 min
    99214: 30-39 min | 99215: 40-54 min

  Documentation tips:
    ✅ MDM: document the number and complexity of problems addressed
    ✅ Time: document total time AND that time was spent on coordination
    ✅ New patient: must meet ALL 3 key components (old guideline)
    ❌ Never select level based on bullet counting under 2021 guidelines

PROCEDURE CODING:
  Step 1: Identify the procedure performed from operative/procedure note
  Step 2: Find the correct CPT code (Section: Surgery, Radiology, Lab, etc.)
  Step 3: Apply global period rules (0-day, 10-day, 90-day)
  Step 4: Apply modifiers as needed:
    -22: Increased procedural services (document time/complexity increase)
    -25: Significant, separately identifiable E/M same day as procedure
    -26: Professional component only (radiology, pathology)
    -51: Multiple procedures (payer-specific — many pay automatically)
    -59: Distinct procedural service (use carefully — OIG target)
    -TC: Technical component only
    -LT/-RT: Left / Right side
    -76: Repeat procedure by same physician
    -GT: Via interactive audio and video (telehealth)
```

### Claim Scrubbing Checklist

```
PRE-SUBMISSION CLAIM REVIEW
───────────────────────────────────────
PATIENT DEMOGRAPHICS
  □ Patient name matches insurance card exactly
  □ Date of birth correct
  □ Insurance ID / Member ID correct
  □ Group number correct
  □ Subscriber information complete (if patient is dependent)

PROVIDER INFORMATION
  □ Billing NPI correct (Type 2 for group)
  □ Rendering NPI correct (Type 1 for individual)
  □ Provider is credentialed and active with this payer
  □ Tax ID / EIN matches payer enrollment
  □ Service location NPI included (if facility billing)

CODING ACCURACY
  □ ICD-10 codes are valid for date of service
  □ CPT/HCPCS codes are valid for date of service
  □ Diagnosis codes support medical necessity for all CPT codes
  □ Diagnosis-procedure linkage is correct (Box 21/24E mapping)
  □ Modifiers are appropriate and documented
  □ Units are correct and documented

BILLING COMPLIANCE
  □ Place of service code matches actual location
  □ Date of service matches documentation
  □ Charges match fee schedule…