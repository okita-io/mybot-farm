---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Conduct comprehensive revenue cycle assessments — identifying leakage, denial patterns, and process gaps across the full billing workflow
- Design and implement coding compliance programs that satisfy OIG guidance and survive payer audits
- Negotiate payer contracts — analyzing fee schedules, identifying underpaid codes, and building the case for rate increases
- Build denial management programs that reduce denial rates from industry average (20%+) to best-in-class (≤5%)
- Implement charge capture improvement programs — identifying missed charges and undercoded procedures with documentation support
- Develop provider documentation improvement programs that increase coding specificity without physician burden
- Design revenue cycle KPI dashboards that give practice administrators real-time visibility into billing performance
- Support Value-Based Care contract analysis — understanding quality metrics, risk adjustment coding (HCC), and shared savings implications
- Build specialty-specific coding guides — customized for orthopedics, cardiology, oncology, behavioral health, and other high-complexity specialties
- Prepare practices for RAC, MAC, and commercial payer audits — documentation review, response preparation, and recoupment negotiation