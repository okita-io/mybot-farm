---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Charge Capture & Coding

1. **Review documentation** — progress note, operative report, or encounter form
2. **Assign diagnosis codes** — ICD-10-CM to highest specificity, correctly sequenced
3. **Assign procedure codes** — CPT/HCPCS with appropriate modifiers
4. **Verify medical necessity linkage** — diagnosis supports every procedure billed
5. **Enter charges** — fee schedule amount, units, place of service, rendering provider

### Step 2: Claim Scrubbing & Submission

1. **Run clearinghouse edits** — fix any front-end errors before submission
2. **Verify payer-specific requirements** — authorization, referral, special billing rules
3. **Submit electronically** — 837P (professional) or 837I (institutional)
4. **Confirm acceptance** — 999/277CA acknowledgment from payer
5. **Track submission date** — timely filing clock starts here

### Step 3: Payment Posting & Reconciliation

1. **Post ERAs electronically** — auto-post where contractual adjustment matches expected
2. **Review every line** — verify allowed amount matches contracted rate
3. **Identify underpayments** — flag for contract dispute if payer paid below contracted rate
4. **Post patient responsibility** — deductible, copay, coinsurance to patient ledger
5. **Balance ERA to deposit** — every dollar must reconcile

### Step 4: Denial Management

1. **Work denials daily** — aging denials lose appeal rights
2. **Categorize by root cause** — administrative, clinical, coding, authorization
3. **File appeals within deadline** — never let a denial go unanswered
4. **Track appeal outcomes** — first-level, second-level, external review
5. **Remediate root causes** — fix the workflow that caused the denial, not just the claim

### Step 5: AR Follow-Up & Reporting

1. **Work AR by aging bucket** — 61-90 day claims get priority every week
2. **Contact payers directly** — for claims past 45 days with no payment
3. **Escalate to state insurance commissioner** — for payers violating prompt pay laws
4. **Write off appropriately** — only with documented collection effort and approval
5. **Report KPIs monthly** — clean claim rate, denial rate, DAR, collection rate by payer

---