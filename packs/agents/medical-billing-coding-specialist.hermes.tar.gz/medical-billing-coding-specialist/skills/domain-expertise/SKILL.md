---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Coding Systems

- **ICD-10-CM**: Diagnosis coding — 70,000+ codes, updated October 1 annually
- **ICD-10-PCS**: Inpatient procedure coding — hospital use only
- **CPT**: Current Procedural Terminology — AMA-maintained, updated January 1 annually
- **HCPCS Level II**: Supplies, DME, drugs, non-physician services
- **Revenue Codes**: UB-04 institutional billing — 4-digit codes by service category

### Payer Landscape

- **Medicare**: CMS-administered, LCD/NCD coverage policies, MAC jurisdiction-specific rules
- **Medicaid**: State-administered, highly variable by state — always verify state-specific policy
- **Commercial**: BCBS, Aetna, UHC, Cigna, Humana — payer-specific policies and fee schedules
- **Medicare Advantage**: Commercial administration with Medicare rules + plan-specific policies
- **Workers Comp**: State-regulated, employer-funded, separate fee schedules
- **VA/TriCare**: Federal military and veterans coverage — specific enrollment and billing rules

### Regulatory Framework

- **HIPAA**: Privacy Rule (PHI protection), Security Rule (electronic PHI), Transactions Rule (standard claim formats)
- **False Claims Act**: Federal liability for knowingly submitting false claims — qui tam provisions
- **Anti-Kickback Statute**: Prohibits remuneration for referrals of federal healthcare program patients
- **Stark Law**: Prohibits physician self-referral for designated health services
- **OIG Work Plan**: Annual list of audit targets — essential reading for compliance prioritization
- **2 CFR Part 200**: Applicable to federally funded health programs

### Certifications & References

- **CPC** (Certified Professional Coder — AAPC): Gold standard for physician billing
- **CCS** (Certified Coding Specialist — AHIMA): Hospital/facility coding
- **CPMA** (Certified Professional Medical Auditor): Compliance auditing
- **AHA Coding Clinic**: Official ICD-10 coding guidance (quarterly)
- **AMA CPT Assistant**: Official CPT coding guidance (monthly)
- **CMS NCCI Edits**: National Correct Coding Initiative — bundling rules

---