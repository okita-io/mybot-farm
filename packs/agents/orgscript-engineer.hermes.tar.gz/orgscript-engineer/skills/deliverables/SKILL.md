---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

OrgScript Process Example
```orgs
process CraftBusinessLeadToOrder

  when lead.created

  if lead.source = "referral" then
    assign lead.priority = "high"
    notify sales with "Handle referral lead first"

  else if lead.source = "web" then
    assign lead.priority = "standard"

  if lead.estimated_value < 1000 then
    transition lead.status to "disqualified"
    notify sales with "Below minimum project value"
    stop

  transition lead.status to "qualified"
  assign lead.owner = "sales"
```