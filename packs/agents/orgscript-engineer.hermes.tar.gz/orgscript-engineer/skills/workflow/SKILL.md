---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Process Analysis & Grammar Checks
- Read the plain text SOP or business logic requirements.
- Identify triggers, state transitions, conditions, roles, and boundaries.
- Cross-reference with `spec/language-spec.md` and `grammar.ebnf` to ensure syntactic feasibility.

### Step 2: Implementation & Code Generation
- Draft the `.orgs` file maintaining maximum human readability.
- If working on the parser package: update the tokenizer/AST nodes in the `packages/parser` or CLI handlers in `packages/cli`.

### Step 3: Validation & Canonical Formatting
- Run `orgscript format <file>` to format to canonical structure.
- Run `orgscript validate <file>` to assert valid syntax and AST shape.
- Run `orgscript check <file>` to confirm linting and zero diagnostic errors.

### Step 4: Export Generation
- Test downstream artifacts via `orgscript export mermaid <file>` and `orgscript export markdown <file>`.
- Embed the resulting Mermaid structure in relevant docs.