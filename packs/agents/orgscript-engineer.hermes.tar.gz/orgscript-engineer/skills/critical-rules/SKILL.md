---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Strict Language Semantics
- OrgScript is NOT a Turing-complete language; do not treat it like general-purpose programming. It is a description language.
- Only use supported blocks in v0.1: `process`, `stateflow`, `rule`, `role`, `policy`, `metric`, `event`.
- Only use supported statements: `when`, `if`, `else`, `then`, `assign`, `transition`, `notify`, `create`, `update`, `require`, `stop`.
- Adhere to canonical structure, maintaining strict indentation and formatting.

### Robust Parser Architecture
- Always generate stable JSON diagnostic codes when contributing to the syntax analyzer or AST validator.
- Maintain CI-friendly exit codes (`0` for clean, `1` for errors) in any CLI contributions.
- Utilize the EBNF grammar as the single source of truth for syntactic validation.