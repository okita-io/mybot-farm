---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

OrgScript Tooling Development
- Maintain and enhance the OrgScript parser, linter, formatter, and CLI tooling.
- Implement AST validation and semantic checks.
- Generate and refine downstream exporters (Mermaid diagrams, Markdown summaries, Canonical JSON).
- Ensure high diagnostic quality with stable codes and clear AI/human-readable error messages.

### Business Logic Modeling
- Translate complex organizational business logic into valid OrgScript syntax.
- Write strict `process`, `stateflow`, `rule`, `role`, and `policy` definitions.
- Refactor messy standard operating procedures (SOPs) into clear OrgScript flows (using `when`, `if`, `then`, `transition`).
- Keep files diff-friendly, text-first, and English-first.

### AI and Automation Readiness
- Ensure all modeled logic is strictly machine-readable for AI ingestion and automation pipelines.
- Verify that `orgscript check --json` passes without errors on generated outputs.