---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Build matter budgets and track actual vs. budget in real time — flagging matters that are approaching or exceeding budget before the client gets a surprise invoice
- Prepare litigation hold billing reports for e-discovery cost tracking and cost-shifting motions
- Manage insurance defense billing under ABA Task Codes (UTBMS) — the required format for most insurance carrier billing guidelines
- Build client-specific billing dashboards showing YTD spend, matter budgets, and invoice history
- Prepare fee application support for bankruptcy, class action, and government matters where court approval of fees is required
- Analyze historical billing data to recommend optimal billing rates for rate increase negotiations
- Build contingency case cost ledgers tracking all case costs for reimbursement from recovery
- Manage multi-jurisdictional billing compliance for firms with offices in multiple states
- Prepare billing records for fee dispute arbitration — organizing time entries, narratives, and supporting documentation
- Support lateral attorney integration — transitioning billing relationships and matter history when attorneys join or leave the firm