---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Time Entry Standards

```
TIME ENTRY STANDARDS GUIDE
───────────────────────────────────────
Minimum time increment: 0.1 hours (6 minutes)
Standard rounding: Round up to nearest 0.1 hour
Time entry deadline: Same day as work performed (preferred)
                     Never more than 48 hours after work performed

GOOD TIME ENTRY EXAMPLES
───────────────────────────────────────
✅ "Review and analyze plaintiff's motion for summary judgment;
    identify key arguments and evidentiary gaps; begin outlining
    response strategy." — 2.4 hrs

✅ "Telephone conference with client re: settlement offer received
    from opposing counsel; discuss pros and cons of acceptance;
    advise client on litigation risks if matter proceeds to trial;
    client instructs to reject offer and continue negotiations."
    — 0.8 hrs

✅ "Draft demand letter to ABC Corp re: breach of contract claim;
    research applicable statute of limitations; calculate damages."
    — 1.6 hrs

✅ "Review title commitment for 123 Main Street property;
    identify Schedule B exceptions; prepare summary of title
    issues for client review." — 0.9 hrs

BAD TIME ENTRY EXAMPLES
───────────────────────────────────────
❌ "Legal services." — Too vague, describes nothing
❌ "Review file." — What file? What was reviewed? Why?
❌ "Phone call." — With whom? About what? What was accomplished?
❌ "Research." — What issue? What was found?
❌ "Work on case." — This is never acceptable
❌ "Misc." — Never appropriate as a billing entry

BLOCK BILLING WARNING
───────────────────────────────────────
Block billing (combining multiple tasks into one entry) should be
avoided with clients whose guidelines prohibit it. When block billing
# … truncated for farm planting — see upstream for the full sample
```

### Billing Narrative Templates by Practice Area

```
BILLING NARRATIVE TEMPLATES
───────────────────────────────────────
LITIGATION
  Research:
    "Research [legal issue] in connection with [matter description];
    review [cases/statutes/regulations] and analyze applicability
    to client's facts; prepare research summary."

  Drafting:
    "Draft [document type] in connection with [matter]; incorporate
    [specific elements]; revise per [attorney/client] comments."

  Court appearances:
    "Appear at [hearing type] before [court/judge] re: [matter];
    [outcome/next steps]."

  Depositions:
    "Prepare for and attend deposition of [witness name] re: [topics];
    [duration] hours of testimony; identify key admissions."

TRANSACTIONAL / CORPORATE
  Contract review:
    "Review and analyze [contract type] submitted by [party];
    identify non-standard provisions and potential risks;
    prepare redline with comments for client review."

  Due diligence:
    "Review [document type] in connection with [transaction];
    identify material issues; update due diligence tracker."

  Drafting:
    "Draft [document type] for [transaction/matter];
    incorporate [specific deal terms]; circulate for review."

REAL ESTATE
  Title review:
    "Review title commitment for [property address]; analyze
    Schedule B exceptions; identify title defects and
    required curative actions."

# … truncated for farm planting — see upstream for the full sample
```

### Invoice Generation Template

```
INVOICE REVIEW CHECKLIST
───────────────────────────────────────
Before sending any invoice, verify:

Client & Matter Information:
  [ ] Correct client name and billing address
  [ ] Correct matter name and number
  [ ] Correct billing attorney listed
  [ ] Invoice number is sequential and unique
  [ ] Invoice date is current
  [ ] Billing period is accurately stated

Time Entries:
  [ ] All time entries have adequate narrative description
  [ ] No block billing (if client guidelines prohibit)
  [ ] No entries for non-billable activities
  [ ] Rates match the fee agreement or current rate schedule
  [ ] All time approved by responsible attorney
  [ ] No duplicate entries

Expenses:
  [ ] All expenses are client-billable per fee agreement
  [ ] Receipts on file for all expenses over threshold
  [ ] No overhead expenses billed to client
  [ ] Expense descriptions are clear and specific
  [ ] Third-party costs billed at actual cost (no markup unless agreed)

Totals:
  [ ] Fees subtotal is mathematically correct
  [ ] Expenses subtotal is mathematically correct
  [ ] Previous balance (if any) is accurate
  [ ] Trust account credit applied if applicable
  [ ] Total amount due is correct…