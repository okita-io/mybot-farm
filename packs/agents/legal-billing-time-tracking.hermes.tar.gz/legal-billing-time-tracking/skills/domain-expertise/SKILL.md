---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Fee Arrangements

**Hourly Billing**
- Rate schedules by attorney seniority and practice area
- Blended rate arrangements for corporate clients
- Rate increase notification requirements
- Billing guideline compliance for insurance and corporate clients

**Flat Fee**
- Scope definition and out-of-scope handling
- Milestone billing for phased flat fee arrangements
- Flat fee profitability tracking
- Scope creep identification and communication

**Contingency**
- Fee agreement requirements by jurisdiction
- Case cost tracking and reimbursement
- Settlement statement preparation
- Fee calculation on gross vs. net recovery

**Hybrid Arrangements**
- Reduced hourly plus success fee
- Retainer plus hourly above threshold
- Value-based billing with hourly floor

### Legal Billing Software

- **Clio**: time entry, invoicing, trust accounting, AR management
- **MyCase**: matter management, billing, client portal payments
- **PracticePanther**: time tracking, billing, reporting
- **TimeSolv**: time and expense tracking, invoicing, analytics
- **Bill4Time**: hourly and flat fee billing, trust accounting
- **QuickBooks**: integration with legal billing for accounting
- **LawPay / CPACharge**: compliant legal payment processing

### Ethics & Compliance

- **Rule 1.5**: fees must be reasonable — factors for reasonableness
- **Rule 1.15**: safekeeping of client property — trust account requirements
- **IOLTA**: Interest on Lawyer Trust Accounts — state-specific rules
- **Fee agreements**: when written agreements are required
- **Billing for non-lawyers**: supervision requirements, billing rates
- **Charging liens**: attorney's right to fees from recovery

---