---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Daily Time Capture Support

1. **Morning prompt** — remind attorneys to capture yesterday's unbilled time
2. **Real-time capture coaching** — help attorneys describe what they're doing as they do it
3. **End-of-day review** — identify any gaps in time entries for the day
4. **Narrative quality check** — flag vague or insufficient entries before they hit the invoice
5. **Client guideline compliance** — check entries against specific client billing requirements

### Step 2: Pre-billing Review

1. **Pull unbilled WIP** — identify all time ready for billing by matter
2. **Review narratives** — flag inadequate descriptions for attorney revision
3. **Check billing guidelines** — verify compliance with client-specific requirements
4. **Identify write-down candidates** — flag time that may not be fully billable
5. **Calculate invoice amounts** — fees plus expenses plus trust activity

### Step 3: Invoice Preparation & Delivery

1. **Generate draft invoices** — prepare invoice for responsible attorney review
2. **Attorney approval** — no invoice sent without attorney sign-off
3. **Apply trust funds** — if applicable, apply trust retainer to invoice
4. **Deliver invoices** — per client preference (email, mail, portal)
5. **Record in accounting system** — update AR and billing records

### Step 4: Collections Management

1. **Monitor AR aging** — weekly review of outstanding invoices
2. **Send reminders** — per collections sequence at 35, 60, 90 days
3. **Escalate to attorney** — at 90 days or per firm policy
4. **Document all contacts** — every collections communication logged
5. **Process payments** — apply payments correctly to oldest invoices first

### Step 5: Trust Account Management

1. **Record all deposits** — same day as funds received
2. **Reconcile client ledgers** — after every transaction
3. **Monthly three-way reconciliation** — bank / ledger / journal
4. **Monitor replenishment thresholds** — notify clients when trust is low
5. **Document all disbursements** — complete audit trail for every transaction

### Step 6: Billing Analysis & Reporting

1. **Monthly billing report** — realization rate, collection rate, AR aging
2. **Attorney productivity report** — hours worked, billed, and collected by attorney
3. **Matter profitability analysis** — revenue vs. cost by matter
4. **Client profitability analysis** — identify most and least profitable client relationships
5. **Write-down analysis** — track patterns and root causes of write-downs

---