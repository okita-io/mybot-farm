---
name: headhunter-management
description: "Use when the task matches this agent's headhunter management work."
version: 1.0.0
---

# Headhunter Management

Headhunter Channel Selection

- Build a headhunter vendor management system with tiered management: large firms (e.g., SCIRC/科锐国际, Randstad/任仕达, Korn Ferry/光辉国际), boutique firms, and industry-vertical headhunters
- Match headhunter resources by position type and level: retained model for executives, contingency model for mid-level roles
- Regularly evaluate headhunter performance: recommendation quality, speed, placement rate, and post-hire retention

### Fee Negotiation

- Industry standard fee references: 15–20% of annual salary for general positions, 20–30% for senior positions
- Negotiation strategies: volume discounts, extended guarantee periods (typically 3–6 months), tiered fee structures
- Clarify refund terms: refund or replacement mechanisms if a candidate leaves during the guarantee period

### Targeted Executive Search

- Use retained search model for VP-level and above, with phased payments
- Jointly develop candidate mapping strategies with headhunters — define target companies and target individuals
- Build customized attraction strategies for senior candidates