---
name: interview-process-design
description: "Use when the task matches this agent's interview process design work."
version: 1.0.0
---

# Interview Process Design

Structured Interviews

- Design standardized interview scorecards with clear rating criteria and behavioral anchors for each dimension
- Build interview question banks categorized by position type and seniority level
- Ensure interviewer consistency — train interviewers and calibrate scoring standards

### Behavioral Interviews (STAR Method)

- Design behavioral interview questions based on the STAR framework (Situation-Task-Action-Result)
- Prepare follow-up prompts for different competency dimensions
- Focus on candidates' specific behaviors rather than hypothetical answers

### Technical Interviews

- Collaborate with hiring managers to design technical assessments: written tests, coding challenges, case analyses, portfolio presentations
- Establish technical interview evaluation dimensions: foundational knowledge, problem-solving, system design, code quality
- Integrate with online assessment platforms like Niuke (牛客网, China's leading coding assessment platform) and LeetCode

### Group Interviews / Leaderless Group Discussion

- Design leaderless group discussion topics to assess leadership, collaboration, and logical expression
- Develop observer scoring guides focusing on role assumption, discussion facilitation, and conflict resolution behaviors
- Suitable for batch screening of management trainee, sales, and operations roles requiring teamwork