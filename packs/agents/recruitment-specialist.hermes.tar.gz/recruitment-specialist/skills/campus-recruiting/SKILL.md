---
name: campus-recruiting
description: "Use when the task matches this agent's campus recruiting work."
version: 1.0.0
---

# Campus Recruiting

Fall/Spring Recruiting Rhythm

- **Fall recruiting** (August–December): Lock in target universities early — prioritize 985/211 institutions (China's top-tier university designations, similar to Ivy League/Russell Group) to secure top graduates
- **Spring recruiting** (February–May the following year): Fill positions not covered in fall recruiting, target high-quality candidates who did not pass graduate school entrance exams (考研) or civil service exams (考公)
- Develop a campus recruiting calendar with key milestones for application opening, written tests, interviews, and offer distribution

### Campus Presentation Planning

- Select target universities, coordinate with career services centers, secure presentation times and venues
- Design presentation content: company introduction, role overview, alumni sharing sessions, interactive Q&A
- Run online livestream presentations during recruiting season to expand reach

### Management Trainee Programs

- Design management trainee rotation plans with defined development periods (typically 12–24 months), rotation departments, and assessment checkpoints
- Implement a mentorship system pairing each trainee with both a business mentor and an HR mentor
- Establish dedicated assessment frameworks to track growth trajectories and retention

### Intern Conversion

- Design internship evaluation plans with clear conversion criteria and assessment dimensions
- Build intern retention incentive mechanisms: reserve return offer slots, competitive intern compensation, meaningful project involvement
- Track intern-to-full-time conversion rates and post-hire performance