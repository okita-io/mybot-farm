---
name: onboarding-management
description: "Use when the task matches this agent's onboarding management work."
version: 1.0.0
---

# Onboarding Management

Offer Issuance

- Design standardized **offer letter** templates including position, compensation, benefits, start date, probation period, and other key information
- Establish an offer approval workflow: compensation plan → hiring manager confirmation → HR director approval → issuance
- Prepare for candidate **offer negotiation** with pre-determined salary flexibility and alternatives (e.g., signing bonuses, equity options, flexible benefits)

### Background Checks

- Conduct background checks for key positions: education verification, employment history validation, non-compete status screening
- Use professional background check firms (e.g., Quanscape/全景求是, TaiHe DingXin/太和鼎信) or conduct reference checks internally
- Establish protocols for handling issues discovered during background checks, including risk contingency plans

### Onboarding SOP

```markdown
# Standardized Onboarding Checklist

## Pre-Onboarding (T-7 Days)
- [ ] Send onboarding notification email/SMS with required materials checklist
- [ ] Prepare workstation, computer, access badge, and other office resources
- [ ] Set up corporate email, OA system, and Feishu/DingTalk/WeCom accounts
- [ ] Notify the hiring team and assigned mentor to prepare for the new hire
- [ ] Schedule onboarding training sessions

## Onboarding Day (Day T)
- [ ] Sign labor contract, confidentiality agreement, and employee handbook acknowledgment
- [ ] Complete social insurance and housing fund registration
- [ ] Enter records into HRIS (Beisen, iRenshi, Feishu People, etc.)
- [ ] Distribute employee handbook and IT usage guide
- [ ] Conduct onboarding training: company culture, organizational structure, policies and procedures
- [ ] Hiring team welcome and team introductions
- [ ] First one-on-one meeting with assigned mentor

## First Week (T+1 to T+7 Days)
- [ ] Confirm job responsibilities and probation period goals
- [ ] Arrange business training and system operations training
- [ ] HR conducts onboarding experience check-in
- [ ] Add new hire to department communication groups and relevant project teams

## First Month (T+30 Days)
- [ ] Mentor conducts first-month feedback session
- [ ] HR conducts new hire satisfaction survey
- [ ] Confirm probation assessment plan and milestone goals
```

### Probation Period Management

- Define clear probation assessment criteria and evaluation timelines (typically monthly or bi-monthly reviews)
- Establish a probation early warning system: proactively communicate improvement plans with underperforming new hires
- Define the process for handling probation failures: thorough documentation, lawful and compliant termination, respectful communication