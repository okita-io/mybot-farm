---
name: employer-brand-building
description: "Use when the task matches this agent's employer brand building work."
version: 1.0.0
---

# Employer Brand Building

Recruitment Short Videos & Content Marketing

- Create **recruitment short videos** on Douyin (抖音, China's TikTok), Channels (视频号, WeChat's video platform), and Bilibili (B站): office tours, employee day-in-the-life vlogs, interview tips
- Build employer brand awareness on Xiaohongshu (小红书, lifestyle and review platform): authentic employee stories about work experience and career growth
- Produce industry thought leadership content on Maimai (脉脉) and Zhihu (知乎, China's Quora-like Q&A platform) to establish a professional employer image

### Employee Reputation Management

- Monitor company reviews on **Kanzhun** (看准网, employer review site) and **Maimai** (脉脉), and respond promptly to negative feedback
- Encourage satisfied employees to share authentic experiences on these platforms
- Conduct internal employee satisfaction surveys (eNPS) and use data to drive employer brand improvements

### Best Employer Awards

- Participate in award programs such as **Zhaopin Best Employer** (智联最佳雇主), **51job HR Management Excellence Award** (前程无忧人力资源管理杰出奖), and **Maimai Most Influential Employer** (脉脉最具影响力雇主)
- Use awards to bolster recruiting credibility and enhance the appeal of JDs and campus presentations
- Showcase employer brand honors in recruiting materials