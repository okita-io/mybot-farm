---
name: china-labor-law-compliance
description: "Use when the task matches this agent's china labor law compliance work."
version: 1.0.0
---

# China Labor Law Compliance

Labor Contract Law Key Points

- **Labor contract signing**: A written contract must be signed within 30 days of onboarding; failure to do so requires paying double wages. Contracts unsigned for over 1 year are deemed open-ended (无固定期限合同)
- **Contract types**: Fixed-term, open-ended, and project-based contracts
- **After two consecutive fixed-term contracts**, the employee has the right to request an open-ended contract

### Probation Period Regulations

- Contract term 3 months to under 1 year: probation period no more than 1 month
- Contract term 1 year to under 3 years: probation period no more than 2 months
- Contract term 3 years or more, or open-ended: probation period no more than 6 months
- Probation wages must be no less than 80% of the agreed salary and no less than the local minimum wage
- An employer may only set one probation period with the same employee

### Social Insurance & Housing Fund (Wuxian Yijin / 五险一金)

- **Five insurances** (五险): Pension insurance, medical insurance, unemployment insurance, work injury insurance, maternity insurance
- **One fund** (一金): Housing provident fund (住房公积金, a mandatory savings program for housing)
- Employers must complete social insurance registration and payment within 30 days of an employee's start date
- Contribution bases and rates vary by city — stay current on local policies (e.g., differences between Beijing, Shanghai, and Shenzhen)
- Supplementary benefits: supplementary medical insurance, enterprise annuity, supplementary housing fund

### Non-Compete Restrictions (竞业限制)

- Non-compete period must not exceed 2 years
- Employers must pay monthly non-compete compensation (typically no less than 30% of the employee's average monthly salary over the 12 months before departure; local standards vary)
- If compensation is unpaid for more than 3 months, the employee has the right to terminate the non-compete obligation
- Applicable to: executives, senior technical staff, and other personnel with confidentiality obligations

### Severance Compensation (N+1)

- **Statutory severance standard**: N (years of service) × monthly salary. Less than 6 months counts as half a month; 6 months to under 1 year counts as 1 year
- **N+1**: If the employer does not give 30 days' advance notice, an additional month's salary is paid as payment in lieu of notice (代通知金)
- **Unlawful termination**: 2N compensation
- **Monthly salary cap**: Capped at 3 times the local average social salary, with maximum 12 years of service for calculation
- Mass layoffs (20+ employees or 10%+ of workforce) require 30 days' advance notice to the labor union or all employees, plus filing with the labor administration authority