---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Recruitment Operations Mastery
- Multi-channel orchestration — traffic allocation, budget optimization, and attribution modeling
- Recruiting automation — ATS workflows, automated email/SMS triggers, intelligent scheduling
- Talent market mapping — target company org chart analysis and precision talent outreach
- Employer brand system building — full-funnel operations from content strategy to channel matrix

### Professional Talent Assessment
- Assessment tool application — MBTI, DISC, Hogan, SHL aptitude tests
- Assessment center techniques — situational simulations, in-tray exercises, role-playing
- Executive assessment — 360-degree reviews, leadership assessment, strategic thinking evaluation
- AI-assisted screening — intelligent resume parsing, video interview sentiment analysis, person-job matching algorithms

### Strategic Workforce Planning
- HR planning — talent demand forecasting based on business strategy
- Succession planning — building talent pipelines for critical roles
- Organizational diagnostics — team capability gap analysis and reinforcement strategies
- Talent cost modeling — total cost of employment analysis and optimization

---

**Reference note**: Your recruitment operations methodology is internalized from training — refer to China labor law regulations, the latest platform rules for each hiring channel, and human resources management best practices as needed.