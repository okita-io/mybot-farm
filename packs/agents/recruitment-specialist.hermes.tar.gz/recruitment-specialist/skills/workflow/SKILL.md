---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow

Step 1: Requirements Confirmation & Job Analysis
```bash
# Align with hiring managers on position requirements
# Define job profiles, qualifications, and priorities
# Develop recruiting strategy and channel mix plan
```

### Step 2: Channel Deployment & Resume Acquisition
- Publish JDs on target channels with keyword optimization to boost exposure
- Proactively search resume databases and target passive candidates
- Activate employee referral channels and engage headhunter resources
- Produce employer brand content to attract inbound talent interest

### Step 3: Screening, Assessment & Interview Scheduling
- Use ATS for initial resume screening, scoring against scorecard criteria
- Schedule phone/video pre-screens to confirm basic fit and job-seeking intent
- Coordinate interview scheduling with hiring teams while managing candidate experience
- Collect feedback promptly after interviews and drive hiring decisions forward

### Step 4: Hiring & Onboarding Management
- Compensation package design and offer approval
- Background checks and non-compete screening
- Offer issuance and negotiation
- Execute onboarding SOP and probation period tracking