---
name: recruitment-data-analytics
description: "Use when the task matches this agent's recruitment data analytics work."
version: 1.0.0
---

# Recruitment Data Analytics

Recruitment Funnel Analysis

```python
class RecruitmentFunnelAnalyzer:
    def __init__(self, recruitment_data):
        self.data = recruitment_data

    def analyze_funnel(self, position_id=None, department=None, period=None):
        """
        Analyze conversion rates at each stage of the recruitment funnel
        """
        filtered_data = self.filter_data(position_id, department, period)

        funnel = {
            'job_impressions': filtered_data['impressions'].sum(),
            'applications': filtered_data['applications'].sum(),
            'resumes_passed': filtered_data['resume_passed'].sum(),
            'first_interviews': filtered_data['first_interview'].sum(),
            'second_interviews': filtered_data['second_interview'].sum(),
            'final_interviews': filtered_data['final_interview'].sum(),
            'offers_sent': filtered_data['offers_sent'].sum(),
            'offers_accepted': filtered_data['offers_accepted'].sum(),
            'onboarded': filtered_data['onboarded'].sum(),
            'probation_passed': filtered_data['probation_passed'].sum(),
        }

        # Calculate conversion rates between stages
        stages = list(funnel.keys())
        conversion_rates = {}
        for i in range(1, len(stages)):
            if funnel[stages[i-1]] > 0:
                rate = funnel[stages[i]] / funnel[stages[i-1]] * 100
                conversion_rates[f'{stages[i-1]} -> {stages[i]}'] = round(rate, 1)

        # Calculate key metrics
        key_metrics = {
            'application_rate': self.safe_divide(funnel['applications'], funnel['job_impressions']),
            'resume_pass_rate': self.safe_divide(funnel['resumes_passed'], funnel['applications']),
            'interview_show_rate': self.safe_divide(funnel['first_interviews'], funnel['resumes_passed']),
            'offer_acceptance_rate': self.safe_divide(funnel['offers_accepted'], funnel['offers_sent']),
            'onboarding_rate': self.safe_divide(funnel['onboarded'], funnel['offers_accepted']),
            'probation_retention_rate': self.safe_divide(funnel['probation_passed'], funnel['onboarded']),
            'overall_conversion_rate': self.safe_divide(funnel['probation_passed'], funnel['applications']),
# … truncated for farm planting — see upstream for the full sample
```

### Recruitment Health Dashboard

```markdown
# [Month] Recruitment Operations Monthly Report

## Key Metrics Overview
**Open positions**: [count] (New: [count], Closed: [count])
**Hires this month**: [count] (Target completion rate: [%])
**Average time-to-hire**: [days] (MoM change: [+/-] days)
**Offer acceptance rate**: [%] (MoM change: [+/-]%)
**Monthly recruiting spend**: ¥[amount] (Budget utilization: [%])

## Channel Performance Analysis
| Channel | Resumes | Hires | Cost per Hire | Quality Score |
|---------|---------|-------|---------------|---------------|
| Boss Zhipin | [count] | [count] | ¥[amount] | [score] |
| Lagou | [count] | [count] | ¥[amount] | [score] |
| Liepin | [count] | [count] | ¥[amount] | [score] |
| Headhunters | [count] | [count] | ¥[amount] | [score] |
| Employee Referrals | [count] | [count] | ¥[amount] | [score] |

## Department Hiring Progress
| Department | Openings | Hired | Completion Rate | Pending Offers |
|------------|----------|-------|-----------------|----------------|
| [Dept] | [count] | [count] | [%] | [count] |

## Probation Retention
**Converted this month**: [count]
**Left during probation**: [count]
**Probation retention rate**: [%]
**Attrition reason analysis**: [categorized summary]

## Action Items & Risks
1. **Urgent**: [Positions requiring acceleration and action plan]
2. **Watch**: [Bottleneck stages in the recruiting funnel]
3. **Optimize**: [Channel adjustments and process improvement recommendations]
```