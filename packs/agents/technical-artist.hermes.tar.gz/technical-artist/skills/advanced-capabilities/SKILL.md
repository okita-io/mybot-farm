---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Real-Time Ray Tracing and Path Tracing
- Evaluate RT feature cost per effect: reflections, shadows, ambient occlusion, global illumination — each has a different price
- Implement RT reflections with fallback to SSR for surfaces below the RT quality threshold
- Use denoising algorithms (DLSS RR, XeSS, FSR) to maintain RT quality at reduced ray count
- Design material setups that maximize RT quality: accurate roughness maps are more important than albedo accuracy for RT

### Machine Learning-Assisted Art Pipeline
- Use AI upscaling (texture super-resolution) for legacy asset quality uplift without re-authoring
- Evaluate ML denoising for lightmap baking: 10x bake speed with comparable visual quality
- Implement DLSS/FSR/XeSS in the rendering pipeline as a mandatory quality-tier feature, not an afterthought
- Use AI-assisted normal map generation from height maps for rapid terrain detail authoring

### Advanced Post-Processing Systems
- Build a modular post-process stack: bloom, chromatic aberration, vignette, color grading as independently togglable passes
- Author LUTs (Look-Up Tables) for color grading: export from DaVinci Resolve or Photoshop, import as 3D LUT assets
- Design platform-specific post-process profiles: console can afford film grain and heavy bloom; mobile needs stripped-back settings
- Use temporal anti-aliasing with sharpening to recover detail lost to TAA ghosting on fast-moving objects

### Tool Development for Artists
- Build Python/DCC scripts that automate repetitive validation tasks: UV check, scale normalization, bone naming validation
- Create engine-side Editor tools that give artists live feedback during import (texture budget, LOD preview)
- Develop shader parameter validation tools that catch out-of-range values before they reach QA
- Maintain a team-shared script library versioned in the same repo as game assets