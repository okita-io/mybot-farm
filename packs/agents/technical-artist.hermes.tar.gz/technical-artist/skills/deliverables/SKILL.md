---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Asset Budget Spec Sheet
```markdown
# Asset Technical Budgets — [Project Name]

## Characters
| LOD  | Max Tris | Texture Res | Draw Calls |
|------|----------|-------------|------------|
| LOD0 | 15,000   | 2048×2048   | 2–3        |
| LOD1 | 8,000    | 1024×1024   | 2          |
| LOD2 | 3,000    | 512×512     | 1          |
| LOD3 | 800      | 256×256     | 1          |

## Environment — Hero Props
| LOD  | Max Tris | Texture Res |
|------|----------|-------------|
| LOD0 | 4,000    | 1024×1024   |
| LOD1 | 1,500    | 512×512     |
| LOD2 | 400      | 256×256     |

## VFX Particles
- Max simultaneous particles on screen: 500 (mobile) / 2000 (PC)
- Max overdraw layers per effect: 3 (mobile) / 6 (PC)
- All additive effects: alpha clip where possible, additive blending only with budget approval

## Texture Compression
| Type          | PC     | Mobile      | Console  |
|---------------|--------|-------------|----------|
| Albedo        | BC7    | ASTC 6×6    | BC7      |
| Normal Map    | BC5    | ASTC 6×6    | BC5      |
| Roughness/AO  | BC4    | ASTC 8×8    | BC4      |
| UI Sprites    | BC7    | ASTC 4×4    | BC7      |
```

### Custom Shader — Dissolve Effect (HLSL/ShaderLab)
```hlsl
// Dissolve shader — works in Unity URP, adaptable to other pipelines
Shader "Custom/Dissolve"
{
    Properties
    {
        _BaseMap ("Albedo", 2D) = "white" {}
        _DissolveMap ("Dissolve Noise", 2D) = "white" {}
        _DissolveAmount ("Dissolve Amount", Range(0,1)) = 0
        _EdgeWidth ("Edge Width", Range(0, 0.2)) = 0.05
        _EdgeColor ("Edge Color", Color) = (1, 0.3, 0, 1)
    }
    SubShader
    {
        Tags { "RenderType"="TransparentCutout" "Queue"="AlphaTest" }
        HLSLPROGRAM
        // Vertex: standard transform
        // Fragment:
        float dissolveValue = tex2D(_DissolveMap, i.uv).r;
        clip(dissolveValue - _DissolveAmount);
        float edge = step(dissolveValue, _DissolveAmount + _EdgeWidth);
        col = lerp(col, _EdgeColor, edge);
        ENDHLSL
    }
}
```

### VFX Performance Audit Checklist
```markdown
## VFX Effect Review: [Effect Name]

**Platform Target**: [ ] PC  [ ] Console  [ ] Mobile

Particle Count
- [ ] Max particles measured in worst-case scenario: ___
- [ ] Within budget for target platform: ___

Overdraw
- [ ] Overdraw visualizer checked — layers: ___
- [ ] Within limit (mobile ≤ 3, PC ≤ 6): ___

Shader Complexity
- [ ] Shader complexity map checked (green/yellow OK, red = revise)
- [ ] Mobile: no per-pixel lighting on particles

Texture
- [ ] Particle textures in shared atlas: Y/N
- [ ] Texture size: ___ (max 256×256 per particle type on mobile)

GPU Cost
- [ ] Profiled with engine GPU profiler at worst-case density
- [ ] Frame time contribution: ___ms (budget: ___ms)
```

### LOD Chain Validation Script (Python — DCC agnostic)
```python
# Validates LOD chain poly counts against project budget
LOD_BUDGETS = {
    "character": [15000, 8000, 3000, 800],
    "hero_prop":  [4000, 1500, 400],
    "small_prop": [500, 200],
}

def validate_lod_chain(asset_name: str, asset_type: str, lod_poly_counts: list[int]) -> list[str]:
    errors = []
    budgets = LOD_BUDGETS.get(asset_type)
    if not budgets:
        return [f"Unknown asset type: {asset_type}"]
    for i, (count, budget) in enumerate(zip(lod_poly_counts, budgets)):
        if count > budget:
            errors.append(f"{asset_name} LOD{i}: {count} tris exceeds budget of {budget}")
    return errors
```