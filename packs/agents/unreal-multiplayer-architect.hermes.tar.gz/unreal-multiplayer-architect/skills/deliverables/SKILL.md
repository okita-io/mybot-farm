---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Replicated Actor Setup
```cpp
// AMyNetworkedActor.h
UCLASS()
class MYGAME_API AMyNetworkedActor : public AActor
{
    GENERATED_BODY()

public:
    AMyNetworkedActor();
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

    // Replicated to all — with RepNotify for client reaction
    UPROPERTY(ReplicatedUsing=OnRep_Health)
    float Health = 100.f;

    // Replicated to owner only — private state
    UPROPERTY(Replicated)
    int32 PrivateInventoryCount = 0;

    UFUNCTION()
    void OnRep_Health();

    // Server RPC with validation
    UFUNCTION(Server, Reliable, WithValidation)
    void ServerRequestInteract(AActor* Target);
    bool ServerRequestInteract_Validate(AActor* Target);
    void ServerRequestInteract_Implementation(AActor* Target);

    // Multicast for cosmetic effects
    UFUNCTION(NetMulticast, Unreliable)
    void MulticastPlayHitEffect(FVector HitLocation);
    void MulticastPlayHitEffect_Implementation(FVector HitLocation);
};

// AMyNetworkedActor.cpp
void AMyNetworkedActor::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);
    DOREPLIFETIME(AMyNetworkedActor, Health);
    DOREPLIFETIME_CONDITION(AMyNetworkedActor, PrivateInventoryCount, COND_OwnerOnly);
}
# … truncated for farm planting — see upstream for the full sample
```

### GameMode / GameState Architecture
```cpp
// AMyGameMode.h — Server only, never replicated
UCLASS()
class MYGAME_API AMyGameMode : public AGameModeBase
{
    GENERATED_BODY()
public:
    virtual void PostLogin(APlayerController* NewPlayer) override;
    virtual void Logout(AController* Exiting) override;
    void OnPlayerDied(APlayerController* DeadPlayer);
    bool CheckWinCondition();
};

// AMyGameState.h — Replicated to all clients
UCLASS()
class MYGAME_API AMyGameState : public AGameStateBase
{
    GENERATED_BODY()
public:
    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

    UPROPERTY(Replicated)
    int32 TeamAScore = 0;

    UPROPERTY(Replicated)
    float RoundTimeRemaining = 300.f;

    UPROPERTY(ReplicatedUsing=OnRep_GamePhase)
    EGamePhase CurrentPhase = EGamePhase::Warmup;

    UFUNCTION()
    void OnRep_GamePhase();
};

// AMyPlayerState.h — Replicated to all clients
UCLASS()
class MYGAME_API AMyPlayerState : public APlayerState
{
    GENERATED_BODY()
public:
    UPROPERTY(Replicated) int32 Kills = 0;
# … truncated for farm planting — see upstream for the full sample
```

### GAS Replication Setup
```cpp
// In Character header — AbilitySystemComponent must be set up correctly for replication
UCLASS()
class MYGAME_API AMyCharacter : public ACharacter, public IAbilitySystemInterface
{
    GENERATED_BODY()

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="GAS")
    UAbilitySystemComponent* AbilitySystemComponent;

    UPROPERTY()
    UMyAttributeSet* AttributeSet;

public:
    virtual UAbilitySystemComponent* GetAbilitySystemComponent() const override
    { return AbilitySystemComponent; }

    virtual void PossessedBy(AController* NewController) override;  // Server: init GAS
    virtual void OnRep_PlayerState() override;                       // Client: init GAS
};

// In .cpp — dual init path required for client/server
void AMyCharacter::PossessedBy(AController* NewController)
{
    Super::PossessedBy(NewController);
    // Server path
    AbilitySystemComponent->InitAbilityActorInfo(GetPlayerState(), this);
    AttributeSet = Cast<UMyAttributeSet>(AbilitySystemComponent->GetOrSpawnAttributes(UMyAttributeSet::StaticClass(), 1)[0]);
}

void AMyCharacter::OnRep_PlayerState()
{
    Super::OnRep_PlayerState();
    // Client path — PlayerState arrives via replication
    AbilitySystemComponent->InitAbilityActorInfo(GetPlayerState(), this);
}
```

### Network Frequency Optimization
```cpp
// Set replication frequency per actor class in constructor
AMyProjectile::AMyProjectile()
{
    bReplicates = true;
    NetUpdateFrequency = 100.f; // High — fast-moving, accuracy critical
    MinNetUpdateFrequency = 33.f;
}

AMyNPCEnemy::AMyNPCEnemy()
{
    bReplicates = true;
    NetUpdateFrequency = 20.f;  // Lower — non-player, position interpolated
    MinNetUpdateFrequency = 5.f;
}

AMyEnvironmentActor::AMyEnvironmentActor()
{
    bReplicates = true;
    NetUpdateFrequency = 2.f;   // Very low — state rarely changes
    bOnlyRelevantToOwner = false;
}
```…