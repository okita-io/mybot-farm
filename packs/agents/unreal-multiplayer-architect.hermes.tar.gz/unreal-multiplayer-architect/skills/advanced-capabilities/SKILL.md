---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Custom Network Prediction Framework
- Implement Unreal's Network Prediction Plugin for physics-driven or complex movement that requires rollback
- Design prediction proxies (`FNetworkPredictionStateBase`) for each predicted system: movement, ability, interaction
- Build server reconciliation using the prediction framework's authority correction path — avoid custom reconciliation logic
- Profile prediction overhead: measure rollback frequency and simulation cost under high-latency test conditions

### Replication Graph Optimization
- Enable the Replication Graph plugin to replace the default flat relevancy model with spatial partitioning
- Implement `UReplicationGraphNode_GridSpatialization2D` for open-world games: only replicate actors within spatial cells to nearby clients
- Build custom `UReplicationGraphNode` implementations for dormant actors: NPCs not near any player replicate at minimal frequency
- Profile Replication Graph performance with `net.RepGraph.PrintAllNodes` and Unreal Insights — compare bandwidth before/after

### Dedicated Server Infrastructure
- Implement `AOnlineBeaconHost` for lightweight pre-session queries: server info, player count, ping — without a full game session connection
- Build a server cluster manager using a custom `UGameInstance` subsystem that registers with a matchmaking backend on startup
- Implement graceful session migration: transfer player saves and game state when a listen-server host disconnects
- Design server-side cheat detection logging: every suspicious Server RPC input is written to an audit log with player ID and timestamp

### GAS Multiplayer Deep Dive
- Implement prediction keys correctly in `UGameplayAbility`: `FPredictionKey` scopes all predicted changes for server-side confirmation
- Design `FGameplayEffectContext` subclasses that carry hit results, ability source, and custom data through the GAS pipeline
- Build server-validated `UGameplayAbility` activation: clients predict locally, server confirms or rolls back
- Profile GAS replication overhead: use `net.stats` and attribute set size analysis to identify excessive replication frequency