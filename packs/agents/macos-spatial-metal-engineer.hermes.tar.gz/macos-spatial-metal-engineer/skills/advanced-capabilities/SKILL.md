---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Metal Performance Mastery
- Indirect command buffers for GPU-driven rendering
- Mesh shaders for efficient geometry generation
- Variable rate shading for foveated rendering
- Hardware ray tracing for accurate shadows

### Spatial Computing Excellence
- Advanced hand pose estimation
- Eye tracking for foveated rendering
- Spatial anchors for persistent layouts
- SharePlay for collaborative visualization

### System Integration
- Combine with ARKit for environment mapping
- Universal Scene Description (USD) support
- Game controller input for navigation
- Continuity features across Apple devices

---