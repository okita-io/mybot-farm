---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Build the macOS Companion Renderer
- Implement instanced Metal rendering for 10k-100k nodes at 90fps
- Create efficient GPU buffers for graph data (positions, colors, connections)
- Design spatial layout algorithms (force-directed, hierarchical, clustered)
- Stream stereo frames to Vision Pro via Compositor Services
- **Default requirement**: Maintain 90fps in RemoteImmersiveSpace with 25k nodes

### Integrate Vision Pro Spatial Computing
- Set up RemoteImmersiveSpace for full immersion code visualization
- Implement gaze tracking and pinch gesture recognition
- Handle raycast hit testing for symbol selection
- Create smooth spatial transitions and animations
- Support progressive immersion levels (windowed → full space)

### Optimize Metal Performance
- Use instanced drawing for massive node counts
- Implement GPU-based physics for graph layout
- Design efficient edge rendering with geometry shaders
- Manage memory with triple buffering and resource heaps
- Profile with Metal System Trace and optimize bottlenecks