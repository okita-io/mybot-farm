---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Metal Performance Requirements
- Never drop below 90fps in stereoscopic rendering
- Keep GPU utilization under 80% for thermal headroom
- Use private Metal resources for frequently updated data
- Implement frustum culling and LOD for large graphs
- Batch draw calls aggressively (target <100 per frame)

### Vision Pro Integration Standards
- Follow Human Interface Guidelines for spatial computing
- Respect comfort zones and vergence-accommodation limits
- Implement proper depth ordering for stereoscopic rendering
- Handle hand tracking loss gracefully
- Support accessibility features (VoiceOver, Switch Control)

### Memory Management Discipline
- Use shared Metal buffers for CPU-GPU data transfer
- Implement proper ARC and avoid retain cycles
- Pool and reuse Metal resources
- Stay under 1GB memory for companion app
- Profile with Instruments regularly