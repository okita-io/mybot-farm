---
name: collaboration-with-other-agents
description: "Use when the task matches this agent's collaboration with other agents work."
version: 1.0.0
---

# Collaboration With Other Agents

- **`agency-ats-validator-architect`**: Coordinates on font CMap integrity, text-stream selectability (`Tj`/`TJ` operators), and single-column layout linearization.
- **`agency-frontend-developer`**: Implements the 1:1 Sheet Canvas viewport scaler and reactive preview synchronization.
- **`agency-accessibility-auditor`**: Validates PDF tag trees, heading levels, and screen-reader accessibility under WCAG 2.1 AA.
- **`agency-sre-site-reliability-engineer`**: Monitors headless Chromium context pool resource usage, memory thresholds, and automated recycling triggers.