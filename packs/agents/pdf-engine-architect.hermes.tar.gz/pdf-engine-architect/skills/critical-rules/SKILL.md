---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. Zero Dual-Template Divergence
Never generate PDF HTML by concatenating raw template strings in a parallel backend codebase. Always snapshot the live, hydrated DOM tree of the active UI preview. If a visual component changes in the web app, the exported PDF must automatically reflect that change identically.

### 2. Vector Preservation in Skia (Anti-Rasterization)
In `@media print` and snapshot stylesheets, enforce:
```css
* {
  filter: none !important;
  backdrop-filter: none !important;
}
```
Any elevation or card separation must use zero-blur `box-shadow: 0 1pt 0 rgba(0,0,0,0.1)` or solid borders. Any use of `filter: drop-shadow()` trips Skia's `not_supported_for_layers()`, forcing `SkPDFDevice` to downgrade vector pages to 72 DPI bitmaps.

### 3. LayoutUnit Subpixel Epsilon Buffering
Blink's LayoutNG calculates layout geometry using 24.6 fixed-point arithmetic (`LayoutUnit`, where $1\text{px} = 64\text{ raw units}$ / $0.015625\text{px}$ per unit). Cumulative floating-point rounding errors on borders and line-heights cause content with mathematical height $= H_{\text{page}}$ to overflow by a fraction of a pixel, spawning a phantom trailing blank page.
Always apply epsilon clipping to the sheet page container:
```css
.sheet-page-container {
  height: calc(100% - 0.5px);
  overflow: hidden;
}
```

### 4. Offscreen Real-DOM Sandbox Isolation
When executing binary search spatial budgeting (font and gap scaling), measure DOM dimensions strictly inside an offscreen sandbox attached to `document.body`:
```css
.spatial-budget-sandbox {
  contain: layout style size !important;
  position: fixed !important;
  top: -10000px !important;
  left: -10000px !important;
  pointer-events: none !important;
  visibility: hidden !important;
}
```
Never measure unattached DOM clones (which lack computed styles) or manipulate the live UI DOM (which triggers massive layout thrashing).

### 5. Strict Headless Automation & Font Synchronization
Deprecate `window.print()` in automated generation pipelines. Automated compilation must use Playwright's `page.pdf()` or direct CDP `Page.printToPDF`. Always verify font availability before capturing the document:
```typescript
await page.evaluate(() => document.fonts.ready);
```

### 6. Dynamic Euclidean Page Sizing (No CSS Variables in `@page`)
Blink LayoutNG does not support CSS variables inside `@page` rules (e.g., `@page { size: var(--cv-page-width) ... }` is invalid and silently ignored). Runtime paper dimensions must be dynamically injected into a dedicated `<style id="runtime-page-geometry">` element:
```css
@page {
  size: 210mm 297mm;
  margin: 0;
}
```

### 7. 1:1 WYSIWYG Geometric Invariance & True Sheet Canvas
The editor or preview canvas must never fluidly expand or contract with the browser viewport. The document DOM maintains immutable physical Euclidean dimensions (`width: 210mm`, etc.). Responsive adaptation to smaller viewports is achieved strictly via optical zoom (`transform: scale(zoomRatio); transform-origin: top center;`). This guarantees that word wraps, line breaks, and whitespace distribution are 100% identical between editor and printed PDF.

### 8. Enterprise Security & Input Sanitization
- Strip all `<script>`, `<iframe>`, `<object>`, `<embed>`, and inline event attributes (`onload`, `onerror`, `onclick`) from DOM snapshots.
- Asset inlining (`urlToBase64`) must validate `https:` protocols and enforce strict same-origin or domain whitelists to prevent Server-Side Request Forgery (SSRF).
- Numerical bisection solvers must enforce bounded loop iterations (`maxIterations: 10`) to eliminate Denial of Service (DoS) risks.

### 9. Tagged Semantic Document Architecture (PDF/UA-1)
Every document compiled for human consumption or ATS ingestion must emit tagged PDF structures (`generateTaggedPDF: true`). All headings must map to semantic HTML tags (`<h1>`–`<h6>`), bullet lists to `<ul>`/`<li>`, tables must declare `<thead>` and `<th scope="col">`, and all images must provide descriptive `alt` attributes.