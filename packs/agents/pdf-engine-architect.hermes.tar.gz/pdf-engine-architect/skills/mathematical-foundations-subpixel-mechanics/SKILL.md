---
name: mathematical-foundations-subpixel-mechanics
description: "Use when the task matches this agent's mathematical foundations & subpixel mechanics work."
version: 1.0.0
---

# Mathematical Foundations & Subpixel Mechanics

1. Dimension Conversion Formulas

Document engines must operate seamlessly across 4 coordinate spaces:

$$\text{Points (pt)} = \frac{\text{Millimeters (mm)} \times 72}{25.4}$$

$$\text{CSS Pixels (px at 96 DPI)} = \frac{\text{Millimeters (mm)} \times 96}{25.4} = \text{Points (pt)} \times \frac{96}{72}$$

| Paper Format | Width (mm) | Height (mm) | Width (pt) | Height (pt) | Width (px at 96 DPI) | Height (px at 96 DPI) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **ISO A4** | 210.00 | 297.00 | 595.28 | 841.89 | 793.70 | 1122.52 |
| **ISO A3** | 297.00 | 420.00 | 841.89 | 1190.55 | 1122.52 | 1587.40 |
| **ISO A5** | 148.00 | 210.00 | 419.53 | 595.28 | 559.37 | 793.70 |
| **US Letter** | 215.90 | 279.40 | 612.00 | 792.00 | 816.00 | 1056.00 |
| **US Legal** | 215.90 | 355.60 | 612.00 | 1008.00 | 816.00 | 1344.00 |
| **Tabloid (11x17)** | 279.40 | 431.80 | 792.00 | 1224.00 | 1056.00 | 1632.00 |

### 2. LayoutUnit Quantization Drift

Chromium represents layout coordinates using the `LayoutUnit` class, storing values as 32-bit signed integers where $1\text{px} = 64\text{ raw units}$ ($0.015625\text{px}$ per unit). When calculating line boxes, fractional font metrics, and border-box paddings, cumulative rounding errors accumulate:

$$\Delta_{\text{drift}} = \sum_{i=1}^{N} \left( \text{actual\_height}_i - \frac{\lfloor \text{actual\_height}_i \times 64 \rfloor}{64} \right)$$

For a document with 100 elements, $\Delta_{\text{drift}}$ can easily reach $0.2\text{px}$–$0.8\text{px}$. If total height is $1122.52\text{px}$ and page height is $1122.52\text{px}$, an extra $0.2\text{px}$ triggers Blink to generate Page 2 with a single empty line.
**Remediation**: Set sheet container height to $H_{\text{page}} - \epsilon$ (where $\epsilon = 0.5\text{px}$ to $1.0\text{px}$).