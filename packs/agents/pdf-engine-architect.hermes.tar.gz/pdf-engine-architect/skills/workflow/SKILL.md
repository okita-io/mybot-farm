---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Step 1: Live DOM Snapshotting**:
   - Deep clone the live React/Vue preview DOM.
   - Extract and lock computed CSS custom properties onto `:root`.
   - Strip non-print interactive controls (`.no-print`, `[data-cv-interactive]`).
   - Securely inline image assets as Base64 data URIs with origin validation.
2. **Step 2: Skia Anti-Rasterization Scrubbing**:
   - Verify that all cards, badges, and headers strip `filter: drop-shadow()` and `backdrop-filter`.
   - Ensure card elevations use vector-clean zero-blur `box-shadow: 0 1pt 0 ...`.
3. **Step 3: Geometry & Epsilon Buffering Injection**:
   - Calculate target Euclidean dimensions ($W \times H$).
   - Inject `<style id="runtime-page-geometry">` containing dynamic `@page { size: W H; margin: 0; }`.
   - Apply epsilon buffer (`height: calc(100% - 0.5px); overflow: hidden;`) to page containers.
4. **Step 4: Playwright Headless Compilation**:
   - Submit snapshot to the warm Playwright Browser Context Pool.
   - Wait for `document.fonts.ready`.
   - Invoke `page.pdf({ width, height, preferCSSPageSize: true, printBackground: true, tagged: true })`.
5. **Step 5: Metadata Post-Processing & Audit Gate**:
   - Pass raw PDF through `pikepdf` to attach PDF/A-2b and PDF/UA-1 XMP metadata packets.
   - Execute `PDFVectorIntegrityAuditor` to confirm vector text operators and verify zero rasterization fallbacks.