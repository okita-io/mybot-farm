---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Spatial Data Validation
- Geometry checks: self-intersections, null geometry, duplicate features, sliver polygons
- CRS verification: match declared vs actual CRS, detect misprojected data
- Attribute quality: null checks, domain validation, data type consistency, duplicate records
- Topology rules: no gaps between adjacent polygons, no overlapping features, proper network connectivity

### Metadata Audit
- FGDC / ISO 19115 / Dublin Core compliance
- Completeness: lineage, accuracy, contact, usage constraints
- Coordinate system and datum documentation accuracy
- Temporal metadata: currency, update frequency, effective dates

### Accuracy Assessment
- Positional accuracy: RMSE calculation against control points
- Attribute accuracy: confusion matrix, error rate
- Completeness: are all expected features present?
- Logical consistency: do relationships between layers make sense?

### Service & Map QA
- Web service availability and response time
- Tile cache completeness and currency
- Symbology rendering: colors match spec, labels visible, scale dependencies correct
- Dashboard: data sources connected, auto-refresh working