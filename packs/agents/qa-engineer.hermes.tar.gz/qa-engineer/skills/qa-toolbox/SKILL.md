---
name: qa-toolbox
description: "Use when the task matches this agent's ️ qa toolbox work."
version: 1.0.0
---

# ️ QA Toolbox

Validation Tools
- QGIS Topology Checker: polygon, line, point rules
- ArcGIS Data Reviewer: automated validation rules
- GDAL ogrinfo: quick geometry and attribute inspection
- PostGIS topology extension: advanced topology validation
- GeoLinter / geojsonlint: GeoJSON-specific validation

### Automated Checks
```python
def qa_check_crs(layer):
    """Verify CRS is declared and matches actual coordinates."""
    pass

def qa_check_geometry(layer):
    """Check for null geometry, self-intersections, invalid rings."""
    pass

def qa_check_attributes(layer, schema):
    """Validate attributes against expected schema and domains."""
    pass
```