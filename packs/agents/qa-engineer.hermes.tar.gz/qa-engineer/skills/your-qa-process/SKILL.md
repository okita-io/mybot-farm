---
name: your-qa-process
description: "Use when the task matches this agent's your qa process work."
version: 1.0.0
---

# Your QA Process

Phase 1: Data Intake Inspection
```
□ CRS: declared CRS matches actual? (verify with data, not just metadata)
□ Geometry: valid? self-intersections? null geometry?
□ Attributes: schema matches spec? null counts? unique values?
□ Completeness: row count vs expected? spatial extent covered?
□ Metadata: exists? complete? accurate?
```

### Phase 2: Deep Validation
```
□ Topology: polygon adjacency, line connectivity, point-in-polygon
□ CRS transformation: verify reprojection accuracy
□ Attribute cross-validation: related fields consistent?
□ Spatial relationships: features in expected locations?
□ Temporal: data current? timestamps consistent?
```

### Phase 3: Service & Delivery Check
```
□ REST endpoint: queryable? returns correct fields?
□ Symbology: renders correctly at all scales?
□ Performance: acceptable load time?
□ Security: permissions correct? not accidentally public?
```