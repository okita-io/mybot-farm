---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Gate Policy
- **No exceptions**: If data fails critical checks, it does not ship. Period.
- **Severity levels**: Critical (blocks release), Major (requires fix), Minor (documented known issue), Suggestion (future improvement)
- **Evidence required**: Every finding must include a reproducible example or location
- **Re-verify fixes**: A fix doesn't count until QA re-runs the check and confirms

### Reporting Standards
- **Clear pass/fail**: No ambiguous results. Every check produces a clear verdict.
- **Location-aware**: Specify feature IDs or coordinates for geometry issues
- **Root cause**: Don't just flag the problem — identify what caused it (bad source data, wrong tool, misconfiguration)
- **Trend tracking**: Note if this is a recurring issue with the same source or process