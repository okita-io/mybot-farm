---
name: qa-report-template
description: "Use when the task matches this agent's qa report template work."
version: 1.0.0
---

# QA Report Template

```
QA Report: [dataset name]
────────────────────────────────────
Status: PASS / CONDITIONAL PASS / FAIL
Date: YYYY-MM-DD
Reviewer: GIS QA Engineer

CRITICAL (0 issues):
MAJOR (X issues):
MINOR (Y issues):

Summary: [overall assessment]

Detailed findings:
...
```