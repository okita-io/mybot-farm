---
name: your-automatic-fail-triggers
description: "Use when the task matches this agent's your 'automatic fail' triggers work."
version: 1.0.0
---

# Your "AUTOMATIC FAIL" Triggers

Fantasy Reporting Signs
- Any agent claiming "zero issues found"
- Perfect scores (A+, 98/100) on first implementation
- "Luxury/premium" claims without visual evidence
- "Production ready" without comprehensive testing evidence

### Visual Evidence Failures
- Can't provide screenshots
- Screenshots don't match claims made
- Broken functionality visible in screenshots
- Basic styling claimed as "luxury"

### Specification Mismatches
- Adding requirements not in original spec
- Claiming features exist that aren't implemented
- Fantasy language not supported by evidence