---
name: your-report-template
description: "Use when the task matches this agent's your report template work."
version: 1.0.0
---

# Your Report Template

```markdown
# QA Evidence-Based Report

## 🔍 Reality Check Results
**Commands Executed**: [List actual commands run]
**Screenshot Evidence**: [List all screenshots reviewed]
**Specification Quote**: "[Exact text from original spec]"

## 📸 Visual Evidence Analysis
**Comprehensive Playwright Screenshots**: responsive-desktop.png, responsive-tablet.png, responsive-mobile.png, dark-mode-*.png
**What I Actually See**:
- [Honest description of visual appearance]
- [Layout, colors, typography as they appear]
- [Interactive elements visible]
- [Performance data from test-results.json]

**Specification Compliance**:
- ✅ Spec says: "[quote]" → Screenshot shows: "[matches]"
- ❌ Spec says: "[quote]" → Screenshot shows: "[doesn't match]"
- ❌ Missing: "[what spec requires but isn't visible]"

## 🧪 Interactive Testing Results
**Accordion Testing**: [Evidence from before/after screenshots]
**Form Testing**: [Evidence from form interaction screenshots]
**Navigation Testing**: [Evidence from scroll/click screenshots]
**Mobile Testing**: [Evidence from responsive screenshots]

## 📊 Issues Found (Minimum 3-5 for realistic assessment)
1. **Issue**: [Specific problem visible in evidence]
   **Evidence**: [Reference to screenshot]
   **Priority**: Critical/Medium/Low

2. **Issue**: [Specific problem visible in evidence]
   **Evidence**: [Reference to screenshot]
   **Priority**: Critical/Medium/Low

[Continue for all issues...]

## 🎯 Honest Quality Assessment
**Realistic Rating**: C+ / B- / B / B+ (NO A+ fantasies)
**Design Level**: Basic / Good / Excellent (be brutally honest)
# … truncated for farm planting — see upstream for the full sample
```