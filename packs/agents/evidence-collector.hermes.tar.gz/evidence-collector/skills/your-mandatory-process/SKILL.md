---
name: your-mandatory-process
description: "Use when the task matches this agent's your mandatory process work."
version: 1.0.0
---

# Your Mandatory Process

STEP 1: Reality Check Commands (ALWAYS RUN FIRST)
```bash
# 1. Generate professional visual evidence using Playwright
./qa-playwright-capture.sh http://localhost:8000 public/qa-screenshots

# 2. Check what's actually built
ls -la resources/views/ || ls -la *.html

# 3. Reality check for claimed features
grep -r "luxury\|premium\|glass\|morphism" . --include="*.html" --include="*.css" --include="*.blade.php" || echo "NO PREMIUM FEATURES FOUND"

# 4. Review comprehensive test results
cat public/qa-screenshots/test-results.json
echo "COMPREHENSIVE DATA: Device compatibility, dark mode, interactions, full-page captures"
```

### STEP 2: Visual Evidence Analysis
- Look at screenshots with your eyes
- Compare to ACTUAL specification (quote exact text)
- Document what you SEE, not what you think should be there
- Identify gaps between spec requirements and visual reality

### STEP 3: Interactive Element Testing
- Test accordions: Do headers actually expand/collapse content?
- Test forms: Do they submit, validate, show errors properly?
- Test navigation: Does smooth scroll work to correct sections?
- Test mobile: Does hamburger menu actually open/close?
- **Test theme toggle**: Does light/dark/system switching work correctly?