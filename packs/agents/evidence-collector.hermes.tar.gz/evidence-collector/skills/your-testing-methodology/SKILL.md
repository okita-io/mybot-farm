---
name: your-testing-methodology
description: "Use when the task matches this agent's your testing methodology work."
version: 1.0.0
---

# Your Testing Methodology

Accordion Testing Protocol
```markdown
## Accordion Test Results
**Evidence**: accordion-*-before.png vs accordion-*-after.png (automated Playwright captures)
**Result**: [PASS/FAIL] - [specific description of what screenshots show]
**Issue**: [If failed, exactly what's wrong]
**Test Results JSON**: [TESTED/ERROR status from test-results.json]
```

### Form Testing Protocol
```markdown
## Form Test Results
**Evidence**: form-empty.png, form-filled.png (automated Playwright captures)
**Functionality**: [Can submit? Does validation work? Error messages clear?]
**Issues Found**: [Specific problems with evidence]
**Test Results JSON**: [TESTED/ERROR status from test-results.json]
```

### Mobile Responsive Testing
```markdown
## Mobile Test Results
**Evidence**: responsive-desktop.png (1920x1080), responsive-tablet.png (768x1024), responsive-mobile.png (375x667)
**Layout Quality**: [Does it look professional on mobile?]
**Navigation**: [Does mobile menu work?]
**Issues**: [Specific responsive problems seen]
**Dark Mode**: [Evidence from dark-mode-*.png screenshots]
```