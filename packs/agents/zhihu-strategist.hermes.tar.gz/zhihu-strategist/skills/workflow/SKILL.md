---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Phase 1: Topic & Expertise Positioning
1. **Topic Authority Assessment**: Identify 3-5 core topics where business has genuine expertise
2. **Topic Research**: Analyze existing expert answers, question trends, audience expectations
3. **Brand Positioning Strategy**: Define unique angle, perspective, or value add vs. existing experts
4. **Competitive Analysis**: Research competitor authority positions and identify differentiation gaps

### Phase 2: Question Identification & Answer Strategy
1. **Question Source Identification**: Identify high-value questions through search, trending topics, followers
2. **Impact Criteria Definition**: Determine which questions align with business goals (lead gen, authority, engagement)
3. **Answer Structure Development**: Create templates for comprehensive, persuasive answers
4. **CTA Strategy**: Design subtle, valuable CTAs that drive website visits or lead capture (never hard sell)

### Phase 3: High-Impact Content Creation
1. **Answer Research & Writing**: Comprehensive answer development with data, examples, formatting
2. **Visual Enhancement**: Include relevant images, screenshots, tables, infographics for clarity
3. **Internal SEO Optimization**: Strategic keyword placement, heading structure, bold text for readability
4. **Credibility Signals**: Include credentials, experience, case studies, or data sources that establish authority
5. **Engagement Encouragement**: Design answers that prompt discussion and follow-up questions

### Phase 4: Column Development & Authority Building
1. **Column Strategy**: Define unique column topic that builds ongoing thought leadership
2. **Content Series Planning**: 6-month rolling content calendar with themes and publishing schedule
3. **Column Launch**: Strategic promotion to build initial subscriber base
4. **Consistent Publishing**: Regular publication schedule (typically 1-2 per week) to maintain subscriber engagement
5. **Subscriber Nurturing**: Engage column subscribers through comments and follow-up discussions

### Phase 5: Relationship Building & Amplification
1. **Expert Relationship Building**: Build connections with other Zhihu experts and opinion leaders
2. **Collaboration Opportunities**: Co-answer questions, cross-promote content, guest columns
3. **Live & Events**: Leverage Zhihu Live for deeper engagement with most interested followers
4. **Books Feature**: Compile best answers into published "Books" for additional authority signal
5. **Community Leadership**: Participate in discussions, moderate topics, build community presence

### Phase 6: Performance Analysis & Optimization
1. **Monthly Performance Review**: Analyze upvote trends, visibility, engagement patterns
2. **Question Selection Refinement**: Identify which topics/questions drive best business results
3. **Content Optimization**: Analyze top-performing answers and replicate success patterns
4. **Lead Quality Tracking**: Monitor which content sources qualified leads and business impact
5. **Strategy Evolution**: Adjust focus topics, column content, and engagement strategies based on data