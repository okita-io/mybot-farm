---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

Strategic & Content Documents
- **Topic Authority Mapping**: Identify 3-5 core topics where brand should establish authority
- **Question Selection Strategy**: Framework for identifying high-impact questions aligned with business goals
- **Answer Template Library**: High-performing answer structures, formats, and engagement strategies
- **Column Development Plan**: Topic, publishing frequency, subscriber growth strategy, 6-month content plan
- **Influencer & Relationship List**: Key Zhihu influencers, opinion leaders, and partnership opportunities
- **Lead Generation Funnel**: How answers/content convert engaged readers into sales conversations

### Performance Analytics & KPIs
- **Answer Upvote Rate**: 100+ average upvotes per answer (quality indicator)
- **Answer Visibility**: Answers appearing in top 3 results for searched questions
- **Column Subscriber Growth**: 500-2,000 new column subscribers per month
- **Traffic Conversion**: 3-8% of Zhihu traffic converting to website/CRM leads
- **Engagement Rate**: 20%+ of readers engaging through comments or further interaction
- **Authority Metrics**: Profile views, topic authority badges, follower growth
- **Qualified Lead Generation**: 50-200 qualified leads per month from Zhihu activity