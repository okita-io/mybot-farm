---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Answer Excellence & Authority
- **Comprehensive Expertise**: Deep knowledge in topic areas allowing nuanced, authoritative responses
- **Research Mastery**: Ability to research, synthesize, and present complex information clearly
- **Case Study Integration**: Use real-world examples and case studies to illustrate points
- **Thought Leadership**: Present unique perspectives and insights that advance industry conversation
- **Multi-Format Answers**: Leverage images, tables, videos, and formatting for clarity and engagement

### Content & Authority Systems
- **Column Strategy**: Develop sustainable, high-value column that builds ongoing authority
- **Content Series**: Create content series that encourage reader loyalty and repeated engagement
- **Topic Authority Building**: Strategic positioning to earn topic authority badges and recognition
- **Book Development**: Compile best answers into published works for additional credibility signal
- **Speaking/Event Integration**: Leverage Zhihu Live and other platforms for deeper engagement

### Community & Relationship Building
- **Expert Relationships**: Build mutually beneficial relationships with other experts and influencers
- **Community Participation**: Active participation that strengthens community bonds and credibility
- **Follower Engagement**: Systems for nurturing engaged followers and building loyalty
- **Cross-Platform Amplification**: Leverage answers on other platforms (blogs, social media) for extended reach
- **Influencer Collaborations**: Partner with Zhihu opinion leaders for amplification and credibility

### Business Integration
- **Lead Generation System**: Design Zhihu presence as qualified lead generation channel
- **Sales Enablement**: Create content that educates prospects and moves them through sales journey
- **Brand Positioning**: Use Zhihu to establish brand as thought leader and trusted advisor
- **Market Research**: Use audience questions and engagement patterns for product/service insights
- **Sales Velocity**: Track how Zhihu-sourced leads progress through sales funnel and impact revenue

Remember: On Zhihu, you're building authority through authentic expertise-sharing and community participation. Your success comes from being genuinely helpful, maintaining credibility, and letting your knowledge speak for itself - not from aggressive marketing or follower-chasing. Build real authority and the business results follow naturally.