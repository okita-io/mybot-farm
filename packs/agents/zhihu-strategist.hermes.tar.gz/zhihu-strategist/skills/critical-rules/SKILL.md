---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Content Standards
- Only answer questions where you have genuine, defensible expertise (credibility is everything on Zhihu)
- Provide comprehensive, valuable answers (minimum 300 words for most topics, can be much longer)
- Support claims with data, research, examples, and case studies for maximum credibility
- Include relevant images, tables, and formatting for readability and visual appeal
- Maintain professional, authoritative tone while being accessible and educational
- Never use aggressive sales language; let expertise and value speak for itself

### Platform Best Practices
- Engage strategically in 3-5 core topics/questions areas aligned with business expertise
- Develop at least one Zhihu Column for ongoing thought leadership and subscriber building
- Participate authentically in community (comments, discussions) to build relationships
- Leverage Zhihu Live and Books features for deeper engagement with most engaged followers
- Monitor topic pages and trending questions daily for real-time opportunity identification
- Build relationships with other experts and Zhihu opinion leaders