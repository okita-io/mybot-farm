---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

GAS Project Configuration (.Build.cs)
```csharp
public class MyGame : ModuleRules
{
    public MyGame(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(new string[]
        {
            "Core", "CoreUObject", "Engine", "InputCore",
            "GameplayAbilities",   // GAS core
            "GameplayTags",        // Tag system
            "GameplayTasks"        // Async task framework
        });

        PrivateDependencyModuleNames.AddRange(new string[]
        {
            "Slate", "SlateCore"
        });
    }
}
```

### Attribute Set — Health & Stamina
```cpp
UCLASS()
class MYGAME_API UMyAttributeSet : public UAttributeSet
{
    GENERATED_BODY()

public:
    UPROPERTY(BlueprintReadOnly, Category = "Attributes", ReplicatedUsing = OnRep_Health)
    FGameplayAttributeData Health;
    ATTRIBUTE_ACCESSORS(UMyAttributeSet, Health)

    UPROPERTY(BlueprintReadOnly, Category = "Attributes", ReplicatedUsing = OnRep_MaxHealth)
    FGameplayAttributeData MaxHealth;
    ATTRIBUTE_ACCESSORS(UMyAttributeSet, MaxHealth)

    virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
    virtual void PostGameplayEffectExecute(const FGameplayEffectModCallbackData& Data) override;

    UFUNCTION()
    void OnRep_Health(const FGameplayAttributeData& OldHealth);

    UFUNCTION()
    void OnRep_MaxHealth(const FGameplayAttributeData& OldMaxHealth);
};
```

### Gameplay Ability — Blueprint-Exposable
```cpp
UCLASS()
class MYGAME_API UGA_Sprint : public UGameplayAbility
{
    GENERATED_BODY()

public:
    UGA_Sprint();

    virtual void ActivateAbility(const FGameplayAbilitySpecHandle Handle,
        const FGameplayAbilityActorInfo* ActorInfo,
        const FGameplayAbilityActivationInfo ActivationInfo,
        const FGameplayEventData* TriggerEventData) override;

    virtual void EndAbility(const FGameplayAbilitySpecHandle Handle,
        const FGameplayAbilityActorInfo* ActorInfo,
        const FGameplayAbilityActivationInfo ActivationInfo,
        bool bReplicateEndAbility,
        bool bWasCancelled) override;

protected:
    UPROPERTY(EditDefaultsOnly, Category = "Sprint")
    float SprintSpeedMultiplier = 1.5f;

    UPROPERTY(EditDefaultsOnly, Category = "Sprint")
    FGameplayTag SprintingTag;
};
```

### Optimized Tick Architecture
```cpp
// ❌ AVOID: Blueprint tick for per-frame logic
// ✅ CORRECT: C++ tick with configurable rate

AMyEnemy::AMyEnemy()
{
    PrimaryActorTick.bCanEverTick = true;
    PrimaryActorTick.TickInterval = 0.05f; // 20Hz max for AI, not 60+
}

void AMyEnemy::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
    // All per-frame logic in C++ only
    UpdateMovementPrediction(DeltaTime);
}

// Use timers for low-frequency logic
void AMyEnemy::BeginPlay()
{
    Super::BeginPlay();
    GetWorldTimerManager().SetTimer(
        SightCheckTimer, this, &AMyEnemy::CheckLineOfSight, 0.2f, true);
}
```

### Nanite Static Mesh Setup (Editor Validation)
```cpp
// Editor utility to validate Nanite compatibility
#if WITH_EDITOR
void UMyAssetValidator::ValidateNaniteCompatibility(UStaticMesh* Mesh)
{
    if (!Mesh) return;

    // Nanite incompatibility checks
    if (Mesh->bSupportRayTracing && !Mesh->IsNaniteEnabled())
    {
        UE_LOG(LogMyGame, Warning, TEXT("Mesh %s: Enable Nanite for ray tracing efficiency"),
            *Mesh->GetName());
    }

    // Log instance budget reminder for large meshes
    UE_LOG(LogMyGame, Log, TEXT("Nanite instance budget: 16M total scene limit. "
        "Current mesh: %s — plan foliage density accordingly."), *Mesh->GetName());
}
#endif
```

### Smart Pointer Patterns
```cpp
// Non-UObject heap allocation — use TSharedPtr
TSharedPtr<FMyNonUObjectData> DataCache;

// Non-owning UObject reference — use TWeakObjectPtr
TWeakObjectPtr<APlayerController> CachedController;

// Accessing weak pointer safely
void AMyActor::UseController()
{
    if (CachedController.IsValid())
    {
        CachedController->ClientPlayForceFeedback(...);
    }
}

// Checking UObject validity — always use IsValid()
void AMyActor::TryActivate(UMyComponent* Component)
{
    if (!IsValid(Component)) return;  // Handles null AND pending-kill
    Component->Activate();
}
```