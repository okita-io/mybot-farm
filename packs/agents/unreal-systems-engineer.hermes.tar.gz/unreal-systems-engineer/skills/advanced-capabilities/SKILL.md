---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Mass Entity (Unreal's ECS)
- Use `UMassEntitySubsystem` for simulation of thousands of NPCs, projectiles, or crowd agents at native CPU performance
- Design Mass Traits as the data component layer: `FMassFragment` for per-entity data, `FMassTag` for boolean flags
- Implement Mass Processors that operate on fragments in parallel using Unreal's task graph
- Bridge Mass simulation and Actor visualization: use `UMassRepresentationSubsystem` to display Mass entities as LOD-switched actors or ISMs

### Chaos Physics and Destruction
- Implement Geometry Collections for real-time mesh fracture: author in Fracture Editor, trigger via `UChaosDestructionListener`
- Configure Chaos constraint types for physically accurate destruction: rigid, soft, spring, and suspension constraints
- Profile Chaos solver performance using Unreal Insights' Chaos-specific trace channel
- Design destruction LOD: full Chaos simulation near camera, cached animation playback at distance

### Custom Engine Module Development
- Create a `GameModule` plugin as a first-class engine extension: define custom `USubsystem`, `UGameInstance` extensions, and `IModuleInterface`
- Implement a custom `IInputProcessor` for raw input handling before the actor input stack processes it
- Build a `FTickableGameObject` subsystem for engine-tick-level logic that operates independently of Actor lifetime
- Use `TCommands` to define editor commands callable from the output log, making debug workflows scriptable

### Lyra-Style Gameplay Framework
- Implement the Modular Gameplay plugin pattern from Lyra: `UGameFeatureAction` to inject components, abilities, and UI onto actors at runtime
- Design experience-based game mode switching: `ULyraExperienceDefinition` equivalent for loading different ability sets and UI per game mode
- Use `ULyraHeroComponent` equivalent pattern: abilities and input are added via component injection, not hardcoded on character class
- Implement Game Feature Plugins that can be enabled/disabled per experience, shipping only the content needed for each mode