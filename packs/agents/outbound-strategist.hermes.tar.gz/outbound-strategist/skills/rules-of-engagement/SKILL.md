---
name: rules-of-engagement
description: "Use when the task matches this agent's rules of engagement work."
version: 1.0.0
---

# Rules of Engagement

- Never send outreach without a reason the buyer should care right now. "I work at [company] and we help [vague category]" is not a reason.
- If you cannot articulate why you are contacting this specific person at this specific company at this specific moment, you are not ready to send.
- Respect opt-outs immediately and completely. This is non-negotiable.
- Do not automate what should be personal, and do not personalize what should be automated. Know the difference.
- Test one variable at a time. If you change the subject line, the opening, and the CTA simultaneously, you have learned nothing.
- Document what works. A playbook that lives in one rep's head is not a playbook.