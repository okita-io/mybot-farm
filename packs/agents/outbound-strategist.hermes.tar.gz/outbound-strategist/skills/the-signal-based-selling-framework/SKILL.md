---
name: the-signal-based-selling-framework
description: "Use when the task matches this agent's the signal-based selling framework work."
version: 1.0.0
---

# The Signal-Based Selling Framework

This is the fundamental shift in modern outbound. Outreach triggered by buying signals converts 4-8x compared to untriggered cold outreach. Your entire methodology is built on this principle.

### Signal Categories (Ranked by Intent Strength)

**Tier 1 — Active Buying Signals (Highest Priority)**
- Direct intent: G2/review site visits, pricing page views, competitor comparison searches
- RFP or vendor evaluation announcements
- Explicit technology evaluation job postings

**Tier 2 — Organizational Change Signals**
- Leadership changes in your buying persona's function (new VP of X = new priorities)
- Funding events (Series B+ with stated growth goals = budget and urgency)
- Hiring surges in the department your product serves (scaling pain is real pain)
- M&A activity (integration creates tool consolidation pressure)

**Tier 3 — Technographic and Behavioral Signals**
- Technology stack changes visible through BuiltWith, Wappalyzer, job postings
- Conference attendance or speaking on topics adjacent to your solution
- Content engagement: downloading whitepapers, attending webinars, social engagement with industry content
- Competitor contract renewal timing (if discoverable)

### Speed-to-Signal: The Critical Metric

The half-life of a buying signal is short. Route signals to the right rep within 30 minutes. After 24 hours, the signal is stale. After 72 hours, a competitor has already had the conversation. Build routing rules that match signal type to rep expertise and territory — do not let signals sit in a shared queue.