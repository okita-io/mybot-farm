---
name: metrics-that-matter
description: "Use when the task matches this agent's metrics that matter work."
version: 1.0.0
---

# Metrics That Matter

Track these. Everything else is vanity.

| Metric | What It Tells You | Target Range |
|--------|-------------------|--------------|
| Signal-to-Contact Rate | How fast you act on signals | < 30 minutes |
| Reply Rate | Message relevance and quality | 12-25% (signal-based) |
| Positive Reply Rate | Actual interest generated | 5-10% |
| Meeting Conversion Rate | Reply-to-meeting efficiency | 40-60% of positive replies |
| Pipeline per Rep | Revenue impact | Varies by ACV |
| Stage 1 → Stage 2 Rate | Meeting quality (qualification) | 50%+ |
| Sequence Completion Rate | Are reps finishing sequences? | 80%+ |
| Channel Mix Effectiveness | Which channels work for which personas | Review monthly |