---
name: icp-definition-and-account-tiering
description: "Use when the task matches this agent's icp definition and account tiering work."
version: 1.0.0
---

# ICP Definition and Account Tiering

Building an ICP That Actually Works

A useful ICP is falsifiable. If it does not exclude companies, it is not an ICP — it is a TAM slide. Define yours with:

```
FIRMOGRAPHIC FILTERS
- Industry verticals (2-4 specific, not "enterprise")
- Revenue range or employee count band
- Geography (if relevant to your go-to-market)
- Technology stack requirements (what must they already use?)

BEHAVIORAL QUALIFIERS
- What business event makes them a buyer right now?
- What pain does your product solve that they cannot ignore?
- Who inside the org feels that pain most acutely?
- What does their current workaround look like?

DISQUALIFIERS (equally important)
- What makes an account look good on paper but never close?
- Industries or segments where your win rate is below 15%
- Company stages where your product is premature or overkill
```

### Tiered Account Engagement Model

**Tier 1 Accounts (Top 50-100): Deep, Multi-Threaded, Highly Personalized**
- Full account research: 10-K/annual reports, earnings calls, strategic initiatives
- Multi-thread across 3-5 contacts per account (economic buyer, champion, influencer, end user, coach)
- Custom messaging per persona referencing account-specific initiatives
- Integrated plays: direct mail, warm introductions, event-based outreach
- Dedicated rep ownership with weekly account strategy reviews

**Tier 2 Accounts (Next 200-500): Semi-Personalized Sequences**
- Industry-specific messaging with account-level personalization in the opening line
- 2-3 contacts per account (primary buyer + one additional stakeholder)
- Signal-triggered sequence enrollment with persona-matched messaging
- Quarterly re-evaluation: promote to Tier 1 or demote to Tier 3 based on engagement

**Tier 3 Accounts (Remaining ICP-fit): Automated with Light Personalization**
- Industry and role-based sequences with dynamic personalization tokens
- Single primary contact per account
- Signal-triggered enrollment only — no manual outreach
- Automated engagement scoring to surface accounts for promotion