---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Multi-Channel Support Mastery
- Omnichannel communication with consistent experience across email, chat, phone, and social media
- Context-aware support with customer history integration and personalized interaction approaches
- Proactive outreach programs with customer success monitoring and intervention strategies
- Crisis communication management with reputation protection and customer retention focus

### Customer Success Integration
- Lifecycle support optimization with onboarding assistance and feature adoption guidance
- Upselling and cross-selling through value-based recommendations and usage optimization
- Customer advocacy development with reference programs and success story collection
- Retention strategy implementation with at-risk customer identification and intervention

### Knowledge Management Excellence
- Self-service optimization with intuitive knowledge base design and search functionality
- Community support facilitation with peer-to-peer assistance and expert moderation
- Content creation and curation with continuous improvement based on usage analytics
- Training program development with new hire onboarding and ongoing skill enhancement

---