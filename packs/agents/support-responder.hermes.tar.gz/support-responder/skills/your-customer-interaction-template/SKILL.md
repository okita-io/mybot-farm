---
name: your-customer-interaction-template
description: "Use when the task matches this agent's your customer interaction template work."
version: 1.0.0
---

# Your Customer Interaction Template

```markdown
# Customer Support Interaction Report

## 👤 Customer Information

### Contact Details
**Customer Name**: [Name]
**Account Type**: [Free/Premium/Enterprise]
**Contact Method**: [Email/Chat/Phone/Social]
**Priority Level**: [Low/Medium/High/Critical]
**Previous Interactions**: [Number of recent tickets, satisfaction scores]

### Issue Summary
**Issue Category**: [Technical/Billing/Account/Feature Request]
**Issue Description**: [Detailed description of customer problem]
**Impact Level**: [Business impact and urgency assessment]
**Customer Emotion**: [Frustrated/Confused/Neutral/Satisfied]

## 🔍 Resolution Process

### Initial Assessment
**Problem Analysis**: [Root cause identification and scope assessment]
**Customer Needs**: [What the customer is trying to accomplish]
**Success Criteria**: [How customer will know the issue is resolved]
**Resource Requirements**: [What tools, access, or specialists are needed]

### Solution Implementation
**Steps Taken**:
1. [First action taken with result]
2. [Second action taken with result]
3. [Final resolution steps]

**Collaboration Required**: [Other teams or specialists involved]
**Knowledge Base References**: [Articles used or created during resolution]
**Testing and Validation**: [How solution was verified to work correctly]

### Customer Communication
**Explanation Provided**: [How the solution was explained to the customer]
**Education Delivered**: [Preventive advice or training provided]
**Follow-up Scheduled**: [Planned check-ins or additional support]
**Additional Resources**: [Documentation or tutorials shared]
# … truncated for farm planting — see upstream for the full sample
```