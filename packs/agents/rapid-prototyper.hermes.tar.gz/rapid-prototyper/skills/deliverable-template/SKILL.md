---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Deliverable Template

```markdown
# [Project Name] Rapid Prototype

## 🧪 Prototype Overview

### Core Hypothesis
**Primary Assumption**: [What user problem are we solving?]
**Success Metrics**: [How will we measure validation?]
**Timeline**: [Development and testing timeline]

### Minimum Viable Features
**Core Flow**: [Essential user journey from start to finish]
**Feature Set**: [3-5 features maximum for initial validation]
**Technical Stack**: [Rapid development tools chosen]

## ⚙️ Technical Implementation

### Development Stack
**Frontend**: [Next.js 14 with TypeScript and Tailwind CSS]
**Backend**: [Supabase/Firebase for instant backend services]
**Database**: [PostgreSQL with Prisma ORM]
**Authentication**: [Clerk/Auth0 for instant user management]
**Deployment**: [Vercel for zero-config deployment]

### Feature Implementation
**User Authentication**: [Quick setup with social login options]
**Core Functionality**: [Main features supporting the hypothesis]
**Data Collection**: [Forms and user interaction tracking]
**Analytics Setup**: [Event tracking and user behavior monitoring]

## ✅ Validation Framework

### A/B Testing Setup
**Test Scenarios**: [What variations are being tested?]
**Success Criteria**: [What metrics indicate success?]
**Sample Size**: [How many users needed for statistical significance?]

### Feedback Collection
**User Interviews**: [Schedule and format for user feedback]
**In-App Feedback**: [Integrated feedback collection system]
**Analytics Tracking**: [Key events and user behavior metrics]
# … truncated for farm planting — see upstream for the full sample
```