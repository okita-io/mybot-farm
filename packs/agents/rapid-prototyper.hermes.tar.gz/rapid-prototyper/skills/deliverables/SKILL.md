---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Rapid Development Stack Example
```typescript
// Next.js 14 with modern rapid development tools
// package.json - Optimized for speed
{
  "name": "rapid-prototype",
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "db:push": "prisma db push",
    "db:studio": "prisma studio"
  },
  "dependencies": {
    "next": "14.0.0",
    "@prisma/client": "^5.0.0",
    "prisma": "^5.0.0",
    "@supabase/supabase-js": "^2.0.0",
    "@clerk/nextjs": "^4.0.0",
    "shadcn-ui": "latest",
    "@hookform/resolvers": "^3.0.0",
    "react-hook-form": "^7.0.0",
    "zustand": "^4.0.0",
    "framer-motion": "^10.0.0"
  }
}

// Rapid authentication setup with Clerk
import { ClerkProvider } from '@clerk/nextjs';
import { SignIn, SignUp, UserButton } from '@clerk/nextjs';

export default function AuthLayout({ children }) {
  return (
    <ClerkProvider>
      <div className="min-h-screen bg-gray-50">
        <nav className="flex justify-between items-center p-4">
          <h1 className="text-xl font-bold">Prototype App</h1>
          <UserButton afterSignOutUrl="/" />
        </nav>
        {children}
      </div>
    </ClerkProvider>
# … truncated for farm planting — see upstream for the full sample
```

### Rapid UI Development with shadcn/ui
```tsx
// Rapid form creation with react-hook-form + shadcn/ui
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';

const feedbackSchema = z.object({
  content: z.string().min(10, 'Feedback must be at least 10 characters'),
  rating: z.number().min(1).max(5),
  email: z.string().email('Invalid email address'),
});

export function FeedbackForm() {
  const form = useForm({
    resolver: zodResolver(feedbackSchema),
    defaultValues: {
      content: '',
      rating: 5,
      email: '',
    },
  });

  async function onSubmit(values) {
    try {
      const response = await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values),
      });

      if (response.ok) {
        toast({ title: 'Feedback submitted successfully!' });
        form.reset();
      } else {
        throw new Error('Failed to submit feedback');
      }
    } catch (error) {
# … truncated for farm planting — see upstream for the full sample
```

### Instant Analytics and A/B Testing
```typescript
// Simple analytics and A/B testing setup
import { useEffect, useState } from 'react';

// Lightweight analytics helper
export function trackEvent(eventName: string, properties?: Record<string, any>) {
  // Send to multiple analytics providers
  if (typeof window !== 'undefined') {
    // Google Analytics 4
    window.gtag?.('event', eventName, properties);

    // Simple internal tracking
    fetch('/api/analytics', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        event: eventName,
        properties,
        timestamp: Date.now(),
        url: window.location.href,
      }),
    }).catch(() => {}); // Fail silently
  }
}

// Simple A/B testing hook
export function useABTest(testName: string, variants: string[]) {
  const [variant, setVariant] = useState<string>('');

  useEffect(() => {
    // Get or create user ID for consistent experience
    let userId = localStorage.getItem('user_id');
    if (!userId) {
      userId = crypto.randomUUID();
      localStorage.setItem('user_id', userId);
    }

    // Simple hash-based assignment
    const hash = [...userId].reduce((a, b) => {
      a = ((a << 5) - a) + b.charCodeAt(0);
      return a & a;
# … truncated for farm planting — see upstream for the full sample
```