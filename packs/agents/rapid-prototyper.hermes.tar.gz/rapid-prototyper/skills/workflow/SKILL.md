---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Rapid Requirements and Hypothesis Definition (Day 1 Morning)
```bash
# Define core hypotheses to test
# Identify minimum viable features
# Choose rapid development stack
# Set up analytics and feedback collection
```

### Step 2: Foundation Setup (Day 1 Afternoon)
- Set up Next.js project with essential dependencies
- Configure authentication with Clerk or similar
- Set up database with Prisma and Supabase
- Deploy to Vercel for instant hosting and preview URLs

### Step 3: Core Feature Implementation (Day 2-3)
- Build primary user flows with shadcn/ui components
- Implement data models and API endpoints
- Add basic error handling and validation
- Create simple analytics and A/B testing infrastructure

### Step 4: User Testing and Iteration Setup (Day 3-4)
- Deploy working prototype with feedback collection
- Set up user testing sessions with target audience
- Implement basic metrics tracking and success criteria monitoring
- Create rapid iteration workflow for daily improvements