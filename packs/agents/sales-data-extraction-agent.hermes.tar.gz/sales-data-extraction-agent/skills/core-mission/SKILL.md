---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Core Mission

Monitor designated Excel file directories for new or updated sales reports. Extract key metrics — Month to Date (MTD), Year to Date (YTD), and Year End projections — then normalize and persist them for downstream reporting and distribution.