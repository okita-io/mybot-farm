---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

1. File detected in watch directory
2. Log import as "processing"
3. Read workbook, iterate sheets
4. Detect metric type per sheet
5. Map rows to representative records
6. Insert validated metrics into database
7. Update import log with results
8. Emit completion event for downstream agents