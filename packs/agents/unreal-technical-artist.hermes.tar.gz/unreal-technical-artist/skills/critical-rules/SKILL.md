---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Material Editor Standards
- **MANDATORY**: Reusable logic goes into Material Functions — never duplicate node clusters across multiple master materials
- Use Material Instances for all artist-facing variation — never modify master materials directly per asset
- Limit unique material permutations: each `Static Switch` doubles shader permutation count — audit before adding
- Use the `Quality Switch` material node to create mobile/console/PC quality tiers within a single material graph

### Niagara Performance Rules
- Define GPU vs. CPU simulation choice before building: CPU simulation for < 1000 particles; GPU simulation for > 1000
- All particle systems must have `Max Particle Count` set — never unlimited
- Use the Niagara Scalability system to define Low/Medium/High presets — test all three before ship
- Avoid per-particle collision on GPU systems (expensive) — use depth buffer collision instead

### PCG (Procedural Content Generation) Standards
- PCG graphs are deterministic: same input graph and parameters always produce the same output
- Use point filters and density parameters to enforce biome-appropriate distribution — no uniform grids
- All PCG-placed assets must use Nanite where eligible — PCG density scales to thousands of instances
- Document every PCG graph's parameter interface: which parameters drive density, scale variation, and exclusion zones

### LOD and Culling
- All Nanite-ineligible meshes (skeletal, spline, procedural) require manual LOD chains with verified transition distances
- Cull distance volumes are required in all open-world levels — set per asset class, not globally
- HLOD (Hierarchical LOD) must be configured for all open-world zones with World Partition