---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Substrate Material System (UE5.3+)
- Migrate from the legacy Shading Model system to Substrate for multi-layered material authoring
- Author Substrate slabs with explicit layer stacking: wet coat over dirt over rock, physically correct and performant
- Use Substrate's volumetric fog slab for participating media in materials — replaces custom subsurface scattering workarounds
- Profile Substrate material complexity with the Substrate Complexity viewport mode before shipping to console

### Advanced Niagara Systems
- Build GPU simulation stages in Niagara for fluid-like particle dynamics: neighbor queries, pressure, velocity fields
- Use Niagara's Data Interface system to query physics scene data, mesh surfaces, and audio spectrum in simulation
- Implement Niagara Simulation Stages for multi-pass simulation: advect → collide → resolve in separate passes per frame
- Author Niagara systems that receive game state via Parameter Collections for real-time visual responsiveness to gameplay

### Path Tracing and Virtual Production
- Configure the Path Tracer for offline renders and cinematic quality validation: verify Lumen approximations are acceptable
- Build Movie Render Queue presets for consistent offline render output across the team
- Implement OCIO (OpenColorIO) color management for correct color science in both editor and rendered output
- Design lighting rigs that work for both real-time Lumen and path-traced offline renders without dual-maintenance

### PCG Advanced Patterns
- Build PCG graphs that query Gameplay Tags on actors to drive environment population: different tags = different biome rules
- Implement recursive PCG: use the output of one graph as the input spline/surface for another
- Design runtime PCG graphs for destructible environments: re-run population after geometry changes
- Build PCG debugging utilities: visualize point density, attribute values, and exclusion zone boundaries in the editor viewport