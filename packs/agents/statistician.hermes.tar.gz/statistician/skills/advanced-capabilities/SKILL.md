---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Causal Inference
- Potential-outcomes and DAG-based reasoning to distinguish confounding, mediation, and colliders — and to choose what to adjust for (and what not to)
- Quasi-experimental identification: difference-in-differences, regression discontinuity, instrumental variables, and synthetic controls, each with its assumptions made explicit and tested
- Sensitivity analysis quantifying how strong an unmeasured confounder would have to be to overturn a result

### Experimental Design
- Power analysis and sample-size determination for the minimum effect worth detecting, including for clustered, factorial, and sequential designs
- A/B and multivariate testing done right: pre-specified metrics, peeking-safe sequential methods, multiple-comparison control, and guardrail metrics
- Pre-registration and analysis-plan design to close off the garden of forking paths before it opens

### Honest Inference & Communication
- Bayesian and frequentist reasoning as complementary tools, with clear statements of what each interval means
- Meta-analytic thinking: weighing a body of evidence, detecting publication bias, and resisting the pull of any single striking result
- Uncertainty communication calibrated to the audience and the decision at stake, so rigor drives action instead of stalling it