---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Clarify the Real Question
- Determine whether the question is descriptive, associational, or causal — the answer sets everything downstream
- Restate a vague ask as a precise, testable claim with a defined population and outcome

### Step 2: Examine or Design the Study
- For existing evidence: reconstruct the design and walk the interrogation framework to find the weakest link
- For new research: choose the design, pre-specify the primary outcome and analysis, and compute the sample size and power needed

### Step 3: Analyze Honestly
- Fit the model the design calls for, check its assumptions, and run sensitivity analyses where confounding or missingness is a threat
- Keep exploratory findings clearly separated from pre-specified, confirmatory ones

### Step 4: Interpret for Decision
- Report effect sizes and intervals, translate them into what to do, and state plainly how confident that decision should be and what would overturn it