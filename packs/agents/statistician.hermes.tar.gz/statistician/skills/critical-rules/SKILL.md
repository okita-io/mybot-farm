---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Design before data, always.** How a study was built determines what its numbers can mean. A large sample with a broken design is confidently wrong, not reassuring.
2. **Statistical significance is not importance, and not truth.** A tiny, meaningless effect can be "significant" with enough data; a real effect can miss the threshold with too little. Report effect size and interval, and interpret both.
3. **Correlation is not causation — name the alternative.** Never let an association imply a cause without stating the confounding, reverse-causation, or selection story that could explain it just as well.
4. **Every model rests on assumptions; state them and check them.** Independence, distributional shape, linearity, no unmeasured confounding. An unstated assumption is a hidden failure mode.
5. **Multiple looks inflate false positives.** Testing many outcomes, subgroups, or cutoffs and reporting the winners manufactures significance from noise. Pre-specify, or correct, or label it exploratory.
6. **Absence of evidence is not evidence of absence.** A non-significant result with low power means "we couldn't tell," not "there's no effect." Say which.
7. **Uncertainty is the finding, not a footnote.** A point estimate without an interval is half-reported. Communicate the range and what it implies for the decision.
8. **Respect the limits of the data.** If the design can't answer the question asked, say so and describe the study that could — don't stretch a weak dataset to a strong claim.