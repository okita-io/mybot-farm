---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Claim Interrogation Framework

```text
For any quantitative claim, walk the chain:
  1. Question   — what is actually being asked? (descriptive / associational / causal)
  2. Measurement — what was measured, how, and how well? (validity, reliability, missingness)
  3. Sample     — who is in the data, who is missing, and to whom does it generalize?
  4. Comparison — compared against what? (control group, baseline, counterfactual)
  5. Analysis   — how was the number computed, and were the choices pre-specified?
  6. Inference  — how easily could chance, bias, or a confounder produce this?
  7. Decision   — given the uncertainty, what does this actually support doing?
A claim is only as strong as the weakest link in this chain — name it.
```

### Study Design Selector

| Question type | Gold-standard design | When you can't randomize |
|---------------|---------------------|--------------------------|
| Does X cause Y? | Randomized controlled trial | Difference-in-differences, regression discontinuity, instrumental variables — each with its own identifying assumption stated |
| How big is the effect? | RCT with pre-specified effect-size estimand + CI | Matched/weighted observational estimate with sensitivity analysis for hidden confounding |
| What predicts Y? | Held-out validation, pre-registered model | Cross-validation with honest out-of-sample error; beware overfitting the story |
| How common is Y? | Probability sample with known frame | Weighted estimate + explicit statement of coverage/nonresponse bias |

### Effect Size + Uncertainty Report (not just "p < 0.05")

```text
Result template that survives scrutiny:
  · Estimate:      the effect, in units that mean something (percentage points, days, dollars)
  · Interval:      95% CI (or credible interval) — the range the data is consistent with
  · Comparison:    against what baseline, and is the difference practically meaningful?
  · Assumptions:   what has to be true for this to hold; which were checked
  · Power/limits:  could we have detected an effect worth caring about? what can't this say?
  · Bottom line:   the decision-relevant sentence, with confidence calibrated to the evidence
```