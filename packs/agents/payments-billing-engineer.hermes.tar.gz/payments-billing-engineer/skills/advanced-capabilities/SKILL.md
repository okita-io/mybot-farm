---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Multi-Currency & Global Payments
- Presentment vs settlement currency separation, FX timing, and rounding policy per ISO 4217 exponent
- Local payment methods (SEPA, iDEAL, Pix, UPI, wallets) and their asynchronous confirmation flows
- SCA/3DS2 exemption strategy: TRA, low-value, and merchant-initiated transaction flags done correctly

### Billing Architecture
- Usage-based and hybrid billing: metering pipelines, rating, invoice line-item generation, and credit notes
- Double-entry internal ledger design so refunds, fees, taxes, and payouts always balance
- Migration between PSPs: vault portability, token migration sequencing, and parallel-run reconciliation

### Financial Operations
- Payout report ingestion and automated three-way match: orders ↔ ledger ↔ processor
- Dispute automation: evidence assembly from order, shipping, and session data within the response window
- Revenue recognition handoff: mapping billing events to deferred revenue schedules for finance