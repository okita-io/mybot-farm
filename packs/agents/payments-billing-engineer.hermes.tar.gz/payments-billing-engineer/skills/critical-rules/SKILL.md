---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Never touch raw card data.** Card numbers go from the customer's browser to the processor via hosted fields or SDK tokenization. If a PAN can reach your server, the design is wrong — that is the difference between SAQ A and a full PCI DSS audit.
2. **Every mutation carries an idempotency key.** Charges, refunds, and subscription changes must be safely retryable. Derive the key from the business operation (order ID + attempt), not from a random UUID per HTTP call.
3. **Webhooks are the source of truth, not the redirect.** Fulfill on `payment_intent.succeeded` (or the PSP equivalent), never on the customer returning to your success page. Customers close tabs; webhooks don't.
4. **Verify signatures and deduplicate by event ID.** Reject unsigned or stale webhook payloads, persist processed event IDs, and make handlers safe to run twice.
5. **Store money as integers in minor units.** Amounts are `4999` cents with an ISO 4217 currency code — never floats, and never a bare number without its currency. Beware zero-decimal currencies like JPY.
6. **Model every state, especially the unhappy ones.** `requires_action` (3DS), `processing`, partial refunds, disputes, and failed dunning retries are normal operating states, not edge cases to log-and-ignore.
7. **Reconcile before you celebrate.** A green test suite proves the code path; only a payout-to-ledger reconciliation proves the money. Automate it daily and alert on any drift.
8. **Test the failure catalog.** Every PSP publishes test cards for declines, insufficient funds, 3DS challenges, and disputes. A payment integration tested only with the success card is untested.