---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Idempotent Payment Creation (TypeScript + Stripe)

```typescript
// The idempotency key is derived from the business operation, so a client
// retry, a server retry, and a double-click all resolve to the same charge.
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' });

export async function createPaymentForOrder(order: Order): Promise<Stripe.PaymentIntent> {
  return stripe.paymentIntents.create(
    {
      amount: order.totalMinorUnits,          // integer cents — never floats
      currency: order.currency,               // ISO 4217, lowercase
      customer: order.stripeCustomerId,
      metadata: { order_id: order.id },       // always link PSP objects back to your domain
      automatic_payment_methods: { enabled: true },
    },
    { idempotencyKey: `order-${order.id}-attempt-${order.paymentAttempt}` }
  );
}
```

### Webhook Handler: Signature, Dedupe, Out-of-Order Safety

```typescript
export async function handleStripeWebhook(req: Request): Promise<Response> {
  // 1. Verify the signature against the raw body — parsed JSON breaks verification
  const event = stripe.webhooks.constructEvent(
    await req.text(),
    req.headers.get('stripe-signature')!,
    process.env.STRIPE_WEBHOOK_SECRET!
  );

  // 2. Deduplicate: at-least-once delivery means "twice" in practice
  const alreadyProcessed = await db.webhookEvents.insertIgnore({ id: event.id });
  if (alreadyProcessed) return new Response('duplicate', { status: 200 });

  // 3. Never trust event order — re-fetch current state instead of applying deltas
  switch (event.type) {
    case 'payment_intent.succeeded': {
      const pi = await stripe.paymentIntents.retrieve(
        (event.data.object as Stripe.PaymentIntent).id
      );
      if (pi.status === 'succeeded') {
        await fulfillOrder(pi.metadata.order_id); // must itself be idempotent
      }
      break;
    }
    case 'charge.dispute.created':
      await freezeOrderAndNotifyFinance(event); // evidence deadline starts NOW
      break;
  }

  // 4. Return 2xx fast; do heavy work in a queue so the PSP doesn't retry-storm you
  return new Response('ok', { status: 200 });
}
```

### Subscription Lifecycle State Machine

```text
trialing ──trial ends──▶ active ──payment fails──▶ past_due ──dunning exhausted──▶ canceled
   │                       │  ▲                        │
   │ card required upfront │  └──payment recovers──────┘
   ▼                       ▼
incomplete ──3DS/action──▶ upgrade/downgrade → proration credit or invoice line item
```

| Transition | Trigger | Your system must |
|------------|---------|------------------|
| `active → past_due` | Renewal charge fails | Keep access (grace period), start dunning emails, retry on smart schedule |
| `past_due → active` | Retry succeeds or card updated | Restore silently, log recovery source for churn analytics |
| `past_due → canceled` | Dunning exhausted (e.g. 4 retries / 21 days) | Revoke access, keep data for win-back window, emit churn event |
| `active → active` (plan change) | Upgrade mid-cycle | Prorate: credit unused time, invoice the difference immediately |

### Daily Reconciliation Query

```sql
-- Every processor payout must equal the sum of our ledger entries for that payout.
-- Any nonzero drift is an incident, not a curiosity.
SELECT
  p.payout_id,
  p.arrival_date,
  p.amount_minor                             AS processor_amount,
  COALESCE(SUM(l.amount_minor), 0)           AS ledger_amount,
  p.amount_minor - COALESCE(SUM(l.amount_minor), 0) AS drift
FROM processor_payouts p
LEFT JOIN ledger_entries l ON l.payout_id = p.payout_id
GROUP BY p.payout_id, p.arrival_date, p.amount_minor
HAVING p.amount_minor <> COALESCE(SUM(l.amount_minor), 0)
ORDER BY p.arrival_date DESC;
```

### PCI Scope Cheat Sheet

| Integration style | PCI validation | Rule of thumb |
|-------------------|---------------|----------------|
| Hosted checkout page (Stripe Checkout, PayPal redirect) | SAQ A | Card data never touches your pages — smallest scope, default choice |
| Embedded iframe fields (Stripe Elements, Adyen Drop-in) | SAQ A | Your page hosts the iframe; the PSP hosts the inputs |
| Your form posts card data via PSP JS (legacy direct-post) | SAQ A-EP | Your page can be attacked — avoid for new builds |
| Card data touches your servers | SAQ D / full audit | Almost never justified — redesign |