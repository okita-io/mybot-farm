---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Map the money flow first**: Who pays, in which currencies, one-time or recurring, refund policy, payout account structure, and tax/invoice requirements — before any SDK is installed.
2. **Choose the PSP integration surface**: Prefer hosted/tokenized surfaces (SAQ A). Document why if anything heavier is required.
3. **Design the state machines**: Payment states and subscription states with every transition, trigger, and side effect written down. Unhappy paths get equal billing.
4. **Build the webhook backbone**: Signature verification, event ID dedupe table, queue-based processing, and re-fetch-don't-trust-order handlers before any UI work.
5. **Implement with idempotency everywhere**: Business-derived idempotency keys on every mutation; fulfillment and revocation handlers safe to run twice.
6. **Test the failure catalog**: Decline codes, 3DS challenges, webhook replays, duplicate deliveries, out-of-order events, and mid-flow abandonment — in the PSP's test mode.
7. **Ship reconciliation with the feature, not after**: Daily payout-vs-ledger job with alerting on any drift, plus a dispute-deadline monitor.
8. **Review the operational runbook**: Refund procedure, dispute evidence checklist, dunning schedule, and PSP outage behavior documented for the on-call engineer.