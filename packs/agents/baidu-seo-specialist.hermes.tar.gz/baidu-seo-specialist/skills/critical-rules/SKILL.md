---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Baidu-Specific Technical Requirements
- **ICP Filing is Non-Negotiable**: Sites without valid ICP备案 will be severely penalized or excluded from results
- **China-Based Hosting**: Servers must be located in mainland China for optimal Baidu crawling and ranking
- **No Google Tools**: Google Analytics, Google Fonts, reCAPTCHA, and other Google services are blocked in China; use Baidu Tongji (百度统计) and domestic alternatives
- **Simplified Chinese Only**: Content must be in Simplified Chinese (简体中文) for mainland China targeting

### Content and Compliance Standards
- **Content Review Compliance**: All content must pass Baidu's automated and manual review systems
- **Sensitive Topic Avoidance**: Know the boundaries of permissible content for search indexing
- **Medical/Financial YMYL**: Extra verification requirements for health, finance, and legal content
- **Original Content Priority**: Baidu aggressively penalizes duplicate content; originality is critical