---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

FloatVariable ScriptableObject
```csharp
[CreateAssetMenu(menuName = "Variables/Float")]
public class FloatVariable : ScriptableObject
{
    [SerializeField] private float _value;

    public float Value
    {
        get => _value;
        set
        {
            _value = value;
            OnValueChanged?.Invoke(value);
        }
    }

    public event Action<float> OnValueChanged;

    public void SetValue(float value) => Value = value;
    public void ApplyChange(float amount) => Value += amount;
}
```

### RuntimeSet — Singleton-Free Entity Tracking
```csharp
[CreateAssetMenu(menuName = "Runtime Sets/Transform Set")]
public class TransformRuntimeSet : RuntimeSet<Transform> { }

public abstract class RuntimeSet<T> : ScriptableObject
{
    public List<T> Items = new List<T>();

    public void Add(T item)
    {
        if (!Items.Contains(item)) Items.Add(item);
    }

    public void Remove(T item)
    {
        if (Items.Contains(item)) Items.Remove(item);
    }
}

// Usage: attach to any prefab
public class RuntimeSetRegistrar : MonoBehaviour
{
    [SerializeField] private TransformRuntimeSet _set;

    private void OnEnable() => _set.Add(transform);
    private void OnDisable() => _set.Remove(transform);
}
```

### GameEvent Channel — Decoupled Messaging
```csharp
[CreateAssetMenu(menuName = "Events/Game Event")]
public class GameEvent : ScriptableObject
{
    private readonly List<GameEventListener> _listeners = new();

    public void Raise()
    {
        for (int i = _listeners.Count - 1; i >= 0; i--)
            _listeners[i].OnEventRaised();
    }

    public void RegisterListener(GameEventListener listener) => _listeners.Add(listener);
    public void UnregisterListener(GameEventListener listener) => _listeners.Remove(listener);
}

public class GameEventListener : MonoBehaviour
{
    [SerializeField] private GameEvent _event;
    [SerializeField] private UnityEvent _response;

    private void OnEnable() => _event.RegisterListener(this);
    private void OnDisable() => _event.UnregisterListener(this);
    public void OnEventRaised() => _response.Invoke();
}
```

### Modular MonoBehaviour (Single Responsibility)
```csharp
// ✅ Correct: one component, one concern
public class PlayerHealthDisplay : MonoBehaviour
{
    [SerializeField] private FloatVariable _playerHealth;
    [SerializeField] private Slider _healthSlider;

    private void OnEnable()
    {
        _playerHealth.OnValueChanged += UpdateDisplay;
        UpdateDisplay(_playerHealth.Value);
    }

    private void OnDisable() => _playerHealth.OnValueChanged -= UpdateDisplay;

    private void UpdateDisplay(float value) => _healthSlider.value = value;
}
```

### Custom PropertyDrawer — Designer Empowerment
```csharp
[CustomPropertyDrawer(typeof(FloatVariable))]
public class FloatVariableDrawer : PropertyDrawer
{
    public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
    {
        EditorGUI.BeginProperty(position, label, property);
        var obj = property.objectReferenceValue as FloatVariable;
        if (obj != null)
        {
            Rect valueRect = new Rect(position.x, position.y, position.width * 0.6f, position.height);
            Rect labelRect = new Rect(position.x + position.width * 0.62f, position.y, position.width * 0.38f, position.height);
            EditorGUI.ObjectField(valueRect, property, GUIContent.none);
            EditorGUI.LabelField(labelRect, $"= {obj.Value:F2}");
        }
        else
        {
            EditorGUI.ObjectField(position, property, label);
        }
        EditorGUI.EndProperty();
    }
}
```