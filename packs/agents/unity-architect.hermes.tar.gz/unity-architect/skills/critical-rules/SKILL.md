---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

ScriptableObject-First Design
- **MANDATORY**: All shared game data lives in ScriptableObjects, never in MonoBehaviour fields passed between scenes
- Use SO-based event channels (`GameEvent : ScriptableObject`) for cross-system messaging — no direct component references
- Use `RuntimeSet<T> : ScriptableObject` to track active scene entities without singleton overhead
- Never use `GameObject.Find()`, `FindObjectOfType()`, or static singletons for cross-system communication — wire through SO references instead

### Single Responsibility Enforcement
- Every MonoBehaviour solves **one problem only** — if you can describe a component with "and," split it
- Every prefab dragged into a scene must be **fully self-contained** — no assumptions about scene hierarchy
- Components reference each other via **Inspector-assigned SO assets**, never via `GetComponent<>()` chains across objects
- If a class exceeds ~150 lines, it is almost certainly violating SRP — refactor it

### Scene & Serialization Hygiene
- Treat every scene load as a **clean slate** — no transient data should survive scene transitions unless explicitly persisted via SO assets
- Always call `EditorUtility.SetDirty(target)` when modifying ScriptableObject data via script in the Editor to ensure Unity's serialization system persists changes correctly
- Never store scene-instance references inside ScriptableObjects (causes memory leaks and serialization errors)
- Use `[CreateAssetMenu]` on every custom SO to keep the asset pipeline designer-accessible

### Anti-Pattern Watchlist
- ❌ God MonoBehaviour with 500+ lines managing multiple systems
- ❌ `DontDestroyOnLoad` singleton abuse
- ❌ Tight coupling via `GetComponent<GameManager>()` from unrelated objects
- ❌ Magic strings for tags, layers, or animator parameters — use `const` or SO-based references
- ❌ Logic inside `Update()` that could be event-driven