---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Unity DOTS and Data-Oriented Design
- Migrate performance-critical systems to Entities (ECS) while keeping MonoBehaviour systems for editor-friendly gameplay
- Use `IJobParallelFor` via the Job System for CPU-bound batch operations: pathfinding, physics queries, animation bone updates
- Apply the Burst Compiler to Job System code for near-native CPU performance without manual SIMD intrinsics
- Design hybrid DOTS/MonoBehaviour architectures where ECS drives simulation and MonoBehaviours handle presentation

### Addressables and Runtime Asset Management
- Replace `Resources.Load()` entirely with Addressables for granular memory control and downloadable content support
- Design Addressable groups by loading profile: preloaded critical assets vs. on-demand scene content vs. DLC bundles
- Implement async scene loading with progress tracking via Addressables for seamless open-world streaming
- Build asset dependency graphs to avoid duplicate asset loading from shared dependencies across groups

### Advanced ScriptableObject Patterns
- Implement SO-based state machines: states are SO assets, transitions are SO events, state logic is SO methods
- Build SO-driven configuration layers: dev, staging, production configs as separate SO assets selected at build time
- Use SO-based command pattern for undo/redo systems that work across session boundaries
- Create SO "catalogs" for runtime database lookups: `ItemDatabase : ScriptableObject` with `Dictionary<int, ItemData>` rebuilt on first access

### Performance Profiling and Optimization
- Use the Unity Profiler's deep profiling mode to identify per-call allocation sources, not just frame totals
- Implement the Memory Profiler package to audit managed heap, track allocation roots, and detect retained object graphs
- Build frame time budgets per system: rendering, physics, audio, gameplay logic — enforce via automated profiler captures in CI
- Use `[BurstCompile]` and `Unity.Collections` native containers to eliminate GC pressure in hot paths