---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# ️ Your Infrastructure Management Deliverables

Comprehensive Monitoring System
```yaml
# Prometheus Monitoring Configuration
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - "infrastructure_alerts.yml"
  - "application_alerts.yml"
  - "business_metrics.yml"

scrape_configs:
  # Infrastructure monitoring
  - job_name: 'infrastructure'
    static_configs:
      - targets: ['localhost:9100']  # Node Exporter
    scrape_interval: 30s
    metrics_path: /metrics

  # Application monitoring
  - job_name: 'application'
    static_configs:
      - targets: ['app:8080']
    scrape_interval: 15s

  # Database monitoring
  - job_name: 'database'
    static_configs:
      - targets: ['db:9104']  # PostgreSQL Exporter
    scrape_interval: 30s

# Critical Infrastructure Alerts
alerting:
  alertmanagers:
    - static_configs:
        - targets:
          - alertmanager:9093

# Infrastructure Alert Rules
groups:
  - name: infrastructure.rules
# … truncated for farm planting — see upstream for the full sample
```

### Infrastructure as Code Framework
```terraform
# AWS Infrastructure Configuration
terraform {
  required_version = ">= 1.0"
  backend "s3" {
    bucket = "company-terraform-state"
    key    = "infrastructure/terraform.tfstate"
    region = "us-west-2"
    encrypt = true
    dynamodb_table = "terraform-locks"
  }
}

# Network Infrastructure
resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name        = "main-vpc"
    Environment = var.environment
    Owner       = "infrastructure-team"
  }
}

resource "aws_subnet" "private" {
  count             = length(var.availability_zones)
  vpc_id            = aws_vpc.main.id
  cidr_block        = "10.0.${count.index + 1}.0/24"
  availability_zone = var.availability_zones[count.index]

  tags = {
    Name = "private-subnet-${count.index + 1}"
    Type = "private"
  }
}

resource "aws_subnet" "public" {
  count                   = length(var.availability_zones)
  vpc_id                  = aws_vpc.main.id
# … truncated for farm planting — see upstream for the full sample
```

### Automated Backup and Recovery System
```bash
#!/bin/bash
# Comprehensive Backup and Recovery Script

set -euo pipefail

# Configuration
BACKUP_ROOT="/backups"
LOG_FILE="/var/log/backup.log"
RETENTION_DAYS=30
ENCRYPTION_KEY="/etc/backup/backup.key"
S3_BUCKET="company-backups"
# IMPORTANT: This is a template example. Replace with your actual webhook URL before use.
# Never commit real webhook URLs to version control.
NOTIFICATION_WEBHOOK="${SLACK_WEBHOOK_URL:?Set SLACK_WEBHOOK_URL environment variable}"

# Logging function
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

# Error handling
handle_error() {
    local error_message="$1"
    log "ERROR: $error_message"

    # Send notification
    curl -X POST -H 'Content-type: application/json' \
        --data "{\"text\":\"🚨 Backup Failed: $error_message\"}" \
        "$NOTIFICATION_WEBHOOK"

    exit 1
}

# Database backup function
backup_database() {
    local db_name="$1"
    local backup_file="${BACKUP_ROOT}/db/${db_name}_$(date +%Y%m%d_%H%M%S).sql.gz"

    log "Starting database backup for $db_name"

# … truncated for farm planting — see upstream for the full sample
```