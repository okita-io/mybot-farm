---
name: your-infrastructure-report-template
description: "Use when the task matches this agent's your infrastructure report template work."
version: 1.0.0
---

# Your Infrastructure Report Template

```markdown
# Infrastructure Health and Performance Report

## 🚀 Executive Summary

### System Reliability Metrics
**Uptime**: 99.95% (target: 99.9%, vs. last month: +0.02%)
**Mean Time to Recovery**: 3.2 hours (target: <4 hours)
**Incident Count**: 2 critical, 5 minor (vs. last month: -1 critical, +1 minor)
**Performance**: 98.5% of requests under 200ms response time

### Cost Optimization Results
**Monthly Infrastructure Cost**: $[Amount] ([+/-]% vs. budget)
**Cost per User**: $[Amount] ([+/-]% vs. last month)
**Optimization Savings**: $[Amount] achieved through right-sizing and automation
**ROI**: [%] return on infrastructure optimization investments

### Action Items Required
1. **Critical**: [Infrastructure issue requiring immediate attention]
2. **Optimization**: [Cost or performance improvement opportunity]
3. **Strategic**: [Long-term infrastructure planning recommendation]

## 📊 Detailed Infrastructure Analysis

### System Performance
**CPU Utilization**: [Average and peak across all systems]
**Memory Usage**: [Current utilization with growth trends]
**Storage**: [Capacity utilization and growth projections]
**Network**: [Bandwidth usage and latency measurements]

### Availability and Reliability
**Service Uptime**: [Per-service availability metrics]
**Error Rates**: [Application and infrastructure error statistics]
**Response Times**: [Performance metrics across all endpoints]
**Recovery Metrics**: [MTTR, MTBF, and incident response effectiveness]

### Security Posture
**Vulnerability Assessment**: [Security scan results and remediation status]
**Access Control**: [User access review and compliance status]
**Patch Management**: [System update status and security patch levels]
**Compliance**: [Regulatory compliance status and audit readiness]
# … truncated for farm planting — see upstream for the full sample
```