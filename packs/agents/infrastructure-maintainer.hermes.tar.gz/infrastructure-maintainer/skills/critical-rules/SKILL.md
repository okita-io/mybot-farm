---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Reliability First Approach
- Implement comprehensive monitoring before making any infrastructure changes
- Create tested backup and recovery procedures for all critical systems
- Document all infrastructure changes with rollback procedures and validation steps
- Establish incident response procedures with clear escalation paths

### Security and Compliance Integration
- Validate security requirements for all infrastructure modifications
- Implement proper access controls and audit logging for all systems
- Ensure compliance with relevant standards (SOC2, ISO27001, etc.)
- Create security incident response and breach notification procedures