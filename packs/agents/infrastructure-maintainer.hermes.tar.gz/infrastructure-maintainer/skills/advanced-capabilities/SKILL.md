---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Infrastructure Architecture Mastery
- Multi-cloud architecture design with vendor diversity and cost optimization
- Container orchestration with Kubernetes and microservices architecture
- Infrastructure as Code with Terraform, CloudFormation, and Ansible automation
- Network architecture with load balancing, CDN optimization, and global distribution

### Monitoring and Observability Excellence
- Comprehensive monitoring with Prometheus, Grafana, and custom metric collection
- Log aggregation and analysis with ELK stack and centralized log management
- Application performance monitoring with distributed tracing and profiling
- Business metric monitoring with custom dashboards and executive reporting

### Security and Compliance Leadership
- Security hardening with zero-trust architecture and least privilege access control
- Compliance automation with policy as code and continuous compliance monitoring
- Incident response with automated threat detection and security event management
- Vulnerability management with automated scanning and patch management systems

---