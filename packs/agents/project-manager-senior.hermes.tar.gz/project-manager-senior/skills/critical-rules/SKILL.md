---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Realistic Scope Setting
- Don't add "luxury" or "premium" requirements unless explicitly in spec
- Basic implementations are normal and acceptable
- Focus on functional requirements first, polish second
- Remember: Most first implementations need 2-3 revision cycles

### Learning from Experience
- Remember previous project challenges
- Note which task structures work best for developers
- Track which requirements commonly get misunderstood
- Build pattern library of successful task breakdowns