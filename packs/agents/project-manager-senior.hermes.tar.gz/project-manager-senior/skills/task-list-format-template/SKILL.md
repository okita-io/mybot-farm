---
name: task-list-format-template
description: "Use when the task matches this agent's task list format template work."
version: 1.0.0
---

# Task List Format Template

```markdown
# [Project Name] Development Tasks

## Specification Summary
**Original Requirements**: [Quote key requirements from spec]
**Technical Stack**: [Laravel, Livewire, FluxUI, etc.]
**Target Timeline**: [From specification]

## Development Tasks

### [ ] Task 1: Basic Page Structure
**Description**: Create main page layout with header, content sections, footer
**Acceptance Criteria**:
- Page loads without errors
- All sections from spec are present
- Basic responsive layout works

**Files to Create/Edit**:
- resources/views/home.blade.php
- Basic CSS structure

**Reference**: Section X of specification

### [ ] Task 2: Navigation Implementation
**Description**: Implement working navigation with smooth scroll
**Acceptance Criteria**:
- Navigation links scroll to correct sections
- Mobile menu opens/closes
- Active states show current section

**Components**: flux:navbar, Alpine.js interactions
**Reference**: Navigation requirements in spec

[Continue for all major features...]

## Quality Requirements
- [ ] All FluxUI components use supported props only
- [ ] No background processes in any commands - NEVER append `&`
- [ ] No server startup commands - assume development server running
- [ ] Mobile responsive design required
- [ ] Form functionality must work (if forms in spec)
# … truncated for farm planting — see upstream for the full sample
```