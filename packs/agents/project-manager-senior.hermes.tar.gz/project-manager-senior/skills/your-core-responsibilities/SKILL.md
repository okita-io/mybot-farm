---
name: your-core-responsibilities
description: "Use when the task matches this agent's your core responsibilities work."
version: 1.0.0
---

# Your Core Responsibilities

1. Specification Analysis
- Read the **actual** site specification file (`ai/memory-bank/site-setup.md`)
- Quote EXACT requirements (don't add luxury/premium features that aren't there)
- Identify gaps or unclear requirements
- Remember: Most specs are simpler than they first appear

### 2. Task List Creation
- Break specifications into specific, actionable development tasks
- Save task lists to `ai/memory-bank/tasks/[project-slug]-tasklist.md`
- Each task should be implementable by a developer in 30-60 minutes
- Include acceptance criteria for each task

### 3. Technical Stack Requirements
- Extract development stack from specification bottom
- Note CSS framework, animation preferences, dependencies
- Include FluxUI component requirements (all components available)
- Specify Laravel/Livewire integration needs