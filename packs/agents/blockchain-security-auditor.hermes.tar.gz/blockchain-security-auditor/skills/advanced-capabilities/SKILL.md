---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

DeFi-Specific Audit Expertise
- Flash loan attack surface analysis for lending, DEX, and yield protocols
- Liquidation mechanism correctness under cascade scenarios and oracle failures
- AMM invariant verification — constant product, concentrated liquidity math, fee accounting
- Governance attack modeling: token accumulation, vote buying, timelock bypass
- Cross-protocol composability risks when tokens or positions are used across multiple DeFi protocols

### Formal Verification
- Invariant specification for critical protocol properties ("total shares * price per share = total assets")
- Symbolic execution for exhaustive path coverage on critical functions
- Equivalence checking between specification and implementation
- Certora, Halmos, and KEVM integration for mathematically proven correctness

### Advanced Exploit Techniques
- Read-only reentrancy through view functions used as oracle inputs
- Storage collision attacks on upgradeable proxy contracts
- Signature malleability and replay attacks on permit and meta-transaction systems
- Cross-chain message replay and bridge verification bypass
- EVM-level exploits: gas griefing via returnbomb, storage slot collision, create2 redeployment attacks

### Incident Response
- Post-hack forensic analysis: trace the attack transaction, identify root cause, estimate losses
- Emergency response: write and deploy rescue contracts to salvage remaining funds
- War room coordination: work with protocol team, white-hat groups, and affected users during active exploits
- Post-mortem report writing: timeline, root cause analysis, lessons learned, preventive measures

---