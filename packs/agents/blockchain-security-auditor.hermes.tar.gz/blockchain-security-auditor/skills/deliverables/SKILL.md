---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Reentrancy Vulnerability Analysis
```solidity
// VULNERABLE: Classic reentrancy — state updated after external call
contract VulnerableVault {
    mapping(address => uint256) public balances;

    function withdraw() external {
        uint256 amount = balances[msg.sender];
        require(amount > 0, "No balance");

        // BUG: External call BEFORE state update
        (bool success,) = msg.sender.call{value: amount}("");
        require(success, "Transfer failed");

        // Attacker re-enters withdraw() before this line executes
        balances[msg.sender] = 0;
    }
}

// EXPLOIT: Attacker contract
contract ReentrancyExploit {
    VulnerableVault immutable vault;

    constructor(address vault_) { vault = VulnerableVault(vault_); }

    function attack() external payable {
        vault.deposit{value: msg.value}();
        vault.withdraw();
    }

    receive() external payable {
        // Re-enter withdraw — balance has not been zeroed yet
        if (address(vault).balance >= vault.balances(address(this))) {
            vault.withdraw();
        }
    }
}

// FIXED: Checks-Effects-Interactions + reentrancy guard
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

contract SecureVault is ReentrancyGuard {
# … truncated for farm planting — see upstream for the full sample
```

### Oracle Manipulation Detection
```solidity
// VULNERABLE: Spot price oracle — manipulable via flash loan
contract VulnerableLending {
    IUniswapV2Pair immutable pair;

    function getCollateralValue(uint256 amount) public view returns (uint256) {
        // BUG: Using spot reserves — attacker manipulates with flash swap
        (uint112 reserve0, uint112 reserve1,) = pair.getReserves();
        uint256 price = (uint256(reserve1) * 1e18) / reserve0;
        return (amount * price) / 1e18;
    }

    function borrow(uint256 collateralAmount, uint256 borrowAmount) external {
        // Attacker: 1) Flash swap to skew reserves
        //           2) Borrow against inflated collateral value
        //           3) Repay flash swap — profit
        uint256 collateralValue = getCollateralValue(collateralAmount);
        require(collateralValue >= borrowAmount * 15 / 10, "Undercollateralized");
        // ... execute borrow
    }
}

// FIXED: Use time-weighted average price (TWAP) or Chainlink oracle
import {AggregatorV3Interface} from "@chainlink/contracts/src/v0.8/interfaces/AggregatorV3Interface.sol";

contract SecureLending {
    AggregatorV3Interface immutable priceFeed;
    uint256 constant MAX_ORACLE_STALENESS = 1 hours;

    function getCollateralValue(uint256 amount) public view returns (uint256) {
        (
            uint80 roundId,
            int256 price,
            ,
            uint256 updatedAt,
            uint80 answeredInRound
        ) = priceFeed.latestRoundData();

        // Validate oracle response — never trust blindly
        require(price > 0, "Invalid price");
        require(updatedAt > block.timestamp - MAX_ORACLE_STALENESS, "Stale price");
# … truncated for farm planting — see upstream for the full sample
```

### Access Control Audit Checklist
```markdown
# Access Control Audit Checklist

## Role Hierarchy
- [ ] All privileged functions have explicit access modifiers
- [ ] Admin roles cannot be self-granted — require multi-sig or timelock
- [ ] Role renunciation is possible but protected against accidental use
- [ ] No functions default to open access (missing modifier = anyone can call)

## Initialization
- [ ] `initialize()` can only be called once (initializer modifier)
- [ ] Implementation contracts have `_disableInitializers()` in constructor
- [ ] All state variables set during initialization are correct
- [ ] No uninitialized proxy can be hijacked by frontrunning `initialize()`

## Upgrade Controls
- [ ] `_authorizeUpgrade()` is protected by owner/multi-sig/timelock
- [ ] Storage layout is compatible between versions (no slot collisions)
- [ ] Upgrade function cannot be bricked by malicious implementation
- [ ] Proxy admin cannot call implementation functions (function selector clash)

## External Calls
- [ ] No unprotected `delegatecall` to user-controlled addresses
- [ ] Callbacks from external contracts cannot manipulate protocol state
- [ ] Return values from external calls are validated
- [ ] Failed external calls are handled appropriately (not silently ignored)
```

### Slither Analysis Integration
```bash
#!/bin/bash…