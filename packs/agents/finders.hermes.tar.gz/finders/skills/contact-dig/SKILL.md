---
name: contact-dig
description: "Use for each venue card to build its contact sheet."
version: 1.0.0
---

# Contact dig

For each venue card, check in this order:
1. The venue's own **booking page first** (`/book`, `/booking`, 'book a show') — dedicated booking inboxes live here and outrank anything else. Then the general contact page, then about.
2. Its social profiles: bios often carry the booking address or a link to the booking page.
3. City arts/music listings or promoter pages — many small venues are run by a promoter who lists a booking address.
4. If nothing is published: mark the field `needs manual` and set a next_action (band calls the front of house or asks at the door), then move on.

Capture: booker name (if public), email address, phone, booking-page URL, social handles. Record source + pull-date for every fact.

Discrepancy rule: if a displayed email differs from the link's actual mailto target, log BOTH, prefer the plain-text listing on the contact page, and flag it in the sheet — broken booking links are common.

Rules: one venue = one contact sheet; no fabricated emails or phones; no DMs to the venue; stop after ~3 public sources if nothing is found — that's a 'needs manual' outcome, not a failure.