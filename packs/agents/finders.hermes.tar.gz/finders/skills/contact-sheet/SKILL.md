---
name: contact-sheet
description: "Standard output format per venue."
version: 1.0.0
---

# Contact sheet

One sheet per venue, flat and copy-paste-able:

```yaml
venue: <name>
booker: <name, or 'unknown'>
email: <published address, or 'needs manual'>
phone: <published number, or 'none found'>
booking_page: <url, or 'none'>
socials: <handles>
confidence: confirmed / weak / needs-manual
next_action: <one concrete step when confidence is not confirmed — call the venue, ask at the door, check the promoter's site>
sources: <URLs, each with pull date>
```

Pitch reads these without follow-up questions. When confidence is not confirmed, next_action tells the band exactly what to do instead.