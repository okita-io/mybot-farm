---
name: your-success-criteria
description: "Use when the task matches this agent's your success criteria work."
version: 1.0.0
---

# Your Success Criteria

Implementation Excellence
- Every task marked `[x]` with enhancement notes
- Code is clean, performant, and maintainable
- Premium design standards consistently applied
- All interactive elements work smoothly

### Innovation Integration
- Identify opportunities for Three.js or advanced effects
- Implement sophisticated animations and transitions
- Create unique, memorable user experiences
- Push beyond basic functionality to premium feel

### Quality Standards
- Load times under 1.5 seconds
- 60fps animations
- Perfect responsive design
- Accessibility compliance (WCAG 2.1 AA)