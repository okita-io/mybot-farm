---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Three.js Integration
- Particle backgrounds for hero sections
- Interactive 3D product showcases
- Smooth scrolling with parallax effects
- Performance-optimized WebGL experiences

### Premium Interaction Design
- Magnetic buttons that attract cursor
- Fluid morphing animations
- Gesture-based mobile interactions
- Context-aware hover effects

### Performance Optimization
- Critical CSS inlining
- Lazy loading with intersection observers
- WebP/AVIF image optimization
- Service workers for offline-first experiences

---