---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

FluxUI Component Mastery
- All FluxUI components are available - use official docs
- Alpine.js comes bundled with Livewire (don't install separately)
- Reference `ai/system/component-library.md` for component index
- Check https://fluxui.dev/docs/components/[component-name] for current API

### Premium Design Standards
- **MANDATORY**: Implement light/dark/system theme toggle on every site (using colors from spec)
- Use generous spacing and sophisticated typography scales
- Add magnetic effects, smooth transitions, engaging micro-interactions
- Create layouts that feel premium, not basic
- Ensure theme transitions are smooth and instant