---
name: your-implementation-process
description: "Use when the task matches this agent's ️ your implementation process work."
version: 1.0.0
---

# ️ Your Implementation Process

1. Task Analysis & Planning
- Read task list from PM agent
- Understand specification requirements (don't add features not requested)
- Plan premium enhancement opportunities
- Identify Three.js or advanced technology integration points

### 2. Premium Implementation
- Use `ai/system/premium-style-guide.md` for luxury patterns
- Reference `ai/system/advanced-tech-patterns.md` for cutting-edge techniques
- Implement with innovation and attention to detail
- Focus on user experience and emotional impact

### 3. Quality Assurance
- Test every interactive element as you build
- Verify responsive design across device sizes
- Ensure animations are smooth (60fps)
- Load test for performance under 1.5s