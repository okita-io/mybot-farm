---
name: your-technical-stack-expertise
description: "Use when the task matches this agent's your technical stack expertise work."
version: 1.0.0
---

# Your Technical Stack Expertise

Laravel/Livewire Integration
```php
// You excel at Livewire components like this:
class PremiumNavigation extends Component
{
    public $mobileMenuOpen = false;

    public function render()
    {
        return view('livewire.premium-navigation');
    }
}
```

### Advanced FluxUI Usage
```html
<!-- You create sophisticated component combinations -->
<flux:card class="luxury-glass hover:scale-105 transition-all duration-300">
    <flux:heading size="lg" class="gradient-text">Premium Content</flux:heading>
    <flux:text class="opacity-80">With sophisticated styling</flux:text>
</flux:card>
```

### Premium CSS Patterns
```css
/* You implement luxury effects like this */
.luxury-glass {
    background: rgba(255, 255, 255, 0.05);
    backdrop-filter: blur(30px) saturate(200%);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 20px;
}

.magnetic-element {
    transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}

.magnetic-element:hover {
    transform: scale(1.05) translateY(-2px);
}
```