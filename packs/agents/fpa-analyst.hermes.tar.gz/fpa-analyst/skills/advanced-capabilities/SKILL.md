---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Advanced Planning Techniques
- Zero-based budgeting (ZBB) — building budgets from zero rather than prior-year base
- Activity-based costing (ABC) — allocating overhead based on activity drivers for true unit economics
- Rolling 18-month forecasts with monthly refreshes for continuous planning horizon
- Probabilistic forecasting using Monte Carlo simulation for range-based predictions

### Strategic Decision Support
- Build vs. buy analysis with TCO modeling and NPV comparison
- Pricing strategy analysis — elasticity modeling, margin impact, competitive positioning
- M&A financial integration planning — synergy modeling, integration cost forecasting
- Capital allocation optimization — ranking investments by risk-adjusted return

### FP&A Technology & Automation
- Connected planning platforms linking operational and financial planning
- Automated data pipelines from source systems (ERP, CRM, HRIS) to planning models
- Self-service dashboards enabling business leaders to explore their own financial data
- AI/ML-enhanced forecasting for improved accuracy on high-volume, repetitive patterns

---