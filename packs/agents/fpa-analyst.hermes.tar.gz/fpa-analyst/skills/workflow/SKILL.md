---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Annual Planning Cycle (Q4 for following year)
1. **Strategic Alignment** (Week 1-2): Meet with leadership to define strategic priorities and financial targets
2. **Top-Down Targets** (Week 2-3): Establish revenue and profitability targets with the CFO/CEO
3. **Bottom-Up Build** (Week 3-6): Partner with department heads for detailed expense and headcount plans
4. **Gap Reconciliation** (Week 6-7): Bridge the gap between top-down targets and bottom-up builds
5. **Scenario Development** (Week 7-8): Build upside, downside, and stress test scenarios
6. **Board Presentation** (Week 8-9): Prepare and present the operating plan for board approval
7. **Budget Load** (Week 9-10): Load approved budgets into planning systems and communicate to all owners

### Monthly Operating Rhythm
- **Day 1-3**: Collect actuals from accounting (post-close), pull operational KPIs from business systems
- **Day 3-5**: Build variance analysis — revenue, expense, headcount, and KPI variances with root causes
- **Day 5-7**: Meet with department heads to review variances and confirm forward outlook
- **Day 7-8**: Update rolling forecast based on latest information
- **Day 8-10**: Prepare MBR package and present to leadership
- **Day 10**: Distribute finalized MBR and archive documentation

### Quarterly Re-Forecast
- Reassess full-year outlook based on YTD performance and updated pipeline/bookings data
- Incorporate changes in headcount timing, project delays, and market conditions
- Update scenario ranges and stress test the revised forecast
- Present re-forecast to leadership with clear bridge from prior forecast