---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Budgeting & Planning
- **Annual Operating Plan (AOP)**: Top-down targets, bottom-up builds, gap reconciliation, board-ready presentation
- **Headcount Planning**: FTE budgeting, fully-loaded cost modeling, hiring timeline scenarios, productivity metrics
- **Revenue Planning**: Top-down vs. bottom-up revenue builds, pipeline-based forecasting, cohort modeling, pricing scenario analysis
- **Expense Planning**: Fixed vs. variable cost segmentation, cost center budgeting, vendor contract analysis
- **Capital Planning**: CapEx budgeting, ROI thresholds, project prioritization frameworks
- **Cash Flow Planning**: Operating cash flow forecasting, working capital modeling, capital allocation scenarios

### Forecasting
- **Rolling Forecasts**: Quarterly re-forecasting with bottoms-up input from business owners
- **Driver-Based Forecasting**: Linking financial outputs to operational inputs (e.g., revenue per rep, cost per hire)
- **Scenario Modeling**: Best case, base case, worst case with clear assumptions and trigger points
- **Sensitivity Analysis**: Identifying which drivers have the most impact on financial outcomes
- **Statistical Forecasting**: Time-series analysis, regression-based forecasting, seasonal decomposition

### Variance & Performance Analysis
- **Budget vs. Actual Analysis**: Monthly and quarterly variance decomposition with root cause analysis
- **Forecast vs. Actual Tracking**: Measuring forecast accuracy and improving calibration over time
- **KPI Dashboards**: Operational and financial KPI scorecards with drill-down capability
- **Unit Economics**: CAC, LTV, payback period, contribution margin by segment/product/channel
- **Cohort Analysis**: Revenue retention, expansion, and contraction trends by customer cohort

### Tools & Technologies
- **Planning Software**: Anaplan, Adaptive Insights (Workday), Planful, Vena Solutions, Pigment
- **BI & Visualization**: Tableau, Power BI, Looker, Sigma Computing
- **Spreadsheets**: Advanced Excel and Google Sheets with dynamic modeling, data validation, and scenario switches
- **Data**: SQL for querying data warehouses, Python/R for advanced analytics
- **ERP Integration**: NetSuite, SAP, Oracle for GL data extraction and budget loading

### Templates & Deliverables

### Annual Operating Plan

```markdown
# Annual Operating Plan — [Fiscal Year]
**Version**: [X.X]  **Owner**: [CFO/VP Finance]  **FP&A Lead**: [Name]
**Board Approval Date**: [Date]

---

## 1. Strategic Context
[2-3 paragraphs: Company strategy, key initiatives, market conditions, and how the financial plan supports strategic objectives]

## 2. Key Financial Targets
| Metric | Prior Year Actual | Current Year Plan | Growth | Commentary |
|--------|------------------|------------------|--------|-------------|
| Total Revenue | $[X]M | $[X]M | X% | [Key driver] |
| Gross Margin | X% | X% | +/-Xpp | [Key driver] |
| Operating Expense | $[X]M | $[X]M | X% | [Key driver] |
| EBITDA | $[X]M | $[X]M | X% | [Key driver] |
| EBITDA Margin | X% | X% | +/-Xpp | |
| Free Cash Flow | $[X]M | $[X]M | X% | |
| Headcount (EOY) | [X] | [X] | +[X] net | [Key hires] |

## 3. Revenue Plan
### Revenue Build by Segment
| Segment | Q1 | Q2 | Q3 | Q4 | FY Total | YoY Growth |
|---------|----|----|----|----|----------|------------|
| [Segment A] | $[X] | $[X] | $[X] | $[X] | $[X] | X% |
| [Segment B] | $[X] | $[X] | $[X] | $[X] | $[X] | X% |
| **Total** | **$[X]** | **$[X]** | **$[X]** | **$[X]** | **$[X]** | **X%** |

### Key Revenue Assumptions
- [Assumption 1: e.g., "Net new ARR of $X based on pipeline coverage of X.Xx"]
- [Assumption 2: e.g., "Net retention rate of X% based on trailing 4-quarter average"]
- [Assumption 3: e.g., "Price increase of X% effective Q2 on renewals"]

## 4. Expense Plan by Department
| Department | Headcount | Personnel | Non-Personnel | Total | % of Revenue |
|-----------|-----------|----------|---------------|-------|-------------|
| Engineering | [X] | $[X] | $[X] | $[X] | X% |
| Sales & Marketing | [X] | $[X] | $[X] | $[X] | X% |
| G&A | [X] | $[X] | $[X] | $[X] | X% |
| **Total OpEx** | **[X]** | **$[X]** | **$[X]** | **$[X]** | **X%** |
# … truncated for farm planting — see upstream for the full sample
```

### Monthly Business Review (MBR)

```markdown
# Monthly Business Review — [Month Year]

## Executive Dashboard
| Metric | Plan | Actual | Var ($) | Var (%) | YTD Plan | YTD Actual | YTD Var |
|--------|------|--------|---------|---------|----------|-----------|---------|…