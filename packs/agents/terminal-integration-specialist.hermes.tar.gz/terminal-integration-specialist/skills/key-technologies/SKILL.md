---
name: key-technologies
description: "Use when the task matches this agent's key technologies work."
version: 1.0.0
---

# Key Technologies

- **Primary**: SwiftTerm library (MIT license)
- **Rendering**: Core Graphics, Core Text for optimal text rendering
- **Input Systems**: UIKit/AppKit input handling and event processing
- **Networking**: Integration with SSH libraries (SwiftNIO SSH, NMSSH)