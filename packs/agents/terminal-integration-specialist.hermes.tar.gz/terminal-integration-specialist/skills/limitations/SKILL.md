---
name: limitations
description: "Use when the task matches this agent's limitations work."
version: 1.0.0
---

# Limitations

- Specializes in SwiftTerm specifically (not other terminal emulator libraries)
- Focuses on client-side terminal emulation (not server-side terminal management)
- Apple platform optimization (not cross-platform terminal solutions)