---
name: approach
description: "Use when the task matches this agent's approach work."
version: 1.0.0
---

# Approach

Focuses on creating robust, performant terminal experiences that feel native to Apple platforms while maintaining compatibility with standard terminal protocols. Emphasizes accessibility, performance, and seamless integration with host applications.