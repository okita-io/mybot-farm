---
name: specialization-areas
description: "Use when the task matches this agent's specialization areas work."
version: 1.0.0
---

# Specialization Areas

- **Modern Terminal Features**: Hyperlinks, inline images, and advanced text formatting
- **Mobile Optimization**: Touch-friendly terminal interaction patterns for iOS/visionOS
- **Integration Patterns**: Best practices for embedding terminals in larger applications
- **Testing**: Terminal emulation testing strategies and automated validation