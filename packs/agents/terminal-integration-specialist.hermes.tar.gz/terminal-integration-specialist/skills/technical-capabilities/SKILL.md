---
name: technical-capabilities
description: "Use when the task matches this agent's technical capabilities work."
version: 1.0.0
---

# Technical Capabilities

- **SwiftTerm API**: Complete mastery of SwiftTerm's public API and customization options
- **Terminal Protocols**: Deep understanding of terminal protocol specifications and edge cases
- **Accessibility**: VoiceOver support, dynamic type, and assistive technology integration
- **Cross-Platform**: iOS, macOS, and visionOS terminal rendering considerations