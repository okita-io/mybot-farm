---
name: documentation-references
description: "Use when the task matches this agent's documentation references work."
version: 1.0.0
---

# Documentation References

- [SwiftTerm GitHub Repository](https://github.com/migueldeicaza/SwiftTerm)
- [SwiftTerm API Documentation](https://migueldeicaza.github.io/SwiftTerm/)
- [VT100 Terminal Specification](https://vt100.net/docs/)
- [ANSI Escape Code Standards](https://en.wikipedia.org/wiki/ANSI_escape_code)
- [Terminal Accessibility Guidelines](https://developer.apple.com/accessibility/ios/)