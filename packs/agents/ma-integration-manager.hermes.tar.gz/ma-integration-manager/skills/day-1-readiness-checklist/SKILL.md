---
name: day-1-readiness-checklist
description: "Use when the task matches this agent's day 1 readiness checklist work."
version: 1.0.0
---

# Day 1 Readiness Checklist

Legal & Regulatory
- [ ] Regulatory approvals confirmed (antitrust, CFIUS, sector-specific)
- [ ] Legal entity formation/transfer documents executed
- [ ] Business licenses transferred or re-filed
- [ ] Contracts requiring third-party consent (change of control) addressed
- [ ] IP assignments completed

### People & HR
- [ ] Offer letters or employment confirmations sent (if required by jurisdiction)
- [ ] Benefits enrollment windows communicated
- [ ] Payroll cutover confirmed; first pay cycle after close verified
- [ ] Organization charts published (to the extent permissible)
- [ ] All-hands communication from CEO delivered on Day 1
- [ ] Manager talking points distributed pre-close
- [ ] Key talent retention agreements executed (if applicable)

### Finance & Systems
- [ ] Bank accounts and payment rails confirmed
- [ ] Financial close process for combined entity defined
- [ ] Intercompany billing mechanism in place (if separate entities post-close)
- [ ] ERP access granted to transition teams
- [ ] Insurance policies updated to cover combined entity
- [ ] Accounts payable and receivable continuity confirmed

### IT & Systems
- [ ] Email domain and directory confirmed (Day 1 email access)
- [ ] VPN / remote access provisioned for integration team
- [ ] Critical system access granted (ERP, CRM, HRIS)
- [ ] Data security protocols extended to target systems
- [ ] Day 1 IT helpdesk support model confirmed

### Customers & Commercial
- [ ] Customer notification letters prepared and approved
- [ ] Sales team briefed on messaging and FAQ
- [ ] Key account calls scheduled with relationship owners
- [ ] Customer-facing contracts reviewed for change-of-control clauses
- [ ] Support continuity confirmed (phone, email, ticketing)

### Communications
- [ ] Internal announcement: employees (CEO all-hands)
- [ ] External announcement: press release, website update
- [ ] Investor / analyst communication (if public company)
- [ ] Supplier and partner notifications
- [ ] Social media posts scheduled

---