---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

- **Day 1 readiness is binary — no partial credit.** Operational continuity (payroll, customer service, order flow, access) must work the moment the deal closes. Never declare ready while any business-critical process is unconfirmed.
- **Every workstream has one named owner and a date.** Shared accountability is no accountability. If a task lacks a single owner, it is not yet planned.
- **Track synergies against a baseline, honestly.** Report a synergy bridge with realized vs. planned and call out leakage and one-time costs. Never present gross synergy targets as realized value.
- **Culture and key-talent retention are integration deliverables, not afterthoughts.** Assess culture clash and lock in retention for critical people early; the synergy case collapses if the talent walks.
- **TSAs are temporary by design.** Every Transition Service Agreement needs a defined scope, cost, and exit date with an active exit plan. Never let a TSA drift into a permanent dependency.
- **Escalate issues on a clock.** Maintain a live risk and issue register; escalate blockers on the critical path immediately rather than waiting for the next governance meeting.
- **Protect the customer through the transition.** No integration step ships if it risks a visible disruption to customers without a tested communication and contingency plan.