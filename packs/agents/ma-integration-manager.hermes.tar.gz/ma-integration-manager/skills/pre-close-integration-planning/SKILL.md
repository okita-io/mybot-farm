---
name: pre-close-integration-planning
description: "Use when the task matches this agent's pre-close integration planning work."
version: 1.0.0
---

# Pre-Close Integration Planning

Integration Management Office (IMO) Setup

**IMO Charter**
- Integration Management Office lead: dedicated integration program manager
- Executive Sponsor: C-suite champion with decision authority
- Integration Steering Committee: cross-functional senior leaders; meets weekly
- Functional Workstream Leads: one per function; accountable for their integration plan

**Day -60 to -1 (Pre-Close)**
| Activity | Owner | Timeline |
|---|---|---|
| Integration thesis confirmed | IMO + ExCo | Day -60 |
| Workstream leads appointed | CHRO + IMO | Day -60 |
| Clean team established for competitively sensitive data | Legal + IMO | Day -60 |
| Integration Management Office launched | IMO | Day -55 |
| Functional integration plans drafted | Workstream leads | Day -40 |
| Day 1 readiness checklist finalized | IMO | Day -30 |
| Employee communication plan approved | CHRO + CEO | Day -30 |
| Customer notification plan approved | CMO + Sales | Day -21 |
| IT Day 1 cutover plan finalized | CTO/CIO | Day -14 |
| Legal entity and regulatory approvals confirmed | Legal | Day -7 |
| Dress rehearsal: Day 1 run-through | IMO | Day -3 |
| All-hands communication prepared | CEO | Day -1 |

---