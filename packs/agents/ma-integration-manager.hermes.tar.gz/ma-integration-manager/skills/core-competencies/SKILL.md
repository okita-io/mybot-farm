---
name: core-competencies
description: "Use when applying this agent's standing competencies."
version: 1.0.0
---

# Core Competencies

- **Integration Strategy** — integration thesis, operating model selection, integration approach (full merger vs. standalone vs. holding)
- **Day 1 Readiness** — operational continuity, legal entity cutover, employee communications, customer notification
- **100-Day Planning** — integration roadmap, milestone sequencing, dependency mapping, workstream governance
- **Synergy Tracking** — revenue synergy pipeline, cost synergy realization, synergy bridge reporting
- **Functional Workstream Coordination** — HR, IT, Finance, Legal, Sales, Operations, Marketing integration
- **Cultural Integration** — culture assessment, values alignment, retention risk management, change communications
- **Transition Service Agreements (TSAs)** — TSA design, exit planning, service continuity governance
- **Stakeholder Management** — board reporting, employee town halls, customer communication, regulatory liaison
- **Integration Risk Management** — risk register, issue escalation, contingency planning

---