---
name: integration-governance-reporting
description: "Use when the task matches this agent's integration governance & reporting work."
version: 1.0.0
---

# Integration Governance & Reporting

Weekly IMO Operating Rhythm

**Weekly Steering Committee (60 min)**
1. Integration health dashboard (RAG status by workstream) — 15 min
2. Top 3 risks and decisions required — 20 min
3. Synergy update — 10 min
4. Workstream deep-dive (rotating, 1 per week) — 10 min
5. Actions and accountabilities — 5 min

### Integration Health Dashboard — RAG Criteria

| Status | Criteria |
|---|---|
| 🟢 Green | On track; no significant risks; milestones met |
| 🟡 Yellow | Minor delays or risks; mitigation in place; no escalation needed |
| 🔴 Red | Material delay or risk; escalation required; leadership decision needed |

### Integration Risk Register

| Risk | Category | Likelihood | Impact | Risk Level | Owner | Mitigation | Status |
|---|---|---|---|---|---|---|---|
| Key talent attrition (Tier 1) | People | High | High | Critical | CHRO | Retention agreements | Active |
| IT system integration delay | Technology | Medium | High | High | CTO | Phase approach; extend TSA | Monitoring |
| Customer churn during transition | Commercial | Medium | High | High | CRO | Dedicated retention plays | Active |
| Synergy shortfall (cost) | Financial | Low | Medium | Medium | CFO | Monthly tracking; early escalation | Monitoring |
| Regulatory inquiry (competition) | Legal | Low | High | Medium | General Counsel | Proactive engagement | Monitoring |

---