---
name: cultural-integration-framework
description: "Use when the task matches this agent's cultural integration framework work."
version: 1.0.0
---

# Cultural Integration Framework

Culture Assessment Protocol

**Step 1 — Baseline Both Cultures**
Survey both organizations on:
- Decision-making style (centralized vs. decentralized; fast vs. deliberate)
- Communication norms (formal vs. informal; top-down vs. collaborative)
- Risk tolerance (innovative vs. conservative)
- Work style (individual vs. team; competitive vs. collaborative)
- Customer orientation (internal process vs. customer-first)
- Values alignment (what behaviors are rewarded?)

**Step 2 — Culture Gap Analysis**
Map differences on each dimension. Identify:
- Complementary strengths (where differences are additive)
- Collision points (where differences will create conflict)
- Non-negotiables (values or behaviors that cannot change)

**Step 3 — Integration Culture Design**
Define the target culture explicitly. Answer:
- Which practices from each organization will we adopt?
- What is the combined values statement?
- What new rituals and behaviors will signal the new culture?
- How will leaders model the target culture?

**Step 4 — Culture Integration Execution**
| Initiative | Owner | Timeline | Success Metric |
|---|---|---|---|
| Leadership alignment sessions | CEO + CHRO | Month 1 | 90% leadership alignment score |
| All-hands culture workshops | CHRO | Month 2–3 | 80% participation |
| Manager toolkit deployment | CHRO | Month 2 | 100% manager coverage |
| Recognition program redesign | CHRO | Month 3 | Programs reflect combined values |
| 6-month culture pulse survey | CHRO | Month 6 | Benchmark vs. baseline |

### Talent Retention Strategy

**Retention Risk Tiering**
| Tier | Criteria | Retention Action |
|---|---|---|
| Tier 1 — Critical | Key to synergy delivery; hard to replace; flight risk | Retention agreement; accelerated vesting; 1:1 CEO/sponsor engagement |
| Tier 2 — Important | Significant knowledge; moderate flight risk | Manager engagement; career path discussion; targeted recognition |
| Tier 3 — Standard | Valuable but replaceable; low flight risk | Standard communication; team engagement |

**Common Retention Risks Post-M&A**
- Role ambiguity (people don't know where they fit)
- Perceived culture clash (acquirer seen as "winning")
- Compensation / title uncertainty
- Loss of equity upside (accelerated vesting on change of control)
- Reporting structure changes (loss of manager relationships)

---