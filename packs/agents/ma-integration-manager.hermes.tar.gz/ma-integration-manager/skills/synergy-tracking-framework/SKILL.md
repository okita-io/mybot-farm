---
name: synergy-tracking-framework
description: "Use when the task matches this agent's synergy tracking framework work."
version: 1.0.0
---

# Synergy Tracking Framework

Synergy Categories

**Cost Synergies**
| Category | Description | Typical Realization |
|---|---|---|
| Headcount reduction | Elimination of duplicate roles | 3–12 months |
| Vendor consolidation | Renegotiate / eliminate duplicate contracts | 3–18 months |
| Facility consolidation | Office / warehouse / data center overlap | 6–24 months |
| Procurement savings | Combined purchasing power | 6–18 months |
| IT decommissioning | Retire redundant systems | 12–36 months |

**Revenue Synergies**
| Category | Description | Typical Realization |
|---|---|---|
| Cross-sell | Sell acquirer's products to target's customers | 6–24 months |
| Geographic expansion | Enter new markets via target's presence | 12–36 months |
| New product development | Combined R&D / capabilities | 18–48 months |
| Pricing optimization | Premium positioning via combined brand | 12–24 months |

### Synergy Tracking Report Template

```
SYNERGY TRACKER — [Month] [Year]
Reporting Period: [Date Range]

TOTAL SYNERGY SUMMARY
                    Deal Model    Revised Target    YTD Actual    Run-Rate
Cost Synergies:     $[X]M         $[X]M             $[X]M         $[X]M
Revenue Synergies:  $[X]M         $[X]M             $[X]M         $[X]M
TOTAL:              $[X]M         $[X]M             $[X]M         $[X]M

COST SYNERGY DETAIL
Initiative          | Owner | Deal Model | Revised | YTD Actual | Status
Headcount reduction | CHRO  | $[X]M      | $[X]M   | $[X]M      | On track / At risk / Behind
Vendor consol.      | CPO   | $[X]M      | $[X]M   | $[X]M      | On track / At risk / Behind

REVENUE SYNERGY PIPELINE
Initiative          | Owner | Deal Model | Pipeline | Closed | Status
Cross-sell [product]| CRO   | $[X]M      | $[X]M    | $[X]M  | On track / At risk / Behind

TOP 3 RISKS TO SYNERGY PLAN:
1. [Risk] — [Owner] — [Mitigation]
2. [Risk] — [Owner] — [Mitigation]
3. [Risk] — [Owner] — [Mitigation]
```

---