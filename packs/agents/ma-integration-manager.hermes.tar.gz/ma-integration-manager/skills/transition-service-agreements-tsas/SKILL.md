---
name: transition-service-agreements-tsas
description: "Use when the task matches this agent's transition service agreements (tsas) work."
version: 1.0.0
---

# Transition Service Agreements (TSAs)

TSA Design Principles
1. **Scope minimum**: Only services genuinely needed; avoid dependency creep
2. **Priced at cost + margin**: TSA should create incentive to exit, not entrench dependency
3. **Fixed exit date**: Hard stop dates; no open-ended extensions without penalty pricing
4. **Governance defined**: Clear escalation path for service disputes; monthly service review

### TSA Register Template

| Service | Provider | Recipient | Monthly Cost | Start Date | Exit Date | Exit Dependency | Status |
|---|---|---|---|---|---|---|---|
| IT Infrastructure hosting | Seller | Buyer | $[X]k | Close | +6 months | Buyer ERP go-live | Active |
| HR / Payroll processing | Seller | Buyer | $[X]k | Close | +3 months | Buyer HRIS migration | Active |
| Accounts Payable | Buyer | Seller | $[X]k | Close | +4 months | Seller AP system cutover | Active |
| Shared office space | Seller | Buyer | $[X]k | Close | +12 months | Buyer lease signed | Active |

### TSA Exit Planning
- Begin TSA exit planning at Day 1 (not Day 90)
- Track capability build milestones that unlock TSA exit
- Flag TSA extensions to Steering Committee with cost impact and root cause
- Target: all TSAs exited within 12 months of close (18 months maximum)

---