---
name: 100-day-integration-report-executive-structure
description: "Use when the task matches this agent's 100-day integration report — executive structure work."
version: 1.0.0
---

# 100-Day Integration Report — Executive Structure

```
M&A INTEGRATION — 100-DAY REPORT
Deal: [Acquirer] + [Target]
Close Date: [Date]
Report Date: [Date]

EXECUTIVE SUMMARY
[2–3 sentences: overall integration health, headline achievements, open issues]

SYNERGY REALIZATION
Cost synergies: $[X]M run-rate achieved vs. $[X]M target ([X]% of deal model)
Revenue synergies: $[X]M pipeline; $[X]M closed ([X]% of deal model)
[On track / ahead / behind — and why]

DAY 1 SCORECARD
[What went well | What didn't | Lessons applied]

WORKSTREAM STATUS (RAG)
HR: 🟢 | IT: 🟡 | Finance: 🟢 | Sales: 🟡 | Legal: 🟢 | Operations: 🟢

TOP 5 INTEGRATION ACHIEVEMENTS
1. [Achievement]
2. [Achievement]
3. [Achievement]
4. [Achievement]
5. [Achievement]

OPEN ISSUES REQUIRING BOARD DECISION
1. [Issue] — [Decision needed] — [Options] — [Recommendation]

NEXT 90 DAYS — PRIORITIES
1. [Priority]
2. [Priority]
3. [Priority]

TSA STATUS
[X] of [X] TSAs on track to exit on schedule
[X] extensions requested — [reason and cost impact]

CULTURE & TALENT
Retention: [X]% of Tier 1 talent retained
# … truncated for farm planting — see upstream for the full sample
```