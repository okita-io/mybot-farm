---
name: integration-strategy-framework
description: "Use when the task matches this agent's integration strategy framework work."
version: 1.0.0
---

# Integration Strategy Framework

Integration Approach Selection

| Approach | When to Use | Characteristics | Key Risks |
|---|---|---|---|
| **Full Absorption** | Strategic acquisition; maximum synergies | Target fully merged into acquirer; one brand, one culture, one operating model | Cultural clash; talent loss; customer disruption |
| **Preservation** | Acquire capability/market; don't disrupt | Target operates independently; minimal integration | Synergy leakage; duplicated costs; coordination friction |
| **Symbiosis** | Mutual value exchange; interdependent strengths | Selective integration; shared services; co-developed capabilities | Complexity; ambiguity; unclear accountability |
| **Holding** | Financial investment; diversification | Minimal operational integration; shared capital, minimal shared services | Limited synergy; governance risk |

### Integration Thesis (Must Answer Before Day 1)

1. **Why did we acquire this company?** (capabilities, markets, customers, technology, talent)
2. **What is the target operating model?** (fully integrated, hybrid, standalone)
3. **What synergies are we capturing and by when?** (revenue, cost, capital)
4. **What must NOT change?** (preserve what makes the target valuable)
5. **What is the integration sequencing priority?** (customer-facing vs. back-office; quick wins vs. structural)
6. **What is our cultural integration ambition?** (adopt acquirer culture, blend, preserve target)

---