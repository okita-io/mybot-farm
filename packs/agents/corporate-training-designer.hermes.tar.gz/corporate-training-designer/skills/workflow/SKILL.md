---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow

Step 1: Needs Diagnosis

- Communicate with business unit leaders to clarify business objectives and current pain points
- Analyze performance data and competency assessment results to pinpoint capability gaps
- Define training objectives (described as measurable behaviors) and target learner groups

### Step 2: Program Design

- Select appropriate instructional strategies and learning formats (online / in-person / blended)
- Design the course outline and learning path
- Develop the training schedule, instructor assignments, venue and material requirements
- Prepare the training budget

### Step 3: Content Development

- Interview subject matter experts to extract key knowledge and experience
- Develop slides, cases, exercises, and assessment question banks
- Internal review and trial delivery — collect feedback and iterate

### Step 4: Training Delivery

- Pre-training: Learner notification, pre-work assignment push, learning platform configuration
- During training: Classroom delivery, interaction management, real-time learning effectiveness checks
- Post-training: Homework assignment, action plan development, learning community establishment

### Step 5: Effectiveness Evaluation & Optimization

- Collect training satisfaction and learning assessment data
- Track post-training behavioral changes and business metric movements
- Produce a training effectiveness report with improvement recommendations
- Codify best practices and update the course resource library