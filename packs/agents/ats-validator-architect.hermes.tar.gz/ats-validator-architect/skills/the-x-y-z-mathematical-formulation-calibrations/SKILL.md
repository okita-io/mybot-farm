---
name: the-x-y-z-mathematical-formulation-calibrations
description: "Use when the task matches this agent's the x-y-z mathematical formulation & calibrations work."
version: 1.0.0
---

# The X-Y-Z Mathematical Formulation & Calibrations

1. Core Bullet Scoring Equation

Every career bullet is deconstructed into:
$$\text{"Accomplished [X], measured by [Y], by doing [Z]"}$$

Its algorithmic score is calculated as:
$$S_{\text{bullet}} = \left( w_X \cdot S_X + w_Y \cdot S_Y + w_Z \cdot S_Z \right) - P$$

Where:
- $w_X = 0.25$ (Weight of Action Verb & Scope, $S_X \in [0, 100]$)
- $w_Y = 0.45$ (Weight of Quantifiable Metric & Business Outcome, $S_Y \in [0, 100]$)
- $w_Z = 0.30$ (Weight of Method, Architecture & Technical Tooling, $S_Z \in [0, 100]$)
- $P \ge 0$ (Accumulated Deductions / Penalties)

### 2. Penalty Matrix ($P$)

| Penalty Condition | Deduction ($P$) | Trigger Criteria |
| :--- | :---: | :--- |
| **Passive Voice / Duty Statement** | **$-40$ pts** | Bullet starts with *"Responsible for"*, *"Assisted in"*, *"Helped to"*, *"Worked on"*, *"Participated in"*. |
| **Vanity Metric / Unanchored Number** | **$-20$ pts** | Number present without business context (e.g., *"Attended 50 meetings"*, *"Wrote 1,000 lines of code"*). |
| **Verbosity / Cognitive Overload** | **$-25$ pts** | Bullet length exceeds 35 words without semantic punctuation, causing recruiter skim fatigue. |
| **Repetitive Action Verbs** | **$-15$ pts** | The same leading action verb (e.g., *"Developed"*) repeated in $\ge 3$ consecutive bullets. |

### 3. Seniority Target Ratios

Seniority levels require different proportions of X-Y-Z formulation versus systemic narrative:

| Seniority Tier | Experience | Target X-Y-Z Ratio | Target Contextual / Systemic Ratio | Strategic Focus |
| :--- | :---: | :---: | :---: | :--- |
| **Junior / Entry** | 0–2 years | **70%** | 30% | Task execution, velocity, foundational stack mastery. |
| **Mid-Level** | 3–5 years | **80%** | 20% | Feature ownership, optimization, throughput, autonomous delivery. |
| **Senior** | 6–9 years | **85%** | 15% | Architecture, latency reduction, cost savings, mentoring, scale. |
| **Staff / Principal** | 10+ years | **60%** | 40% | Cross-org initiatives, architectural standards, technical vision. |
| **Executive / VP** | 15+ years | **50%** | 50% | P&L ownership, org design, governance, enterprise risk mitigation. |

### 4. Regex Guards & Disambiguation Rules

To prevent false positives when identifying metrics ($Y$):
- **Exclude Software Versions**: `/(?:Python|Java|Angular|Node|React|v)\s*\d+(?:\.\d+)+/i` must NOT count as a numerical impact metric.
- **Exclude Network Ports & Protocols**: `/\b(?:Port\s*\d{2,5}|HTTP\s*[1-5]\d{2}|IPv[46])\b/i` must NOT count as a metric.
- **Exclude Regulatory & Compliance Standards**: `/\b(?:ISO\s*\d{4,5}|SOC\s*[123]|RFC\s*\d{3,5})\b/i` must NOT count as a metric.
- **Include Binary Impact True Positives**: Recognize high-impact non-numeric achievements:
  `/\b(?:zero\s+(?:downtime|day\s+vulnerabilit(?:y|ies)|data\s+loss)|first-ever|from\s+scratch|patent\s+granted)\b/i`.