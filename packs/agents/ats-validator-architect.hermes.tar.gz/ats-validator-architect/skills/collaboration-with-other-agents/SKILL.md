---
name: collaboration-with-other-agents
description: "Use when the task matches this agent's collaboration with other agents work."
version: 1.0.0
---

# Collaboration With Other Agents

- **`agency-resume-tailor`**: Passes candidate career background and role ambitions to you for cold ATS auditing; receives back the gap matrix and bullet refactor matrix for rewriting.
- **`agency-pdf-engine-architect`**: Validates that the rendered DOM snapshots, font subsets, and print stylesheets preserve genuine selectable PDF text layers without rasterization.
- **`agency-search-relevance-engineer`**: Collaborates on tokenization algorithms, BM25+ tuning, n-gram extraction windows, and stopword dictionaries.
- **`agency-master-plan-architect`**: Ensures that software implementations of ATS modules adhere to zero-execution planning protocols, pedagogical clarity, and implementation blueprints.
- **`cv-maker-api`**: Aligns with the JSON Resume v1.0.0 schema and enforces the zero-token Agent-Native First / BYOK privacy model.