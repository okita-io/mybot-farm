---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

```
[ Step 1: Ingestion & Text Layer / PUA Audit ]
                   │
                   ▼
[ Step 2: Structural Geometry & Linearization Check ]
                   │
                   ▼
[ Step 3: Stopword Filtering & Lexical BM25 Keyword Mapping ]
                   │
                   ▼
[ Step 4: Calibrated X-Y-Z Bullet Scoring with Regex Guards ]
                   │
                   ▼
[ Step 5: Scorecard Generation & Agent-Native Handoff ]
```

### Step 1: Ingestion & Text Layer / PUA Audit
1. Ingest raw resume content (YAML, JSON Resume v1.0.0, plain text, or serialized HTML/DOM).
2. Validate that the text stream contains genuine Unicode characters. Run the PUA trap regex (`/[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u{100000}-\u{10FFFD}]/u`).
3. If rasterized canvas or corrupted fonts are detected, abort and require vector/true-text regeneration.

### Step 2: Structural Geometry & Linearization Check
1. Audit section hierarchy: Contact (`basics`), Summary (`summary`), Experience (`work`), Education (`education`), Skills (`skills`).
2. Verify reading-order serialization: confirm that sidebars serialize sequentially before or after core experience, never interleaved.
3. Validate reading density: assert that total word count falls within optimal windows (350–650 words for 1 page; 650–1,100 words for 2 pages).

### Step 3: Stopword Filtering & Lexical BM25 Keyword Mapping
1. Tokenize text into lowercase tokens, filter multilingual stopwords (Portuguese, English, Spanish), and extract unigrams, bigrams, and trigrams.
2. If Job Description is supplied, compute lexical frequency and identify keyword gaps.
3. If no Job Description is supplied, match against preloaded technical ontologies (>170 canonical industry competencies).

### Step 4: Calibrated X-Y-Z Bullet Scoring with Regex Guards
1. Deconstruct all work experience bullets.
2. Apply regex filters for strong past-tense action verbs, metric anchors (excluding version numbers and port numbers), and technical context.
3. Calculate score per bullet: $S = (0.25 S_X + 0.45 S_Y + 0.30 S_Z) - P$.
4. Check whether the proportion of X-Y-Z bullets meets the candidate's seniority target ratio.

### Step 5: Scorecard Generation & Agent-Native Handoff
1. Compute aggregate weighted score:
   $$\text{Overall Score} = (\text{Keywords} \times 0.40) + (\text{XYZ} \times 0.30) + (\text{Structure} \times 0.15) + (\text{Density} \times 0.15)$$
2. Assign executive letter grades ($A+, A, B, C, D$).
3. Output the 5 Standard Technical Deliverables.
4. Export the Agent-Native prompt for candidate BYOK LLM refactoring.