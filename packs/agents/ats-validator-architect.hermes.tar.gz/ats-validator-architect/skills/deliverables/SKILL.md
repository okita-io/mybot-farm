---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

When performing an ATS audit or designing an ATS validation engine, you must produce the following standardized artifacts:

### Deliverable 1: The ATS Compliance Scorecard

```markdown
# 🎯 ATS Compliance Audit Scorecard: [Role Title]
**Candidate**: [Candidate Name] | **Target Seniority**: [Junior / Mid / Senior / Staff / Executive]
**Overall ATS Score**: [Score]/100 (Grade: [A+ / A / B / C / D])
**Legal Audit Safe Harbor**: COMPLIANT (Deterministic 4-Pillar Arithmetic, Zero Protected Attribute Proxy)

| Pillar | Weight | Score | Health Status | Key Finding |
| :--- | :---: | :---: | :---: | :--- |
| **1. Keywords & Hard Skills** | 40% | [0-100]% | 🟢/🟡/🔴 | [X of Y core technical competencies detected] |
| **2. Google/IBM X-Y-Z Impact** | 30% | [0-100]% | 🟢/🟡/🔴 | [X% of bullets contain verified metrics; Seniority target: Z%] |
| **3. Structural Parseability** | 15% | [0-100]% | 🟢/🟡/🔴 | [Clean single-column flow, standard headers, no PUA traps] |
| **4. Reading Density & Volume** | 15% | [0-100]% | 🟢/🟡/🔴 | [[Word Count] words — optimal window for [1/2] page(s)] |
```

### Deliverable 2: Structural & Layout Linearization Audit

```markdown
## 🏛️ Layout Linearization & Parsing Diagnostics

| Checkpoint | Status | Risk Level | Diagnostic / Remediation |
| :--- | :---: | :---: | :--- |
| **Text Layer Selectability** | PASS / FAIL | HIGH | Verifies real Unicode text stream operators (Tj/TJ) vs rasterized canvas. |
| **Font CMap & PUA Check** | PASS / FAIL | CRITICAL | Asserts absence of Private Use Area glyphs (\uE000-\uF8FF) or replacement \uFFFD. |
| **Column Reading Order** | PASS / WARN | CRITICAL | Verifies whether left/right columns serialize sequentially or scramble in scanline sort. |
| **Section Standardization** | PASS / WARN | MEDIUM | Checks for canonical headings (`Experience`, `Education`, `Skills`, `Projects`). |
| **Contact Hygiene** | PASS / FAIL | HIGH | Validates RFC-compliant email, standardized phone, and clean clickable links. |
| **Tables & Floating Elements** | PASS / FAIL | HIGH | Flags any nested HTML/PDF tables or unanchored text boxes used for layout. |
```

### Deliverable 3: Keyword & Hard Skills Gap Matrix

```markdown
## 🔍 Semantic Keyword Alignment

### ✅ Supported Competencies (Detected in CV)
- `[Tool/Skill 1]`: Found in [Section Name] (Frequency: [N], Exact Match)
- `[Tool/Skill 2]`: Found in [Section Name] (Frequency: [N], Exact Match)

### ⚠️ Critical Missing Keywords (Job Description Gaps)
- `[Missing Tool/Skill 1]`: High Priority (Appears [N] times in JD). Recommendation: [Add if verified in user background].
- `[Missing Tool/Skill 2]`: Medium Priority (Appears [N] times in JD). Recommendation: [Add if verified in user background].

### 💡 Domain Synonyms Recognized
- `[Resume Term]` ➔ Recognized as equivalent to `[JD Term]` via standardized ontology (e.g. K8s ➔ Kubernetes).
```

### Deliverable 4: Bullet Rewrite & Impact Matrix (X-Y-Z)

```markdown
## ⚡ Google/IBM X-Y-Z Bullet Refactor Matrix

| Original Bullet | Impact Classification | Missing Element | Refactored Bullet (X-Y-Z Canônico) |
| :--- | :---: | :--- | :--- |
| "[Original passive text]" | 🔴 Passivo (-40pts) | Verbo + Métrica | "[Action Verb] [Scope/Object], achieving [Quantified Result %/$], utilizing [Tool/Method]." |
| "[Partial text with metric]" | 🟡 Parcial | Contexto Técnico | "[Strong Action Verb] [Scope], resulting in [Metric], through [Method/Tool]." |
| "[Complete X-Y-Z bullet]" | 🟢 X-Y-Z (100pts) | Nenhum | Mantido (Alta Densidade e Impacto Verificado). |
```

### Deliverable 5: Agent-Native Export Prompt

```markdown
## 🤖 Prompt Pronto para Agentes Externos (Claude / ChatGPT / your editor)

```markdown
VOCÊ É O RESUME TAILOR & RECRUITMENT ARCHITECT.
Com base no diagnóstico ATS estruturado abaixo, reescreva os bullets fracos do candidato utilizando estritamente a fórmula Google/IBM X-Y-Z ("Atingiu [X], medido por [Y], fazendo [Z]"), respeitando a meta de senioridade de [Junior/Mid/Senior/Staff].

REQUISITOS DA VAGA:
[Job Description Text]

LACUNAS DE COMPETÊNCIAS IDENTIFICADAS:
[Missing Keywords List]

BULLETS A SEREM REESCRITOS:
[Weak Bullets List]

REGRAS RÍGIDAS:
1. Jamais invente métricas, porcentagens ou ferramentas não confirmadas pelo usuário.
2. Inicie cada bullet com verbo de ação forte no passado (taxonomia de Bloom).
3. Não exceda 30 palavras por bullet (evite sobrecarga cognitiva).
4. Retorne apenas os bullets reescritos formatados em Markdown.
```
```