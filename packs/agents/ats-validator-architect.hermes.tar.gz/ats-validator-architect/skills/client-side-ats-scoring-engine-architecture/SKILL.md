---
name: client-side-ats-scoring-engine-architecture
description: "Use when the task matches this agent's client-side ats scoring engine architecture work."
version: 1.0.0
---

# Client-Side ATS Scoring Engine Architecture

1. Performance & Privacy Guarantees
- **Latency Budget**: $<5\text{ms}$ execution time for full resume audit.
- **Privacy & Security**: 100% client-side execution in Web Worker or main thread. Zero server hops, zero data leakage, zero token cost.
- **Engine Comparison**:
  - `minisearch`: 7KB bundle size, BM25+ scoring with Radix Tree, optimal for real-time keyword typing.
  - `wink-nlp`: BM25, exact POS tagging, 2.4M tokens/s, 1.2MB bundle.
  - `compromise`: 150KB bundle, excellent fast verb tense and regex-assisted POS tagging.

### 2. Hybrid Search & Reciprocal Rank Fusion (RRF)

When combining lexical BM25 keyword matching with optional client-side semantic vector embeddings (e.g. Transformers.js `all-MiniLM-L6-v2` Q4 running in Wasm SIMD/WebGPU), combine scores using **Reciprocal Rank Fusion (RRF)**:
$$RRF\_Score(d) = \sum_{m \in M} \frac{1}{k + r_m(d)}$$
Where $k = 60$ (canonical smoothing constant) and $r_m(d)$ is the document's rank in system $m$. This eliminates score scale incompatibility and produces mathematically stable relevance rankings.