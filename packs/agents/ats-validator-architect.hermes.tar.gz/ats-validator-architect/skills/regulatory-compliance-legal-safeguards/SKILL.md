---
name: regulatory-compliance-legal-safeguards
description: "Use when the task matches this agent's ️ regulatory compliance & legal safeguards work."
version: 1.0.0
---

# ️ Regulatory Compliance & Legal Safeguards

1. EU AI Act (Regulation (EU) 2024/1689)
- **High-Risk Classification**: Under **Annex III, Point 4**, AI systems used in recruitment, screening, candidate evaluation, and job application filtering are classified as **High-Risk AI Systems**.
- **Article 10 (Data & Governance)**: Demands mitigation of biases and representative training data.
- **Article 13 & 14 (Transparency & Human Oversight)**: Systems must provide human-interpretable metrics, enabling recruiters to understand why a candidate received a specific score.
- **Article 86 (Right to Explanation)**: Candidates subjected to automated decision-making have a legally enforceable right to receive clear, meaningful explanations of the assessment criteria.

### 2. NYC Local Law 144 (AEDT Bias Audits)
- Applies to Automated Employment Decision Tools (AEDT) used in New York City.
- Requires annual independent bias audits measuring the **Selection Rate** and **Scoring Rate** across race, ethnicity, and sex.
- **Impact Ratio ($IR$) Calculation**:
  $$IR = \frac{\text{Selection Rate of Protected Group}}{\text{Selection Rate of Highest Performing Group}} \ge 0.80$$
  Under the EEOC **Four-Fifths Rule**, any ratio below $0.80$ constitutes prima facie evidence of disparate impact.

### 3. Legal Precedent: *Mobley v. Workday, Inc.* (2024)
- Federal court held that third-party software vendors providing algorithmic screening tools can be sued directly as "agents" of employers under Title VII, ADA, and ADEA.
- **Safe Harbor Strategy**: Transparent, deterministic client-side scoring rules (which analyze syntax, layout, and explicit keyword presence without proxy variables like zip code, graduation year, or ethnic linguistic markers) protect both candidates and employers from algorithmic bias exposure.