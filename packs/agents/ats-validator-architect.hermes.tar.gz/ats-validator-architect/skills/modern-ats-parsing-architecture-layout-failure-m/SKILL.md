---
name: modern-ats-parsing-architecture-layout-failure-m
description: "Use when the task matches this agent's ️ modern ats parsing architecture & layout failure modes work."
version: 1.0.0
---

# ️ Modern ATS Parsing Architecture & Layout Failure Modes

1. The 6 ATS Ingestion Pipeline Stages

```
[ 1. Ingestion & Preprocessing ]
  ├── PDF Content Stream Extraction (Tj, TJ, Tm)
  └── OCR Fallback (if stream is rasterized)
         │
         ▼
[ 2. Structural Segmentation & Block Classification ]
  ├── Recursive XY-Cut Algorithm (horizontal/vertical projection profiles)
  └── Visual Bounding-Box Grouping
         │
         ▼
[ 3. Reading-Order Linearization ]
  ├── Top-to-bottom, Left-to-right (Scanline Sort)
  └── Multi-Column Disambiguation
         │
         ▼
[ 4. Named Entity Recognition (NER) & Sequence Labeling ]
  ├── Header Parsing (Candidate Name, RFC Email, Phone, LinkedIn)
  └── Work Experience Chunking (Company, Title, Date Range, Bullets)
         │
         ▼
[ 5. Normalization & Taxonomy Mapping ]
  ├── O*NET / ESCO / Custom Industry Ontologies
  └── Acronym Expansion & Synonym Resolution
         │
         ▼
[ 6. Scoring & Candidate Ranking ]
  ├── Deterministic Keyword Recall (BM25+)
  ├── Semantic Hybrid Fusion (RRF k=60)
  └── Knockout Rules (Years of Experience, Degree, Location)
```

### 2. Multi-Column Failure Modes: Scanline Sorting vs. XY-Cut

1. **Scanline Sorting Trap**: Legacy and mid-market parsers divide the page into horizontal bands based on $Y$-coordinates. If a candidate has a left sidebar (Skills, Contact) and a right column (Work Experience), any text on the same horizontal plane is concatenated:
   $$\text{"Skills: Kubernetes, Docker" (Left)} \parallel \text{"Architected cloud platform" (Right)}$$
   $$\Longrightarrow \text{"Skills: Kubernetes, Docker Architected cloud platform"}$$
   This breaks sentence syntax and corrupts both the skill entity and the bullet action verb.
2. **Recursive XY-Cut Trap**: Advanced parsers project white-space valleys horizontally and vertically. If a graphical element (horizontal rule `<hr>`, table border, or full-width banner) intersects the gutter, or if the gutter between columns is $<12\text{pt}$ ($16\text{px}$), the vertical cut fails, causing the parser to treat the two columns as a single column.
3. **The Solution**: Maintain a single-column layout or ensure that all multi-column visual presentations are rendered from a strictly sequential, single-column DOM stream where columns are visual CSS grids that serialize linearly.

### 3. Font Encoding & Private Use Area (PUA) Traps

- When fonts are subsetted during PDF compilation without embedding a `/ToUnicode` CMap dictionary, character codes map to arbitrary internal glyph indices or Unicode Private Use Area (PUA) codepoints (`\uE000`–`\uF8FF`).
- **Detection Regex**:
  ```typescript
  const PUA_REGEX = /[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u{100000}-\u{10FFFD}]/u;
  ```
  If detected in the extracted text stream, the document is corrupted and will be unsearchable in Workday/Taleo.