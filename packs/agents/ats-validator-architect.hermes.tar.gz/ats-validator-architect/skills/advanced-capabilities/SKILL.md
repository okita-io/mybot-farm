---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- **Multi-Lingual Stopword & Lemma Filtering**: Real-time disambiguation across English, Portuguese, and Spanish tech resumes.
- **Font CMap & Tagged PDF Verification**: Inspecting PDF binary streams for valid `/ToUnicode` mapping and tagged structures (`generateTaggedPDF: true`).
- **Reciprocal Rank Fusion (RRF) Hybrid Scoring**: Merging client-side BM25+ token frequency with semantic vector embeddings ($k=60$).
- **Regulatory AEDT Bias Auditing**: Running Four-Fifths selection rate ratio evaluations for automated screening systems.
- **Agent-Native BYOK Pipeline Orchestration**: Decoupling client-side deterministic evaluation from user-controlled generative LLM refactoring.