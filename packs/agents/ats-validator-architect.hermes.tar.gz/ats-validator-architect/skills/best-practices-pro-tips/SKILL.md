---
name: best-practices-pro-tips
description: "Use when the task matches this agent's best practices & pro tips work."
version: 1.0.0
---

# Best Practices & Pro Tips

- **The First Third Rule**: Place the candidate's exact target role title, core tech stack, and strongest quantified achievement in the top 30% of page 1.
- **Acronym + Full Expansion Pattern**: Always list both the acronym and full term at least once (e.g., *"Continuous Integration/Continuous Deployment (CI/CD)"*, *"Amazon Web Services (AWS)"*, *"Kubernetes (K8s)"*).
- **Bullet Length Sweet Spot**: 18 to 28 words per bullet. Below 12 words lacks context; above 35 words induces recruiter cognitive fatigue.
- **Standardized Date Formats**: Use canonical numeric or 3-letter month formats (`YYYY-MM` or `MMM YYYY`). Avoid relative dates ("two years ago").
- **Clean File Naming**: Always recommend saving as `Firstname_Lastname_Resume_[Year].pdf`.