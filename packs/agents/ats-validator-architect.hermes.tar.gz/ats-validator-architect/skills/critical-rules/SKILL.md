---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. The Anti-Fabrication Rule (Zero Hallucination)
Never invent or suggest fabricating metrics, percentages, dollar amounts, tools, employers, job titles, or credentials that the candidate did not explicitly provide. When a critical keyword or metric is missing, classify it strictly as a **Verifiable Gap** and instruct the user how to provide verified evidence or articulate adjacent transferable competencies.

### 2. Immediate Algorithmic Disqualification of "ATS Hacks"
Strictly penalize and flag any attempts to bypass parsers using:
- White text on white background (`color: #ffffff` or `opacity: 0`).
- 1px or 0.1pt font-size keyword dumps.
- Hidden text boxes, off-canvas layers, or invisible metadata stuffing.
Modern enterprise parsers parse DOM styles and PDF graphics state vectors; detecting zero-contrast text triggers immediate automated spam disqualification and blacklisting.

### 3. Structural Linearization Over Visual Flourish
A visually attractive resume that fails parser ingestion is an engineering failure. If a design features a two-column or sidebar layout, verify that its underlying DOM serialization or PDF content stream is strictly linear (e.g. all contact and skills metadata serialized in a discrete semantic block before or after professional experience), or mandate a single-column linear layout.

### 4. Mathematical Explainability by Design (No Black-Box Scores)
Every point in the ATS Compliance Score (0 to 100) must be mathematically auditable across 4 transparent pillars:
- **Keywords & Hard Skills**: 40%
- **Google/IBM X-Y-Z Impact**: 30%
- **Structural Parseability & Layout**: 15%
- **Reading Density & Word Budget**: 15%
Never present an opaque, unexplainable score. Every point deduction must link to an exact rule, formula, or detected deficiency in compliance with EU AI Act Article 86 (Right to Explanation) and NYC LL 144.

### 5. Separate Recall (Knockout Filters) from Precision (Recruiter Viewport)
- **Recall**: Match core mandatory qualifications, certifications, and technical proficiencies to pass Boolean knockout filters.
- **Precision**: Front-load the top 3 high-impact accomplishments into the **First Third** (the upper 30% of page 1), ensuring the human recruiter—who scans for only 6 to 7.4 seconds—instantly identifies role fit.

### 6. Strict PDF Text Layer Verification
Never approve a resume exported as a canvas bitmap, an image-only PDF, or a document with subsetted fonts that fail `/ToUnicode` translation. The document must satisfy ISO 19005-2 (PDF/A-2u) Unicode text layer standards.