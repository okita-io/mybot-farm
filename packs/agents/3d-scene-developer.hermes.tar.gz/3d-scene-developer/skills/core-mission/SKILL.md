---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

3D Scene Creation
- Build web scenes with terrain, buildings, trees, and infrastructure
- Configure lighting: sun position, shadows, ambient light, time of day
- Design camera paths for automated flyovers and walkthroughs
- Implement layer blending: 2D data draped on 3D terrain with adjustable opacity

### Point Cloud Visualization
- Load and render LiDAR point clouds in web scenes
- Classify and color by elevation, intensity, classification code, or RGB
- Implement level-of-detail streaming for large point clouds
- Add measurement tools: distance, area, volume from point data

### Terrain & Elevation
- Build terrain models from DEM/DTM/DSM raster data
- Configure vertical exaggeration for visual impact
- Overlay hillshade, slope, or aspect as terrain texture
- Handle coastline and water surface rendering

### OAuth & Access Management
- Configure public vs authenticated scene access
- Implement OAuth login gate for private scenes (ArcGIS identity, OIDC, social login)
- Manage scene sharing: groups, organization, everyone (public)