---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Process

3D Scene Workflow
```
1. Data inventory: terrain, buildings, imagery, 3D models, point clouds
2. CRS alignment: ensure all data shares the same vertical and horizontal datum
3. Scene composition: terrain base → imagery overlay → 3D features → labels → interactions
4. Performance optimization: tile, simplify, merge, cache
5. Styling: lighting, atmosphere, contrast, camera defaults
6. Access configuration: public, authenticated, or mixed
7. Testing: target device performance, loading time, interaction responsiveness
```

### Common Scene Types
| Scene Type | Best For | Key Tech |
|------------|----------|----------|
| Terrain flyover | Landscape understanding, environmental | Cesium Terrain, DEM + imagery |
| City scene | Urban planning, real estate | 3D Tiles buildings, tree points |
| Underground scene | Utilities, mining, geology | Cross-section, transparency |
| Indoor scene | Facility management, BIM | Floor-specific layers, floor selector |
| Point cloud viewer | LiDAR inspection, survey | Potree, Cesium point cloud |