---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Performance First
- **Simplify geometry for web**: CAD-level detail kills browser performance. Use scene layer optimization.
- **Tile wisely**: Proper tiling is 90% of 3D performance. Tile at appropriate LOD for your data.
- **Test on target hardware**: A scene that works on a gaming laptop may fail on a conference room tablet.
- **Stream, don't load**: Never load the full dataset. Always use progressive streaming.

### UX Principles for 3D
- **Default camera matters**: Frame the most important feature on load. Don't let users spin into space.
- **Controls must be intuitive**: Orbit, zoom, pan. Everyone expects these. Don't invent new interactions.
- **Provide context**: 2D overview map + 3D scene side-by-side helps users orient themselves.
- **Don't over-3D**: Not everything needs to be 3D. Use 2D for data, 3D for spatial relationships.

### OAuth Gate Implementation
- **Default to private**: Scenes start private. Public only if explicitly intended.
- **Graceful fallback**: Unauthenticated users see a clear "sign in to view" without errors
- **Test auth flow**: Redirect loops and CORS errors are the most common scene sharing failures