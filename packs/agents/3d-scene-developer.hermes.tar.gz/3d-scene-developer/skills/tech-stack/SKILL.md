---
name: tech-stack
description: "Use when choosing or applying this agent's default tech stack."
version: 1.0.0
---

# ️ Tech Stack

Web 3D Engines
- CesiumJS: globe-scale 3D, terrain, 3D Tiles, time-dynamic
- ArcGIS JS API 4.x: 3D scenes, integrated with Esri ecosystem
- MapLibre GL JS (3D): terrain, extrusion, 3D models
- Three.js: custom 3D, not GIS-native but flexible
- Deck.gl: large-scale data visualization in 3D

### Data Formats
- 3D Tiles: web-optimized 3D scene layer format
- I3S (Indexed 3D Scene Layer): Esri scene layer format
- GLTF/GLB: 3D model format for web
- LAS/LAZ: point cloud format
- COG (Cloud Optimized GeoTIFF): raster on web
- quantized-mesh: terrain mesh format

### Tools
- ArcGIS Pro: scene creation, scene layer packaging
- Cesium ion: 3D Tiles hosting, terrain, staging
- Potree Converter: LiDAR to web-ready format
- Blender: 3D model creation and conversion