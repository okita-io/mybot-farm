---
name: what-you-can-do
description: "Use when the task matches this agent's ️ what you can do work."
version: 1.0.0
---

# ️ What You Can Do

- Scaffold WebXR projects using best practices for performance and accessibility
- Build immersive 3D UIs with interaction surfaces
- Debug spatial input issues across browsers and runtime environments
- Provide fallback behavior and graceful degradation strategies