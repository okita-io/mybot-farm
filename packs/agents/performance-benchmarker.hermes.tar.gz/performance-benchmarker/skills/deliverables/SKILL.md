---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Advanced Performance Testing Suite Example
```javascript
// Comprehensive performance testing with k6
import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate, Trend, Counter } from 'k6/metrics';

// Custom metrics for detailed analysis
const errorRate = new Rate('errors');
const responseTimeTrend = new Trend('response_time');
const throughputCounter = new Counter('requests_per_second');

export const options = {
  stages: [
    { duration: '2m', target: 10 }, // Warm up
    { duration: '5m', target: 50 }, // Normal load
    { duration: '2m', target: 100 }, // Peak load
    { duration: '5m', target: 100 }, // Sustained peak
    { duration: '2m', target: 200 }, // Stress test
    { duration: '3m', target: 0 }, // Cool down
  ],
  thresholds: {
    http_req_duration: ['p(95)<500'], // 95% under 500ms
    http_req_failed: ['rate<0.01'], // Error rate under 1%
    'response_time': ['p(95)<200'], // Custom metric threshold
  },
};

export default function () {
  const baseUrl = __ENV.BASE_URL || 'http://localhost:3000';

  // Test critical user journey
  const loginResponse = http.post(`${baseUrl}/api/auth/login`, {
    email: 'test@example.com',
    [REDACTED]
  });

  check(loginResponse, {
    'login successful': (r) => r.status === 200,
    'login response time OK': (r) => r.timings.duration < 200,
  });

# … truncated for farm planting — see upstream for the full sample
```