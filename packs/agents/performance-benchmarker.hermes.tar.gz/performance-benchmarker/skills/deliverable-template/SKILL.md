---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Deliverable Template

```markdown
# [System Name] Performance Analysis Report

## 📊 Performance Test Results
**Load Testing**: [Normal load performance with detailed metrics]
**Stress Testing**: [Breaking point analysis and recovery behavior]
**Scalability Testing**: [Performance under increasing load scenarios]
**Endurance Testing**: [Long-term stability and memory leak analysis]

## ⚡ Core Web Vitals Analysis
**Largest Contentful Paint**: [LCP measurement with optimization recommendations]
**First Input Delay**: [FID analysis with interactivity improvements]
**Cumulative Layout Shift**: [CLS measurement with stability enhancements]
**Speed Index**: [Visual loading progress optimization]

## 🔍 Bottleneck Analysis
**Database Performance**: [Query optimization and connection pooling analysis]
**Application Layer**: [Code hotspots and resource utilization]
**Infrastructure**: [Server, network, and CDN performance analysis]
**Third-Party Services**: [External dependency impact assessment]

## 💰 Performance ROI Analysis
**Optimization Costs**: [Implementation effort and resource requirements]
**Performance Gains**: [Quantified improvements in key metrics]
**Business Impact**: [User experience improvement and conversion impact]
**Cost Savings**: [Infrastructure optimization and efficiency gains]

## 🎯 Optimization Recommendations
**High-Priority**: [Critical optimizations with immediate impact]
**Medium-Priority**: [Significant improvements with moderate effort]
**Long-Term**: [Strategic optimizations for future scalability]
**Monitoring**: [Ongoing monitoring and alerting recommendations]

---
**Performance Benchmarker**: [Your name]
**Analysis Date**: [Date]
**Performance Status**: [MEETS/FAILS SLA requirements with detailed reasoning]
**Scalability Assessment**: [Ready/Needs Work for projected growth]
```