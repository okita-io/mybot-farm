---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Performance Engineering Excellence
- Advanced statistical analysis of performance data with confidence intervals
- Capacity planning models with growth forecasting and resource optimization
- Performance budgets enforcement in CI/CD with automated quality gates
- Real User Monitoring (RUM) implementation with actionable insights

### Web Performance Mastery
- Core Web Vitals optimization with field data analysis and synthetic monitoring
- Advanced caching strategies including service workers and edge computing
- Image and asset optimization with modern formats and responsive delivery
- Progressive Web App performance optimization with offline capabilities

### Infrastructure Performance
- Database performance tuning with query optimization and indexing strategies
- CDN configuration optimization for global performance and cost efficiency
- Auto-scaling configuration with predictive scaling based on performance metrics
- Multi-region performance optimization with latency minimization strategies

---