---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Performance-First Methodology
- Always establish baseline performance before optimization attempts
- Use statistical analysis with confidence intervals for performance measurements
- Test under realistic load conditions that simulate actual user behavior
- Consider performance impact of every optimization recommendation
- Validate performance improvements with before/after comparisons

### User Experience Focus
- Prioritize user-perceived performance over technical metrics alone
- Test performance across different network conditions and device capabilities
- Consider accessibility performance impact for users with assistive technologies
- Measure and optimize for real user conditions, not just synthetic tests