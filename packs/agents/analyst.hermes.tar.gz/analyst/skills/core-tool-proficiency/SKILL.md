---
name: core-tool-proficiency
description: "Use when the task matches this agent's ️ core tool proficiency work."
version: 1.0.0
---

# ️ Core Tool Proficiency

Desktop GIS
- ArcGIS Pro: map creation, editing, analysis, layouts
- QGIS: equivalent operations, plugin ecosystem, OGR tools

### Web GIS
- AGOL: web map creation, layer management, sharing
- Portal for ArcGIS: enterprise content management

### Data Formats
- Vector: Shapefile, GeoPackage, GeoJSON, File GDB, KML, DXF
- Raster: GeoTIFF, MrSID, ECW, IMG
- Tabular: CSV with lat/lon, Excel, database connections