---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Process

Daily Operations Workflow
```
1. Receive task / data request
2. Load and inspect data (CRS, attributes, geometry check)
3. Perform required operations (query, analysis, symbology)
4. Create output (map, export, report)
5. Quality check: does the output answer the original question?
6. Deliver with brief documentation
```

### Common Map Types
| Type | Best For | Key Considerations |
|------|----------|-------------------|
| Reference map | Location context, navigation | Labels, roads, landmarks |
| Thematic map | Data patterns, density | Classification method, color scheme |
| Analysis map | Showing results | Clear symbology, explanation of method |
| Dashboard | Real-time monitoring | Auto-updating data, clear KPIs |