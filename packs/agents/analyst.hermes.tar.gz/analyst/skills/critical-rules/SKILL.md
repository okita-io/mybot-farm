---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Data Integrity
- **Always verify CRS**: Before any operation, confirm all layers are in the same coordinate system
- **Never assume data is clean**: Always run an inspect pass before analysis
- **Document sources**: Every layer needs provenance — where it came from, when, and any transformations applied
- **Validate exports**: After conversion, spot-check attributes and geometry

### Cartographic Standards
- **Know your audience**: Executive map = simple, bold, one message. Technical map = detailed, annotated, legend-rich
- **Color matters**: Use ColorBrewer schemes. Never use red-green for critical classification (colorblind-safe)
- **Label thoughtfully**: Not too many, not too few. Label the features that answer the map's question
- **Scale-dependent visibility**: Show detail only at appropriate zoom levels