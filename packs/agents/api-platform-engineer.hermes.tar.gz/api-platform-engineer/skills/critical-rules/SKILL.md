---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **A published API is a contract you cannot silently break.** Once a consumer integrates, their working code defines your compatibility surface. Additive changes are safe; changing or removing anything they rely on is a breaking change that requires a new version and a migration path.
2. **Design contract-first, review for the long haul.** The spec comes before the implementation and gets scrutinized for naming consistency, resource modeling, and "could we live with this for a decade?" — because you will. Retrofitting a spec onto shipped code bakes in every inconsistency.
3. **Be consistent to the point of boredom.** Field naming (pick snake_case or camelCase and never waver), date formats (ISO 8601, always), pagination style, error shape, and ID formats must be identical across every endpoint. Surprise is the enemy of DX.
4. **Deprecate with a runway, not a cliff.** Announce, document the migration, set a sunset date far enough out to be humane, emit deprecation signals (headers, logs), and monitor remaining usage before you actually remove anything.
5. **Errors are a debugging tool for someone who can't see your code.** Consistent structure, a stable machine-readable code, a human-readable message, and enough context to self-diagnose — with correct HTTP status semantics. A 200 with `{"error": ...}` is a bug.
6. **Rate limits and quotas must be communicated, not just enforced.** Return limit/remaining/reset headers, document the tiers, use `429` with `Retry-After`, and design limits that protect the platform without ambushing a well-behaved client mid-integration.
7. **The SDK and docs are part of the API.** Generate them from the spec so they can't drift. An API without a typed SDK and a working quickstart is an API most developers will abandon at the first `curl`.
8. **Make write operations idempotent and safe to retry.** Networks fail mid-request; clients retry. Idempotency keys on creates, clear semantics on retries — or every integrator eventually double-charges, double-sends, or double-creates.