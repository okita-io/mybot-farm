---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Contract-First OpenAPI (the source of truth, reviewed before code)

```yaml
# The spec is the contract. Consistency here is the whole product.
paths:
  /v1/orders:
    post:
      operationId: createOrder
      parameters:
        - { name: Idempotency-Key, in: header, required: true, schema: { type: string } }
      requestBody:
        required: true
        content: { application/json: { schema: { $ref: '#/components/schemas/OrderCreate' } } }
      responses:
        '201': { description: Created, content: { application/json: { schema: { $ref: '#/components/schemas/Order' } } } }
        '429': { description: Rate limited, headers: { Retry-After: { schema: { type: integer } } } }
        default: { description: Error, content: { application/json: { schema: { $ref: '#/components/schemas/Error' } } } }
components:
  schemas:
    Error:                          # ONE error shape, used everywhere — no exceptions
      type: object
      required: [code, message]
      properties:
        code:      { type: string, example: rate_limit_exceeded }  # stable, machine-readable
        message:   { type: string, example: "API rate limit exceeded; retry after 30s" }
        details:   { type: object, description: "Field-level or contextual detail for self-diagnosis" }
        request_id:{ type: string, description: "Echo this to support — traceable on our side" }
```

### Backward-Compatibility Rules (memorize the two columns)

| Safe (additive — no version bump) | Breaking (needs new version + deprecation) |
|-----------------------------------|--------------------------------------------|
| Add a new optional field to a response | Remove or rename a field |
| Add a new endpoint | Change a field's type or format |
| Add a new optional request parameter | Make an optional parameter required |
| Add a new enum value *(if clients tolerate unknowns — document this!)* | Remove an enum value; change default behavior |
| Add a new error `code` within the existing error shape | Change the error response structure or HTTP status meaning |
| Relax a validation constraint | Tighten a validation constraint |

### Versioning & Deprecation Lifecycle

```text
Version strategy: major version in the path (/v1, /v2) for breaking changes only.
Everything backward-compatible ships continuously WITHIN a version — no v1.1 churn.

Deprecation runway (never a cliff):
  1. Announce      — changelog, email to registered developers, migration guide published
  2. Signal        — `Deprecation` + `Sunset` response headers on affected endpoints; log usage
  3. Runway        — a humane window (public APIs: 6–12+ months; measure who's still calling)
  4. Monitor       — track remaining traffic by consumer; reach out to stragglers directly
  5. Sunset        — remove only after usage is near-zero and the date has passed
A breaking change with no migration path and no runway is a broken promise, not a release.
```

### Rate Limiting the Client Can Actually Live With

```http
# Every response tells the client where it stands — no guessing, no ambush
HTTP/1.1 200 OK
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 847
X-RateLimit-Reset: 1720483200

# On breach: 429 with a concrete wait, not a silent drop
HTTP/1.1 429 Too Many Requests
Retry-After: 30
Content-Type: application/json
{ "code": "rate_limit_exceeded", "message": "1000 req/hr exceeded; retry after 30s", "request_id": "req_a1b2" }
```