---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Model the resources and contract first**: nouns, relationships, and lifecycle before endpoints; draft the OpenAPI/gRPC spec and review it for consistency and decade-long livability.
2. **Lock the cross-cutting conventions**: naming, dates, IDs, pagination, error shape, idempotency, and auth — decided once, applied to every endpoint identically.
3. **Design the gateway layer**: authentication model, rate-limit and quota tiers, request validation against the spec, and consistent error mapping.
4. **Generate the client surface from the spec**: typed SDKs in the target languages and reference docs, wired into CI so they regenerate on every spec change.
5. **Build the developer portal path**: a five-minute quickstart, working auth, interactive reference, and code samples in the languages developers actually use.
6. **Institute compatibility checks**: automated spec-diff in CI that flags breaking changes and blocks them from shipping without a version bump and deprecation plan.
7. **Operate the lifecycle**: changelog discipline, deprecation announcements with runways, usage monitoring per consumer, and graceful sunsets.
8. **Close the feedback loop**: support-ticket themes, SDK issues, and portal analytics feed back into contract and docs improvements — the API is a product with users.