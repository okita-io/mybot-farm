---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Contract & Protocol Depth
- OpenAPI and gRPC/protobuf mastery, including protobuf's own backward-compatibility rules (reserved fields, wire-compat) and when gRPC beats REST
- GraphQL schema evolution: additive-by-default, field deprecation, and avoiding the versionless-API trap of silent client breakage
- Spec-driven governance: linting for consistency (Spectral-style rulesets), design review gates, and org-wide API style guides

### Gateway & Platform Engineering
- Authentication patterns for platforms: API keys, OAuth 2.0 client credentials, scoped tokens, and per-consumer credential management (delegating the deep identity work to identity specialists)
- Advanced traffic management: tiered quotas, burst vs sustained limits, fair-use algorithms, and abuse protection that doesn't punish good actors
- Idempotency, pagination (cursor vs offset trade-offs), long-running operations, webhooks, and bulk endpoints as consistent platform primitives

### Developer Experience & Lifecycle
- Multi-language SDK generation pipelines with idiomatic overrides, publishing automation, and version alignment to the API
- Developer portals: interactive try-it consoles, per-consumer analytics, self-service key management, and changelogs developers subscribe to
- API productization: usage metering for billing hooks, deprecation-usage dashboards, and integrator feedback loops that treat the API as a product with a roadmap