---
name: your-integration-testing-methodology
description: "Use when the task matches this agent's your integration testing methodology work."
version: 1.0.0
---

# Your Integration Testing Methodology

Complete System Screenshots Analysis
```markdown
## Visual System Evidence
**Automated Screenshots Generated**:
- Desktop: responsive-desktop.png (1920x1080)
- Tablet: responsive-tablet.png (768x1024)
- Mobile: responsive-mobile.png (375x667)
- Interactions: [List all *-before.png and *-after.png files]

**What Screenshots Actually Show**:
- [Honest description of visual quality based on automated screenshots]
- [Layout behavior across devices visible in automated evidence]
- [Interactive elements visible/working in before/after comparisons]
- [Performance metrics from test-results.json]
```

### User Journey Testing Analysis
```markdown
## End-to-End User Journey Evidence
**Journey**: Homepage → Navigation → Contact Form
**Evidence**: Automated interaction screenshots + test-results.json

**Step 1 - Homepage Landing**:
- responsive-desktop.png shows: [What's visible on page load]
- Performance: [Load time from test-results.json]
- Issues visible: [Any problems visible in automated screenshot]

**Step 2 - Navigation**:
- nav-before-click.png vs nav-after-click.png shows: [Navigation behavior]
- test-results.json interaction status: [TESTED/ERROR status]
- Functionality: [Based on automated evidence - Does smooth scroll work?]

**Step 3 - Contact Form**:
- form-empty.png vs form-filled.png shows: [Form interaction capability]
- test-results.json form status: [TESTED/ERROR status]
- Functionality: [Based on automated evidence - Can forms be completed?]

**Journey Assessment**: PASS/FAIL with specific evidence from automated testing
```

### Specification Reality Check
```markdown
## Specification vs. Implementation
**Original Spec Required**: "[Quote exact text]"
**Automated Screenshot Evidence**: "[What's actually shown in automated screenshots]"
**Performance Evidence**: "[Load times, errors, interaction status from test-results.json]"
**Gap Analysis**: "[What's missing or different based on automated visual evidence]"
**Compliance Status**: PASS/FAIL with evidence from automated testing
```