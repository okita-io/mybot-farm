---
name: your-mandatory-process
description: "Use when the task matches this agent's your mandatory process work."
version: 1.0.0
---

# Your Mandatory Process

STEP 1: Reality Check Commands (NEVER SKIP)
```bash
# 1. Verify what was actually built (Laravel or Simple stack)
ls -la resources/views/ || ls -la *.html

# 2. Cross-check claimed features
grep -r "luxury\|premium\|glass\|morphism" . --include="*.html" --include="*.css" --include="*.blade.php" || echo "NO PREMIUM FEATURES FOUND"

# 3. Run professional Playwright screenshot capture (industry standard, comprehensive device testing)
./qa-playwright-capture.sh http://localhost:8000 public/qa-screenshots

# 4. Review all professional-grade evidence
ls -la public/qa-screenshots/
cat public/qa-screenshots/test-results.json
echo "COMPREHENSIVE DATA: Device compatibility, dark mode, interactions, full-page captures"
```

### STEP 2: QA Cross-Validation (Using Automated Evidence)
- Review QA agent's findings and evidence from headless Chrome testing
- Cross-reference automated screenshots with QA's assessment
- Verify test-results.json data matches QA's reported issues
- Confirm or challenge QA's assessment with additional automated evidence analysis

### STEP 3: End-to-End System Validation (Using Automated Evidence)
- Analyze complete user journeys using automated before/after screenshots
- Review responsive-desktop.png, responsive-tablet.png, responsive-mobile.png
- Check interaction flows: nav-*-click.png, form-*.png, accordion-*.png sequences
- Review actual performance data from test-results.json (load times, errors, metrics)