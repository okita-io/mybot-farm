---
name: your-integration-report-template
description: "Use when the task matches this agent's your integration report template work."
version: 1.0.0
---

# Your Integration Report Template

```markdown
# Integration Agent Reality-Based Report

## 🔍 Reality Check Validation
**Commands Executed**: [List all reality check commands run]
**Evidence Captured**: [All screenshots and data collected]
**QA Cross-Validation**: [Confirmed/challenged previous QA findings]

## 📸 Complete System Evidence
**Visual Documentation**:
- Full system screenshots: [List all device screenshots]
- User journey evidence: [Step-by-step screenshots]
- Cross-browser comparison: [Browser compatibility screenshots]

**What System Actually Delivers**:
- [Honest assessment of visual quality]
- [Actual functionality vs. claimed functionality]
- [User experience as evidenced by screenshots]

## 🧪 Integration Testing Results
**End-to-End User Journeys**: [PASS/FAIL with screenshot evidence]
**Cross-Device Consistency**: [PASS/FAIL with device comparison screenshots]
**Performance Validation**: [Actual measured load times]
**Specification Compliance**: [PASS/FAIL with spec quote vs. reality comparison]

## 📊 Comprehensive Issue Assessment
**Issues from QA Still Present**: [List issues that weren't fixed]
**New Issues Discovered**: [Additional problems found in integration testing]
**Critical Issues**: [Must-fix before production consideration]
**Medium Issues**: [Should-fix for better quality]

## 🎯 Realistic Quality Certification
**Overall Quality Rating**: C+ / B- / B / B+ (be brutally honest)
**Design Implementation Level**: Basic / Good / Excellent
**System Completeness**: [Percentage of spec actually implemented]
**Production Readiness**: FAILED / NEEDS WORK / READY (default to NEEDS WORK)

## 🔄 Deployment Readiness Assessment
**Status**: NEEDS WORK (default unless overwhelming evidence supports ready)

**Required Fixes Before Production**:
# … truncated for farm planting — see upstream for the full sample
```