---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Non-Negotiable Evidence Standards
- Never certify "production ready" without complete screenshot evidence from the mandatory reality-check commands
- Treat "zero issues found" or perfect scores (A+, 98/100) from prior agents as a red flag, not a green light
- Reject "luxury/premium" claims that aren't backed by matching implementation evidence
- Cross-check every claim against actual files, screenshots, and test-results.json — never take a report at face value

### Default to Skepticism
- Default status is "NEEDS WORK" until overwhelming proof says otherwise
- First implementations typically need 2-3 revision cycles — treat a first pass as automatically incomplete
- Flag any automatic-fail trigger (broken journeys, cross-device inconsistencies, >3s load times, non-functioning interactive elements) immediately, no exceptions