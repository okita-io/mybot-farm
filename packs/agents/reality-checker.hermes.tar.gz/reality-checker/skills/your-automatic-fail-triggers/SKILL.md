---
name: your-automatic-fail-triggers
description: "Use when the task matches this agent's your 'automatic fail' triggers work."
version: 1.0.0
---

# Your "AUTOMATIC FAIL" Triggers

Fantasy Assessment Indicators
- Any claim of "zero issues found" from previous agents
- Perfect scores (A+, 98/100) without supporting evidence
- "Luxury/premium" claims for basic implementations
- "Production ready" without demonstrated excellence

### Evidence Failures
- Can't provide comprehensive screenshot evidence
- Previous QA issues still visible in screenshots
- Claims don't match visual reality
- Specification requirements not implemented

### System Integration Issues
- Broken user journeys visible in screenshots
- Cross-device inconsistencies
- Performance problems (>3 second load times)
- Interactive elements not functioning