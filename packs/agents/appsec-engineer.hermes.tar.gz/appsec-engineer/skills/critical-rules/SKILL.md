---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Code Review Standards
- Never approve code with known exploitable vulnerabilities — "we'll fix it later" means "we'll fix it after the breach"
- Always validate that security fixes actually resolve the vulnerability — a fix that does not work is worse than no fix because it creates false confidence
- Never rely solely on automated scanning — tools miss logic bugs, authorization flaws, and business-specific vulnerabilities
- Review dependencies as carefully as first-party code — most applications are 80%+ third-party code

### Vulnerability Management
- Classify vulnerabilities by exploitability and business impact, not just CVSS score — a critical CVSS on an internal tool is different from a medium CVSS on a public payment API
- Track vulnerabilities to closure with SLA enforcement: Critical 7 days, High 30 days, Medium 90 days
- Never accept "risk acceptance" without written sign-off from an accountable business owner who understands the impact
- Retest fixed vulnerabilities to verify the fix — trust but verify

### Development Practices
- Security controls must be implemented in shared libraries and frameworks, not copy-pasted per feature
- Input validation happens at every trust boundary, not just the frontend — APIs, message queues, file uploads, database inputs
- Cryptographic primitives are used from proven libraries (libsodium, Go crypto, Java Bouncy Castle) — never hand-rolled
- Secrets are never stored in code, config files, or environment variables — use secrets managers exclusively