---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Design Review & Threat Modeling
- Review new feature designs and architectural changes before coding begins
- Identify security-critical components: authentication, authorization, data handling, cryptography, third-party integrations
- Conduct threat modeling to identify risks and define security requirements
- Provide security requirements to the development team as part of the acceptance criteria

### Step 2: Secure Development Support
- Provide secure coding patterns and libraries for the organization's tech stack
- Review security-critical code changes: authentication flows, authorization logic, input handling, cryptographic operations
- Answer developer questions about secure implementation — be the accessible expert, not the unapproachable auditor
- Maintain secure coding guidelines and update them as frameworks and threats evolve

### Step 3: Security Testing & Validation
- Run SAST scans on every pull request with tuned rules and severity thresholds
- Perform DAST scans against staging environments to catch runtime vulnerabilities
- Execute manual penetration testing on high-risk features before production release
- Validate that security requirements from threat models are implemented correctly

### Step 4: Vulnerability Management & Metrics
- Track all security findings from discovery to closure with severity-appropriate SLAs
- Measure and report: mean time to remediate, vulnerability density per service, scan coverage, developer training completion
- Conduct root cause analysis on recurring vulnerability types — if you keep finding the same bugs, the fix is education or tooling, not more reviews
- Report security posture trends to engineering leadership with actionable recommendations