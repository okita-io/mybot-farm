---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

OWASP Top 10 Secure Coding Patterns

```typescript
// === A01: Broken Access Control ===
// VULNERABLE: Direct object reference without authorization check
app.get('/api/users/:id/profile', async (req, res) => {
  const profile = await db.getUserProfile(req.params.id);
  res.json(profile); // Anyone can access any user's profile
});

// SECURE: Authorization check using middleware + ownership verification
const requireAuth = (req: Request, res: Response, next: NextFunction) => {
  const [REDACTED]'Bearer ', '');
  if (!token) return res.status(401).json({ error: 'Authentication required' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET!) as UserClaims;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid token' });
  }
};

app.get('/api/users/:id/profile', requireAuth, async (req, res) => {
  const targetId = req.params.id;
  // Ownership check: users can only access their own profile
  // Admins can access any profile
  if (req.user.id !== targetId && !req.user.roles.includes('admin')) {
    return res.status(403).json({ error: 'Access denied' });
  }
  const profile = await db.getUserProfile(targetId);
  if (!profile) return res.status(404).json({ error: 'Not found' });
  res.json(profile);
});


// === A03: Injection ===
// VULNERABLE: SQL injection via string concatenation
app.get('/api/search', async (req, res) => {
  const query = req.query.q as string;
  // NEVER DO THIS — attacker sends: ' OR 1=1; DROP TABLE users; --
  const results = await db.raw(`SELECT * FROM products WHERE name LIKE '%${query}%'`);
  res.json(results);
});
# … truncated for farm planting — see upstream for the full sample
```

### Dependency Vulnerability Management
```python
#!/usr/bin/env python3
"""
Dependency security scanner integration for CI/CD pipelines.
Wraps multiple SCA tools and enforces organizational policy.
"""

import json
import subprocess
import sys
from dataclasses import dataclass
from enum import Enum
from pathlib import Path


class Severity(Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class VulnFinding:
    package: str
    version: str
    severity: Severity
    cve: str
    fixed_version: str
    description: str
    exploitable: bool = False


class DependencyScanner:
    """Unified dependency scanning with policy enforcement."""

    # SLA: max days to remediate by severity
    REMEDIATION_SLA = {
        Severity.CRITICAL: 7,
        Severity.HIGH: 30,
        Severity.MEDIUM: 90,
# … truncated for farm planting — see upstream for the full sample
```

### Threat Model Template (STRIDE)
```markdown
# Threat Model: [Feature/System Name]

## System Overview
**Description**: [What this system does]
**Data Classification**: [Public / Internal / Confidential / Restricted]
**Compliance Scope**: [PCI-DSS / HIPAA / SOC 2 / None]

## Architecture Diagram
[Include or reference a data flow diagram showing components, trust boundaries, and data flows]

## Assets
| Asset | Classification | Location | Owner |
|-------|---------------|----------|-------|
| User credentials | Restricted | Auth service DB | Identity team |
| Payment data | Restricted (PCI) | Payment processor | Payments team |
| User profiles | Confidential | Main DB | Product team |

## Trust Boundaries
1. Internet → Load balancer (untrusted → semi-trusted)
2. Load balancer → API gateway (semi-trusted → trusted)
3. API gateway → Internal services (trusted → trusted)
4. Internal services → Database (trusted → restricted)

## STRIDE Analysis

### Spoofing (Authentication)
| Threat | Component | Risk | Mitigation |
|--------|-----------|------|------------|
| Stolen JWT used to impersonate user | API Gateway | High | Short-lived tokens (15min), refresh token rotation, token binding to IP range |
| API key leaked in client code | Mobile app | High | Use OAuth2 PKCE flow, never embed secrets in client apps |

### Tampering (Integrity)
| Threat | Component | Risk | Mitigation |
|--------|-----------|------|------------|
| Request body modified in transit | All APIs | Medium | TLS 1.3 enforced, HMAC signature on sensitive operations |
| Database records modified by attacker | Database | Critical | Parameterized queries, row-level security, audit logging |

### Repudiation (Audit)
| Threat | Component | Risk | Mitigation |
|--------|-----------|------|------------|
# … truncated for farm planting — see upstream for the full sample
```