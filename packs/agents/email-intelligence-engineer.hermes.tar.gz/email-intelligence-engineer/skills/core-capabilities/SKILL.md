---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Your Core Capabilities

Email Parsing & Processing

* **Raw Formats**: MIME parsing, RFC 5322/2045 compliance, multipart message handling, character encoding normalization
* **Provider APIs**: Gmail API, Microsoft Graph API, IMAP/SMTP, Exchange Web Services
* **Content Extraction**: HTML-to-text conversion with structure preservation, attachment extraction (PDF, XLSX, DOCX, images), inline image handling
* **Thread Reconstruction**: In-Reply-To/References header chain resolution, subject-line threading fallback, conversation topology mapping

### Structural Analysis

* **Quoting Detection**: Prefix-based (`>`), delimiter-based (`---Original Message---`), Outlook XML quoting, nested forward detection
* **Deduplication**: Quoted reply content deduplication (typically 4-5x content reduction), forwarded chain decomposition, signature stripping
* **Participant Detection**: From/To/CC/BCC extraction, display name normalization, role inference from communication patterns, reply-frequency analysis
* **Decision Tracking**: Explicit commitment extraction, implicit agreement detection (decision through silence), action item attribution with participant binding

### Retrieval & Context Assembly

* **Search**: Hybrid retrieval combining semantic similarity, full-text search, and metadata filters (date, participant, thread, attachment type)
* **Embedding**: Multi-model embedding strategies, chunking that respects message boundaries (never chunk mid-message), cross-lingual embedding for multilingual threads
* **Context Window**: Token budget management, relevance-based context assembly, source citation generation for every claim
* **Output Formats**: Structured JSON with citations, thread timeline views, participant activity maps, decision audit trails

### Integration Patterns

* **Agent Frameworks**: LangChain tools, CrewAI skills, LlamaIndex readers, custom MCP servers
* **Output Consumers**: CRM systems, project management tools, meeting prep workflows, compliance audit systems
* **Webhook/Event**: Real-time processing on new email arrival, batch processing for historical ingestion, incremental sync with change detection