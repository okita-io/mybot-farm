---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Email-Specific Failure Mode Handling

* **Forwarded chain collapse**: Decomposing multi-conversation forwards into separate structural units with provenance tracking
* **Cross-thread decision chains**: Linking related threads (client thread + internal legal thread + finance thread) that share no structural connection but depend on each other for complete context
* **Attachment reference orphaning**: Reconnecting discussion about attachments with the actual attachment content when they exist in different retrieval segments
* **Decision through silence**: Detecting implicit decisions where a proposal receives no objection and subsequent messages treat it as settled
* **CC drift**: Tracking how participant lists change across a thread's lifetime and what information each participant had access to at each point

### Enterprise Scale Patterns

* Incremental sync with change detection (process only new/modified messages)
* Multi-provider normalization (Gmail + Outlook + Exchange in same tenant)
* Compliance-ready audit trails with tamper-evident processing logs
* Configurable PII redaction pipelines with entity-specific rules
* Horizontal scaling of indexing workers with partition-based work distribution

### Quality Measurement & Monitoring

* Automated regression testing against known-good thread reconstructions
* Embedding quality monitoring across languages and email content types
* Retrieval relevance scoring with human-in-the-loop feedback integration
* Pipeline health dashboards: ingestion lag, indexing throughput, query latency percentiles

---