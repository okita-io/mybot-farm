---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Email Ingestion & Normalization

```python
# Connect to email source and fetch raw messages
import imaplib
import email
from email import policy

def fetch_thread(imap_conn, thread_ids):
    """Fetch and parse raw messages, preserving full MIME structure."""
    messages = []
    for msg_id in thread_ids:
        _, data = imap_conn.fetch(msg_id, "(RFC822)")
        raw = data[0][1]
        parsed = email.message_from_bytes(raw, policy=policy.default)
        messages.append({
            "message_id": parsed["Message-ID"],
            "in_reply_to": parsed["In-Reply-To"],
            "references": parsed["References"],
            "from": parsed["From"],
            "to": parsed["To"],
            "cc": parsed["CC"],
            "date": parsed["Date"],
            "subject": parsed["Subject"],
            "body": extract_body(parsed),
            "attachments": extract_attachments(parsed)
        })
    return messages
```

### Step 2: Thread Reconstruction & Deduplication

```python
def reconstruct_thread(messages):
    """Build conversation topology from message headers.

    Key challenges:
    - Forwarded chains collapse multiple conversations into one message body
    - Quoted replies duplicate content (20-msg thread = ~4-5x token bloat)
    - Thread forks when people reply to different messages in the chain
    """
    # Build reply graph from In-Reply-To and References headers
    graph = {}
    for msg in messages:
        parent_id = msg["in_reply_to"]
        graph[msg["message_id"]] = {
            "parent": parent_id,
            "children": [],
            "message": msg
        }

    # Link children to parents
    for msg_id, node in graph.items():
        if node["parent"] and node["parent"] in graph:
            graph[node["parent"]]["children"].append(msg_id)

    # Deduplicate quoted content
    for msg_id, node in graph.items():
        node["message"]["unique_body"] = strip_quoted_content(
            node["message"]["body"],
            get_parent_bodies(node, graph)
        )

    return graph

def strip_quoted_content(body, parent_bodies):
    """Remove quoted text that duplicates parent messages.

    Handles multiple quoting styles:
    - Prefix quoting: lines starting with '>'
    - Delimiter quoting: '---Original Message---', 'On ... wrote:'
    - Outlook XML quoting: nested <div> blocks with specific classes
    """
# … truncated for farm planting — see upstream for the full sample
```

### Step 3: Structural Analysis & Extraction

```python
def extract_structured_context(thread_graph):
    """Extract structured data from reconstructed thread.

    Produces:
    - Participant map with roles and activity patterns
    - Decision timeline (explicit commitments + implicit agreements)
    - Action items with correct participant attribution
    - Attachment references linked to discussion context
    """
    participants = build_participant_map(thread_graph)
    decisions = extract_decisions(thread_graph, participants)
    action_items = extract_action_items(thread_graph, participants)
    attachments = link_attachments_to_context(thread_graph)

    return {
        "thread_id": get_root_id(thread_graph),
        "message_count": len(thread_graph),
        "participants": participants,
        "decisions": decisions,
        "action_items": action_items,
        "attachments": attachments,
        "timeline": build_timeline(thread_graph)
    }

def extract_action_items(thread_graph, participants):
    """Extract action items with correct attribution.

    Critical: In a flattened thread, 'I' refers to different people
    in different messages. Without preserved From: headers, an LLM
    will misattribute tasks. This function binds each commitment
    to the actual sender of that message.
    """
    items = []
    for msg_id, node in thread_graph.items():
        sender = node["message"]["from"]
        commitments = find_commitments(node["message"]["unique_body"])
        for commitment in commitments:
            items.append({
                "task": commitment,
                "owner": participants[sender]["normalized_name"],
# … truncated for farm planting — see upstream for the full sample
```

### Step 4: Context Assembly & Tool Interface

```python
def build_agent_context(thread_graph, query, token_budget=4000):
    """Assemble context for an AI agent, respecting token limits.

    Uses hybrid retrieval:
    1. Semantic search for query-relevant message segments…