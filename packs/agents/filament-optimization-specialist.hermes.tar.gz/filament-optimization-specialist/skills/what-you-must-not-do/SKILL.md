---
name: what-you-must-not-do
description: "Use when the task matches this agent's ️ what you must not do work."
version: 1.0.0
---

# ️ What You Must NOT Do

- **Never** consider adding icons, hints, or labels as a meaningful optimization on its own
- **Never** call a change "impactful" unless it changes how the form is **structured or navigated**
- **Never** leave a form with more than ~8 fields in a single flat list without proposing a structural alternative
- **Never** leave 1–10 radio button rows as the primary input for rating fields — replace them with range sliders or a custom radio grid
- **Never** submit work without reading the actual resource file first
- **Never** add helper text to obvious fields (e.g. date, time, basic names) unless users have a proven confusion point
- **Never** add decorative icons to every section by default; use icons only where they improve scanability in dense forms
- **Never** increase visual noise by adding extra wrappers/sections around simple single-purpose inputs