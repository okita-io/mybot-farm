---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

Structural Split: Side-by-Side Sections
```php
// Two related sections placed side by side — cuts vertical scroll in half
Grid::make(2)
    ->schema([
        Section::make('Sleep')
            ->icon('heroicon-o-moon')
            ->schema([
                TimePicker::make('bedtime')->required(),
                TimePicker::make('wake_time')->required(),
                // range slider instead of radio row:
                TextInput::make('sleep_quality')
                    ->extraInputAttributes(['type' => 'range', 'min' => 1, 'max' => 10, 'step' => 1])
                    ->label('Sleep Quality (1–10)')
                    ->default(5),
            ]),
        Section::make('Morning Energy')
            ->icon('heroicon-o-bolt')
            ->schema([
                TextInput::make('energy_morning')
                    ->extraInputAttributes(['type' => 'range', 'min' => 1, 'max' => 10, 'step' => 1])
                    ->label('Energy after waking (1–10)')
                    ->default(5),
            ]),
    ])
    ->columnSpanFull(),
```

### Tab-Based Form Restructure
```php
Tabs::make('EnergyLog')
    ->tabs([
        Tabs\Tab::make('Overview')
            ->icon('heroicon-o-calendar-days')
            ->schema([
                DatePicker::make('date')->required(),
                // summary placeholder on edit:
                Placeholder::make('summary')
                    ->content(fn ($record) => $record
                        ? "Sleep: {$record->sleep_quality}/10 · Morning: {$record->energy_morning}/10"
                        : null
                    )
                    ->hiddenOn('create'),
            ]),
        Tabs\Tab::make('Sleep & Energy')
            ->icon('heroicon-o-bolt')
            ->schema([/* sleep + energy sections side by side */]),
        Tabs\Tab::make('Nutrition')
            ->icon('heroicon-o-cake')
            ->schema([/* food repeater */]),
        Tabs\Tab::make('Crashes & Notes')
            ->icon('heroicon-o-exclamation-triangle')
            ->schema([/* crashes repeater + notes textarea */]),
    ])
    ->columnSpanFull()
    ->persistTabInQueryString(),
```

### Repeater with Meaningful Item Labels
```php
Repeater::make('crashes')
    ->schema([
        TimePicker::make('time')->required(),
        Textarea::make('description')->required(),
    ])
    ->itemLabel(fn (array $state): ?string =>
        isset($state['time'], $state['description'])
            ? $state['time'] . ' — ' . \Str::limit($state['description'], 40)
            : null
    )
    ->collapsible()
    ->collapsed()
    ->addActionLabel('Add crash moment'),
```

### Collapsible Secondary Section
```php
Section::make('Notes')
    ->icon('heroicon-o-pencil')
    ->schema([
        Textarea::make('notes')
            ->placeholder('Any remarks about today — medication, weather, mood...')
            ->rows(4),
    ])
    ->collapsible()
    ->collapsed()  // hidden by default — most days have no notes
    ->columnSpanFull(),
```

### Navigation Optimization
```php
// In app/Providers/Filament/AdminPanelProvider.php
public function panel(Panel $panel): Panel
{
    return $panel
        ->navigationGroups([
            NavigationGroup::make('Shop Management')
                ->icon('heroicon-o-shopping-bag'),
            NavigationGroup::make('Users & Permissions')
                ->icon('heroicon-o-users'),
            NavigationGroup::make('System')
                ->icon('heroicon-o-cog-6-tooth')
                ->collapsed(),
        ]);
}
```

### Dynamic Conditional Fields
```php
Forms\Components\Select::make('type')
    ->options(['physical' => 'Physical', 'digital' => 'Digital'])
    ->live(),

Forms\Components\TextInput::make('weight')
    ->hidden(fn (Get $get) => $get('type') !== 'physical')
    ->required(fn (Get $get) => $get('type') === 'physical'),
```