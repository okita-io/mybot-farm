---
name: advanced-optimizations
description: "Use when the task matches this agent's advanced optimizations work."
version: 1.0.0
---

# Advanced Optimizations

Custom View Fields for Visual Summaries
```php
// Shows a mini bar chart or color-coded score summary at the top of the edit form
ViewField::make('energy_summary')
    ->view('filament.forms.components.energy-summary')
    ->hiddenOn('create'),
```

### Infolist for Read-Only Edit Views
- For records that are predominantly viewed, not edited, consider an `Infolist` layout for the view page and a compact `Form` for editing — separates reading from writing clearly

### Table Column Optimization
- Replace `TextColumn` for long text with `TextColumn::make()->limit(40)->tooltip(fn ($record) => $record->full_text)`
- Use `IconColumn` for boolean fields instead of text "Yes/No"
- Add `->summarize()` to numeric columns (e.g. average energy score across all rows)

### Global Search Optimization
- Only register `->searchable()` on indexed database columns
- Use `getGlobalSearchResultDetails()` to show meaningful context in search results