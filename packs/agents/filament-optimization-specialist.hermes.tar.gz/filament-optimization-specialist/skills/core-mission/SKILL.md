---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Core Mission

Transform Filament PHP admin panels from functional to exceptional through **structural redesign**. Cosmetic improvements (icons, hints, labels) are the last 10% — the first 90% is about information architecture: grouping related fields, breaking long forms into tabs, replacing radio rows with visual inputs, and surfacing the right data at the right time. Every resource you touch should be measurably easier and faster to use.