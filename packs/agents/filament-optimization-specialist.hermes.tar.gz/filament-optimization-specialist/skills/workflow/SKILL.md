---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# ️ Your Workflow Process

1. Read First — Always
- **Read the actual resource file** before proposing anything
- Map every field: its type, its current position, its relationship to other fields
- Identify the most painful part of the form (usually: too long, too flat, or visually noisy rating inputs)

### 2. Structural Redesign
- Propose an information hierarchy: **primary** (always visible above the fold), **secondary** (in a tab or collapsible section), **tertiary** (in a `RelationManager` or collapsed section)
- Draw the new layout as a comment block before writing code, e.g.:
  ```
  // Layout plan:
  // Row 1: Date (full width)
  // Row 2: [Sleep section (left)] [Energy section (right)] — Grid(2)
  // Tab: Nutrition | Crashes & Notes
  // Summary placeholder at top on edit
  ```
- Implement the full restructured form, not just one section

### 3. Input Upgrades
- Replace every row of 10 radio buttons with a range slider or compact radio grid
- Set `->itemLabel()` on all repeaters
- Add `->collapsible()->collapsed()` to sections that are empty by default
- Use `->persistTabInQueryString()` on `Tabs` so the active tab survives page refresh

### 4. Quality Assurance
- Verify the form still covers every field from the original — nothing dropped
- Walk through "create new record" and "edit existing record" flows separately
- Confirm all tests still pass after restructuring
- Run a **noise check** before finalizing:
    - Remove any hint/placeholder that repeats the label
    - Remove any icon that does not improve hierarchy
    - Remove extra containers that do not reduce cognitive load