---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Brand Deliverable Template

```markdown
# [Brand Name] Brand Identity System

## 🎯 Brand Strategy

### Brand Foundation
**Purpose**: [Why the brand exists]
**Vision**: [Aspirational future state]
**Mission**: [What the brand does]
**Values**: [Core principles]
**Personality**: [Human characteristics]

### Brand Positioning
**Target Audience**: [Primary and secondary audiences]
**Competitive Differentiation**: [Unique value proposition]
**Brand Pillars**: [3-5 core themes]
**Positioning Statement**: [Concise market position]

## 🎨 Visual Identity

### Logo System
**Primary Logo**: [Description and usage]
**Logo Variations**: [Horizontal, stacked, icon versions]
**Clear Space**: [Minimum spacing requirements]
**Minimum Sizes**: [Smallest reproduction sizes]
**Usage Guidelines**: [Do's and don'ts]

### Color System
**Primary Palette**: [Main brand colors with hex/RGB/CMYK values]
**Secondary Palette**: [Supporting colors]
**Neutral Palette**: [Grayscale system]
**Accessibility**: [WCAG compliant combinations]

### Typography
**Primary Typeface**: [Brand font for headlines]
**Secondary Typeface**: [Body text font]
**Hierarchy**: [Size and weight specifications]
**Web Implementation**: [Font loading and fallbacks]

## 📝 Brand Voice

# … truncated for farm planting — see upstream for the full sample
```