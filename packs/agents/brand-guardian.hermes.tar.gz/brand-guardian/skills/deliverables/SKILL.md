---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Brand Strategy Deliverables

Brand Foundation Framework
```markdown
# Brand Foundation Document

## Brand Purpose
Why the brand exists beyond making profit - the meaningful impact and value creation

## Brand Vision
Aspirational future state - where the brand is heading and what it will achieve

## Brand Mission
What the brand does and for whom - the specific value delivery and target audience

## Brand Values
Core principles that guide all brand behavior and decision-making:
1. [Primary Value]: [Definition and behavioral manifestation]
2. [Secondary Value]: [Definition and behavioral manifestation]
3. [Supporting Value]: [Definition and behavioral manifestation]

## Brand Personality
Human characteristics that define brand character:
- [Trait 1]: [Description and expression]
- [Trait 2]: [Description and expression]
- [Trait 3]: [Description and expression]

## Brand Promise
Commitment to customers and stakeholders - what they can always expect
```

### Visual Identity System
```css
/* Brand Design System Variables */
:root {
  /* Primary Brand Colors */
  --brand-primary: [hex-value];      /* Main brand color */
  --brand-secondary: [hex-value];    /* Supporting brand color */
  --brand-accent: [hex-value];       /* Accent and highlight color */

  /* Brand Color Variations */
  --brand-primary-light: [hex-value];
  --brand-primary-dark: [hex-value];
  --brand-secondary-light: [hex-value];
  --brand-secondary-dark: [hex-value];

  /* Neutral Brand Palette */
  --brand-neutral-100: [hex-value];  /* Lightest */
  --brand-neutral-500: [hex-value];  /* Medium */
  --brand-neutral-900: [hex-value];  /* Darkest */

  /* Brand Typography */
  --brand-font-primary: '[font-name]', [fallbacks];
  --brand-font-secondary: '[font-name]', [fallbacks];
  --brand-font-accent: '[font-name]', [fallbacks];

  /* Brand Spacing System */
  --brand-space-xs: 0.25rem;
  --brand-space-sm: 0.5rem;
  --brand-space-md: 1rem;
  --brand-space-lg: 2rem;
  --brand-space-xl: 4rem;
}

/* Brand Logo Implementation */
.brand-logo {
  /* Logo sizing and spacing specifications */
  min-width: 120px;
  min-height: 40px;
  padding: var(--brand-space-sm);
}

.brand-logo--horizontal {
# … truncated for farm planting — see upstream for the full sample
```

### Brand Voice and Messaging
```markdown
# Brand Voice Guidelines

## Voice Characteristics
- **[Primary Trait]**: [Description and usage context]
- **[Secondary Trait]**: [Description and usage context]
- **[Supporting Trait]**: [Description and usage context]

## Tone Variations
- **Professional**: [When to use and example language]
- **Conversational**: [When to use and example language]
- **Supportive**: [When to use and example language]

## Messaging Architecture
- **Brand Tagline**: [Memorable phrase encapsulating brand essence]
- **Value Proposition**: [Clear statement of customer benefits]
- **Key Messages**:
  1. [Primary message for main audience]
  2. [Secondary message for secondary audience]
  3. [Supporting message for specific use cases]

## Writing Guidelines
- **Vocabulary**: Preferred terms, phrases to avoid
- **Grammar**: Style preferences, formatting standards
- **Cultural Considerations**: Inclusive language guidelines
```