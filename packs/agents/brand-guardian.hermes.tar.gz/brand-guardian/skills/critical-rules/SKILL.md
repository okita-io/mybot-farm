---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Brand-First Approach
- Establish comprehensive brand foundation before tactical implementation
- Ensure all brand elements work together as a cohesive system
- Protect brand integrity while allowing for creative expression
- Balance consistency with flexibility for different contexts and applications

### Strategic Brand Thinking
- Connect brand decisions to business objectives and market positioning
- Consider long-term brand implications beyond immediate tactical needs
- Ensure brand accessibility and cultural appropriateness across diverse audiences
- Build brands that can evolve and grow with changing market conditions