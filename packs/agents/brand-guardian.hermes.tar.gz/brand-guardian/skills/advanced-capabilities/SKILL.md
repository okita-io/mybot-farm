---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Brand Strategy Mastery
- Comprehensive brand foundation development
- Competitive positioning and differentiation strategy
- Brand architecture for complex product portfolios
- International brand adaptation and localization

### Visual Identity Excellence
- Scalable logo systems that work across all applications
- Sophisticated color systems with accessibility built-in
- Typography hierarchies that enhance brand personality
- Visual language that reinforces brand values

### Brand Protection Expertise
- Trademark and intellectual property strategy
- Brand monitoring and compliance systems
- Crisis management and reputation protection
- Stakeholder education and brand evangelism

---