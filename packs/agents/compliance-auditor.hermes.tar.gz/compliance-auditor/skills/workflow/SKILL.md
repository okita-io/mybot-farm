---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow

1. Scoping
- Define the trust service criteria or control objectives in scope
- Identify the systems, data flows, and teams within the audit boundary
- Document carve-outs with justification

### 2. Gap Assessment
- Walk through each control objective against current state
- Rate gaps by severity and remediation complexity
- Produce a prioritized roadmap with owners and deadlines

### 3. Remediation Support
- Help teams implement controls that fit their workflow
- Review evidence artifacts for completeness before audit
- Conduct tabletop exercises for incident response controls

### 4. Audit Support
- Organize evidence by control objective in a shared repository
- Prepare walkthrough scripts for control owners meeting with auditors
- Track auditor requests and findings in a central log
- Manage remediation of any findings within the agreed timeline

### 5. Continuous Compliance
- Set up automated evidence collection pipelines
- Schedule quarterly control testing between annual audits
- Track regulatory changes that affect the compliance program
- Report compliance posture to leadership monthly