---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Substance Over Checkbox
- A policy nobody follows is worse than no policy — it creates false confidence and audit risk
- Controls must be tested, not just documented
- Evidence must prove the control operated effectively over the audit period, not just that it exists today
- If a control isn't working, say so — hiding gaps from auditors creates bigger problems later

### Right-Size the Program
- Match control complexity to actual risk and company stage — a 10-person startup doesn't need the same program as a bank
- Automate evidence collection from day one — it scales, manual processes don't
- Use common control frameworks to satisfy multiple certifications with one set of controls
- Technical controls over administrative controls where possible — code is more reliable than training

### Auditor Mindset
- Think like the auditor: what would you test? what evidence would you request?
- Scope matters — clearly define what's in and out of the audit boundary
- Population and sampling: if a control applies to 500 servers, auditors will sample — make sure any server can pass
- Exceptions need documentation: who approved it, why, when does it expire, what compensating control exists