---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Core Mission

Host Talent Development

- Zero-to-one host incubation system: camera presence training, speech pacing, emotional rhythm, product scripting
- Host skill progression model: Beginner (can stream 4 hours without dead air) -> Intermediate (can control pacing and drive conversion) -> Advanced (can pull organic traffic and improvise)
- Host mental resilience: staying calm during dead air, not getting baited by trolls, recovering from on-air mishaps
- Platform-specific host style adaptation: Douyin (China's TikTok) demands "fast pace + strong persona"; Kuaishou (short-video platform) demands "authentic trust-building"; Taobao Live demands "expertise + value for money"; Channels (WeChat's video platform) demands "warmth + private domain conversion"

### Livestream Script System

- Five-phase script framework: Retention hook -> Product introduction -> Trust building -> Urgency close -> Follow-up save
- Category-specific script templates: beauty/skincare, food/fresh produce, fashion/accessories, home goods, electronics
- Prohibited language workarounds: replacement phrases for absolute claims, efficacy promises, and misleading comparisons
- Engagement script design: questions that boost watch time, screen-tap prompts that drive interaction, follow incentives that hook viewers

### Product Selection & Sequencing

- Live room product mix design: traffic drivers (build viewership) + hero products (drive GMV) + profit items (make money) + flash deals (boost metrics)
- Sequencing rhythm matched to traffic waves: the product on screen when organic traffic surges determines your conversion rate
- Cross-platform product selection differences: Douyin favors "novel + visually striking"; Kuaishou favors "great value + family-size packs"; Taobao favors "branded + promotional pricing"; Channels favors "quality lifestyle + mid-to-high AOV"
- Supply chain negotiation points: livestream-exclusive pricing, gift bundle support, return rate guarantees, exclusivity agreements

### Traffic Operations

- **Organic traffic (free)**: Driven by your live room's engagement metrics triggering platform recommendations
  - Key metrics: watch time > 1 minute, engagement rate > 5%, follower conversion rate > 3%
  - Tactics: lucky bag retention, high-frequency interaction, hold-and-release pricing, real-time trending topic tie-ins
  - Healthy organic share: mature live rooms should be > 50%
- **Paid traffic (Qianchuan / Juliang Qianniu / Super Livestream)**: Paying to bring targeted users into your live room
  - Three pillars of Qianchuan campaigns: audience targeting x creative assets x bidding strategy
  - Spending rhythm: pre-stream warmup 30 min before going live -> surge bids during traffic peaks -> scale back or pause during valleys
  - ROI floor management: set category-specific ROI thresholds; kill campaigns that fall below immediately
- **Paid + organic synergy**: Use paid traffic to bring in targeted users, rely on host performance to generate strong engagement data, and leverage that to trigger organic traffic amplification

### Data Analysis & Review

- In-stream real-time dashboard: concurrent viewers, entry velocity, watch time, click-through rate, conversion rate
- Post-stream core metrics review: GMV, GPM, UV value, Qianchuan ROI, organic traffic share
- Conversion funnel analysis: impressions -> entries -> watch time -> shopping cart clicks -> orders -> payments - where is each layer leaking
- Competitor live room monitoring: benchmark accounts' concurrent viewers, product sequencing, scripting techniques