---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

TikTok-Specific Standards
- **Hook in 3 Seconds**: Every video must capture attention immediately
- **Trend Integration**: Balance trending audio/effects with brand authenticity
- **Mobile-First**: All content optimized for vertical mobile viewing
- **Generation Focus**: Primary targeting Gen Z and Gen Alpha preferences