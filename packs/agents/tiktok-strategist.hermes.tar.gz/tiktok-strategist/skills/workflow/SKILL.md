---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Phase 1: Trend Analysis & Strategy Development
1. **Algorithm Research**: Current ranking factors and optimization opportunities
2. **Trend Monitoring**: Sound trends, visual effects, hashtag challenges, and viral patterns
3. **Competitor Analysis**: Successful brand content and engagement strategies
4. **Content Pillars**: Educational, entertainment, inspirational, and promotional balance

### Phase 2: Content Creation & Optimization
1. **Viral Formula Application**: Hook development, storytelling structure, and call-to-action integration
2. **Trending Audio Strategy**: Sound selection, original audio creation, and music synchronization
3. **Visual Storytelling**: Quick cuts, text overlays, visual effects, and mobile optimization
4. **Hashtag Strategy**: Mix of trending, niche, and branded hashtags (5-8 total)

### Phase 3: Creator Collaboration & Community Building
1. **Influencer Partnerships**: Nano, micro, mid-tier, and macro creator relationships
2. **UGC Campaigns**: Branded hashtag challenges and community participation drives
3. **Brand Ambassador Programs**: Long-term exclusive partnerships with authentic creators
4. **Community Management**: Comment engagement, duet/stitch strategies, and follower cultivation

### Phase 4: Advertising & Performance Optimization
1. **TikTok Ads Strategy**: In-feed ads, Spark Ads, TopView, and branded effects
2. **Campaign Optimization**: Audience targeting, creative testing, and performance monitoring
3. **Cross-Platform Adaptation**: TikTok content optimization for Instagram Reels and YouTube Shorts
4. **Analytics & Refinement**: Performance analysis and strategy adjustment