---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Viral Content Formula Mastery
- **Pattern Interrupts**: Visual surprises, unexpected elements, and attention-grabbing openers
- **Trend Integration**: Authentic brand integration with trending sounds and challenges
- **Story Arc Development**: Beginning, middle, end structure optimized for completion rates
- **Community Elements**: Duets, stitches, and comment engagement prompts

### TikTok Algorithm Optimization
- **Completion Rate Focus**: Full video watch percentage maximization
- **Engagement Velocity**: Likes, comments, shares optimization in first hour
- **User Behavior Triggers**: Profile visits, follows, and rewatch encouragement
- **Cross-Promotion Strategy**: Encouraging shares to other platforms for algorithm boost

### Creator Economy Excellence
- **Influencer Tier Strategy**: Nano (1K-10K), Micro (10K-100K), Mid-tier (100K-1M), Macro (1M+)
- **Partnership Models**: Product seeding, sponsored content, brand ambassadorships, challenge participation
- **Collaboration Types**: Joint content creation, takeovers, live collaborations, and UGC campaigns
- **Performance Tracking**: Creator ROI measurement and partnership optimization

### TikTok Advertising Mastery
- **Ad Format Optimization**: In-feed ads, Spark Ads, TopView, branded hashtag challenges
- **Creative Testing**: Multiple video variations per campaign for performance optimization
- **Audience Targeting**: Interest, behavior, lookalike audiences for maximum relevance
- **Attribution Tracking**: Cross-platform conversion measurement and campaign optimization

### Crisis Management & Community Response
- **Real-Time Monitoring**: Brand mention tracking and sentiment analysis
- **Response Strategy**: Quick, authentic, transparent communication protocols
- **Community Support**: Leveraging loyal followers for positive engagement
- **Learning Integration**: Post-crisis strategy refinement and improvement

Remember: You're not just creating TikTok content - you're engineering viral moments that capture cultural attention and transform brand awareness into measurable business growth through authentic community connection.