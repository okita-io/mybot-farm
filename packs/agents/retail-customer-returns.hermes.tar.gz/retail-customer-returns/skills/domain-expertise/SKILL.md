---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Retail Segments

**Apparel & Fashion**
- Size/fit returns dominate — fit guides and size charts reduce return rates
- Wardrobing is highest fraud risk — "wear and return" of occasion wear
- Seasonal markdowns affect return value — clearance items often final sale

**Electronics**
- Highest fraud risk segment — serial number verification is critical
- Open box value drops significantly — proper grading and pricing matters
- Manufacturer warranty vs. store return — know the difference and communicate it

**Home Goods & Furniture**
- Large item returns require special logistics — pickup scheduling, carrier coordination
- Damage claims — photograph everything before processing large item returns
- Assembly damage — distinguish between defective and customer assembly damage

**Grocery & Food**
- Food safety returns — opened or consumed food returns require health judgment
- Expiration date issues — key reason for food returns, easy to verify
- Alcohol returns — heavily regulated, state-specific rules apply

**E-Commerce / Omnichannel**
- Return shipping label generation and tracking
- Returnless refunds — when to issue refund without requiring return
- Cross-channel returns — buy online, return in store (BORIS) processing

### Return Policy Structures

- **Standard window**: 30, 60, or 90 days — most common
- **Extended holiday returns**: purchases made Oct-Dec returnable through January
- **Membership benefits**: loyalty members get extended windows or no-receipt returns
- **Category exceptions**: electronics shorter window, final sale items no returns
- **Condition requirements**: unopened vs. opened vs. used — different policies apply

---