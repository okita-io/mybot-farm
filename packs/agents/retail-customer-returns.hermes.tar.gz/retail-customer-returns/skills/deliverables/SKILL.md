---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Return Eligibility Checker

```
RETURN ELIGIBILITY ASSESSMENT
───────────────────────────────────────
Customer:           [Name]
Transaction Date:   [Date of purchase]
Return Date:        [Today's date]
Days Since Purchase: [Calculation]
Item:               [Product name / SKU]
Purchase Price:     $___________
Has Receipt:        [ ] Yes  [ ] No  [ ] Gift receipt  [ ] Digital

POLICY CHECK
───────────────────────────────────────
Standard Return Window:     ___ days
Days Remaining in Window:   ___
Within Return Window:       [ ] Yes  [ ] No — expired by ___ days

Item Condition:
  [ ] New/unopened — full refund eligible
  [ ] Opened/used — per open box policy
  [ ] Damaged by customer — refund denied / partial refund
  [ ] Defective — full refund or exchange regardless of window
  [ ] Missing parts/accessories — partial refund or exchange only

Category Restrictions:
  [ ] No restrictions apply
  [ ] Final sale item — no returns
  [ ] Opened software/media — exchange only
  [ ] Personal hygiene / swimwear — unopened only
  [ ] Hazardous materials — no returns
  [ ] Custom/personalized — no returns
  [ ] Other restriction: _______________

ELIGIBILITY DETERMINATION
───────────────────────────────────────
Return Eligible:    [ ] Yes — full policy  [ ] Yes — exception
                    [ ] No — reason: _______________
Refund Method:      [ ] Original payment  [ ] Store credit  [ ] Exchange
Refund Amount:      $___________
Restocking Fee:     $___________  (___%)
Net Refund:         $___________
# … truncated for farm planting — see upstream for the full sample
```

### Return Processing Workflow

```
RETURN PROCESSING CHECKLIST
───────────────────────────────────────
Step 1: GREET & VERIFY
  [ ] Greet customer warmly
  [ ] Ask for receipt, order confirmation, or order lookup
  [ ] Verify purchase in system — confirm item, price, and date
  [ ] Verify customer identity if required by policy

Step 2: INSPECT THE ITEM
  [ ] Examine item condition — new, like new, used, damaged
  [ ] Check for all original components — accessories, manuals, packaging
  [ ] Check for signs of use, wear, or damage
  [ ] Check for serial number match (electronics)
  [ ] Check for price tag / label tampering
  [ ] Check for signs of fraud — receipt alterations, price switching

Step 3: DETERMINE ELIGIBILITY
  [ ] Confirm within return window
  [ ] Confirm item meets condition requirements
  [ ] Confirm no category restrictions apply
  [ ] Check customer's return history (if system available)
  [ ] Determine refund amount — full, partial, or store credit

Step 4: PROCESS THE RETURN
  [ ] Select return reason code in POS/system
  [ ] Process refund to original payment method
  [ ] Issue store credit if applicable
  [ ] Process exchange if requested
  [ ] Print/email return confirmation to customer

Step 5: DISPOSITION THE ITEM
  [ ] Return to stock (new/unopened, no defects)
  [ ] Open box / refurbished area (opened, good condition)
  [ ] Vendor return / RMA (defective, vendor responsibility)
  [ ] Salvage / liquidation (damaged, unsaleable)
  [ ] Destroy (health/safety, non-resaleable)
  [ ] Hold for LP review (fraud suspected)

Step 6: CLOSE THE INTERACTION
  [ ] Thank the customer genuinely
# … truncated for farm planting — see upstream for the full sample
```

### Return Reason Code Guide

```
RETURN REASON CODES
───────────────────────────────────────
Use accurate reason codes — return data drives buying decisions,
product quality feedback, and vendor claims.

PRODUCT ISSUES
  P01 — Defective / not working
  P02 — Damaged — arrived damaged (e-commerce)
  P03 — Missing parts or accessories
  P04 — Not as described / not as pictured
  P05 — Wrong item sent (e-commerce fulfillment error)
  P06 — Size / fit issue (apparel, footwear)
  P07 — Color / style different than expected
  P08 — Quality below expectation

CUSTOMER PREFERENCE
  C01 — Changed mind / no longer needed
  C02 — Found better price elsewhere
  C03 — Duplicate purchase / received as gift
  C04 — Ordered wrong item / size
  C05 — Gift — recipient doesn't want / need

OPERATIONAL
  O01 — Cashier error — wrong item rung
  O02 — Price discrepancy
  O03 — Promotional item — did not meet promotion terms

FRAUD FLAGS (Internal use — do not tell customer)
  F01 — Return of stolen merchandise suspected
  F02 — Wardrobing suspected (wear and return)
  F03 — Receipt fraud suspected
  F04 — Price switching suspected
  F05 — Excessive returns — policy abuse…