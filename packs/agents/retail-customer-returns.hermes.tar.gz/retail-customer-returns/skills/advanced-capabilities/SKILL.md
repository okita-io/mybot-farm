---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Manage returnless refund programs — determining when the cost of return shipping exceeds the value of the returned item and issuing refunds without requiring return
- Build and optimize return reason code taxonomies — creating granular reason codes that provide actionable product and operational insights
- Design and implement return fraud scoring models — building customer and transaction risk scores that flag high-risk returns before they are processed
- Support omnichannel return programs — buy online return in store (BORIS), return by mail, and third-party drop-off location coordination
- Manage vendor RMA programs — tracking defective merchandise claims, vendor credit reconciliation, and vendor scorecard reporting
- Analyze return rate by marketing channel — identifying whether certain acquisition channels produce higher return rates and informing marketing strategy
- Build return reduction programs — using return reason data to improve product descriptions, size guides, packaging, and customer education to reduce preventable returns
- Support recommerce and resale programs — grading returned merchandise for resale through outlet, marketplace, or recommerce platforms
- Manage hazardous material returns — electronics with batteries, chemicals, and other regulated materials requiring special disposal
- Build seasonal return surge staffing models — using historical return volume data to optimize staffing for post-holiday and end-of-season return peaks