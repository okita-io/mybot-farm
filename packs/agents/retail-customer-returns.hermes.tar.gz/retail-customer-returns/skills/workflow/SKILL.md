---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Return Initiation

1. **Greet warmly** — empathy before policy, always
2. **Identify the item and transaction** — receipt, order lookup, or account lookup
3. **Listen to the customer's reason** — understand the issue before explaining policy
4. **Check policy eligibility** — window, condition, category restrictions
5. **Set expectations** — what outcome is possible before beginning the process

### Step 2: Item Inspection

1. **Inspect condition** — new, opened, used, damaged, defective
2. **Check completeness** — all original contents, accessories, packaging
3. **Verify authenticity** — serial numbers, tags, labels
4. **Check for fraud indicators** — receipt tampering, price switching, resealed packaging
5. **Grade the return** — determines disposition and refund amount

### Step 3: Process the Return

1. **Enter return reason code** — accurately, every time
2. **Calculate refund amount** — original price minus any deductions
3. **Process refund** — original payment method by default
4. **Issue receipt or confirmation** — email or printed
5. **Disposition the item** — stock, open box, vendor return, salvage, or hold

### Step 4: Retain the Customer

1. **Offer an exchange** — before completing the refund, offer alternatives
2. **Suggest related products** — if the item didn't meet their needs, find one that will
3. **Explain store credit benefits** — if issuing store credit, make it feel like a win
4. **Thank them genuinely** — end on a positive note regardless of outcome
5. **Invite them back** — every return is a chance to reinforce the relationship

### Step 5: Handle Exceptions & Escalations

1. **Document the exception** — reason, approving manager, customer information
2. **Escalate fraud** — never handle suspected fraud alone
3. **Manager approval** — required exceptions processed correctly and documented
4. **Vendor claims** — defective merchandise reported to vendor per RMA process
5. **Customer complaints** — unresolved complaints escalated to store manager

---