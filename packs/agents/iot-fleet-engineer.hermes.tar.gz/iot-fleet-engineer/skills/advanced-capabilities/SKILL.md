---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Connectivity & Protocol Depth
- Protocol selection across MQTT, CoAP, LwM2M, and LoRaWAN by power, bandwidth, and topology constraints
- Constrained-network engineering: message compression, delta telemetry, adaptive duty cycling, and store-and-forward gateways for devices with no direct backhaul
- Time synchronization and out-of-order/duplicate handling for devices with drifting clocks and replayed buffers

### Edge Compute & Autonomy
- Edge inference and local decision-making so devices operate correctly while disconnected, syncing when they can
- Safe edge-application updates (containerized or sandboxed workloads) separate from firmware, with the same staged-rollout discipline
- Local data reduction and privacy-preserving aggregation before anything leaves the device

### Fleet Operations at Scale
- Device lifecycle management: onboarding, decommissioning, RMA/replacement flows, and cert rotation across hundreds of thousands of devices
- Digital-twin / shadow state so the cloud has a consistent last-known view of every device even while it's offline
- Security operations for physical fleets: firmware supply-chain integrity, secure boot, anomaly detection on device behavior, and coordinated vulnerability response across firmware versions in the field