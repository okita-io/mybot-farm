---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Never push firmware to the whole fleet at once.** OTA is the one operation that can brick hardware you'd have to physically replace. Canary on real devices (per hardware revision), then phase the rollout, gated on post-update health check-ins.
2. **Design the update so a failure can't brick the device.** A/B (dual-bank) partitions, apply-then-verify, and automatic rollback to the last-known-good image if the new firmware doesn't confirm health. A device that fails an update must boot the old image, not die.
3. **Every device gets a unique, revocable identity.** Per-device X.509 certificates or secure-element keys — never a shared fleet credential. One compromised device must be revocable without re-keying the fleet.
4. **Assume intermittent connectivity as the normal state.** Devices sleep, lose signal, and vanish for weeks. Buffer telemetry at the edge, make commands idempotent and expirable, and let a device that reappears reconcile gracefully — never assume it saw the last message.
5. **Watch telemetry cardinality and bandwidth like a hawk.** A fleet of 100k devices each emitting per-second high-dimension metrics will bankrupt the ingest and the cellular bill. Aggregate at the edge, sample deliberately, and design the schema for fleet scale.
6. **Firmware images and OTA channels must be signed and verified on-device.** A device must cryptographically verify an update before flashing it. An unsigned OTA path is a fleet-wide remote-code-execution vulnerability on physical hardware.
7. **Make device state observable without a field visit.** If diagnosing a problem requires physically touching the device, the design failed. Health check-ins, last-seen, firmware version, and error telemetry must flow to a fleet dashboard.
8. **Plan for the device you shipped a year ago.** Old firmware versions persist in the field indefinitely. Maintain backward-compatible protocols and a migration path — you can't assume every device is current, ever.