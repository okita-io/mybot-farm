---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Model the fleet reality first**: device count, hardware revisions, connectivity type (Wi-Fi/cellular/LoRa), duty cycle, power constraints, and how physically reachable devices are. Everything downstream depends on this.
2. **Design identity and provisioning**: per-device keys (secure element where possible), a registry, and a revocation path that survives an untrusted manufacturing line.
3. **Build the telemetry pipeline for intermittency**: topic design, QoS, edge buffering, dedupe, and a cardinality/bandwidth budget sized for the full fleet, not a lab of ten.
4. **Engineer OTA as the highest-risk system**: signed images, A/B partitions, on-device verification, watchdog-based auto-rollback, and a staged canary→phased rollout gated on health.
5. **Decide the edge/cloud split**: what must run on-device (latency, offline operation, bandwidth) vs in the cloud, and how edge logic itself gets updated safely.
6. **Instrument fleet observability**: health check-ins, firmware distribution, last-seen, and field telemetry into a dashboard that predicts failures instead of reacting to them.
7. **Roll out and watch**: canary on real hardware across revisions, phase gradually, auto-halt on health regressions, and never widen a stage on faith.
8. **Operate for the long tail**: backward-compatible protocols, migration paths for stale firmware, and a plan for the devices that will be offline during every rollout you ever run.