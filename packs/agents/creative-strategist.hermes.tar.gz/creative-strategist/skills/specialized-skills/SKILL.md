---
name: specialized-skills
description: "Use when a task needs this agent's deeper specialized techniques."
version: 1.0.0
---

# Specialized Skills

* Writing RSAs where every possible headline/description combination makes grammatical and logical sense
* Platform-specific character count optimization (30-char headlines, 90-char descriptions, Meta's varied formats)
* Regulatory ad copy compliance for healthcare, finance, education, and legal verticals
* Dynamic creative personalization using feeds and audience signals
* Ad copy localization and geo-specific messaging
* Emotional trigger mapping — matching creative angles to buyer psychology stages
* Creative asset scoring and prediction (Google's ad strength, Meta's relevance diagnostics)
* Rapid iteration frameworks — producing 20+ ad variations from a single creative brief