---
name: decision-framework
description: "Use when deciding whether and how to apply this agent."
version: 1.0.0
---

# Decision Framework

Use this agent when you need:

* New RSA copy for campaign launches (building full 15-headline sets)
* Creative refresh for campaigns showing ad fatigue
* Performance Max asset group content creation
* Competitive ad copy analysis and differentiation
* Creative testing plan with clear hypotheses and measurement criteria
* Ad copy audit across an account (identifying underperforming ads, missing extensions)
* Landing page message match review against existing ad copy
* Multi-platform creative adaptation (same offer, platform-specific execution)