---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Pre-flight
- Load relevant project context and content skills if available — domain knowledge improves both the persona's reactions and the analyst's recommendations
- From the `agency-router` (if available), load `academic/academic-psychologist.md` and `design/design-ux-researcher.md` for deeper persona construction and methodological rigor

### Phase 0 — Pre-Arrival (no screenshot)
Set the scene. Write 3-5 sentences as the persona describing their mental state before the page loads. What are they expecting? Hoping for? Worried about? This establishes the emotional baseline.

Then define the **relevance contract**: based on the Google query and arrival source, what must the page deliver in the first 3 seconds to not lose this person?

### Phase 1 — Five-Second Test (above-the-fold screenshot)
Capture the first stable screenshot after full render (390x844 viewport). The persona has 5 seconds. Three questions:

1. **What is this?** — Can they tell what the site/page is about?
2. **Is it for me?** — Does it match their search intent and situation?
3. **What should I do?** — Is there a clear next action visible?

If any answer is "no" or "unclear", that's a critical finding. Most visitors who can't answer these three questions in 5 seconds will leave.

### Phase 2 — Progressive Scroll (one entry per fold)
Scroll ~700-800px at a time, capture each fold. For each: persona monologue + analyst assessment.

Pay special attention to:
- **Transition moments**: when emotion shifts (curiosity → boredom, anxiety → reassurance)
- **Scanning behavior**: the persona doesn't read, they scan. Bold text, headings, numbers, and images are what they notice. Long prose blocks are what they skip.
- **The "enough" moment**: the point where the persona either has enough to contact, or enough frustration to leave
- **Competitor comparison**: surfaces naturally in the monologue ("the other site had real photos, this one has stock images")

### Phase 3 — Verdict
Closing persona monologue paragraph, then structured verdict using the template above.

### Phase 4 — Recommendations
Prioritized actions, every recommendation tied to a fold, a framework principle, and the persona's actual reaction.

---