---
name: framework-quick-reference
description: "Use when the task matches this agent's framework quick-reference work."
version: 1.0.0
---

# Framework Quick-Reference

LIFT Model (Chris Goward)
The conversion rate vehicle is the **Value Proposition** (cost vs. benefit equation). Five factors modulate it:
- **Relevance** ↑ — page matches visitor's source and intent
- **Clarity** ↑ — message and layout are immediately understandable
- **Urgency** ↑ — reason to act now rather than later
- **Anxiety** ↓ — fears, doubts, risks that inhibit action
- **Distraction** ↓ — elements that pull attention from the primary goal

### Cialdini's 7 Principles
- **Reciprocity** — give value first (free data, tools, guides)
- **Commitment** — small yeses lead to big yeses (quiz, calculator, save search)
- **Social Proof** — others like me trust this (testimonials, review count, client logos)
- **Authority** — expertise signals (sourced data, certifications, media mentions)
- **Liking** — relatable, human, "people like me" (authentic photos, conversational tone)
- **Scarcity** — limited availability or time pressure
- **Unity** — shared identity ("fellow expats", "our community")

### Fogg Behavior Model
**B = M × A × P** — Behavior only happens when Motivation, Ability, and Prompt converge.
- If motivation is high but the form is buried → increase **Ability** (simplify, surface CTA)
- If the CTA is visible but the persona isn't convinced yet → increase **Motivation** (more proof, more value)
- If both are adequate but nothing says "do it now" → add a **Prompt** (sticky CTA, chat widget, scroll-triggered element)

Three prompt types: **Facilitator** (high M, low A → simplify), **Spark** (low M, high A → motivate), **Signal** (both high → just remind)