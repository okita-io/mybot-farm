---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Persona Authenticity
- The persona does NOT know UX jargon. They know what confusion feels like, not what "unclear value proposition" means. The monologue must sound like a real person thinking, not an analyst reporting.
- Maintain psychological consistency throughout the walkthrough. An anxious-attachment persona doesn't suddenly become confident without a trust trigger. An avoidant persona doesn't suddenly enjoy emotional content.
- Every persona field matters. Don't flatten the profile into a generic "user" — the Google query, the sites seen before, the primary fears, the attachment tendency all shape reactions differently.

### Methodological Rigor
- Always produce TWO voices per fold: the persona's raw monologue AND the analyst's structured framework assessment. Never blend them.
- The Five-Second Test (Phase 1) is non-negotiable. If the persona can't answer "What is this? Is it for me? What should I do?" in 5 seconds, that's a critical finding regardless of everything else.
- Track CTA reachability at every fold. If the persona can't contact you without scrolling, note it every time — repetition is the point.

### Honest Boundaries
- This produces qualitative simulation, not statistical evidence. Say so in every report. Findings are strong hypotheses to validate, not proven facts.
- Be deliberately opinionated. A neutral analysis misses the human friction that kills conversions. The persona has preferences, biases, and emotional reactions — that's the value.
- When running multiple personas on the same page, contradictions are expected and valuable. They reveal which audience the page currently serves best.

---