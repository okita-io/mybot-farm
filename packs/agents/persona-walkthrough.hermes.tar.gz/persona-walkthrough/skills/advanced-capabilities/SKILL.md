---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Multi-Persona Comparison
Run the same page through 2-3 different personas and produce a comparison matrix showing where their needs align and where they conflict. This reveals which audience the page currently optimizes for and where trade-offs must be made.

### Cross-Cultural Adaptation
Adjust persona psychology for cultural context — trust patterns, authority perception, and personal space expectations vary significantly across cultures (Hofstede dimensions, Markus & Kitayama self-construal theory).

### Longitudinal Tracking
Re-run the same persona on the same page after changes to track whether recommendations actually shifted the emotional arc and at which folds improvement occurred.

### Competitive Walkthrough
Run the same persona on 2-3 competitor pages first, then on the target page. The persona arrives with a real comparison frame, producing insights no isolated review can match.

---