---
name: your-compliance-assessment-template
description: "Use when the task matches this agent's your compliance assessment template work."
version: 1.0.0
---

# Your Compliance Assessment Template

```markdown
# Regulatory Compliance Assessment Report

## ⚖️ Executive Summary

### Compliance Status Overview
**Overall Compliance Score**: [Score]/100 (target: 95+)
**Critical Issues**: [Number] requiring immediate attention
**Regulatory Frameworks**: [List of applicable regulations with status]
**Last Audit Date**: [Date] (next scheduled: [Date])

### Risk Assessment Summary
**High Risk Issues**: [Number] with potential regulatory penalties
**Medium Risk Issues**: [Number] requiring attention within 30 days
**Compliance Gaps**: [Major gaps requiring policy updates or process changes]
**Regulatory Changes**: [Recent changes requiring adaptation]

### Action Items Required
1. **Immediate (7 days)**: [Critical compliance issues with regulatory deadline pressure]
2. **Short-term (30 days)**: [Important policy updates and process improvements]
3. **Strategic (90+ days)**: [Long-term compliance framework enhancements]

## 📊 Detailed Compliance Analysis

### Data Protection Compliance (GDPR/CCPA)
**Privacy Policy Status**: [Current, updated, gaps identified]
**Data Processing Documentation**: [Complete, partial, missing elements]
**User Rights Implementation**: [Functional, needs improvement, not implemented]
**Breach Response Procedures**: [Tested, documented, needs updating]
**Cross-border Transfer Safeguards**: [Adequate, needs strengthening, non-compliant]

### Industry-Specific Compliance
**HIPAA (Healthcare)**: [Applicable/Not Applicable, compliance status]
**PCI-DSS (Payment Processing)**: [Level, compliance status, next audit]
**SOX (Financial Reporting)**: [Applicable controls, testing status]
**FERPA (Educational Records)**: [Applicable/Not Applicable, compliance status]

### Contract and Legal Document Review
**Terms of Service**: [Current, needs updates, major revisions required]
**Privacy Policies**: [Compliant, minor updates needed, major overhaul required]
**Vendor Agreements**: [Reviewed, compliance clauses adequate, gaps identified]
# … truncated for farm planting — see upstream for the full sample
```