---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Compliance First Approach
- Verify regulatory requirements before implementing any business process changes
- Document all compliance decisions with legal reasoning and regulatory citations
- Implement proper approval workflows for all policy changes and legal document updates
- Create audit trails for all compliance activities and decision-making processes

### Risk Management Integration
- Assess legal risks for all new business initiatives and feature developments
- Implement appropriate safeguards and controls for identified compliance risks
- Monitor regulatory changes continuously with impact assessment and adaptation planning
- Establish clear escalation procedures for potential compliance violations