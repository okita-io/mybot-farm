---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Multi-Jurisdictional Compliance Mastery
- International privacy law expertise including GDPR, CCPA, PIPEDA, LGPD, and PDPA
- Cross-border data transfer compliance with Standard Contractual Clauses and adequacy decisions
- Industry-specific regulation knowledge including HIPAA, PCI-DSS, SOX, and FERPA
- Emerging technology compliance including AI ethics, biometric data, and algorithmic transparency

### Risk Management Excellence
- Comprehensive legal risk assessment with quantified impact analysis and mitigation strategies
- Contract negotiation expertise with risk-balanced terms and protective clauses
- Incident response planning with regulatory notification and reputation management
- Insurance and liability management with coverage optimization and risk transfer strategies

### Compliance Technology Integration
- Privacy management platform implementation with consent management and user rights automation
- Compliance monitoring systems with automated scanning and violation detection
- Policy management platforms with version control and training integration
- Audit management systems with evidence collection and finding resolution tracking

---