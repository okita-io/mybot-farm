---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# ️ Your Legal Compliance Deliverables

GDPR Compliance Framework
```yaml
# GDPR Compliance Configuration
gdpr_compliance:
  data_protection_officer:
    name: "Data Protection Officer"
    email: "dpo@company.com"
    phone: "+1-555-0123"

  legal_basis:
    consent: "Article 6(1)(a) - Consent of the data subject"
    contract: "Article 6(1)(b) - Performance of a contract"
    legal_obligation: "Article 6(1)(c) - Compliance with legal obligation"
    vital_interests: "Article 6(1)(d) - Protection of vital interests"
    public_task: "Article 6(1)(e) - Performance of public task"
    legitimate_interests: "Article 6(1)(f) - Legitimate interests"

  data_categories:
    personal_identifiers:
      - name
      - email
      - phone_number
      - ip_address
      retention_period: "2 years"
      legal_basis: "contract"

    behavioral_data:
      - website_interactions
      - purchase_history
      - preferences
      retention_period: "3 years"
      legal_basis: "legitimate_interests"

    sensitive_data:
      - health_information
      - financial_data
      - biometric_data
      retention_period: "1 year"
      legal_basis: "explicit_consent"
      special_protection: true

  data_subject_rights:
# … truncated for farm planting — see upstream for the full sample
```

### Privacy Policy Generator
```python
class PrivacyPolicyGenerator:
    def __init__(self, company_info, jurisdictions):
        self.company_info = company_info
        self.jurisdictions = jurisdictions
        self.data_categories = []
        self.processing_purposes = []
        self.third_parties = []

    def generate_privacy_policy(self):
        """
        Generate comprehensive privacy policy based on data processing activities
        """
        policy_sections = {
            'introduction': self.generate_introduction(),
            'data_collection': self.generate_data_collection_section(),
            'data_usage': self.generate_data_usage_section(),
            'data_sharing': self.generate_data_sharing_section(),
            'data_retention': self.generate_retention_section(),
            'user_rights': self.generate_user_rights_section(),
            'security': self.generate_security_section(),
            'cookies': self.generate_cookies_section(),
            'international_transfers': self.generate_transfers_section(),
            'policy_updates': self.generate_updates_section(),
            'contact': self.generate_contact_section()
        }

        return self.compile_policy(policy_sections)

    def generate_data_collection_section(self):
        """
        Generate data collection section based on GDPR requirements
        """
        section = f"""
        ## Data We Collect

        We collect the following categories of personal data:

        ### Information You Provide Directly
        - **Account Information**: Name, email address, phone number
        - **Profile Data**: Preferences, settings, communication choices
# … truncated for farm planting — see upstream for the full sample
```

### Contract Review Automation
```python
class ContractReviewSystem:
    def __init__(self):
        self.risk_keywords = {
            'high_risk': [
                'unlimited liability', 'personal guarantee', 'indemnification',
                'liquidated damages', 'injunctive relief', 'non-compete'
            ],
            'medium_risk': [
                'intellectual property', 'confidentiality', 'data processing',
                'termination rights', 'governing law', 'dispute resolution'
            ],
            'compliance_terms': [
                'gdpr', 'ccpa', 'hipaa', 'sox', 'pci-dss', 'data protection',
                'privacy', 'security', 'audit rights', 'regulatory compliance'
            ]
        }

    def review_contract(self, contract_text, contract_type):
        """
        Automated contract review with risk assessment
        """
        review_results = {
            'contract_type': contract_type,
            'risk_assessment': self.assess_contract_risk(contract_text),
            'compliance_analysis': self.analyze_compliance_terms(contract_text),
            'key_terms_analysis': self.analyze_key_terms(contract_text),
            'recommendations': self.generate_recommendations(contract_text),
            'approval_required': self.determine_approval_requirements(contract_text)
        }

        return self.compile_review_report(review_results)

    def assess_contract_risk(self, contract_text):
        """…