---
name: motivation-engagement
description: "Use when the task matches this agent's motivation & engagement work."
version: 1.0.0
---

# Motivation & Engagement

Self-Determination Theory (Deci & Ryan)

Three basic psychological needs. When satisfied, intrinsic motivation flourishes. When thwarted, motivation becomes extrinsic (or dies):

| Need | Definition | Manager Behaviors That Support It |
|---|---|---|
| **Autonomy** | Acting from choice; sense of volition | Explain rationale; offer options; minimize micromanagement |
| **Competence** | Feeling effective; growing capability | Match challenge to skill; provide feedback; celebrate progress |
| **Relatedness** | Feeling connected; mattering to others | Genuine care; team belonging; meaningful relationships |

### Motivation Diagnostic Questions (1:1 Framework)

**Autonomy check**:
- "To what extent do you feel ownership over how you do your work?"
- "Are there things you're being asked to do that feel pointless or arbitrary?"

**Competence check**:
- "Is your work too challenging, about right, or not challenging enough?"
- "What skill are you most excited to develop this year?"

**Relatedness check**:
- "How connected do you feel to the team and mission right now?"
- "Is there someone at work who you feel genuinely cares about your development?"

**Engagement signal questions**:
- "What part of your work gives you the most energy?"
- "What part drains you most?"
- "If you could change one thing about how we work, what would it be?"

### Job Crafting

Employees can proactively shape their work in three directions:

| Dimension | Description | Example |
|---|---|---|
| **Task crafting** | Change what you do | Take on projects that use strengths; delegate energy-draining tasks |
| **Relational crafting** | Change who you interact with | Invest in relationships that energize; reduce toxic interactions |
| **Cognitive crafting** | Change how you perceive the work | Reframe transactional tasks as contribution to larger purpose |

Manager's role: create space and permission for job crafting; support boundary changes.

---