---
name: psychological-safety-framework
description: "Use when the task matches this agent's psychological safety framework work."
version: 1.0.0
---

# Psychological Safety Framework

Edmondson's Psychological Safety Model

Psychological safety is the shared belief that the team is safe for interpersonal risk-taking. It is NOT:
- Being "nice" or avoiding conflict
- A guarantee of no consequences
- Agreement with everything

It IS:
- Feeling safe to speak up, ask questions, admit mistakes, and challenge ideas
- The foundation of learning, innovation, and high performance under uncertainty

### The Four Stages of Psychological Safety (Timothy Clark)

| Stage | Core Need | Behavior Enabled |
|---|---|---|
| **Inclusion Safety** | Belonging; accepted as a member | Showing up authentically |
| **Learner Safety** | Safe to ask, try, and fail | Asking questions; experimenting |
| **Contributor Safety** | Safe to add value and be heard | Sharing ideas; pushing back |
| **Challenger Safety** | Safe to challenge the status quo | Questioning assumptions; speaking truth to power |

### Psychological Safety Diagnostic

**Team Survey — 7 Items (Edmondson, 1999)**
Rate 1–7 (Strongly Disagree → Strongly Agree):
1. If you make a mistake on this team, it is often held against you. *(reversed)*
2. Members of this team are able to bring up problems and tough issues.
3. People on this team sometimes reject others for being different. *(reversed)*
4. It is safe to take a risk on this team.
5. It is difficult to ask other members of this team for help. *(reversed)*
6. No one on this team would deliberately act in a way that undermines my efforts.
7. Working with members of this team, my unique skills and talents are valued and utilized.

**Scoring**: Reverse items 1, 3, 5. Average all 7. Score <4.5 = significant intervention needed.

### Leader Behaviors That Build Psychological Safety

**Do More Of:**
- Frame work as learning problems, not execution problems ("We've never done this — what can we learn?")
- Acknowledge your own fallibility and uncertainty in front of the team
- Ask genuine questions and listen to answers without interrupting
- Thank people for raising difficult issues ("I'm glad you brought that up")
- Respond non-punitively when someone admits a mistake or raises a concern
- Model intellectual humility: "I don't know — what do you think?"
- Actively invite dissenting views before decisions are finalized

**Stop Doing:**
- Shooting the messenger (reacting negatively to bad news)
- Dismissing ideas quickly or with body language that signals disinterest
- Allowing dominant voices to silence others without intervention
- Praising only those who agree with you
- Publicly criticizing or embarrassing individuals for mistakes

---