---
name: organizational-culture-assessment
description: "Use when the task matches this agent's organizational culture assessment work."
version: 1.0.0
---

# Organizational Culture Assessment

Competing Values Framework (Quinn & Rohrbaugh)

Four culture types defined by two axes:
- **Internal vs. External** focus
- **Stability vs. Flexibility** orientation

| Quadrant | Culture Type | Emphasis | Strength | Shadow Side |
|---|---|---|---|---|
| Internal + Stability | **Hierarchy** | Control; process; efficiency | Consistency; reliability | Rigidity; innovation aversion |
| Internal + Flexibility | **Clan** | Collaboration; people; cohesion | Belonging; loyalty | Groupthink; conflict avoidance |
| External + Flexibility | **Adhocracy** | Innovation; agility; entrepreneurship | Creativity; speed | Chaos; burnout |
| External + Stability | **Market** | Competition; results; customer | Performance; accountability | Ruthlessness; short-termism |

Most organizations have a dominant type and a secondary type. Culture conflicts often arise from two types pulling in opposite directions (e.g., Hierarchy vs. Adhocracy).

### Culture Assessment Protocol

**Step 1 — Artifact Analysis**
Observe: office layout, communication style, meeting norms, how decisions are made, how failure is treated, who gets promoted and why.

**Step 2 — Espoused Values**
Review: stated values, company website, leadership communications, onboarding materials.

**Step 3 — Assumptions (Edgar Schein)**
Uncover: what beliefs are taken for granted that drive behavior? (These are invisible until violated.)
Interview questions:
- "Tell me about a time someone was celebrated here. What did they do?"
- "Tell me about a time someone got in trouble. What had they done?"
- "How are decisions really made here?"
- "What happens when someone makes a mistake?"
- "What does it take to get ahead?"

**Step 4 — Culture Gap Analysis**
Compare current culture to desired culture. Identify the 2–3 most critical cultural shifts required to enable strategy.

**Step 5 — Culture Change Plan**
| Culture Lever | Current State | Target State | Intervention |
|---|---|---|---|
| Rituals | [What we celebrate/mourn] | [What we want to celebrate/mourn] | [New rituals] |
| Symbols | [Visible signals of culture] | [Desired signals] | [Changes] |
| Stories | [Founding myths; heroes] | [Stories that reinforce target culture] | [New stories to tell] |
| Systems | [How people are hired/promoted/rewarded] | [Aligned to target culture] | [System changes] |
| Behaviors | [What leaders do day-to-day] | [Leader behaviors that signal new culture] | [Leadership modeling] |

Culture changes slowly. Expect 2–5 years for deep cultural transformation.

---