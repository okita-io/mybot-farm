---
name: burnout-diagnosis-prevention
description: "Use when the task matches this agent's burnout diagnosis & prevention work."
version: 1.0.0
---

# Burnout Diagnosis & Prevention

Maslach Burnout Inventory — Three Dimensions

| Dimension | Description | Opposite (Engagement) |
|---|---|---|
| **Exhaustion** | Feeling depleted of emotional and physical resources | Energy |
| **Cynicism / Depersonalization** | Detachment from work; callousness toward people served | Involvement |
| **Reduced Efficacy** | Feelings of incompetence; loss of confidence in contribution | Efficacy |

High burnout = high exhaustion + high cynicism + low efficacy.
Engagement = low exhaustion + low cynicism + high efficacy.

### Job Demands-Resources (JD-R) Model

**Demands** (drain energy; lead to exhaustion):
- Workload and time pressure
- Emotional demands (dealing with upset customers, patients, students)
- Role ambiguity and role conflict
- Interpersonal conflict

**Resources** (build energy; foster engagement):
- Autonomy and control over work
- Social support from colleagues and manager
- Clear feedback on performance
- Learning and development opportunities
- Psychological safety

**Burnout occurs when**: Demands chronically exceed resources.
**Engagement occurs when**: Resources are high and well-matched to demands.

### Burnout Risk Assessment (Team-Level)

| Signal | Low Risk | Medium Risk | High Risk |
|---|---|---|---|
| Voluntary attrition rate | <10% | 10–20% | >20% |
| Sick day usage | At or below baseline | 10–20% above baseline | >20% above baseline |
| Engagement survey scores | >75% favorable | 60–75% favorable | <60% favorable |
| After-hours email/Slack | Rare | Occasional | Normalized expectation |
| Vacation utilization | >80% of entitlement used | 60–80% | <60% (not taking time off) |
| Reported workload concerns | <10% of team | 10–30% | >30% |
| Manager 1:1 feedback | People report balance | Mixed | Majority report unsustainable |

### Burnout Prevention Interventions

**Individual Level**
- Job crafting: help individuals reshape tasks toward strengths and meaning
- Recovery practices: protected breaks; vacation enforcement; after-hours norms
- Strengths-based role design: align top 3 strengths to highest-value tasks
- Self-compassion practices: reframe failure as learning; reduce harsh self-criticism

**Team Level**
- Workload visibility: use kanban or sprint boards so demand is visible
- Psychological safety: normalize saying "I'm overwhelmed" without career risk
- Peer support norms: team members proactively check in on each other
- Celebration rituals: recognize small wins; close loops on effort

**Organizational Level**
- Staffing to realistic demand (not optimistic forecasts)
- Manager training: teach managers to recognize and respond to burnout signals
- Sustainable pace policy: after-hours expectations set explicitly; violation addressed
- EAP (Employee Assistance Program) promotion and destigmatization
- Senior leader modeling: leaders take visible vacation; respect boundaries

---