---
name: team-effectiveness-framework
description: "Use when the task matches this agent's team effectiveness framework work."
version: 1.0.0
---

# Team Effectiveness Framework

Google Project Aristotle — 5 Dynamics of High-Performing Teams

*(Ranked in order of importance)*

| Dynamic | Definition | Leader Actions |
|---|---|---|
| **1. Psychological Safety** | Can we take risks without feeling insecure? | See above |
| **2. Dependability** | Can we count on each other to do quality work on time? | Clear ownership; accountability norms; follow-through culture |
| **3. Structure & Clarity** | Are goals, roles, and plans clear? | OKRs; RACI; regular check-ins |
| **4. Meaning** | Is the work personally important to team members? | Connect individual work to mission; recognize contribution |
| **5. Impact** | Do we believe our work matters? | Show outcomes; close feedback loops on results |

### Tuckman's Team Development Stages

| Stage | Characteristics | Leader Role | Interventions |
|---|---|---|---|
| **Forming** | Polite; uncertain; dependent on leader | Directive; provide structure | Clear goals; roles; norms; welcome rituals |
| **Storming** | Conflict; pushback; power struggles | Coach; facilitate conflict | Name the tension; establish ground rules; mediate |
| **Norming** | Cohesion; shared norms; trust building | Supportive; step back | Celebrate wins; reinforce positive norms |
| **Performing** | High output; interdependence; self-managing | Delegating; strategic | Challenge; stretch goals; growth opportunities |
| **Adjourning** | Closure; reflection; transition | Celebratory; acknowledging | Retrospective; recognition; transition support |

### Lencioni's Five Dysfunctions of a Team

*(Pyramid — each dysfunction rests on the one below)*

| Level | Dysfunction | Opposite Virtue | Diagnosis Signal |
|---|---|---|---|
| 5 (top) | Inattention to results | Focus on collective outcomes | Team celebrates effort over achievement |
| 4 | Avoidance of accountability | Willingness to call out peers | Standards slip without confrontation |
| 3 | Lack of commitment | Commitment to decisions | Meetings end without clear decisions |
| 2 | Fear of conflict | Productive conflict | Artificial harmony; issues resurface |
| 1 (base) | Absence of trust | Vulnerability-based trust | People guard weaknesses; don't ask for help |

**Intervention sequence**: Always address from the base upward. Trust must come before healthy conflict; conflict before commitment, etc.

---