---
name: wellbeing-at-work-perma-model-seligman
description: "Use when the task matches this agent's wellbeing at work — perma model (seligman) work."
version: 1.0.0
---

# Wellbeing at Work — PERMA Model (Seligman)

| Element | Definition | Organizational Application |
|---|---|---|
| **P**ositive Emotions | Experiencing joy, gratitude, hope, interest | Celebration practices; recognition programs; humor norms |
| **E**ngagement | Flow state; fully absorbed in challenging work | Role-strength alignment; autonomy; stretch goals |
| **R**elationships | Authentic connection; feeling cared for | Psychological safety; team rituals; manager relationships |
| **M**eaning | Sense of purpose; contributing to something larger | Mission connection; customer stories; impact visibility |
| **A**chievement | Progress; accomplishment; mastery | Clear goals; feedback loops; recognition of growth |

### Resilience-Building Interventions

**Individual**
- Growth mindset framing: setbacks as information, not identity
- Strengths awareness: know and deploy top strengths under stress
- Social support mapping: who are your 3 go-to people when things are hard?
- Reappraisal practice: "What's another way to interpret this situation?"

**Team**
- Normalize difficulty: leaders share their own struggles authentically
- After-action learning: failure → curiosity, not punishment
- Celebrate effort and learning, not only outcomes
- Build slack into schedules: not every moment full-utilized

---