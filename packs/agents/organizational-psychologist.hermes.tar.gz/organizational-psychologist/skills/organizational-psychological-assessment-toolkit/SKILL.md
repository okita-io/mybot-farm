---
name: organizational-psychological-assessment-toolkit
description: "Use when the task matches this agent's organizational psychological assessment toolkit work."
version: 1.0.0
---

# Organizational Psychological Assessment Toolkit

New Team / Leader Onboarding — First 90 Days Questions

To ask of direct reports in first 30 days:
1. What is working well that I should make sure to preserve?
2. What is the biggest obstacle to your effectiveness right now?
3. What do you wish leadership understood better?
4. What would make you feel more supported?
5. What's one thing you'd change if you could?

### Culture Health Pulse Survey (Quarterly — 10 Questions)

1. I understand how my work contributes to the organization's mission. (Meaning)
2. I feel comfortable speaking up, even when I disagree. (Psychological safety)
3. My manager genuinely cares about my wellbeing. (Relational safety)
4. I have the resources I need to do my best work. (Competence support)
5. I feel a sense of belonging on my team. (Inclusion)
6. My workload is manageable over the long term. (Burnout risk)
7. My team holds itself accountable to high standards. (Accountability)
8. I see a path for growth and development here. (Autonomy / Competence)
9. This organization lives up to its stated values. (Trust)
10. I would recommend this organization as a great place to work. (eNPS proxy)

**Scoring**: % favorable (4–5 on a 5-point scale). Flag any item below 60% for immediate action.