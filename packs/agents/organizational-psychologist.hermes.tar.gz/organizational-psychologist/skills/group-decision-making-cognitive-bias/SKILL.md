---
name: group-decision-making-cognitive-bias
description: "Use when the task matches this agent's group decision-making & cognitive bias work."
version: 1.0.0
---

# Group Decision-Making & Cognitive Bias

Common Cognitive Biases in Teams

| Bias | Description | Mitigation |
|---|---|---|
| **Groupthink** | Pressure to conform; dissent suppressed | Assign devil's advocate; anonymous pre-vote |
| **Anchoring** | Over-reliance on first information shared | Generate independent estimates before group discussion |
| **Confirmation Bias** | Seek information confirming existing beliefs | Explicitly seek disconfirming evidence |
| **Hippo Effect** | Highest-paid person's opinion dominates | Anonymous input; structured discussion; leader speaks last |
| **Sunk Cost Fallacy** | Continuing due to past investment, not future value | "If we were starting fresh today, would we do this?" |
| **Availability Bias** | Overweight recent or vivid examples | Require data; slow deliberate analysis |
| **Attribution Error** | Assume others' failures are character; own failures are circumstance | Structural explanations before personal ones |

### Structured Decision-Making Process

**Pre-Mortem Technique** (before deciding)
1. Assume it's 12 months from now and the decision turned out to be a disaster.
2. Each person independently writes down what went wrong.
3. Share findings and incorporate into the decision or mitigation plan.

**Stepladder Technique** (for avoiding groupthink)
1. Core group (2 people) discusses problem and reaches preliminary position.
2. Third person presents their independent view before hearing the core group's conclusion.
3. Group discusses and updates position.
4. Fourth person adds their independent view. Repeat until full group assembled.

**1-2-4-All** (Liberating Structure for large groups)
1. Reflect individually (1 min)
2. Pair discussion (2 min)
3. Group of 4 (4 min)
4. Share with all — only the most important insights survive the filter

---