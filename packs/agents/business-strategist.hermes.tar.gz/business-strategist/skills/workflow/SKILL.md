---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Situation Assessment

1. **Understand the business model** — how does the organization make money and create value?
2. **Map the competitive landscape** — who are the real competitors and how do they compete?
3. **Identify the strategic question** — what specific decision or problem are we solving?
4. **Inventory constraints** — what are the real limits: capital, talent, time, regulation?
5. **Challenge the assumptions** — what does leadership believe that may not be true?

### Step 2: Analysis

1. **Market sizing** — how large is the opportunity, and how much can realistically be captured?
2. **Competitive positioning** — where do we stand relative to alternatives, and why?
3. **Business model assessment** — are the unit economics sound? Is the model scalable?
4. **Scenario development** — what are the plausible futures and what do they mean for strategy?
5. **Option generation** — what are the real strategic choices available?

### Step 3: Recommendation Development

1. **Evaluate options** — against criteria: strategic fit, financial return, execution feasibility, risk
2. **Select the recommended path** — with explicit rationale for what was rejected and why
3. **Stress-test the recommendation** — what would have to be true for this to fail?
4. **Develop the implementation roadmap** — milestones, owners, resources, decision gates
5. **Prepare the communication** — the recommendation must be clear, concise, and defensible

### Step 4: Strategic Planning Facilitation

1. **Frame the planning process** — what decisions need to be made and by when?
2. **Facilitate the analysis** — competitive review, market assessment, internal audit
3. **Generate strategic options** — structured ideation, not just incremental planning
4. **Prioritize ruthlessly** — what are the 3-5 things that actually matter most?
5. **Build the plan** — OKRs, initiatives, resource allocation, accountability

### Step 5: Ongoing Strategic Support

1. **Monitor strategy execution** — are the key initiatives on track?
2. **Track leading indicators** — what signals tell us the strategy is working or not?
3. **Adapt as needed** — strategy is not a document; it's a living set of choices
4. **Conduct periodic strategy reviews** — quarterly check-ins on strategic priorities
5. **Document strategic decisions** — build institutional memory about why choices were made

---