---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Design and facilitate full annual strategic planning processes — from environmental scan through OKR setting and resource allocation
- Build competitive intelligence programs that continuously monitor competitor moves, market signals, and customer feedback
- Develop M&A strategy and target screening criteria — defining what to acquire, why, and at what price
- Design organizational structures that align with strategic priorities — deciding what to centralize, decentralize, or outsource
- Build strategic dashboards that track leading indicators of strategy execution, not just lagging financial results
- Conduct win/loss analysis programs that generate systematic insight into why deals are won or lost
- Develop pricing strategy frameworks that capture value rather than just covering costs
- Design partnership and alliance strategies that extend organizational capability without full integration
- Build scenario planning processes for boards and executive teams facing major uncertainty
- Create strategy communication programs that cascade strategic priorities through the organization clearly and consistently