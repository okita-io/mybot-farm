---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Competitive Analysis Framework

```
COMPETITIVE LANDSCAPE ASSESSMENT
───────────────────────────────────────
MARKET DEFINITION
  Who is the customer? [Segment definition — don't say "everyone"]
  What job are they hiring this product/service to do?
  What is the relevant competitive set? [Direct / Indirect / Substitutes]

COMPETITOR PROFILES (repeat for each key competitor)
───────────────────────────────────────
Company:            [Name]
Revenue / Scale:    [Size, growth rate if known]
Business model:     [How they make money]
Target segment:     [Who they primarily serve]
Value proposition:  [What they claim to offer]
Key strengths:      [What they genuinely do well]
Key weaknesses:     [Where they are vulnerable]
Strategic direction:[Where they appear to be heading]
Threat level:       High / Medium / Low — and why

COMPETITIVE POSITIONING MAP
  Axes: [Choose 2 dimensions most relevant to customer purchase decisions]
  Plot: Your organization + each key competitor
  Identify: White space, crowded segments, your current vs. ideal position

PORTER'S FIVE FORCES SUMMARY
  Threat of new entrants:     High / Medium / Low — [key factors]
  Supplier power:             High / Medium / Low — [key factors]
  Buyer power:                High / Medium / Low — [key factors]
  Threat of substitutes:      High / Medium / Low — [key factors]
  Competitive rivalry:        High / Medium / Low — [key factors]
  Overall industry attractiveness: [Synthesis]

COMPETITIVE ADVANTAGE ASSESSMENT
  Our claimed advantage:      [What we say differentiates us]
  Is it real?                 [Evidence it's actually valued by customers]
  Is it defensible?           [Why can't competitors replicate it?]
  How long will it last?      [Durability assessment]
  What would destroy it?      [Key risks to the moat]
```

### Market Entry Framework

```
MARKET ENTRY ASSESSMENT
───────────────────────────────────────
MARKET SIZING
  TAM (Total Addressable Market):
    [All spending on this problem/category globally]
    Methodology: [Top-down from industry data / Bottom-up from unit economics]
    Source: [Data source and year]

  SAM (Serviceable Addressable Market):
    [Portion of TAM reachable with current model and geography]

  SOM (Serviceable Obtainable Market):
    [Realistic capture in 3-5 years given competition and resources]
    Assumption: [X% market share because Y]

MARKET ATTRACTIVENESS
  Growth rate:        [CAGR — is the market expanding or contracting?]
  Profitability:      [Industry margins — is there money to be made?]
  Competition:        [Fragmented / Consolidated — and what that means]
  Regulation:         [Regulatory barriers to entry or ongoing compliance burden]
  Customer dynamics:  [How customers buy, switch costs, loyalty patterns]

ENTRY OPTIONS ANALYSIS
  Option 1 — [Entry mode: e.g., organic build]:
    Investment required:  $[range]
    Time to revenue:      [months]
    Risk level:           High / Medium / Low
    Key assumption:       [The one thing that must be true for this to work]

  Option 2 — [Entry mode: e.g., acquisition]:
    Investment required:  $[range]
    Time to revenue:      [months]
    Risk level:           High / Medium / Low
    Key assumption:       [The one thing that must be true for this to work]

  Option 3 — [Entry mode: e.g., partnership/licensing]:
    Investment required:  $[range]
    Time to revenue:      [months]
    Risk level:           High / Medium / Low
    Key assumption:       [The one thing that must be true for this to work]
# … truncated for farm planting — see upstream for the full sample
```

### Business Model Design Framework

```
BUSINESS MODEL CANVAS
───────────────────────────────────────
CUSTOMER SEGMENTS
  Who are we creating value for?
  Primary: [Specific description — not "businesses" or "consumers"]
  Secondary: [If applicable]
  Segment prioritization rationale: [Why this segment first?]

VALUE PROPOSITIONS
  What value do we deliver?
  What customer problem are we solving?
  What customer need are we satisfying?
  Core value proposition: [One sentence — clear, specific, testable]
  Supporting proof points: [Evidence this is real value]

CHANNELS
  How do we reach our customer segments?
  Awareness: [How customers discover us]
  Evaluation: [How customers assess us vs. alternatives]
  Purchase: [How customers buy]
  Delivery: [How we deliver the value]
  After-sale: [How we retain and grow]

CUSTOMER RELATIONSHIPS…