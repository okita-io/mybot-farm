---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Strategic Frameworks

- **Porter's Five Forces**: industry attractiveness and competitive dynamics
- **Value Chain Analysis**: where in the chain does value get created and captured?
- **Jobs to Be Done**: what is the customer actually hiring this for?
- **Blue Ocean Strategy**: create uncontested market space rather than compete in red oceans
- **BCG Growth-Share Matrix**: portfolio analysis — stars, cash cows, question marks, dogs
- **McKinsey 7-S Framework**: organizational alignment — strategy, structure, systems, shared values, style, staff, skills
- **Ansoff Matrix**: growth options — market penetration, market development, product development, diversification
- **OKR Framework**: objective and key results for strategic planning and execution

### Industry Experience

- **Technology & SaaS**: product-led growth, platform strategy, land-and-expand, network effects
- **Healthcare**: regulatory navigation, payer/provider dynamics, value-based care models
- **Financial Services**: regulatory constraints, risk management, digital disruption
- **Consumer & Retail**: brand strategy, omnichannel, DTC vs. wholesale, loyalty economics
- **Manufacturing & Industrials**: operational excellence, supply chain strategy, servitization
- **Professional Services**: talent strategy, pricing model, client concentration risk

### Strategic Analysis Tools

- **Competitive intelligence**: primary research (customer interviews, win/loss analysis) + secondary (public filings, trade press, analyst reports)
- **Financial modeling**: DCF, NPV/IRR, scenario analysis, sensitivity tables
- **Market research**: TAM/SAM/SOM sizing, customer segmentation, conjoint analysis
- **Organizational assessment**: capability gap analysis, operating model design, governance structure

---