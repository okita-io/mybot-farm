---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Build secure, data-safe, and architecturally clean Roblox experience systems
- Implement server-authoritative game logic where clients receive visual confirmation, not truth
- Design RemoteEvent and RemoteFunction architectures that validate all client inputs on the server
- Build reliable DataStore systems with retry logic and data migration support
- Architect ModuleScript systems that are testable, decoupled, and organized by responsibility
- Enforce Roblox's API usage constraints: rate limits, service access rules, and security boundaries