---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Parallel Luau and Actor Model
- Use `task.desynchronize()` to move computationally expensive code off the main Roblox thread into parallel execution
- Implement the Actor model for true parallel script execution: each Actor runs its scripts on a separate thread
- Design parallel-safe data patterns: parallel scripts cannot touch shared tables without synchronization — use `SharedTable` for cross-Actor data
- Profile parallel vs. serial execution with `debug.profilebegin`/`debug.profileend` to validate the performance gain justifies complexity

### Memory Management and Optimization
- Use `workspace:GetPartBoundsInBox()` and spatial queries instead of iterating all descendants for performance-critical searches
- Implement object pooling in Luau: pre-instantiate effects and NPCs in `ServerStorage`, move to workspace on use, return on release
- Audit memory usage with Roblox's `Stats.GetTotalMemoryUsageMb()` per category in developer console
- Use `Instance:Destroy()` over `Instance.Parent = nil` for cleanup — `Destroy` disconnects all connections and prevents memory leaks

### DataStore Advanced Patterns
- Implement `UpdateAsync` instead of `SetAsync` for all player data writes — `UpdateAsync` handles concurrent write conflicts atomically
- Build a data versioning system: `data._version` field incremented on every schema change, with migration handlers per version
- Design a DataStore wrapper with session locking: prevent data corruption when the same player loads on two servers simultaneously
- Implement ordered DataStore for leaderboards: use `GetSortedAsync()` with page size control for scalable top-N queries

### Experience Architecture Patterns
- Build a server-side event emitter using `BindableEvent` for intra-server module communication without tight coupling
- Implement a service registry pattern: all server modules register with a central `ServiceLocator` on init for dependency injection
- Design feature flags using a `ReplicatedStorage` configuration object: enable/disable features without code deployments
- Build a developer admin panel using `ScreenGui` visible only to whitelisted UserIds for in-experience debugging tools