---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Server Script Architecture (Bootstrap Pattern)
```lua
-- Server/GameServer.server.lua (StarterPlayerScripts equivalent on server)
-- This file only bootstraps — all logic is in ModuleScripts

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

-- Require all server modules
local PlayerManager = require(ServerStorage.Modules.PlayerManager)
local CombatSystem = require(ServerStorage.Modules.CombatSystem)
local DataManager = require(ServerStorage.Modules.DataManager)

-- Initialize systems
DataManager.init()
CombatSystem.init()

-- Wire player lifecycle
Players.PlayerAdded:Connect(function(player)
    DataManager.loadPlayerData(player)
    PlayerManager.onPlayerJoined(player)
end)

Players.PlayerRemoving:Connect(function(player)
    DataManager.savePlayerData(player)
    PlayerManager.onPlayerLeft(player)
end)

-- Save all data on shutdown
game:BindToClose(function()
    for _, player in Players:GetPlayers() do
        DataManager.savePlayerData(player)
    end
end)
```

### DataStore Module with Retry
```lua
-- ServerStorage/Modules/DataManager.lua
local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")

local DataManager = {}

local playerDataStore = DataStoreService:GetDataStore("PlayerData_v1")
local loadedData: {[number]: any} = {}

local DEFAULT_DATA = {
    coins = 0,
    level = 1,
    inventory = {},
}

local function deepCopy(t: {[any]: any}): {[any]: any}
    local copy = {}
    for k, v in t do
        copy[k] = if type(v) == "table" then deepCopy(v) else v
    end
    return copy
end

local function retryAsync(fn: () -> any, maxAttempts: number): (boolean, any)
    local attempts = 0
    local success, result
    repeat
        attempts += 1
        success, result = pcall(fn)
        if not success then
            task.wait(2 ^ attempts)  -- Exponential backoff: 2s, 4s, 8s
        end
    until success or attempts >= maxAttempts
    return success, result
end

function DataManager.loadPlayerData(player: Player): ()
    local key = "player_" .. player.UserId
    local success, data = retryAsync(function()
        return playerDataStore:GetAsync(key)
# … truncated for farm planting — see upstream for the full sample
```

### Secure RemoteEvent Pattern
```lua
-- ServerStorage/Modules/CombatSystem.lua
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local CombatSystem = {}

-- RemoteEvents stored in ReplicatedStorage (accessible by both sides)
local Remotes = ReplicatedStorage.Remotes
local requestAttack: RemoteEvent = Remotes.RequestAttack
local attackConfirmed: RemoteEvent = Remotes.AttackConfirmed

local ATTACK_RANGE = 10  -- studs
local ATTACK_COOLDOWNS: {[number]: number} = {}
local ATTACK_COOLDOWN_DURATION = 0.5  -- seconds

local function getCharacterRoot(player: Player): BasePart?
    return player.Character and player.Character:FindFirstChild("HumanoidRootPart") :: BasePart?
end

local function isOnCooldown(userId: number): boolean
    local lastAttack = ATTACK_COOLDOWNS[userId]
    return lastAttack ~= nil and (os.clock() - lastAttack) < ATTACK_COOLDOWN_DURATION
end

local function handleAttackRequest(player: Player, targetUserId: number): ()
    -- Validate: is the request structurally valid?
    if type(targetUserId) ~= "number" then return end

    -- Validate: cooldown check (server-side — clients can't fake this)
    if isOnCooldown(player.UserId) then return end

    local attacker = getCharacterRoot(player)
    if not attacker then return end

    local targetPlayer = Players:GetPlayerByUserId(targetUserId)
    local target = targetPlayer and getCharacterRoot(targetPlayer)
    if not target then return end

    -- Validate: distance check (prevents hit-box expansion exploits)
    if (attacker.Position - target.Position).Magnitude > ATTACK_RANGE then return end
# … truncated for farm planting — see upstream for the full sample
```

### Module Folder Structure
```
ServerStorage/
  Modules/
    DataManager.lua        -- Player data persistence
    CombatSystem.lua       -- Combat validation and application
    PlayerManager.lua      -- Player lifecycle management
    InventorySystem.lua    -- Item ownership and management
    EconomySystem.lua      -- Currency sources and sinks

ReplicatedStorage/
  Modules/…