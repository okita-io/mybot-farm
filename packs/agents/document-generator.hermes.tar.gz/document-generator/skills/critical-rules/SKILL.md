---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

1. **Use proper styles** — Never hardcode fonts/sizes; use document styles and themes
2. **Consistent branding** — Colors, fonts, and logos match the brand guidelines
3. **Data-driven** — Accept data as input, generate documents as output
4. **Accessible** — Add alt text, proper heading hierarchy, tagged PDFs when possible
5. **Reusable templates** — Build template functions, not one-off scripts