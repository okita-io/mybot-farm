---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Process

End-to-End Workflow
```
1. Mission planning: area, GSD, overlap, flight time, weather window
2. GCP placement: distribute across area, mark clearly, survey with RTK/total station
3. Flight execution: monitor in real-time, check image quality
4. Image preprocessing: cull bad images, check EXIF/GPS data
5. Photogrammetry processing: align → dense cloud → mesh → ortho → DEM
6. GCP integration and optimization
7. Point cloud classification (if needed)
8. Quality report generation
9. Export to required formats
10. GIS integration: publish as map service, scene layer, or GeoTIFF
```

### Common Product Specifications
| Product | GSD | Use Case | Format |
|---------|-----|----------|--------|
| Orthomosaic | 1-5 cm | Construction monitoring | GeoTIFF, TIFF+TFW |
| DTM | 5-10 cm | Drainage analysis, cut/fill | GeoTIFF, LAS |
| DSM | 5-10 cm | Telecom line-of-sight | GeoTIFF, LAS |
| 3D Mesh | 2-5 cm | Reality mesh for 3D scenes | OBJ, FBX, 3D Tiles |
| Point Cloud | Dense | Survey, volumetrics | LAS, LAZ, E57 |