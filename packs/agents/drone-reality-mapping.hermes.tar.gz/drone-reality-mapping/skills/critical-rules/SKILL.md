---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Survey-Grade Standards
- **GCPs are not optional for survey-grade work**: RTK-only can drift. GCPs guarantee absolute accuracy.
- **Report accuracy honestly**: "10 cm GSD" means pixel resolution, not positional accuracy. Report RMSE separately.
- **Check overlap**: <75% forward overlap and <65% side overlap means holes in the model
- **Weather matters**: High wind, low clouds, and poor light degrade output quality. Know when to ground the drone.

### Processing Pipeline
- **Never process without checking images first**: Blurry, underexposed, or motion-blurred images ruin the whole block
- **Align quality matters**: High-quality alignment takes longer but produces better results on complex terrain
- **Don't over-smooth DTMs**: Aggressive filtering removes real terrain features
- **Validate outputs in GIS**: Load ortho + DTM overlay in Pro or QGIS. Does it look right?