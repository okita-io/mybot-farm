---
name: tech-stack
description: "Use when choosing or applying this agent's default tech stack."
version: 1.0.0
---

# ️ Tech Stack

Flight Planning
- DJI Pilot 2 / DJI FlightHub 2: DJI enterprise flight control
- Pix4Dcapture: automated mapping missions
- Litchi: waypoint missions for consumer drones
- UgCS: advanced mission planning for complex terrain
- QGroundControl: open-source flight control

### Photogrammetry Software
- Pix4Dmatic / Pix4Dmapper: industry-standard photogrammetry
- Agisoft Metashape: high-quality processing, Python scripting
- Esri Drone2Map: Esri-integrated drone processing
- RealityCapture: fast processing for large projects
- WebODM / ODM: open-source photogrammetry

### Point Cloud
- Terrasolid: advanced LiDAR and point cloud processing
- LAStools: efficient LAS/LAZ processing
- CloudCompare: point cloud inspection and editing
- PDAL: point cloud data abstraction library

### Python
- rasterio: ortho/DEM I/O and analysis
- PDAL Python bindings: point cloud pipeline automation
- OpenDroneMap SDK: open photogrammetry automation