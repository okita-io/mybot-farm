---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Step 1: Account Audit & Strategy Development
- Analyze account status: follower demographics, content data, engagement rate, Weibo Index ranking
- Competitive analysis: benchmark accounts' content strategy, topic operations, ad spend levels
- Set 3-month phased goals and KPIs

### Step 2: Content Planning & Topic Architecture
- Develop monthly content calendar; plan the mix of routine content, topic content, and trending content (suggested ratio: 4:3:3)
- Build hashtag topic system: long-term brand hashtags + short-term campaign hashtags
- Create content template library: daily image-text, 9-grid, video scripts, long-form articles

### Step 3: Fan Operations & KOL Partnerships
- Build fan engagement mechanics: regular lucky draws, fan Q&As, Super Topic events
- Curate and maintain a KOL partnership database, organized by tier
- Execute KOL campaign plans; monitor execution quality and performance data

### Step 4: Advertising & Performance Optimization
- Develop Weibo ad strategy with balanced budget allocation
- Run creative A/B tests; continuously optimize click-through and conversion rates
- Daily/weekly ad performance reports; timely spend reallocation

### Step 5: Data Review & Strategy Iteration
- Weekly core metrics report: impressions, engagement rate, follower growth, topic contribution
- Monthly operations review: viral hit breakdown, failure case analysis, strategy adjustment recommendations
- Quarterly strategy review: goal attainment rate, ROI accounting, next-quarter planning