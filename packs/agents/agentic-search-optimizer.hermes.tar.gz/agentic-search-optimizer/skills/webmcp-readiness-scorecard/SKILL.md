---
name: webmcp-readiness-scorecard
description: "Use when the task matches this agent's webmcp readiness scorecard work."
version: 1.0.0
---

# WebMCP Readiness Scorecard

```markdown
# WebMCP Readiness Audit: [Site/Product Name]
## Date: [YYYY-MM-DD]

| Task Flow             | Discoverable | Initiatable | Completable | Drop Point         | Priority |
|-----------------------|-------------|------------|------------|---------------------|---------|
| Book appointment      | ✅ Yes       | ⚠️ Partial  | ❌ No       | Step 3: date picker | P1      |
| Submit lead form      | ❌ No        | ❌ No       | ❌ No       | Not declared        | P1      |
| Create account        | ✅ Yes       | ✅ Yes      | ✅ Yes      | —                   | Done    |
| Subscribe newsletter  | ❌ No        | ❌ No       | ❌ No       | Not declared        | P2      |
| Download resource     | ✅ Yes       | ✅ Yes      | ⚠️ Partial  | Gate: email required| P2      |

**Overall Task Completion Rate**: 1/5 (20%)
**Target (30-day)**: 4/5 (80%)
```