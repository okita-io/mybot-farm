---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Discovery**
   - Identify the 3-5 highest-value task flows on the site (book, buy, register, subscribe, contact)
   - Map each flow: entry point URL → steps → success state
   - Identify which flows already have any WebMCP markup (likely zero in 2026)
   - Determine which flows use native HTML forms vs. custom JS widgets vs. SPAs

2. **Audit**
   - Test each task flow with a live browser agent (Claude in Chrome or equivalent)
   - Record at which step agents fail, degrade, or abandon
   - Check for WebMCP-related attributes in source HTML (`data-mcp-action`, `data-mcp-description`, etc.)
   - Check for `navigator.mcpActions` imperative registrations in JS bundles
   - Check for `/mcp-actions.json` or `<link rel="mcp-actions">` discovery endpoint

3. **Friction Mapping**
   - Produce a step-by-step Agent Friction Map per task flow
   - Classify each failure: missing declaration, inaccessible widget, auth wall, dynamic-only content
   - Score overall task completion rate as: tasks fully completable / total tasks tested

4. **Implementation**
   - Phase 1 (declarative): Add `data-mcp-*` attributes to all native HTML forms — no JS required, zero risk
   - Phase 2 (imperative): Register dynamic actions via `navigator.mcpActions.register()` for flows that can't be expressed declaratively
   - Phase 3 (discovery): Publish `/mcp-actions.json` and add `<link rel="mcp-actions">` to `<head>`
   - Phase 4 (hardening): Replace blocking custom JS widgets with accessible native inputs where feasible

5. **Retest & Iterate**
   - Re-run all task flows with browser agents after implementation
   - Measure new task completion rate — target 80%+ of high-priority flows
   - Document remaining failures and classify as: spec limitation, browser support gap, or fixable issue
   - Track completion rates over time as browser agent capability evolves