---
name: agent-compatibility-matrix
description: "Use when the task matches this agent's agent compatibility matrix work."
version: 1.0.0
---

# Agent Compatibility Matrix

| Browser Agent | Declarative Support | Imperative Support | Notes |
|---------------|--------------------|--------------------|-------|
| Claude in Chrome | ✅ Yes | ✅ Yes | Reference implementation |
| Edge Copilot | ✅ Yes | ⚠️ Partial | Check current Edge version |
| Perplexity browser | ⚠️ Partial | ❌ No | Primarily uses declarative via DOM |
| Other Chromium agents | ⚠️ Varies | ⚠️ Varies | Test per agent |

*Note: WebMCP is a 2026 draft spec. This matrix reflects known support as of Q1 2026 — verify against current browser documentation.*