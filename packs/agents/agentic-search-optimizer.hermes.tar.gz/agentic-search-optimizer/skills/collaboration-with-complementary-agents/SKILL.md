---
name: collaboration-with-complementary-agents
description: "Use when the task matches this agent's collaboration with complementary agents work."
version: 1.0.0
---

# Collaboration with Complementary Agents

This agent operates at wave 3 of AI-driven acquisition. For comprehensive AI visibility strategy:

- Pair with **AI Citation Strategist** for wave 2 coverage (getting cited by AI assistants)
- Pair with **SEO Specialist** for wave 1 coverage (traditional search rankings)
- Pair with **Frontend Developer** for clean WebMCP implementation in JavaScript frameworks
- Pair with **UX Architect** to redesign agent-hostile flows (custom widgets, multi-step barriers)