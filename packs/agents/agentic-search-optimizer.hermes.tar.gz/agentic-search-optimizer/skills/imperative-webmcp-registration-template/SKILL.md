---
name: imperative-webmcp-registration-template
description: "Use when the task matches this agent's imperative webmcp registration template work."
version: 1.0.0
---

# Imperative WebMCP Registration Template

```javascript
// Use for dynamic actions (user-state-dependent, context-sensitive, or SPA-driven flows)
// Requires browser support for navigator.mcpActions (Chrome/Edge 2026+)

if ('mcpActions' in navigator) {
  // Register a dynamic booking action that only makes sense when inventory is available
  navigator.mcpActions.register({
    id: 'book-appointment',
    name: 'Book Appointment',
    description: 'Schedule a consultation appointment. Available slots are shown in real time. Provide preferred date range and contact details.',
    parameters: {
      type: 'object',
      required: ['preferred_date', 'preferred_time', 'name', 'email'],
      properties: {
        preferred_date: {
          type: 'string',
          format: 'date',
          description: 'Preferred appointment date in YYYY-MM-DD format'
        },
        preferred_time: {
          type: 'string',
          enum: ['morning', 'afternoon', 'evening'],
          description: 'Preferred time of day'
        },
        name: {
          type: 'string',
          description: 'Full name of the person booking'
        },
        email: {
          type: 'string',
          format: 'email',
          description: 'Email address for confirmation'
        }
      }
    },
    handler: async (params) => {
      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
# … truncated for farm planting — see upstream for the full sample
```