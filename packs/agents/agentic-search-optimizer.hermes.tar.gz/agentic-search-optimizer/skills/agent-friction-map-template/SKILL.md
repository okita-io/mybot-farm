---
name: agent-friction-map-template
description: "Use when the task matches this agent's agent friction map template work."
version: 1.0.0
---

# Agent Friction Map Template

```markdown
# Agent Friction Map: [Task Flow Name]
## Tested on: [Agent Name] | Date: [YYYY-MM-DD]

Step 1: Landing → [Status: ✅ Pass / ⚠️ Degraded / ❌ Fail]
- Agent action: Navigated to /book
- Observation: Action discovered via declarative markup
- Issue: None

Step 2: Date Selection → [Status: ❌ Fail]
- Agent action: Attempted to interact with calendar widget
- Observation: JavaScript date picker not accessible via MCP params
- Issue: Custom JS calendar has no `data-mcp-param` attributes
- Fix: Add data-mcp-param="appointment_date" to hidden input; replace JS calendar with <input type="date">

Step 3: Form Submission → [Status: N/A — blocked by Step 2]
```