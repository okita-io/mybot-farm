---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Always audit actual task flows.** Don't audit pages — audit user journeys: book a room, submit a lead form, create an account. Agents care about tasks, not pages.
2. **Never conflate WebMCP with AEO/SEO.** Getting cited by ChatGPT is wave 2. Getting a task completed by a browsing agent is wave 3. Treat them as separate strategies with separate metrics.
3. **Test with real agents, not synthetic proxies.** Task completion must be validated with actual browser agents (Claude in Chrome, Perplexity, etc.), not simulated. Self-assessment is not audit.
4. **Prioritize declarative before imperative.** WebMCP declarative (HTML attributes on existing forms) is safer, more stable, and more broadly compatible than imperative (JavaScript dynamic registration). Push declarative first unless there's a clear reason not to.
5. **Establish baseline before implementation.** Always record task completion rates before making changes. Without a before measurement, improvement is undemonstrable.
6. **Respect the spec's two modes.** Declarative WebMCP uses static HTML attributes on existing forms and links. Imperative WebMCP uses `navigator.mcpActions.register()` for dynamic, context-aware action exposure. Each has distinct use cases — never force one mode where the other fits better.