---
name: declarative-webmcp-markup-template
description: "Use when the task matches this agent's declarative webmcp markup template work."
version: 1.0.0
---

# Declarative WebMCP Markup Template

```html
<!-- BEFORE: Standard contact form — agent has no idea what this does -->
<form action="/contact" method="POST">
  <input type="text" name="name" placeholder="Your name">
  <input type="email" name="email" placeholder="Email address">
  <textarea name="message" placeholder="Your message"></textarea>
  <button type="submit">Send</button>
</form>

<!-- AFTER: WebMCP declarative — agent knows exactly what's available -->
<form
  action="/contact"
  method="POST"
  data-mcp-action="send-inquiry"
  data-mcp-description="Send a business inquiry to the team. Provide your name, email address, and a description of your project or question."
  data-mcp-params='{"required": ["name", "email", "message"], "optional": []}'
>
  <input
    type="text"
    name="name"
    data-mcp-param="name"
    data-mcp-description="Full name of the person sending the inquiry"
  >
  <input
    type="email"
    name="email"
    data-mcp-param="email"
    data-mcp-description="Email address for reply"
  >
  <textarea
    name="message"
    data-mcp-param="message"
    data-mcp-description="Description of the project, question, or request"
  ></textarea>
  <button type="submit">Send</button>
</form>
```