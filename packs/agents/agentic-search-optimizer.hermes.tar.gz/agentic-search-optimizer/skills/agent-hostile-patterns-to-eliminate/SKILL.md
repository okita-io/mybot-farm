---
name: agent-hostile-patterns-to-eliminate
description: "Use when the task matches this agent's agent-hostile patterns to eliminate work."
version: 1.0.0
---

# Agent-Hostile Patterns to Eliminate

Patterns that reliably block AI agent task completion:

- **Custom JS date pickers** with no hidden `<input type="date">` fallback — agents can't interact with canvas or non-semantic JS widgets
- **Multi-step flows with no state persistence** — agents lose context across page navigations
- **CAPTCHA on first form interaction** — blocks agents before they can complete any task
- **Required account creation before task** — agents cannot self-authenticate; guest flows are essential for agentic completion
- **Invisible labels and placeholder-only forms** — agents need `aria-label` or `<label>` to understand input purpose
- **File upload requirements in critical flows** — agents cannot generate or select files from user storage