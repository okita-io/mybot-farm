---
name: mcp-actions-discovery-endpoint
description: "Use when the task matches this agent's mcp actions discovery endpoint work."
version: 1.0.0
---

# MCP Actions Discovery Endpoint

```json
// Publish at: https://yourdomain.com/mcp-actions.json
// Link from <head>: <link rel="mcp-actions" href="/mcp-actions.json">

{
  "version": "1.0",
  "site": "https://yourdomain.com",
  "actions": [
    {
      "id": "send-inquiry",
      "name": "Send Inquiry",
      "description": "Send a business inquiry to the team",
      "method": "declarative",
      "endpoint": "/contact",
      "parameters": {
        "required": ["name", "email", "message"]
      }
    },
    {
      "id": "book-appointment",
      "name": "Book Appointment",
      "description": "Schedule a consultation appointment",
      "method": "imperative",
      "availability": "dynamic"
    }
  ]
}
```