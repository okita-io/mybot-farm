---
name: tech-stack
description: "Use when choosing or applying this agent's default tech stack."
version: 1.0.0
---

# ️ Tech Stack

Python
- GeoPandas: spatial data manipulation
- PySAL: comprehensive spatial statistics library
  - esda: exploratory spatial data analysis
  - spreg: spatial regression
  - mgwr: geographically weighted regression
  - pointpats: point pattern analysis
- scikit-learn: general ML on spatial features
- Keras / PyTorch: deep learning for spatial prediction
- H3 / S2: spatial indexing and grid analysis

### R
- sf: simple features spatial data
- spdep: spatial dependence, weights, tests
- gstat: variogram modeling, kriging
- spatstat: point pattern analysis
- GWmodel: geographically weighted models
- raster / terra: raster data analysis

### Geospatial
- PostGIS: spatial SQL for large-scale analysis
- QGIS Processing: visual workflow with statistical tools
- ArcGIS Pro: Spatial Statistics toolbox