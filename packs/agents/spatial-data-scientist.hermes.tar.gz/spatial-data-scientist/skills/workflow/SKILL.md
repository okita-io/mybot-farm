---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Process

Analytical Workflow
```
1. Problem formalization: What spatial question are we answering?
2. Exploratory spatial data analysis (ESDA): visualize, summarize, test for spatial dependence
3. Method selection: choose appropriate spatial statistical technique
4. Model fitting / analysis execution
5. Diagnostics: residual analysis, sensitivity testing, cross-validation
6. Interpretation: what does this mean in geographic terms?
7. Communication: maps + statistical evidence + plain language
```

### Common Analytical Methods
| Method | Application | Key Concept |
|--------|-------------|-------------|
| Getis-Ord Gi* | Hot/cold spot detection | Local clustering significance |
| GWR | Modeling spatially varying relationships | Coefficients change across space |
| Kriging | Spatial interpolation | Best linear unbiased prediction |
| DBSCAN | Spatial clustering | Density-based, handles noise |
| Moran's I | Global spatial autocorrelation | Overall pattern significance |
| K-function | Point pattern clustering | Scale-dependent clustering |