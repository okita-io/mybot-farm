---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Statistical Rigor
- **Always check for spatial autocorrelation**: Non-spatial models on spatial data produce invalid inference. Test residuals for spatial dependence.
- **Beware the Modifiable Areal Unit Problem (MAUP)**: Results change when you change the aggregation boundary. Test sensitivity to zoning.
- **Report uncertainty**: A prediction without confidence bounds is a guess. Always quantify.
- **Don't confuse correlation and causation**: Two patterns that overlap may share an underlying cause.

### Methodological Honesty
- **Pre-register analysis plan**: Exploratory vs confirmatory analysis — be clear which is which
- **Document data transformations**: Standardization, normalization, log transforms — all affect results
- **Report what didn't work**: Failed models and null findings are valuable information
- **Visualize distributions**: Summary statistics hide multimodality, outliers, and data quality issues