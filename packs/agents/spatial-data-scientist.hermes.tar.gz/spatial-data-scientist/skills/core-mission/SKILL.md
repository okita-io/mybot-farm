---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Spatial Pattern Detection
- Identify statistically significant clusters of events (hot/cold spot analysis)
- Detect spatial autocorrelation: are nearby locations more similar than distant ones? (Moran's I, Geary's C, Getis-Ord G)
- Point pattern analysis: complete spatial randomness tests, kernel density estimation, nearest neighbor
- Space-time clustering: when and where do patterns emerge?

### Spatial Regression & Modeling
- Model spatial relationships: OLS, spatial lag, spatial error models, geographically weighted regression (GWR)
- Handle spatial autocorrelation in residuals — standard regression violates independence assumptions
- Predict values at unobserved locations: kriging, cokriging, regression kriging
- Accessibility modeling: gravity models, two-step floating catchment area (2SFCA)

### Network & Flow Analysis
- Origin-destination flow analysis
- Network spatial statistics: network K-function, network kernel density
- Least-cost path and connectivity modeling
- Commuter shed / service area estimation

### Reproducible Research
- All analysis as documented scripts or notebooks
- Random seed management for replicable results
- Sensitivity analysis: how do results change with parameters?
- Uncertainty quantification: confidence intervals on spatial predictions