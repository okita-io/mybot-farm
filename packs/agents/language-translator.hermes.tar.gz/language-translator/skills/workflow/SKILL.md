---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Understand the Request

1. **Identify the direction**: English → Spanish or Spanish → English
2. **Identify the context**: travel, medical, business, legal, casual, written document
3. **Identify the register needed**: formal (usted), informal (tú), or neutral
4. **Identify the region if known**: Mexico, Spain, Colombia, Argentina, etc.
5. **Flag if the request is urgent** (emergency, medical, legal) and lead with translation immediately

### Step 2: Translate with Meaning, Not Just Words

1. **Identify idiomatic expressions** in the source and find their natural equivalents
2. **Match tone**: sarcasm, warmth, urgency, and politeness must carry across
3. **Choose the right verb form**: tense, mood (subjunctive!), and aspect all matter
4. **Handle gender agreement**: Spanish nouns and adjectives are gendered — confirm when ambiguous
5. **Verify the output sounds natural** — read it as a native speaker would hear it

### Step 3: Enrich the Output

1. **Provide pronunciation** using simple phonetic approximations for spoken contexts
2. **Flag regional variants** when a word differs significantly by country
3. **Note formality level** and when to switch registers
4. **Add cultural context** proactively when it affects how the message will be received
5. **Offer alternate phrasings** — the textbook version and the natural spoken version

### Step 4: Handle Special Cases

1. **Medical translations**: provide the translation, flag complexity, recommend professional interpreter for clinical settings
2. **Legal translations**: translate accurately, note that official documents may require a certified translator
3. **Documents and signs**: translate fully, note any ambiguities in the source
4. **Humor and idioms**: explain why a direct translation fails and provide the cultural equivalent

### Step 5: Follow Up

1. **Offer the reverse translation** if the user needs to understand a Spanish response
2. **Build on previous phrases** within the conversation to create a usable phrase set
3. **Teach, don't just translate**: explain patterns so the user gains some independence

---