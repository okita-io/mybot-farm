---
name: language-expertise
description: "Use when the task matches this agent's language expertise work."
version: 1.0.0
---

# Language Expertise

Spanish Dialects & Regional Variants

- **Mexican Spanish**: most common variant for US-based English speakers; uses "ustedes" for formal plural; rich in indigenous vocabulary (Nahuatl) for food, places, culture
- **Castilian Spanish (Spain)**: uses "vosotros" for informal plural; "th" pronunciation of c/z; "coger" is a common neutral verb (means something very different in Latin America — always flag this)
- **Rioplatense Spanish (Argentina/Uruguay)**: uses "vos" instead of "tú" with different conjugations; distinctive intonation; Italian-influenced vocabulary
- **Colombian Spanish (Bogotá)**: considered one of the clearest accents; formal "usted" used even between close friends in some regions
- **Caribbean Spanish (Cuba, Puerto Rico, Dominican Republic)**: rapid speech, dropped consonants (especially final s), distinct vocabulary

### Grammar Landmines to Watch

- **Ser vs. Estar**: both mean "to be" but are not interchangeable — "Estoy aburrido" (I'm bored right now) vs. "Soy aburrido" (I'm a boring person)
- **Subjunctive mood**: used constantly in Spanish for wishes, doubts, emotions, and hypotheticals — "Quiero que vengas" (I want you to come), not "Quiero que vienes"
- **Preterite vs. Imperfect**: "Fui" (I went, completed action) vs. "Iba" (I was going, ongoing/habitual)
- **False cognates**: "embarazada" = pregnant (not embarrassed); "sensible" = sensitive (not sensible); "éxito" = success (not exit)
- **Diminutives**: "-ito/-ita" adds warmth and smallness — "un momentito" is softer than "un momento"; critical for Mexican Spanish where diminutives are used constantly

### High-Value Travel Vocabulary

- Directions, transport, accommodation, food & dining, shopping, medical, emergency, legal/police interactions, currency and numbers

### Business Spanish

- Formal correspondence openings and closings, meeting vocabulary, negotiation phrases, contract terminology, professional titles and forms of address

---