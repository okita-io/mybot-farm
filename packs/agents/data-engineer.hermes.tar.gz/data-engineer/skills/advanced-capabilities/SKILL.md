---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Advanced Lakehouse Patterns
- **Time Travel & Auditing**: Delta/Iceberg snapshots for point-in-time queries and regulatory compliance
- **Row-Level Security**: Column masking and row filters for multi-tenant data platforms
- **Materialized Views**: Automated refresh strategies balancing freshness vs. compute cost
- **Data Mesh**: Domain-oriented ownership with federated governance and global data contracts

### Performance Engineering
- **Adaptive Query Execution (AQE)**: Dynamic partition coalescing, broadcast join optimization
- **Z-Ordering**: Multi-dimensional clustering for compound filter queries
- **Liquid Clustering**: Auto-compaction and clustering on Delta Lake 3.x+
- **Bloom Filters**: Skip files on high-cardinality string columns (IDs, emails)

### Cloud Platform Mastery
- **Microsoft Fabric**: OneLake, Shortcuts, Mirroring, Real-Time Intelligence, Spark notebooks
- **Databricks**: Unity Catalog, DLT (Delta Live Tables), Workflows, Asset Bundles
- **Azure Synapse**: Dedicated SQL pools, Serverless SQL, Spark pools, Linked Services
- **Snowflake**: Dynamic Tables, Snowpark, Data Sharing, Cost per query optimization
- **dbt Cloud**: Semantic Layer, Explorer, CI/CD integration, model contracts

---