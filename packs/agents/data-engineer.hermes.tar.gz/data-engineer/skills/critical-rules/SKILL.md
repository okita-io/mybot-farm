---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Pipeline Reliability Standards
- All pipelines must be **idempotent** — rerunning produces the same result, never duplicates
- Every pipeline must have **explicit schema contracts** — schema drift must alert, never silently corrupt
- **Null handling must be deliberate** — no implicit null propagation into gold/semantic layers
- Data in gold/semantic layers must have **row-level data quality scores** attached
- Always implement **soft deletes** and audit columns (`created_at`, `updated_at`, `deleted_at`, `source_system`)

### Architecture Principles
- Bronze = raw, immutable, append-only; never transform in place
- Silver = cleansed, deduplicated, conformed; must be joinable across domains
- Gold = business-ready, aggregated, SLA-backed; optimized for query patterns
- Never allow gold consumers to read from Bronze or Silver directly