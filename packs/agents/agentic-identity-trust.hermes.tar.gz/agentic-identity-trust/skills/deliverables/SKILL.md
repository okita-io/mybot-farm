---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Agent Identity Schema

```json
{
  "agent_id": "trading-agent-prod-7a3f",
  "identity": {
    "public_key_algorithm": "Ed25519",
    "public_key": "MCowBQYDK2VwAyEA...",
    "issued_at": "2026-03-01T00:00:00Z",
    "expires_at": "2026-06-01T00:00:00Z",
    "issuer": "identity-service-root",
    "scopes": ["trade.execute", "portfolio.read", "audit.write"]
  },
  "attestation": {
    "identity_verified": true,
    "verification_method": "certificate_chain",
    "last_verified": "2026-03-04T12:00:00Z"
  }
}
```

### Trust Score Model

```python
class AgentTrustScorer:
    """
    Penalty-based trust model.
    Agents start at 1.0. Only verifiable problems reduce the score.
    No self-reported signals. No "trust me" inputs.
    """

    def compute_trust(self, agent_id: str) -> float:
        score = 1.0

        # Evidence chain integrity (heaviest penalty)
        if not self.check_chain_integrity(agent_id):
            score -= 0.5

        # Outcome verification (did agent do what it said?)
        outcomes = self.get_verified_outcomes(agent_id)
        if outcomes.total > 0:
            failure_rate = 1.0 - (outcomes.achieved / outcomes.total)
            score -= failure_rate * 0.4

        # Credential freshness
        if self.credential_age_days(agent_id) > 90:
            score -= 0.1

        return max(round(score, 4), 0.0)

    def trust_level(self, score: float) -> str:
        if score >= 0.9:
            return "HIGH"
        if score >= 0.5:
            return "MODERATE"
        if score > 0.0:
            return "LOW"
        return "NONE"
```

### Delegation Chain Verification

```python
class DelegationVerifier:
    """
    Verify a multi-hop delegation chain.
    Each link must be signed by the delegator and scoped to specific actions.
    """

    def verify_chain(self, chain: list[DelegationLink]) -> VerificationResult:
        for i, link in enumerate(chain):
            # Verify signature on this link
            if not self.verify_signature(link.delegator_pub_key, link.signature, link.payload):
                return VerificationResult(
                    valid=False,
                    failure_point=i,
                    reason="invalid_signature"
                )

            # Verify scope is equal or narrower than parent
            if i > 0 and not self.is_subscope(chain[i-1].scopes, link.scopes):
                return VerificationResult(
                    valid=False,
                    failure_point=i,
                    reason="scope_escalation"
                )

            # Verify temporal validity
            if link.expires_at < datetime.utcnow():
                return VerificationResult(
                    valid=False,
                    failure_point=i,
                    reason="expired_delegation"
                )

        return VerificationResult(valid=True, chain_length=len(chain))
```

### Evidence Record Structure

```python
class EvidenceRecord:
    """
    Append-only, tamper-evident record of an agent action.
    Each record links to the previous for chain integrity.
    """

    def create_record(
        self,
        agent_id: str,
        action_type: str,
        intent: dict,
        decision: str,
        outcome: dict | None = None,
    ) -> dict:
        previous = self.get_latest_record(agent_id)
        prev_hash = previous["record_hash"] if previous else "0" * 64

        record = {
            "agent_id": agent_id,
            "action_type": action_type,
            "intent": intent,
            "decision": decision,
            "outcome": outcome,
            "timestamp_utc": datetime.utcnow().isoformat(),
            "prev_record_hash": prev_hash,
        }

        # Hash the record for chain integrity
        canonical = json.dumps(record, sort_keys=True, separators=(",", ":"))
        record["record_hash"] = hashlib.sha256(canonical.encode()).hexdigest()

        # Sign with agent's key
        record["signature"] = self.sign(canonical.encode())

        self.append(record)
        return record
```

### Peer Verification Protocol

```python
class PeerVerifier:
    """
    Before accepting work from another agent, verify its identity
    and authorization. Trust nothing. Verify everything.
    """

    def verify_peer(self, peer_request: dict) -> PeerVerification:
        checks = {
            "identity_valid": False,
            "credential_current": False,
            "scope_sufficient": False,…