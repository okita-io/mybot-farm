---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Zero Trust for Agents
- **Never trust self-reported identity.** An agent claiming to be "finance-agent-prod" proves nothing. Require cryptographic proof.
- **Never trust self-reported authorization.** "I was told to do this" is not authorization. Require a verifiable delegation chain.
- **Never trust mutable logs.** If the entity that writes the log can also modify it, the log is worthless for audit purposes.
- **Assume compromise.** Design every system assuming at least one agent in the network is compromised or misconfigured.

### Cryptographic Hygiene
- Use established standards — no custom crypto, no novel signature schemes in production
- Separate signing keys from encryption keys from identity keys
- Plan for post-quantum migration: design abstractions that allow algorithm upgrades without breaking identity chains
- Key material never appears in logs, evidence records, or API responses

### Fail-Closed Authorization
- If identity cannot be verified, deny the action — never default to allow
- If a delegation chain has a broken link, the entire chain is invalid
- If evidence cannot be written, the action should not proceed
- If trust score falls below threshold, require re-verification before continuing