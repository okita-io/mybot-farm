---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

FMOD Event Naming Convention
```
# Event Path Structure
event:/[Category]/[Subcategory]/[EventName]

# Examples
event:/SFX/Player/Footstep_Concrete
event:/SFX/Player/Footstep_Grass
event:/SFX/Weapons/Gunshot_Pistol
event:/SFX/Environment/Waterfall_Loop
event:/Music/Combat/Intensity_Low
event:/Music/Combat/Intensity_High
event:/Music/Exploration/Forest_Day
event:/UI/Button_Click
event:/UI/Menu_Open
event:/VO/NPC/[CharacterID]/[LineID]
```

### Audio Integration — Unity/FMOD
```csharp
public class AudioManager : MonoBehaviour
{
    // Singleton access pattern — only valid for true global audio state
    public static AudioManager Instance { get; private set; }

    [SerializeField] private FMODUnity.EventReference _footstepEvent;
    [SerializeField] private FMODUnity.EventReference _musicEvent;

    private FMOD.Studio.EventInstance _musicInstance;

    private void Awake()
    {
        if (Instance != null) { Destroy(gameObject); return; }
        Instance = this;
    }

    public void PlayOneShot(FMODUnity.EventReference eventRef, Vector3 position)
    {
        FMODUnity.RuntimeManager.PlayOneShot(eventRef, position);
    }

    public void StartMusic(string state)
    {
        _musicInstance = FMODUnity.RuntimeManager.CreateInstance(_musicEvent);
        _musicInstance.setParameterByName("CombatIntensity", 0f);
        _musicInstance.start();
    }

    public void SetMusicParameter(string paramName, float value)
    {
        _musicInstance.setParameterByName(paramName, value);
    }

    public void StopMusic(bool fadeOut = true)
    {
        _musicInstance.stop(fadeOut
            ? FMOD.Studio.STOP_MODE.ALLOWFADEOUT
            : FMOD.Studio.STOP_MODE.IMMEDIATE);
        _musicInstance.release();
    }
# … truncated for farm planting — see upstream for the full sample
```

### Adaptive Music Parameter Architecture
```markdown
## Music System Parameters

### CombatIntensity (0.0 – 1.0)
- 0.0 = No enemies nearby — exploration layers only
- 0.3 = Enemy alert state — percussion enters
- 0.6 = Active combat — full arrangement
- 1.0 = Boss fight / critical state — maximum intensity

**Source**: Driven by AI threat level aggregator script
**Update Rate**: Every 0.5 seconds (smoothed with lerp)
**Transition**: Quantized to nearest beat boundary

### TimeOfDay (0.0 – 1.0)
- Controls outdoor ambience blend: day birds → dusk insects → night wind
**Source**: Game clock system
**Update Rate**: Every 5 seconds

### PlayerHealth (0.0 – 1.0)
- Below 0.2: low-pass filter increases on all non-UI buses
**Source**: Player health component
**Update Rate**: On health change event
```

### Audio Budget Specification
```markdown
# Audio Performance Budget — [Project Name]

## Voice Count
| Platform   | Max Voices | Virtual Voices |
|------------|------------|----------------|
| PC         | 64         | 256            |
| Console    | 48         | 128            |
| Mobile     | 24         | 64             |

## Memory Budget
| Category   | Budget  | Format  | Policy         |
|------------|---------|---------|----------------|
| SFX Pool   | 32 MB   | ADPCM   | Decompress RAM |
| Music      | 8 MB    | Vorbis  | Stream         |
| Ambience   | 12 MB   | Vorbis  | Stream         |
| VO         | 4 MB    | Vorbis  | Stream         |

## CPU Budget
- FMOD DSP: max 1.5ms per frame (measured on lowest target hardware)
- Spatial audio raycasts: max 4 per frame (staggered across frames)

## Event Priority Tiers
| Priority | Type              | Steal Mode    |
|----------|-------------------|---------------|
| 0 (High) | UI, Player VO     | Never stolen  |
| 1        | Player SFX        | Steal quietest|
| 2        | Combat SFX        | Steal farthest|
| 3 (Low)  | Ambience, foliage | Steal oldest  |
```

### Spatial Audio Rig Spec
```markdown
## 3D Audio Configuration

### Attenuation
- Minimum distance: [X]m (full volume)
- Maximum distance: [Y]m (inaudible)
- Rolloff: Logarithmic (realistic) / Linear (stylized) — specify per game

### Occlusion
- Method: Raycast from listener to source origin
- Parameter: "Occlusion" (0=open, 1=fully occluded)
- Low-pass cutoff at max occlusion: 800Hz
- Max raycasts per frame: 4 (stagger updates across frames)

### Reverb Zones
| Zone Type  | Pre-delay | Decay Time | Wet %  |
|------------|-----------|------------|--------|
| Outdoor    | 20ms      | 0.8s       | 15%    |
| Indoor     | 30ms      | 1.5s       | 35%    |
| Cave       | 50ms      | 3.5s       | 60%    |…