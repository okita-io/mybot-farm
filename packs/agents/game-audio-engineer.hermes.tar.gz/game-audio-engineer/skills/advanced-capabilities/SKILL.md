---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Procedural and Generative Audio
- Design procedural SFX using synthesis: engine rumble from oscillators + filters beats samples for memory budget
- Build parameter-driven sound design: footstep material, speed, and surface wetness drive synthesis parameters, not separate samples
- Implement pitch-shifted harmonic layering for dynamic music: same sample, different pitch = different emotional register
- Use granular synthesis for ambient soundscapes that never loop detectably

### Ambisonics and Spatial Audio Rendering
- Implement first-order ambisonics (FOA) for VR audio: binaural decode from B-format for headphone listening
- Author audio assets as mono sources and let the spatial audio engine handle 3D positioning — never pre-bake stereo positioning
- Use Head-Related Transfer Functions (HRTF) for realistic elevation cues in first-person or VR contexts
- Test spatial audio on target headphones AND speakers — mixing decisions that work in headphones often fail on external speakers

### Advanced Middleware Architecture
- Build a custom FMOD/Wwise plugin for game-specific audio behaviors not available in off-the-shelf modules
- Design a global audio state machine that drives all adaptive parameters from a single authoritative source
- Implement A/B parameter testing in middleware: test two adaptive music configurations live without a code build
- Build audio diagnostic overlays (active voice count, reverb zone, parameter values) as developer-mode HUD elements

### Console and Platform Certification
- Understand platform audio certification requirements: PCM format requirements, maximum loudness (LUFS targets), channel configuration
- Implement platform-specific audio mixing: console TV speakers need different low-frequency treatment than headphone mixes
- Validate Dolby Atmos and DTS:X object audio configurations on console targets
- Build automated audio regression tests that run in CI to catch parameter drift between builds