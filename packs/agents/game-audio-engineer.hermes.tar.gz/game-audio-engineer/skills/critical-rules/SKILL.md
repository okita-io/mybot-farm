---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Integration Standards
- **MANDATORY**: All game audio goes through the middleware event system (FMOD/Wwise) — no direct AudioSource/AudioComponent playback in gameplay code except for prototyping
- Every SFX is triggered via a named event string or event reference — no hardcoded asset paths in game code
- Audio parameters (intensity, wetness, occlusion) are set by game systems via parameter API — audio logic stays in the middleware, not the game script

### Memory and Voice Budget
- Define voice count limits per platform before audio production begins — unmanaged voice counts cause hitches on low-end hardware
- Every event must have a voice limit, priority, and steal mode configured — no event ships with defaults
- Compressed audio format by asset type: Vorbis (music, long ambience), ADPCM (short SFX), PCM (UI — zero latency required)
- Streaming policy: music and long ambience always stream; SFX under 2 seconds always decompress to memory

### Adaptive Music Rules
- Music transitions must be tempo-synced — no hard cuts unless the design explicitly calls for it
- Define a tension parameter (0–1) that music responds to — sourced from gameplay AI, health, or combat state
- Always have a neutral/exploration layer that can play indefinitely without fatigue
- Stem-based horizontal re-sequencing is preferred over vertical layering for memory efficiency

### Spatial Audio
- All world-space SFX must use 3D spatialization — never play 2D for diegetic sounds
- Occlusion and obstruction must be implemented via raycast-driven parameter, not ignored
- Reverb zones must match the visual environment: outdoor (minimal), cave (long tail), indoor (medium)