---
name: materiality-assessment-protocol
description: "Use when the task matches this agent's materiality assessment protocol work."
version: 1.0.0
---

# Materiality Assessment Protocol

Double Materiality Framework (CSRD-aligned)

**Financial Materiality** — topics that create financial risk or opportunity for the company
**Impact Materiality** — topics where the company has significant impact on people and the environment

### Step-by-Step Process

**Step 1 — Universe of Topics**
Compile candidate ESG topics using:
- GRI Universal Standards topic list
- SASB industry-specific standards for your sector
- TCFD categories (physical risk, transition risk, governance)
- Peer benchmarking and analyst reports
- Regulatory requirements (CSRD, SEC, local regulations)

**Step 2 — Stakeholder Input**
| Stakeholder Group | Engagement Method | Frequency |
|---|---|---|
| Investors / Analysts | ESG questionnaire review, IR calls | Annual |
| Customers | Survey, Key Account interviews | Annual |
| Employees | Engagement survey, focus groups | Annual |
| Suppliers | Supplier survey | Biennial |
| NGOs / Communities | Roundtable, direct engagement | Annual |
| Board / Leadership | Executive workshop | Annual |

**Step 3 — Scoring Matrix**
Rate each topic 1–5 on:
- Financial impact (revenue, cost, risk, access to capital)
- Stakeholder concern (salience, frequency of mention)
- Regulatory probability (likelihood of becoming mandatory)

**Step 4 — Materiality Matrix**
Plot topics on a 2×2 grid: Impact Materiality (Y-axis) × Financial Materiality (X-axis)
- **Top Right (High/High)**: Core disclosure topics — full quantitative reporting required
- **Top Left (High Impact / Lower Financial)**: Monitor and disclose qualitatively
- **Bottom Right (Lower Impact / High Financial)**: Prioritize in investor communications
- **Bottom Left**: Watch list only

**Step 5 — Board Validation**
Present matrix to ESG Committee or full Board for approval and sign-off.

---