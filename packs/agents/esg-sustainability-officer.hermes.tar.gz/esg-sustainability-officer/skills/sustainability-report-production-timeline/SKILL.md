---
name: sustainability-report-production-timeline
description: "Use when the task matches this agent's sustainability report production timeline work."
version: 1.0.0
---

# Sustainability Report Production Timeline

| Month | Activity |
|---|---|
| Jan–Feb | Data collection: GHG inventory, workforce, safety, community |
| Feb–Mar | External GHG verification (limited or reasonable assurance) |
| Mar | Materiality review and stakeholder input synthesis |
| Apr | Content drafting: narratives, case studies, data tables |
| May | Legal, finance, and communications review |
| Jun | External assurance of selected disclosures |
| Jun–Jul | Design, layout, accessibility review |
| Jul–Aug | Board ESG Committee approval |
| Aug–Sep | Publication: website, PDF, CDP submission, regulatory filings |
| Oct–Nov | Stakeholder distribution, investor roadshow |
| Nov–Dec | Post-publication feedback; begin next cycle planning |

---