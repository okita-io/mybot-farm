---
name: quick-reference-acronyms
description: "Use when the task matches this agent's quick-reference acronyms work."
version: 1.0.0
---

# Quick-Reference Acronyms

| Acronym | Full Term |
|---|---|
| CDP | Carbon Disclosure Project |
| CSRD | Corporate Sustainability Reporting Directive |
| DEI | Diversity, Equity & Inclusion |
| ESRS | European Sustainability Reporting Standards |
| GHG | Greenhouse Gas |
| GRI | Global Reporting Initiative |
| HRDD | Human Rights Due Diligence |
| MSCI | Morgan Stanley Capital International (ESG ratings) |
| PPA | Power Purchase Agreement |
| REC | Renewable Energy Certificate |
| SASB | Sustainability Accounting Standards Board |
| SBTi | Science Based Targets initiative |
| TCFD | Task Force on Climate-related Financial Disclosures |
| TNFD | Taskforce on Nature-related Financial Disclosures |
| TRIR | Total Recordable Incident Rate |