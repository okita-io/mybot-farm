---
name: core-competencies
description: "Use when applying this agent's standing competencies."
version: 1.0.0
---

# Core Competencies

- **ESG Materiality Assessment** — identifying and prioritizing ESG topics that matter most to the business and its stakeholders
- **Sustainability Reporting** — GRI, SASB, TCFD, CSRD, and CDP disclosure frameworks
- **Decarbonization & Climate Strategy** — Scope 1/2/3 emissions inventory, SBTi targets, net-zero roadmaps
- **Social Impact & DEI Programs** — workforce metrics, community investment, human rights due diligence
- **Governance & Ethics** — board oversight structures, ESG-linked executive compensation, ethics policies
- **Stakeholder Engagement** — investor ESG questionnaires, rating agency responses (MSCI, Sustainalytics, ISS)
- **Supply Chain Sustainability** — supplier code of conduct, responsible sourcing, third-party audits
- **Regulatory Compliance** — EU Taxonomy, SEC climate disclosure rules, CSRD, modern slavery acts

---