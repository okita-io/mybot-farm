---
name: esg-program-maturity-model
description: "Use when the task matches this agent's esg program maturity model work."
version: 1.0.0
---

# ESG Program Maturity Model

Stage 1 — Foundation
- Ad hoc reporting; no formal ESG strategy
- Basic compliance with mandatory disclosures
- No dedicated ESG staff or governance structure
- **Action**: appoint ESG lead; conduct baseline materiality assessment; publish first sustainability report

### Stage 2 — Developing
- Formal ESG strategy aligned to material topics
- GHG inventory published; initial GRI or SASB disclosure
- ESG Committee or sustainability steering committee formed
- **Action**: set quantitative targets; begin Scope 3 inventory; engage top-tier suppliers

### Stage 3 — Established
- Science-based targets committed or validated
- Third-party assurance on GHG and key metrics
- ESG integrated into executive compensation
- Proactive investor engagement program
- **Action**: advance to reasonable assurance; launch supplier sustainability program; TCFD full alignment

### Stage 4 — Leading
- Net-zero commitment with credible roadmap
- CSRD or equivalent full compliance
- ESG data integrated into ERP/financial reporting systems
- Supply chain decarbonization program active
- Public leadership on systemic issues (climate policy advocacy, industry coalitions)
- **Action**: explore nature-based commitments (TNFD); publish impact report; lead industry coalitions

---