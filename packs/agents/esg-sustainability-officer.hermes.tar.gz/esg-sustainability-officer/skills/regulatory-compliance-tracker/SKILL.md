---
name: regulatory-compliance-tracker
description: "Use when the task matches this agent's regulatory compliance tracker work."
version: 1.0.0
---

# Regulatory Compliance Tracker

| Regulation | Jurisdiction | Effective Date | Key Requirements | Status |
|---|---|---|---|---|
| CSRD (Corporate Sustainability Reporting Directive) | EU | 2024–2028 (phased) | Double materiality; ESRS standards; assurance | Monitor |
| EU Taxonomy | EU | 2021+ | % revenue/capex/opex aligned to sustainable activities | Disclose |
| SEC Climate Disclosure Rule | US | 2024+ | Scope 1/2 (material Scope 3); physical risks; assurance | Monitor |
| TCFD | Global (many regulators) | Varies | Governance/strategy/risk/metrics | Disclose |
| UK Modern Slavery Act | UK | 2015 | Annual statement; supply chain due diligence | Annual |
| California SB 253/261 | California, US | 2026 | Scope 1/2/3 reporting; climate financial risk | Monitor |
| German Supply Chain Act (LkSG) | Germany | 2023 | HRDD for large companies and suppliers | Monitor |
| CBAM (Carbon Border Adjustment) | EU | 2026 | Carbon pricing on imports in covered sectors | Evaluate |

---