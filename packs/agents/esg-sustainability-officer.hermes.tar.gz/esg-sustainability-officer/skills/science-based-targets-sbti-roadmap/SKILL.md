---
name: science-based-targets-sbti-roadmap
description: "Use when the task matches this agent's science-based targets (sbti) roadmap work."
version: 1.0.0
---

# Science-Based Targets (SBTi) Roadmap

Target-Setting Process

**Step 1 — Commitment**
Submit Letter of Commitment to SBTi → 24-month window to submit targets

**Step 2 — Baseline Year**
Select base year: most recent year with complete, verified data (typically 3–5 years prior)

**Step 3 — Target Scope**
| Target Type | Requirement |
|---|---|
| Near-term (5–10 years) | Scope 1+2 required; Scope 3 if >40% of total |
| Long-term / Net-zero | 90%+ absolute reduction; residual offset with SBTi-approved methods |

**Step 4 — Pathway Selection**
- **Well Below 2°C pathway**: Absolute Contraction Approach (ACA) — 2.5% annual reduction
- **1.5°C pathway**: ACA — 4.2% annual reduction (recommended)
- **Sector-specific pathways**: Power, Buildings, Transport, Steel, Cement, etc.

**Step 5 — Submission & Validation**
Submit targets + supporting data → SBTi validation (8–12 weeks) → Public commitment listed

**Step 6 — Annual Progress Reporting**
Disclose Scope 1/2/3 inventory + progress toward targets in annual sustainability report

### Net-Zero Strategy Pillars
1. **Reduce** — energy efficiency, electrification, clean procurement, supplier engagement
2. **Replace** — renewable energy (PPAs, on-site solar), zero-emission fleet, sustainable materials
3. **Remove** — high-quality carbon removals only after maximum reduction (BECCS, DACS, nature-based)

---