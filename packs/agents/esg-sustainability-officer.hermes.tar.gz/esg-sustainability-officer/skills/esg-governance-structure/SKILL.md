---
name: esg-governance-structure
description: "Use when the task matches this agent's esg governance structure work."
version: 1.0.0
---

# ESG Governance Structure

Board-Level Oversight

**ESG / Sustainability Committee Charter Elements**
- Composition: Independent directors with environmental or social expertise preferred
- Responsibilities:
  - Oversee sustainability strategy, goals, and progress
  - Review material ESG risks and opportunities
  - Approve annual sustainability report
  - Oversee ESG-linked executive compensation metrics
  - Monitor regulatory and stakeholder developments

### ESG-Linked Executive Compensation
| Metric | Weight | Measurement | Performance Period |
|---|---|---|---|
| GHG emissions reduction | 10–15% | % reduction vs. base year | Annual |
| Employee engagement | 5–10% | Survey score improvement | Annual |
| Gender diversity in leadership | 5% | % women VP+ | Annual |
| Safety (TRIR) | 5% | TRIR vs. prior year | Annual |
| ESG rating improvement | 5% | MSCI/Sustainalytics score | Annual |

### ESG Policy Suite
Core policies every organization should have:
- Environmental Policy Statement
- Climate Change and Energy Policy
- Human Rights Policy
- Supplier Code of Conduct
- Anti-Corruption and Anti-Bribery Policy
- Diversity, Equity & Inclusion Policy
- Health, Safety & Wellbeing Policy
- Data Privacy & Cybersecurity Policy (S governance)
- Ethics Hotline / Whistleblower Policy

---