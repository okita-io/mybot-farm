---
name: ghg-emissions-inventory-framework
description: "Use when the task matches this agent's ghg emissions inventory framework work."
version: 1.0.0
---

# GHG Emissions Inventory Framework

Scope Definitions (GHG Protocol)

| Scope | Definition | Examples |
|---|---|---|
| Scope 1 | Direct emissions owned/controlled | Boilers, fleet vehicles, refrigerants |
| Scope 2 (Market-based) | Purchased electricity/heat/steam | Electricity with RECs or PPAs |
| Scope 2 (Location-based) | Grid average for purchased energy | National/regional grid factors |
| Scope 3 | Value chain indirect emissions | Business travel, supply chain, product use, end-of-life |

### Scope 3 Category Inventory Checklist

| Category | Relevant? | Data Source | Calculation Method |
|---|---|---|---|
| 1. Purchased goods & services | | Spend data + EIO-LCA | Spend-based |
| 2. Capital goods | | Asset registry | Spend-based |
| 3. Fuel & energy upstream | | Energy invoices | Supplier-specific |
| 4. Upstream transportation | | Freight invoices | Distance-based |
| 5. Waste generated in operations | | Waste manifests | Waste-type specific |
| 6. Business travel | | Expense system / travel agency | Distance-based |
| 7. Employee commuting | | Employee survey | Average-data |
| 8. Upstream leased assets | | Lease agreements | Asset-specific |
| 9. Downstream transportation | | Customer delivery data | Distance-based |
| 10. Processing of sold products | | Not applicable for most | — |
| 11. Use of sold products | | Product energy/fuel data | Lifetime use |
| 12. End-of-life treatment | | Product lifecycle data | Waste-type |
| 13. Downstream leased assets | | Lease agreements | Asset-specific |
| 14. Franchises | | Franchisee data | Scope 1+2 of franchisees |
| 15. Investments | | Portfolio data | Investment-specific |

### Emissions Factor Sources
- **Scope 1**: IPCC AR5/AR6 GWP factors; EPA emission factors
- **Scope 2 Market-based**: Supplier-specific factors, AIB for Europe
- **Scope 2 Location-based**: IEA grid factors; EPA eGRID (US)
- **Scope 3**: EPA Supply Chain Greenhouse Gas Emission Factors; Ecoinvent; DEFRA

---