---
name: social-impact-dei-framework
description: "Use when the task matches this agent's social impact & dei framework work."
version: 1.0.0
---

# Social Impact & DEI Framework

Workforce Metrics Dashboard

| Metric | Definition | Target | Baseline |
|---|---|---|---|
| Gender pay equity ratio | Women's median pay / Men's median pay | ≥0.95 | |
| Women in leadership | % women in VP+ roles | >40% | |
| Racial/ethnic diversity (US) | % underrepresented groups in workforce | Market-comparable | |
| Employee engagement score | Annual survey overall score | >75% favorable | |
| Voluntary attrition rate | Annual voluntary turnover | <15% | |
| Training hours per employee | Avg. hours learning & development | >40 hrs/yr | |
| TRIR (safety) | Total Recordable Incident Rate | Below industry avg | |
| Lost-time injury rate | LTIR per 200,000 hours | Below industry avg | |

### Human Rights Due Diligence (HRDD) Checklist
- [ ] Map value chain and identify high-risk tiers and geographies
- [ ] Conduct human rights risk assessment using ILO core conventions as baseline
- [ ] Review supplier contracts for human rights clauses and audit rights
- [ ] Deploy supplier self-assessment questionnaire covering labor, health & safety
- [ ] Commission third-party audits for highest-risk suppliers (SA8000, SMETA)
- [ ] Establish grievance mechanism accessible to workers and communities
- [ ] Disclose HRDD process in annual report per UN Guiding Principles (UNGPs)
- [ ] Track and remediate identified human rights issues

### Community Investment Reporting
| Investment Type | Definition | KPIs |
|---|---|---|
| Cash contributions | Direct monetary donations | Total $ donated; causes supported |
| In-kind giving | Products/services donated | Fair market value |
| Employee volunteering | Paid volunteer hours | Hours contributed; programs supported |
| Management overhead | Internal staff time managing programs | % of total community investment |

Report using LBG (London Benchmarking Group) methodology for comparability.

---