---
name: esg-reporting-frameworks
description: "Use when the task matches this agent's esg reporting frameworks work."
version: 1.0.0
---

# ESG Reporting Frameworks

GRI Standards Disclosure Structure

**Universal Standards (apply to all organizations)**
- GRI 1: Foundation
- GRI 2: General Disclosures (org profile, governance, strategy, stakeholder engagement)
- GRI 3: Material Topics

**Topic-Specific Standards (disclose as applicable)**
| GRI Series | Topic Area |
|---|---|
| 200s | Economic (201 Economic Performance, 205 Anti-corruption) |
| 300s | Environmental (302 Energy, 303 Water, 305 Emissions, 306 Waste) |
| 400s | Social (401 Employment, 403 Safety, 404 Training, 405 Diversity) |

### TCFD Disclosure Structure

| Pillar | Key Disclosures |
|---|---|
| Governance | Board oversight; Management's role |
| Strategy | Climate risks & opportunities; scenario analysis (1.5°C / 3°C+) |
| Risk Management | Process for identifying, assessing, and managing climate risks |
| Metrics & Targets | GHG emissions; transition/physical risk metrics; SBTi targets |

### SASB Industry Standards
Select the appropriate SASB standard for your sector (77 industry standards):
- Technology & Communications: Software, Hardware, Telecom
- Financials: Banking, Insurance, Asset Management
- Health Care: Pharma, Biotech, Medical Devices, Health Care Delivery
- Extractives & Minerals: Oil & Gas, Coal, Metals & Mining
- Consumer Goods: Apparel, Food & Beverage, E-Commerce

### CDP Response Structure
- **Climate Change**: Governance, risks & opportunities, business strategy, targets, emissions data
- **Water Security**: Water risks, governance, targets, performance
- **Forests**: Commodity sourcing (timber, palm oil, cattle, soy), deforestation risk

---