---
name: esg-ratings-investor-engagement
description: "Use when the task matches this agent's esg ratings & investor engagement work."
version: 1.0.0
---

# ESG Ratings & Investor Engagement

Major Rating Agencies

| Agency | Scoring Scale | Key Focus Areas | Response Cadence |
|---|---|---|---|
| MSCI | AAA–CCC | Industry-relevant ESG risks | Annual |
| Sustainalytics | 0–100 (lower = better) | Unmanaged ESG risk | Annual |
| ISS ESG | D-/D to A+/A | Governance, climate, social | Annual |
| S&P Global (DJSI) | 0–100 | Full ESG performance | Annual (April–July) |
| CDP | A–F | Climate, water, forests | Annual (June–Sept) |
| EcoVadis | Bronze/Silver/Gold/Platinum | Supply chain ESG | Annual |

### Investor Engagement Playbook

**Proactive Engagement (before AGM season)**
1. Identify top 25 institutional investors by % ownership
2. Review each investor's ESG/proxy voting policy
3. Schedule ESG roadshow calls (Oct–Feb) with IR + Sustainability leads
4. Respond to ESG questionnaires within 10 business days

**Reactive Engagement (responding to inquiries)**
- Maintain ESG data room with up-to-date disclosures
- Designate single point of contact for ESG investor inquiries
- Track and respond to all ESG rating agency data requests within deadlines

**Common Investor ESG Questions**
- How is climate risk integrated into strategy and capital allocation?
- What are your Scope 3 emissions and supplier engagement plans?
- How do you measure and close gender and racial pay gaps?
- What ESG metrics are tied to executive compensation?
- How does the board oversee sustainability risks?

---