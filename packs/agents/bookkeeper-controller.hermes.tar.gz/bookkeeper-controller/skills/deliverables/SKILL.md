---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Day-to-Day Accounting Operations
- **Accounts Payable**: Invoice processing, three-way matching, payment scheduling, vendor management, 1099 preparation
- **Accounts Receivable**: Invoice generation, collections management, cash application, bad debt assessment, aging analysis
- **Payroll Accounting**: Payroll journal entries, benefit accruals, tax withholding reconciliation, PTO liability tracking
- **Cash Management**: Daily cash position tracking, bank reconciliations, cash forecasting, wire/ACH processing
- **Fixed Assets**: Capitalization policy enforcement, depreciation schedule maintenance, impairment testing, disposal tracking
- **Revenue Recognition**: ASC 606 compliance, contract review, performance obligation identification, deferred revenue management

### Month-End Close Process
- **Close Calendar Management**: Task assignment, deadline tracking, sequential dependency mapping
- **Account Reconciliations**: Bank, credit card, intercompany, prepaid, accrual, and balance sheet reconciliations
- **Accrual Management**: Expense accruals, revenue accruals, bonus accruals, lease accounting (ASC 842)
- **Journal Entries**: Standard recurring entries, adjusting entries, reclassification entries, elimination entries
- **Financial Statements**: Income statement, balance sheet, cash flow statement, equity rollforward
- **Flux Analysis**: Month-over-month and budget-vs-actual variance analysis with explanations

### Internal Controls
- **Control Design**: Authorization matrices, approval workflows, system access controls, data validation rules
- **Control Monitoring**: Key control testing, exception tracking, remediation management
- **Policy Maintenance**: Accounting policy documentation, procedure manuals, delegation of authority matrices
- **SOX Compliance**: Control documentation, testing schedules, deficiency tracking, management assertions

### Tools & Technologies
- **ERP/Accounting Software**: QuickBooks, Xero, NetSuite, Sage Intacct, SAP, Oracle Financials
- **Close Management**: FloQast, BlackLine, Trintech, Workiva
- **AP Automation**: Bill.com, Tipalti, AvidXchange, Coupa
- **Expense Management**: Expensify, Concur, Brex, Ramp
- **Spreadsheets**: Advanced Excel — pivot tables, VLOOKUP/INDEX-MATCH, conditional formatting, macro automation

### Templates & Deliverables

### Month-End Close Checklist

```markdown
# Month-End Close — [Month Year]
**Close Deadline**: [Business Day X]  **Controller**: [Name]
**Status**: In Progress / Complete

---

## Pre-Close (Day 1-2)
- [ ] Confirm all bank feeds are synced and current
- [ ] Verify all AP invoices received and entered through cut-off date
- [ ] Confirm payroll journal entries posted for all pay periods in month
- [ ] Review and post employee expense reports
- [ ] Verify AR invoices issued for all delivered goods/services
- [ ] Confirm intercompany transactions reconciled with counterparties

## Core Close (Day 3-5)
- [ ] Post standard recurring journal entries (depreciation, amortization, rent, insurance)
- [ ] Calculate and post expense accruals (utilities, professional services, commissions)
- [ ] Calculate and post revenue accruals / deferred revenue adjustments
- [ ] Post payroll tax and benefit accruals
- [ ] Record credit card transactions and reconcile statements
- [ ] Post foreign currency revaluation entries (if applicable)
- [ ] Post intercompany elimination entries (if consolidated)

## Reconciliations (Day 3-6)
- [ ] Bank account reconciliations (all accounts)
- [ ] Credit card reconciliations (all cards)
- [ ] Accounts receivable aging reconciliation to GL
- [ ] Accounts payable aging reconciliation to GL
- [ ] Prepaids & deposits reconciliation with amortization schedules
- [ ] Fixed assets reconciliation — additions, disposals, depreciation
- [ ] Accrued liabilities reconciliation — detail support for all balances
- [ ] Deferred revenue reconciliation — roll-forward schedule
- [ ] Intercompany reconciliation — zero net balance confirmation
- [ ] Equity reconciliation — stock compensation, dividends, treasury stock
- [ ] Payroll tax liability reconciliation to returns

## Financial Statements (Day 6-7)
- [ ] Generate trial balance and review for unusual balances
- [ ] Prepare income statement with variance analysis (MoM and BvA)
- [ ] Prepare balance sheet with reconciliation tie-out
# … truncated for farm planting — see upstream for the full sample
```

### Account Reconciliation Template

```markdown…