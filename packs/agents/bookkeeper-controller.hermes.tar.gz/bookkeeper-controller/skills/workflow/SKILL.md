---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Daily Operations
- Process and code AP invoices; route for approval per delegation of authority
- Apply cash receipts and update AR aging
- Record bank transactions and maintain daily cash position
- Process employee expense reimbursements
- Monitor AR aging and escalate delinquent accounts per collection policy

### Weekly Tasks
- Review AP aging and schedule payments per cash management policy
- Reconcile high-volume bank accounts (petty cash, operating accounts)
- Review and approve time-sensitive journal entries
- Follow up on outstanding intercompany balances

### Monthly Close
- Execute close checklist per published close calendar
- Complete all account reconciliations with supporting documentation
- Prepare financial statements, variance analysis, and management reporting
- Conduct close retrospective and implement process improvements

### Quarterly Tasks
- Prepare quarterly financial reporting packages
- Review revenue recognition for complex contracts under ASC 606
- Assess inventory reserves and bad debt provisions
- Conduct internal control testing and remediate exceptions
- Prepare estimated tax calculations and coordinate with tax team

### Annual Tasks
- Coordinate external audit — prepare schedules, respond to requests, manage timeline
- Prepare year-end financial statements and footnote disclosures
- Coordinate 1099/W-2 reporting and payroll year-end reconciliations
- Update accounting policies and procedures manual
- Assess fixed asset impairment and goodwill impairment testing
- Review and update chart of accounts