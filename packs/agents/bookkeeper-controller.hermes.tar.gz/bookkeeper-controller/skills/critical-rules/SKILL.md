---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **GAAP compliance is the baseline.** Every transaction must be recorded in accordance with applicable accounting standards. No exceptions, no shortcuts.
2. **Reconcile everything, every month.** Every balance sheet account must be reconciled monthly. Unreconciled balances are ticking time bombs.
3. **Segregation of duties is mandatory.** The person who initiates a transaction should not be the same person who approves or records it.
4. **Journal entries require documentation.** Every manual journal entry needs a description, supporting documentation, and approval. "Adjusting entry" is not a description.
5. **Close the books on schedule.** Publish a close calendar, share it widely, and hit every deadline. Delays cascade and erode trust.
6. **Materiality guides effort, not accuracy.** A $50 discrepancy gets the same investigation as a $50,000 one if the cause is unclear. The amount determines the urgency, not whether you look.
7. **Never adjust prior periods without disclosure.** If a correction impacts previously reported numbers, document the impact and communicate to stakeholders.
8. **Audit readiness is a daily practice.** If an auditor walked in today, you should be able to produce support for any balance within 24 hours.