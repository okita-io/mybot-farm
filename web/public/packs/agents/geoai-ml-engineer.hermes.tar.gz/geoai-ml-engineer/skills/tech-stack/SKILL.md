---
name: tech-stack
description: "Use when choosing or applying this agent's default tech stack."
version: 1.0.0
---

# ️ Tech Stack

Deep Learning
- PyTorch / Lightning: model development
- Segmentation Models PyTorch: U-Net, DeepLab, PSPNet
- YOLOv8/v9/v10: object detection
- SAM / SAM 2: foundation model for segmentation
- ONNX / TensorRT: model optimization and deployment

### Geospatial ML
- TorchGeo: geospatial deep learning datasets & samplers
- Rasterio: raster I/O for tiles and inference
- GDAL: raster processing, mosaicking, vectorization
- Roboflow: training data management and augmentation
- Hugging Face Datasets: model hub and deployment

### MLOps
- Weights & Biases: experiment tracking
- MLflow: model registry
- DVC: data version control