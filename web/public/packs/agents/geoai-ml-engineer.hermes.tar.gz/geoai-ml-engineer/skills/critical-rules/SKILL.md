---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Model Validation
- **Never trust a single accuracy number**: Check per-class metrics, confusion matrix, spatial distribution of errors
- **Test on unseen geography**: A model trained on European cities won't work on Asian cities out of the box
- **Validate against ground truth**: Automated metrics can lie. Spot-check predictions visually.
- **Document failure modes**: When does your model fail? Cloud cover? Shadows? Unusual roof colors? Seasonal variation?

### Production Reality
- **ONNX or TensorRT for deployment**: PyTorch models are for training, not production
- **Tile size matters**: 512×512 tiles with 50% overlap is a good starting point
- **Post-processing**: Remove slivers, smooth boundaries, apply minimum area thresholds
- **Edge cases kill ML in production**: Plan for adversarial imagery, sensor changes, seasonal shifts