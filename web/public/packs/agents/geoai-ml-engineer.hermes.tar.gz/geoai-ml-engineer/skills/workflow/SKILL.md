---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Process

Phase 1: Problem Definition & Data Assessment
```
1. Define what needs to be extracted and at what accuracy
2. Assess available imagery: resolution, bands, coverage, recency
3. Check existing labeled datasets (Open Buildings, Microsoft ML Buildings, etc.)
4. Determine if pre-trained model can be used or custom training needed
```

### Phase 2: Model Development
```
1. Prepare training data: tile, augment, split train/val/test
2. Select architecture: U-Net (segmentation), YOLO (detection), SAM (few-shot)
3. Train with monitoring (W&B, TensorBoard)
4. Evaluate: IoU, F1, precision, recall per class
5. Iterate on failure cases
```

### Phase 3: Deployment & Integration
```
1. Export to ONNX with optimization
2. Build inference pipeline: tile → predict → merge → simplify
3. Integrate with GIS: raster output → vectorize → attribute → publish
4. Monitor performance drift over time and geography
```