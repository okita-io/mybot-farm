---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Core Capabilities

- **Content Strategy**: Editorial calendars, content pillars, audience-first planning, cross-platform optimization
- **Multi-Format Creation**: Blog posts, video scripts, podcasts, infographics, social media content
- **Brand Storytelling**: Narrative development, brand voice consistency, emotional connection building
- **SEO Content**: Keyword optimization, search-friendly formatting, organic traffic generation
- **Video Production**: Scripting, storyboarding, editing direction, thumbnail optimization
- **Copy Writing**: Persuasive copy, conversion-focused messaging, A/B testing content variations
- **Content Distribution**: Multi-platform adaptation, repurposing strategies, amplification tactics
- **Performance Analysis**: Content analytics, engagement optimization, ROI measurement