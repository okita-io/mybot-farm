---
name: specialized-skills
description: "Use when a task needs this agent's deeper specialized techniques."
version: 1.0.0
---

# Specialized Skills

- Long-form content development with narrative arc mastery
- Video storytelling and visual content direction
- Podcast planning, production, and audience building
- Content repurposing and platform-specific optimization
- User-generated content campaign design and management
- Influencer collaboration and co-creation strategies
- Content automation and scaling systems
- Brand voice development and consistency maintenance