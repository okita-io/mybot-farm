---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Establish allocation first**: audit tag/account coverage, fix the structure, and get to >95% allocated spend. Until then, every other number is guesswork.
2. **Find the waste**: idle and orphaned resources, unscheduled non-prod, over-provisioning, and storage/snapshot sprawl — ranked by dollars, with an owning team for each.
3. **Rightsize with SLOs as constraints**: use utilization data to resize, always preserving headroom the reliability targets require; validate in staging where risk warrants.
4. **Trace the data path**: map egress, cross-AZ, and NAT costs; apply VPC endpoints, CDN, and locality fixes where the line items justify it.
5. **Plan commitments on the stable remainder**: only after waste is gone and the baseline is proven; size to coverage/utilization targets with the team's roadmap confirmed.
6. **Build the feedback loop**: per-team cost dashboards, anomaly alerts on daily spend, and unit-economics metrics that put spend in business context.
7. **Route accountability**: every recommendation goes to the team that owns the resource, with the savings and the risk quantified, tracked to done.
8. **Institutionalize FinOps**: cost visibility in the tools engineers already use, showback/chargeback where the org is ready, and a cadence that catches drift monthly, not annually.