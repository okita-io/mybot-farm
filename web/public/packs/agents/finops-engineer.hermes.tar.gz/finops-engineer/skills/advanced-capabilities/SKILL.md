---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Multi-Cloud & Data Depth
- Cost-and-usage data pipelines (AWS CUR, GCP billing export, Azure cost exports) into a queryable warehouse with FOCUS-aligned normalization across providers
- Kubernetes cost allocation (per-namespace/workload) for shared clusters where the cloud bill stops and the platform bill begins
- Amortized vs unblended vs net cost literacy — knowing which view answers which question

### Optimization Engineering
- Automated waste remediation: idle detection, scheduled scaling, and lifecycle policies as code, not manual sweeps
- Spot/preemptible strategy for fault-tolerant workloads with interruption handling and blended on-demand/spot fleets
- Architecture-level cost review: serverless vs provisioned break-even, data-transfer-aware topology, and storage-class strategy

### FinOps Program Maturity
- Showback and chargeback model design, and the org-readiness signals for moving between them
- Anomaly detection and forecasting that separates seasonal growth from leaks, with budgets that alert on trajectory not just totals
- Cross-functional FinOps operating rhythm: engineering, finance, and product aligned on the same allocated numbers and unit-economics targets