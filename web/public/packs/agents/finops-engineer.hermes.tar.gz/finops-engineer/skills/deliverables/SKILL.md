---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Tagging & Allocation Strategy (the foundation everything else needs)

```yaml
# Mandatory tag policy — enforced at provisioning, audited continuously.
# Untagged resources are quarantined to an "unallocated" bucket that teams
# are held accountable to drive toward zero.
required_tags:
  team:        # owning team — routes cost + optimization actions to a human
  service:     # logical service/app — the unit product cares about
  environment: # prod | staging | dev — dev/staging are prime shutdown targets
  cost_center: # finance's allocation key — bridges to the P&L
enforcement:
  - deny provisioning without required tags (SCP / Azure Policy / GCP org policy)
  - daily audit: % of spend allocated; target > 95%
  - shared costs (networking, observability, shared clusters) split by a
    documented, agreed key (usage-based where possible, headcount otherwise)
```

### Optimization Lever Priority (do them in this order)

| Priority | Lever | Typical savings | Reliability risk | Rule |
|----------|-------|-----------------|------------------|------|
| 1 | Kill idle/orphaned (unattached disks, idle load balancers, zombie envs) | High | ~None | Free money — automate detection |
| 2 | Schedule non-prod (stop dev/staging nights + weekends) | ~65% of non-prod | None if truly non-prod | Start/stop automation, opt-out not opt-in |
| 3 | Rightsize over-provisioned compute/DB | Medium–High | Medium | Only with headroom preserved to SLO |
| 4 | Storage tiering + snapshot lifecycle | Medium | Low | Lifecycle policies, not manual cleanup |
| 5 | Egress path optimization (VPC endpoints, CDN, region locality) | Situational, sometimes huge | Low–Medium | Trace the data flow first |
| 6 | Commitments (RIs / savings plans / CUDs) on the stable remainder | 20–72% on covered spend | Financial (lock-in) | Last — only after 1–5 stabilize |

### Commitment Planning (quantified, not vibes)

```text
Before buying any reserved instance / savings plan:
  1. Baseline: the always-on floor of usage over the last 30–90 days (not peaks)
  2. Stability check: is this workload staying put for the commitment term?
     (No pending migration, refactor, or deprecation — confirm with the team)
  3. Coverage target: cover ~70–85% of the stable baseline, leave on-demand
     headroom for growth and the ability to change architecture
  4. Term + payment: 1yr vs 3yr and upfront vs no-upfront by cash + confidence
  5. Track after: utilization (are we using what we bought?) AND
     coverage (how much of eligible spend is discounted?) — both, monthly
A commitment you don't fully utilize is a discount you paid for and threw away.
```

### Unit Economics Dashboard (spend judged against value)

```sql
-- Cost per active customer, trended — the number that tells growth from waste.
-- Total cloud cost rising is fine IF cost-per-unit is flat or falling.
SELECT
  date_trunc('month', usage_date)               AS month,
  SUM(unblended_cost)                            AS total_cloud_cost,
  COUNT(DISTINCT customer_id)                    AS active_customers,
  SUM(unblended_cost) / NULLIF(COUNT(DISTINCT customer_id), 0) AS cost_per_customer,
  SUM(unblended_cost) FILTER (WHERE tag_environment = 'prod')  AS prod_cost,
  SUM(unblended_cost) FILTER (WHERE tag_environment != 'prod') AS nonprod_cost
FROM cost_and_usage
JOIN customer_activity USING (usage_date)
GROUP BY 1 ORDER BY 1;
-- Present alongside: allocated %, commitment coverage %, commitment utilization %.
```