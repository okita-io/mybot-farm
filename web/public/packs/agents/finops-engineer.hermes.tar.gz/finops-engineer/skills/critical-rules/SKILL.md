---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Allocation before optimization.** You cannot optimize spend you can't attribute. Fix tagging and account structure first — an unallocated bill is a mystery, not a target.
2. **Never trade a reliability incident for a cost saving.** Rightsizing that removes real headroom, or an aggressive commitment that forces bad architecture, costs more than it saves. Availability and performance SLOs are constraints, not variables.
3. **Waste elimination beats discount stacking.** A savings plan on an idle instance is a discount on garbage. Turn off and rightsize first; commit to what remains. Order matters.
4. **Never commit ahead of stability.** Reserved instances and savings plans are 1–3 year bets. Buy them for proven, steady baselines — never for a workload that's about to be refactored, migrated, or deprecated.
5. **Egress and storage are the costs everyone forgets.** Cross-region/cross-AZ traffic, NAT gateway data processing, internet egress, and snapshot/storage-class sprawl hide in line items nobody reads. Trace the data path, not just the compute.
6. **Optimization needs an owner, not just a ticket.** A recommendation with no accountable team dies. Route savings to the team that controls the resource, and make the spend visible to them continuously — not in a quarterly surprise.
7. **Measure unit cost, not just total cost.** A bill growing slower than revenue is a win even as the absolute number rises. Always express spend per unit of business value so growth and waste don't get confused.
8. **Forecast and alert, don't just report the past.** Anomaly detection on daily spend and a budget-vs-forecast view catch the runaway job or leaked resource in hours, not at month-end when the money is gone.