---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Phase 1: Subscriber & Business Analysis
1. **Current State Assessment**: Existing subscriber demographics, engagement metrics, content performance
2. **Business Objective Definition**: Clear goals (brand awareness, lead generation, sales, retention)
3. **Subscriber Research**: Survey, interviews, or analytics to understand preferences and pain points
4. **Competitive Landscape**: Analyze competitor OAs, identify differentiation opportunities

### Phase 2: Content Strategy & Calendar
1. **Content Pillar Development**: Define 4-5 core themes that align with business goals and subscriber interests
2. **Content Format Optimization**: Mix of articles, polls, video, mini programs, interactive content
3. **Publishing Schedule**: Optimal posting frequency (typically 2-3 per week) and timing
4. **Editorial Calendar**: 3-month rolling calendar with themes, content ideas, seasonal integration
5. **Menu Architecture**: Design custom menus for easy navigation, automation, Mini Program access

### Phase 3: Content Creation & Optimization
1. **Copywriting Excellence**: Compelling headlines, emotional hooks, clear structure, scannable formatting
2. **Visual Design**: Consistent branding, readable typography, attractive cover images
3. **SEO Optimization**: Keyword placement in titles and body for internal search discoverability
4. **Interactive Elements**: Polls, questions, calls-to-action that drive engagement
5. **Mobile Optimization**: Content sized and formatted for mobile reading (primary WeChat consumption method)

### Phase 4: Automation & Engagement Building
1. **Auto-Reply System**: Welcome message, common questions, menu guidance
2. **Keyword Automation**: Automated responses for popular queries or keywords
3. **Segmentation Strategy**: Organize subscribers for targeted, relevant communication
4. **Mini Program Integration**: If applicable, integrate interactive features for enhanced engagement
5. **Community Building**: Encourage feedback, user-generated content, community interaction

### Phase 5: Performance Analysis & Optimization
1. **Weekly Analytics Review**: Open rates, click-through rates, completion rates, subscriber trends
2. **Content Performance Analysis**: Identify top-performing content, themes, and formats
3. **Subscriber Feedback Monitoring**: Monitor messages, comments, and engagement patterns
4. **Optimization Testing**: A/B test headlines, sending times, content formats
5. **Scaling & Evolution**: Identify successful patterns, expand successful content series, evolve with audience