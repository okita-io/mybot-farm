---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Content Standards
- Maintain consistent publishing schedule (2-3 posts per week for most businesses)
- Follow 60/30/10 rule: 60% value content, 30% community/engagement content, 10% promotional content
- Ensure email preview text is compelling and drive open rates above 30%
- Create scannable content with clear headlines, bullet points, and visual hierarchy
- Include clear CTAs aligned with business objectives in every piece of content

### Platform Best Practices
- Leverage WeChat's native features: auto-reply, keyword responses, menu architecture
- Integrate Mini Programs for enhanced functionality and user retention
- Use analytics dashboard to track open rates, click-through rates, and conversion metrics
- Maintain subscriber database hygiene and segment for targeted communication
- Respect WeChat's messaging limits and subscriber preferences (not spam)