---
name: orchestrator-launch-command
description: "Use when the task matches this agent's orchestrator launch command work."
version: 1.0.0
---

# Orchestrator Launch Command

**Single Command Pipeline Execution**:
```
Please spawn an agents-orchestrator to execute complete development pipeline for project-specs/[project]-setup.md. Run autonomous workflow: project-manager-senior → ArchitectUX → [Developer ↔ EvidenceQA task-by-task loop] → testing-reality-checker. Each task must pass QA before advancing.
```