---
name: available-specialist-agents
description: "Use when the task matches this agent's available specialist agents work."
version: 1.0.0
---

# Available Specialist Agents

The following agents are available for orchestration based on task requirements:

### 🎨 Design & UX Agents
- **ArchitectUX**: Technical architecture and UX specialist providing solid foundations
- **UI Designer**: Visual design systems, component libraries, pixel-perfect interfaces
- **UX Researcher**: User behavior analysis, usability testing, data-driven insights
- **Brand Guardian**: Brand identity development, consistency maintenance, strategic positioning
- **design-visual-storyteller**: Visual narratives, multimedia content, brand storytelling
- **Whimsy Injector**: Personality, delight, and playful brand elements
- **XR Interface Architect**: Spatial interaction design for immersive environments

### 💻 Engineering Agents
- **Frontend Developer**: Modern web technologies, React/Vue/Angular, UI implementation
- **Backend Architect**: Scalable system design, database architecture, API development
- **engineering-senior-developer**: Premium implementations with Laravel/Livewire/FluxUI
- **engineering-ai-engineer**: ML model development, AI integration, data pipelines
- **Mobile App Builder**: Native iOS/Android and cross-platform development
- **DevOps Automator**: Infrastructure automation, CI/CD, cloud operations
- **Rapid Prototyper**: Ultra-fast proof-of-concept and MVP creation
- **XR Immersive Developer**: WebXR and immersive technology development
- **LSP/Index Engineer**: Language server protocols and semantic indexing
- **macOS Spatial/Metal Engineer**: Swift and Metal for macOS and Vision Pro

### 📈 Marketing Agents
- **marketing-growth-hacker**: Rapid user acquisition through data-driven experimentation
- **marketing-content-creator**: Multi-platform campaigns, editorial calendars, storytelling
- **marketing-social-media-strategist**: Twitter, LinkedIn, professional platform strategies
- **marketing-twitter-engager**: Real-time engagement, thought leadership, community growth
- **marketing-instagram-curator**: Visual storytelling, aesthetic development, engagement
- **marketing-tiktok-strategist**: Viral content creation, algorithm optimization
- **marketing-reddit-community-builder**: Authentic engagement, value-driven content
- **App Store Optimizer**: ASO, conversion optimization, app discoverability

### 📋 Product & Project Management Agents
- **project-manager-senior**: Spec-to-task conversion, realistic scope, exact requirements
- **Experiment Tracker**: A/B testing, feature experiments, hypothesis validation
- **Project Shepherd**: Cross-functional coordination, timeline management
- **Studio Operations**: Day-to-day efficiency, process optimization, resource coordination
- **Studio Producer**: High-level orchestration, multi-project portfolio management
- **product-sprint-prioritizer**: Agile sprint planning, feature prioritization
- **product-trend-researcher**: Market intelligence, competitive analysis, trend identification
- **product-feedback-synthesizer**: User feedback analysis and strategic recommendations

### 🛠️ Support & Operations Agents
- **Support Responder**: Customer service, issue resolution, user experience optimization
- **Analytics Reporter**: Data analysis, dashboards, KPI tracking, decision support
- **Finance Tracker**: Financial planning, budget management, business performance analysis
- **Infrastructure Maintainer**: System reliability, performance optimization, operations
- **Legal Compliance Checker**: Legal compliance, data handling, regulatory standards
- **Workflow Optimizer**: Process improvement, automation, productivity enhancement

### 🧪 Testing & Quality Agents
- **EvidenceQA**: Screenshot-obsessed QA specialist requiring visual proof
- **testing-reality-checker**: Evidence-based certification, defaults to "NEEDS WORK"
- **API Tester**: Comprehensive API validation, performance testing, quality assurance
- **Performance Benchmarker**: System performance measurement, analysis, optimization
- **Test Results Analyzer**: Test evaluation, quality metrics, actionable insights
- **Tool Evaluator**: Technology assessment, platform recommendations, productivity tools

### 🎯 Specialized Agents
- **XR Cockpit Interaction Specialist**: Immersive cockpit-based control systems
- **data-analytics-reporter**: Raw data transformation into business insights

---