---
name: hermes-multi-agent-teams
description: "Use when building a portable Hermes multi-agent team."
metadata:
  hermes:
    editorial_name: "Multi-Agent Team Builder"
    editorial_description: "Design and build a tight, portable Hermes agent team: shared workspace, role charters, team memory, and a cron heartbeat."
---

# Hermes Multi-Agent Teams

Class: "build me a 3-agent X team / a team that does Y around the clock".
Deliverable: N named profiles + one shared workspace + one portable team
memory file + cron heartbeat jobs + a verified first handoff. The team must
survive moving: fresh profiles + the team directory = a working resume.

## Design rules (decide these before writing files)
- **Non-overlapping ownership + a separated gate.** Each role owns exactly one
  artifact surface; the release/QA gate is owned by a role that never builds
  (builder ≠ shipper). A team where one agent can both build and declare
  done is one agent with extra steps.
- **One board, one state machine.** `WORK.md` (or a Hermes kanban board — see
  **Board substrate** below) is the single source of truth: card states, who may
  move which edge, and an atomic claim (owner + claim timestamp set in the same
  edit; a kanban board gives atomic claims + dependency edges + auto-dispatch
  for free) so two agents cannot race a card. DMs are handoffs/questions, NEVER
  the record of state.
- **Escalation path to the human** baked into the team memory (double-bounce,
stuck >48h, empty backlog) — a team that idles silently on empty work or
  pings endlessly on status both fail.

## Build procedure
1. **Workspace**: `~/.hermes/teams/<team>/{reports,repos,state}` — shared code
   lives in `repos/<project>/`, evidence in `reports/`, machine snapshots in
   `state/`.
2. **TEAM.md (the portable team memory)** — roster table (handle, profile,
   role, one-line contract), workspace map, card format + state transitions +
   who-moves-what, DM handoff protocol (one short message per handoff, with
   example), quality bar, cron table, escalation rules, portability note.
   This file is what a brand-new agent reads to join mid-board.
3. **Board seeded with one day-one card** in `Ready` (observable acceptance
   checks) — an empty team proves nothing; a shippable card makes the first
   standup real.
4. **Profiles**: `hermes profile create <team>-<role> --no-alias` (no wrapper
   alias needed; `--no-skills` if the role needs none). For EACH profile:
   - `SOUL.md` = full role charter: identity line, "read TEAM.md first" order,
     what it owns, what it never does, per-day rhythm, voice. Charter, not
     biography — every line load-bearing.
   - `config.yaml` = fully self-contained model block (profiles do NOT
     inherit the main config: model/providers/fallback blocks copied from a
     known-good profile, e.g. the `spark-4f07` + opencode-free fallback shape).
   - `memories/MEMORY.md` = short team pointer: workspace paths, teammate
     handles, cron table, session-hygiene rule. The deep team knowledge stays
     in TEAM.md (one file to travel), this file points at it.
5. **Verify wiring before scheduling**: fire a one-shot
   `hermes -p <profile> chat -q "<role + protocol question>" -Q` and check the
   answer cites TEAM.md — proves the profile reads the shared memory and its
   charter, on the live model.
6. **Cron heartbeat**: one parameterized runner script
   `~/.hermes/scripts/<team>_cron.sh <job>` PLUS one thin wrapper per job
   (`<team>_cron_<job>.sh` → `exec <team>_cron.sh <job>`), one `cronjob`
   entry per (schedule, owning role, prompt). The cronjob `script=` field is
   a bare path and NEVER passes arguments — `"run.sh standup"` fails with
   "Script not found" (rule lives in `hermes-cron-authoring`); the wrappers
   are the fix. Create via the cronjob tool with `no_agent=true`,
   `script="<team>_cron_<job>.sh"`, `deliver` + `failure_deliver` `local`
   (the team's real communication is its own DMs; the job's stdout stays
   quiet).
7. **Fire one job manually** and verify the artifact on disk (report written,
   board unchanged unless a transition is due, DMs actually landed in the
   partner's Bot Chat) before declaring the team operational.

## Board substrate: flat file vs kanban board
A flat `WORK.md` board is fully portable and fine for small teams, but it has no
atomic claims, no dependency edges, and no auto-dispatch. Upgrade to a Hermes
kanban board when the team runs unattended via the dispatcher or handoffs must
be durable. Verified procedure:
1. `hermes kanban boards create <team> --name "<Team>"` — an isolated board per
team (its own DB, workspaces, dispatcher); check `hermes kanban boards list`
first.
2. **Two task types per card.** A **Build task** (requirements role creates,
builder assigned) and a **QA task** (builder creates, gate role assigned) with
`parents=[<build task id>]`. The parent edge IS the handoff: the QA task
auto-promotes to ready the moment the build completes — a DM can die in transit
and strand nothing, because the board owns the transition.
3. **The QA task records the verdict** — it is not "done = shipped": complete
with metadata `verdict: "PASS"` (shipped) or `verdict: "FAIL"` + repro +
evidence paths. On FAIL the gate role creates a **rework task** for the builder
(`parents=[<QA task>]`, body = repro + expected vs actual + evidence); the
builder completes it and creates a FRESH QA task. Never reuse a completed QA
task.
4. **Orphan rule (end-of-day reconciliation):** a completed build/rework task
with no QA task and no rework task pointing at it = a handoff that died
mid-run. The harvest job detects it and DMs the builder to create the missing
QA task — never ship around the gate.
5. **Migrate history on upgrade:** shipped cards → completed tasks (preserve the
verdict in the summary); backlog cards → unassigned ready tasks (the dispatcher
skips unassigned). The record file is demoted to shipped history + user-seeded
backlog notes that standup promotes to tasks.
- **Cron prompts drive the board**, not the record file: standup lists the
board + promotes backlog notes; the QA sweep's queue is
`kanban_list(assignee=<gate role>, status=ready)`; harvest reconciles orphans
and mirrors shipped cards into the record file.
- **Verify the upgrade with a probe card before declaring it operational:**
author a trivial build task whose body spells out the exact handoff
instructions, let the dispatcher run it unattended through the full loop
(build → complete → QA auto-promote → gate verdict on the real app → shipped),
then inspect the board's event chain. Keep the probe tasks on the board as
evidence; delete only the throwaway repo.
- **A protocol upgrade touches EVERY surface** — team memory, record file,
every profile's SOUL.md + MEMORY.md, every cron job prompt, **and the team's
learned skills.** A skill that codified the old handoff mechanics keeps
re-teaching the old protocol on every dispatch until patched; grep each team
skill for stale board references after any protocol change, then re-export and re-scrub the profiles that carry the updated skill. The **published team-pack (GAF) JSON is a fourth, hand-maintained copy** of the protocol — `shared.gettingStarted`, `skills[]`, and `topology.handoffs` do NOT regenerate from the tarballs or the README, so a version that upgrades the tarballs leaves the GAF still describing the old protocol (stale install steps, a stale skills list). Regenerate all of it and re-verify against the live site.

## Cron script pattern (verified)
```bash
#!/bin/bash
set -euo pipefail
JOB="${1:?}"; WS="$HOME/.hermes/teams/<team>"; DATE="$(date +%F)"
case "$JOB" in
  standup)  PROFILE="<team>-spec";    SESSION="standup-$DATE";  PROMPT="Cron: … one-line job brief…" ;;
  qa-sweep) PROFILE="<team>-smoke";   SESSION="qa-sweep-$DATE"; PROMPT="Cron: …" ;;
esac
cd "$WS"
exec hermes -p "$PROFILE" chat -q "$PROMPT" --continue "$SESSION" --create-if-missing -Q
```
- **Date-stamped session names, one per run** — a persistent shared session
  across ticks pins a stale model and bloats to context-overflow (the
  multi-day "Bot Chat" failure). Each day's named session is fresh; history
  lives in reports/, not in session context.
- `hermes chat` has NO `-c` flag: named/resumable sessions are
  `--continue <name>` (+ `--create-if-missing` for first run).
- Prompts are self-contained job briefs (a cron run has no chat context) and
  carry the quiet-when-idle rule: nothing actionable → one report line, no DMs.
- macOS has no `timeout` binary — one-shot `-Q` invocations exit on their own;
  don't wrap them.

## Pitfalls
- **Profiles are self-contained** — a profile with no `providers:` block in
  its own config.yaml silently has no model. Copy a known-good block per
  profile; config changes need that profile's gateway restart (TERM; desktop
  respawns it).
- **The team memory must be load-bearing, not decorative** — verify with the
  step-5 one-shot before wiring crons; an agent that answers the role
  question from its SOUL.md alone but can't recite the handoff protocol has a
  pointer that doesn't resolve.
- **Tear down profiles the way they were built**: `rm -rf
  ~/.hermes/profiles/<p>` plus `~/.local/bin/<p>` if a wrapper alias exists;
  batch deletions into ONE terminal command (the mass-deletion security gate
  is calibrated per command, so several separate deletes each trip the
  approval prompt while one explicit command over known names passes).
- **Seed cards need observable acceptance checks** — a card without a
  runnable check gives the QA gate nothing to gate on.
- **Keep DM handoffs to one short message** (card id, new state, run command /
  watch-out). Chatty handoffs burn the profiles' context and the model
  fleet's attention; the board already records the state.
- **Cron-launched profiles have no `message_agent` tool.** An agent invoked
  via `hermes -p <profile> chat` falls back to the local bot-mode transport
  — and if it picks a persistent named session like "Bot Chat", it resurrects
  the stale-model + context-bloat failure this skill's date-stamped sessions
  exist to prevent. The job prompt must name the DM transport explicitly
  (e.g. "send with the local bot-mode DM transport into the partner's Bot
  Chat — never into your own session"). Verify after the first fire: inspect
  the partner profile's `state.db` `sessions` table for an unexpected
  long-lived session, and check its `messages` table shows the handoff text
  with attribution prefix.
- A handoff that triggers real downstream work (a claim + build) runs for
  many minutes; don't assume the fire-and-forget DM returned when the sender
  finished. Verify end-state on the board (state transition + `## Done`
  entry + report file), not the DM's acknowledgement.

## Portability (shipping the whole team)
Export each profile (`hermes profile export`), scrub each (mybot.farm
`scrub.py` — see the `hermes-agent-sharing` skill), and ship the team
workspace directory alongside. A receiver gets: N clean profile packs +
`<team>/` (TEAM.md, WORK.md, reports/) → import profiles, drop the directory
in place, re-point `memories/MEMORY.md` paths if the install differs.
Performance claims in any published copy must trace to real run evidence
(verdict files, reports), never to the design intent.

Bundling procedure (verified):
- **Long-lived team profiles accumulate machine-local bloat the drop list
  misses** — `lsp/` (a full LSP `node_modules`, tens of MB), `wisdom/`,
  `sessions/`, `runtime/`, per-role `state-snapshots`, execution state. After
  scrubbing, list each pack's top-level tar members: anything beyond the
  share scope (SOUL.md, memories/, skills/, redacted config.yaml, cron/
  bindings) is bloat. Fix the repo `scrub.py` `DROP_GLOBS` (the tool, so
  future exports benefit) and re-scrub — never hand-prune the pack.
- **Bundle layout** for a site stall: `packs/teams/<team>/` holding
  `<team>-<role>.hermes.tar.gz` per profile + the team memory + record file + the
  cron runner/wrapper scripts + one install README (import each tarball,
  recreate the team dir, create the kanban board if the team uses one, set the
  `SET_YOUR_ENDPOINT` placeholders, create the cron jobs). Mirror to root
  `packs/teams/` per the site convention. Optional README section: seat the
  team in a Bot-Mode group room (desktop-only, no CLI; 2–6 bots; rooms live in
  gateway-synced profile metadata, so a pack ships the profiles but NOT the
  room — say so in the README).
- **Reset the board before shipping**: shipped history preserved under
  `## Done`, active sections emptied, no live-owner claims — a fresh install
  resumes coordination from TEAM.md + skills without inheriting this team's
  in-flight state. For a kanban board: shipped cards become completed tasks,
  in-flight cards are archived, backlog stays unassigned — and since the board
  is machine-local SQLite, the pack ships the record file + the board-creation
  install step, never the board itself. The episodic session history (state.db) is dropped by
  design: TEAM.md + the team's learned skills in each profile are the
  portable knowledge; verify those skills survived the scrub's
  bundled-unused drop and the board's lessons (bounce fixes, repro
  fixtures) are encoded in them.
- **Hardening pass per pack**: neutralize `base_url` to a placeholder, final
  byte-level leak rescan over the archive (LAN IP ranges, key prefixes,
  home-username), then `hermes profile import <one tarball> --name
  <test>` end-to-end (SOUL intact, config sanitized, skills present) and
  tear the test profile down.
  - **Full-system ejection test before declaring the pack shippable.** Per-pack import tests miss missing *team* artifacts and a GAF that doesn't match reality. To prove the team installs as a unit: fully eject the source team (delete all member profiles, archive the board, remove the team dir + its cron jobs), then reinstall **only from the published URLs** — follow the live GAF `gettingStarted`, download every member tarball + the team files from the live pack dir, import each, recreate the workspace + board, set the endpoints — then run one trivial build→QA probe card through the re-installed profiles on a fresh board and require the gate's verdict PASS. This is what catches an omitted artifact, a 200-but-stale file, or an install step the GAF got wrong. Watch the deleted-name re-import tombstone (see `hermes-agent-sharing`) when re-importing under the same names. Keep the probe tasks on the board as evidence; delete only the throwaway repo.
