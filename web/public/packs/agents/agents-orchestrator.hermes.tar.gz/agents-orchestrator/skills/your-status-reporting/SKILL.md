---
name: your-status-reporting
description: "Use when the task matches this agent's your status reporting work."
version: 1.0.0
---

# Your Status Reporting

Pipeline Progress Template
```markdown
# WorkflowOrchestrator Status Report

## 🚀 Pipeline Progress
**Current Phase**: [PM/ArchitectUX/DevQALoop/Integration/Complete]
**Project**: [project-name]
**Started**: [timestamp]

## 📊 Task Completion Status
**Total Tasks**: [X]
**Completed**: [Y]
**Current Task**: [Z] - [task description]
**QA Status**: [PASS/FAIL/IN_PROGRESS]

## 🔄 Dev-QA Loop Status
**Current Task Attempts**: [1/2/3]
**Last QA Feedback**: "[specific feedback]"
**Next Action**: [spawn dev/spawn qa/advance task/escalate]

## 📈 Quality Metrics
**Tasks Passed First Attempt**: [X/Y]
**Average Retries Per Task**: [N]
**Screenshot Evidence Generated**: [count]
**Major Issues Found**: [list]

## 🎯 Next Steps
**Immediate**: [specific next action]
**Estimated Completion**: [time estimate]
**Potential Blockers**: [any concerns]

---
**Orchestrator**: WorkflowOrchestrator
**Report Time**: [timestamp]
**Status**: [ON_TRACK/DELAYED/BLOCKED]
```

### Completion Summary Template
```markdown
# Project Pipeline Completion Report

## ✅ Pipeline Success Summary
**Project**: [project-name]
**Total Duration**: [start to finish time]
**Final Status**: [COMPLETED/NEEDS_WORK/BLOCKED]

## 📊 Task Implementation Results
**Total Tasks**: [X]
**Successfully Completed**: [Y]
**Required Retries**: [Z]
**Blocked Tasks**: [list any]

## 🧪 Quality Validation Results
**QA Cycles Completed**: [count]
**Screenshot Evidence Generated**: [count]
**Critical Issues Resolved**: [count]
**Final Integration Status**: [PASS/NEEDS_WORK]

## 👥 Agent Performance
**project-manager-senior**: [completion status]
**ArchitectUX**: [foundation quality]
**Developer Agents**: [implementation quality - Frontend/Backend/Senior/etc.]
**EvidenceQA**: [testing thoroughness]
**testing-reality-checker**: [final assessment]

## 🚀 Production Readiness
**Status**: [READY/NEEDS_WORK/NOT_READY]
**Remaining Work**: [list if any]
**Quality Confidence**: [HIGH/MEDIUM/LOW]

---
**Pipeline Completed**: [timestamp]
**Orchestrator**: WorkflowOrchestrator
```