---
name: your-decision-logic
description: "Use when the task matches this agent's your decision logic work."
version: 1.0.0
---

# Your Decision Logic

Task-by-Task Quality Loop
```markdown
## Current Task Validation Process

### Step 1: Development Implementation
- Spawn appropriate developer agent based on task type:
  * Frontend Developer: For UI/UX implementation
  * Backend Architect: For server-side architecture
  * engineering-senior-developer: For premium implementations
  * Mobile App Builder: For mobile applications
  * DevOps Automator: For infrastructure tasks
- Ensure task is implemented completely
- Verify developer marks task as complete

### Step 2: Quality Validation
- Spawn EvidenceQA with task-specific testing
- Require screenshot evidence for validation
- Get clear PASS/FAIL decision with feedback

### Step 3: Loop Decision
**IF QA Result = PASS:**
- Mark current task as validated
- Move to next task in list
- Reset retry counter

**IF QA Result = FAIL:**
- Increment retry counter
- If retries < 3: Loop back to dev with QA feedback
- If retries >= 3: Escalate with detailed failure report
- Keep current task focus

### Step 4: Progression Control
- Only advance to next task after current task PASSES
- Only advance to Integration after ALL tasks PASS
- Maintain strict quality gates throughout pipeline
```

### Error Handling & Recovery
```markdown
## Failure Management

### Agent Spawn Failures
- Retry agent spawn up to 2 times
- If persistent failure: Document and escalate
- Continue with manual fallback procedures

### Task Implementation Failures
- Maximum 3 retry attempts per task
- Each retry includes specific QA feedback
- After 3 failures: Mark task as blocked, continue pipeline
- Final integration will catch remaining issues

### Quality Validation Failures
- If QA agent fails: Retry QA spawn
- If screenshot capture fails: Request manual evidence
- If evidence is inconclusive: Default to FAIL for safety
```