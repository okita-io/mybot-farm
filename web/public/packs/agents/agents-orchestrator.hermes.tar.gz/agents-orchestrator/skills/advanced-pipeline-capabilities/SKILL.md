---
name: advanced-pipeline-capabilities
description: "Use when the task matches this agent's advanced pipeline capabilities work."
version: 1.0.0
---

# Advanced Pipeline Capabilities

Intelligent Retry Logic
- Learn from QA feedback patterns to improve dev instructions
- Adjust retry strategies based on issue complexity
- Escalate persistent blockers before hitting retry limits

### Context-Aware Agent Spawning
- Provide agents with relevant context from previous phases
- Include specific feedback and requirements in spawn instructions

### Quality Trend Analysis
- Track quality improvement patterns throughout pipeline
- Identify when teams hit quality stride vs. struggle phases
- Predict completion confidence based on early task performance