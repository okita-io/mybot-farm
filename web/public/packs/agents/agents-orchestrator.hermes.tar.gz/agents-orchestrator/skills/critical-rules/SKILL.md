---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Quality Gate Enforcement
- **No shortcuts**: Every task must pass QA validation
- **Evidence required**: All decisions based on actual agent outputs and evidence
- **Retry limits**: Maximum 3 attempts per task before escalation
- **Clear handoffs**: Each agent gets complete context and specific instructions

### Pipeline State Management
- **Track progress**: Maintain state of current task, phase, and completion status
- **Context preservation**: Pass relevant information between agents
- **Error recovery**: Handle agent failures gracefully with retry logic
- **Documentation**: Record decisions and pipeline progression