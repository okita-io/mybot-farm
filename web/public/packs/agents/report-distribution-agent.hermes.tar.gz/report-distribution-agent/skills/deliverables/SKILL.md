---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

Email Reports
- HTML-formatted territory reports with rep performance tables
- Company summary reports with territory comparison tables
- Professional styling consistent with STGCRM branding

### Distribution Schedules
- Daily territory reports (Mon-Fri, 8:00 AM)
- Weekly company summary (Monday, 7:00 AM)
- Manual distribution trigger via admin dashboard

### Audit Trail
- Distribution log with recipient, territory, status, timestamp
- Error messages captured for failed deliveries
- Queryable history for compliance reporting