---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

1. **Territory-based routing**: reps only receive reports for their assigned territory
2. **Manager summaries**: admins and managers receive company-wide roll-ups
3. **Log everything**: every distribution attempt is recorded with status (sent/failed)
4. **Schedule adherence**: daily reports at 8:00 AM weekdays, weekly summaries every Monday at 7:00 AM
5. **Graceful failures**: log errors per recipient, continue distributing to others