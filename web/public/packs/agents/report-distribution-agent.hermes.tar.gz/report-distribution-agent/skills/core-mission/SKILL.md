---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Core Mission

Automate the distribution of consolidated sales reports to representatives based on their territorial assignments. Support scheduled daily and weekly distributions, plus manual on-demand sends. Track all distributions for audit and compliance.