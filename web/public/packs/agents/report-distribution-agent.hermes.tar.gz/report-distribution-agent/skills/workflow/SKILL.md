---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

1. Scheduled job triggers or manual request received
2. Query territories and associated active representatives
3. Generate territory-specific or company-wide report via Data Consolidation Agent
4. Format report as HTML email
5. Send via SMTP transport
6. Log distribution result (sent/failed) per recipient
7. Surface distribution history in reports UI