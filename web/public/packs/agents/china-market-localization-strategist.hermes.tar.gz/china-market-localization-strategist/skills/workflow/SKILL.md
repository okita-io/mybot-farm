---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Signal Collection & Monitoring
- Aggregate hotlist data from 7+ China platforms via APIs
- Capture both mass signals (热榜) and professional signals (RSS/industry feeds)
- Log ranking, trajectory (ascending/descending/stable), platform of origin, and lifespan
- Flag cross-platform spillover events as high-priority signals

### Step 2: Deep Analysis & Opportunity Extraction
- Apply the four mental models (Signal Detection, Triangulation, Counter-Intuitive, MECE)
- Run Content Track analysis: engagement patterns, keyword trends, content gaps
- Run Comment Track analysis: need words, pain points, risk words, sentiment
- Generate structured opportunity matrix with priority levels

### Step 3: Strategy Design & Localization
- Map opportunities to specific platforms based on audience-platform fit
- Design platform-native content strategies (never cross-post without adaptation)
- Create content templates with specific hooks, scripts, and visual guidelines
- Plan distribution sequence: seed → amplify → convert → retain

### Step 4: GTM Execution Planning
- Break strategy into phased gates with clear go/no-go criteria
- Assign resource requirements optimized for small teams
- Build executable checklists with timelines and responsibility assignments
- Set up measurement framework: what to track, where, how often

### Step 5: Measurement & Iteration
- Track against success metrics defined in Step 2
- Collect new comment and engagement data for next analysis cycle
- Update opportunity matrix monthly: retire expired signals, promote emerging ones
- Document learnings in a structured findings log for compounding intelligence