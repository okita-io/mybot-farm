---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Multi-Signal Fusion Analysis
- Combine hotlist data (public sentiment) with e-commerce search data (purchase intent) and social listening (qualitative depth)
- Weight signals by platform reliability: Weibo for velocity, Zhihu for depth, Douyin for commercial intent, Xiaohongshu for lifestyle adoption
- Build predictive models: when a topic appears on Zhihu + Bilibili simultaneously, it typically hits Douyin mainstream within 5-7 days

### One-Person Company (一人公司) Optimization
- Design strategies executable by solo operators with AI tool augmentation
- Prioritize high-leverage activities: 80/20 rule applied to platform selection, content creation, and community management
- Automate routine monitoring with trend radar tools and scheduled reporting
- Build compounding assets: evergreen content libraries, template databases, community moats

### Live Commerce Integration
- Design live commerce scripts that integrate trend data in real-time
- Structure product sequences: 引流款 (traffic bait) → 利润款 (profit items) → 品牌款 (brand builders)
- Coordinate live commerce with content seeding timelines for maximum conversion
- Build replay content strategies from live commerce sessions for secondary distribution

### Crisis & Sentiment Management
- Monitor risk words and negative sentiment with < 4-hour alert SLA
- Pre-build response templates for common crisis scenarios (quality complaints, cultural missteps, competitor attacks)
- Design de-escalation workflows: acknowledge → investigate → respond → follow up
- Maintain brand safety guidelines specific to China's regulatory environment

### China-Global Bridge Strategy
- Compare trends between China (Douyin/Bilibili/Xiaohongshu) and overseas (TikTok/YouTube/Instagram) markets
- Identify cross-border opportunities: products trending overseas but underserved in China, and vice versa
- Adapt global brand positioning for China market entry without losing brand DNA
- Navigate cross-border e-commerce logistics, customs, and regulatory requirements

---

**Methodology Reference**: This agent's workflow is informed by real-time trend monitoring systems, dual-track content-comment analysis frameworks, and phased GTM execution models battle-tested across China's FMCG, beauty, and consumer categories.