---
name: topology-patterns
description: "Use when the task matches this agent's topology patterns work."
version: 1.0.0
---

# Topology Patterns

Pattern 1 — Sequential Chain

```
Input → Agent A → Agent B → Agent C → Output
```

**Use when:**
- Each step depends on the output of the previous step
- Task has a natural linear progression (research → draft → review → publish)
- Debugging simplicity is prioritized over latency

**Failure mode**: Single agent failure halts entire pipeline. Agent C has no visibility into Agent A's reasoning — context loss compounds across hops.

**Design rules:**
- Pass structured outputs between agents, not raw prose (reduces misinterpretation)
- Include a brief "context summary" field each agent appends for downstream agents
- Set maximum chain length: chains >5 agents typically degrade in output quality
- Define what each agent receives, produces, and is NOT responsible for

---

### Pattern 2 — Parallel Fan-Out / Fan-In

```
              ┌→ Agent A ─┐
Input → Router ├→ Agent B ─┤→ Synthesizer → Output
              └→ Agent C ─┘
```

**Use when:**
- Subtasks are independent and can run concurrently
- Latency reduction is a priority
- Multiple perspectives on the same input are valuable (e.g., legal + financial + technical review)

**Failure mode**: Partial results if one agent fails. Synthesizer must handle missing branches gracefully. Race conditions if agents share mutable state.

**Design rules:**
- Agents in a fan-out MUST be truly independent — no shared mutable state
- Synthesizer must explicitly handle: all results present, partial results, zero results
- Define merge strategy before building: vote, weight, concatenate, or defer to human
- Fan-out width limit: >7 parallel agents typically exceeds synthesis quality threshold

---

### Pattern 3 — Hierarchical (Orchestrator-Subagent)

```
                    ┌→ Subagent A
Orchestrator ───────├→ Subagent B
                    └→ Subagent C
         ↑____feedback_____|
```

**Use when:**
- Tasks are complex and require dynamic decomposition
- The set of subtasks isn't known upfront
- Quality control requires a coordinating judgment layer

**Failure mode**: Orchestrator becomes a bottleneck. Orchestrator prompt complexity grows unbounded. Subagents that "succeed" on their local objective but contradict each other.

**Design rules:**
- Orchestrator's job is decomposition, delegation, and synthesis — NOT execution
- Orchestrator must maintain a task ledger: what was delegated, to whom, status, output
- Subagents must return structured results + confidence signal, not just answers
- Orchestrator must detect contradiction between subagent outputs and resolve explicitly
- Limit orchestrator context window consumption: subagent outputs should be summarized, not appended in full

---

### Pattern 4 — Evaluator-Optimizer Loop

```
Generator → Evaluator → [pass] → Output
     ↑_______[fail + feedback]__|
```

**Use when:**
- Output quality is measurable or scorable
- First-pass output is expected to be imperfect
- Iterative refinement is worth the latency/cost trade-off

**Failure mode**: Infinite loop if evaluator criteria are impossible or contradictory. Generator stops improving after N iterations (diminishing returns). Evaluator and generator share the same blind spots.

**Design rules:**
- Evaluator must use different criteria framing than Generator's instructions
- Define hard exit: maximum iterations (recommend: 3) regardless of evaluator score
- Evaluator output must be structured: score, specific failure reasons, actionable feedback
- Log each iteration's score — if score plateaus across 2 consecutive iterations, exit and escalate
- Generator and Evaluator should ideally be different models or have different system prompts

---

### Pattern 5 — Mesh / Peer Network

```
Agent A ⟷ Agent B
  ⟷         ⟷
Agent C ⟷ Agent D
```

**Use when:**
- Agents need to negotiate or reach consensus
- No single agent has sufficient context to make the final decision
- Simulating diverse expert panel deliberation

**Failure mode**: Highest complexity. Circular dependencies. Consensus deadlock. Exponential context growth as agents read each other's outputs. Hard to debug.

**Design rules:**
- Rarely the right choice for production systems — default to hierarchical first
- Require a moderator agent or termination condition (max rounds, consensus threshold)
- Each agent's read access to peer outputs should be scoped: full transcript vs. summary
- Define explicit consensus mechanism: majority, unanimity, weighted by confidence…