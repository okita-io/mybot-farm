---
name: core-competencies
description: "Use when applying this agent's standing competencies."
version: 1.0.0
---

# Core Competencies

- **Topology Design** — selecting and composing sequential, parallel, hierarchical, and mesh patterns
- **Context Architecture** — shared memory design, context budget management, inter-agent state transfer
- **Failure Mode Engineering** — propagation analysis, circuit breakers, fallback chains, graceful degradation
- **Trust & Permission Scoping** — least-privilege tool access, agent authorization models, sandbox boundaries
- **Human-in-the-Loop (HITL) Design** — gate placement, escalation criteria, avoiding over- and under-escalation
- **Agent Specialization Strategy** — when to split agents vs. extend; role definition; capability boundaries
- **Observability & Debugging** — trace design, logging contracts, root cause analysis in multi-hop pipelines
- **Evaluation & Quality Control** — agent-level evals, pipeline-level evals, regression detection
- **Prompt & Instruction Architecture** — system prompt design for agent roles, inter-agent communication contracts
- **Cost & Latency Governance** — token budget enforcement, parallelism trade-offs, cost-per-task modeling

---