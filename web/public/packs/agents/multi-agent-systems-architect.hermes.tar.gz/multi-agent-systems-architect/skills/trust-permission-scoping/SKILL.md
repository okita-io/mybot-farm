---
name: trust-permission-scoping
description: "Use when the task matches this agent's trust & permission scoping work."
version: 1.0.0
---

# Trust & Permission Scoping

Least-Privilege Principle for Agents

Each agent should have access to only the tools and data it needs — nothing more.

**Tool Access Matrix (example)**

| Agent Role | Web Search | Code Execution | File Write | External API | DB Read | DB Write |
|---|---|---|---|---|---|---|
| Researcher | ✅ | ❌ | ❌ | Read-only | ✅ | ❌ |
| Analyst | ❌ | ✅ (sandbox) | ❌ | ❌ | ✅ | ❌ |
| Writer | ❌ | ❌ | ✅ (drafts only) | ❌ | ❌ | ❌ |
| Publisher | ❌ | ❌ | ✅ | ✅ (publish API) | ❌ | ✅ (status only) |
| Orchestrator | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ (task ledger) |

### Agent Authorization Model

**Identity**: Each agent instance has a unique ID and role label. Inter-agent messages must include sender ID — downstream agents validate the source.

**Scope tokens**: Each agent receives a scoped token that grants only its permitted tool access. Tokens are not passed between agents.

**Sandboxing**: Code execution agents run in isolated environments. File system access is restricted to designated directories. Network access is allowlisted, not open.

**Audit log**: Every tool call by every agent is logged with: agent ID, tool name, inputs, outputs, timestamp. Non-negotiable for production systems.

### Prompt Injection Defense

Agents that process external content (web pages, user-submitted documents, emails) are at risk of prompt injection — malicious content that hijacks the agent's instructions.

**Mitigations:**
- Separate content processing from instruction processing: never concatenate external content directly into the system prompt
- Use a "sanitizer" agent whose only job is to extract structured data from untrusted content before passing to downstream agents
- Validate structured outputs with schema enforcement — injected instructions don't produce valid JSON
- Flag and quarantine any agent output that contains instruction-like language (imperative verbs + tool names)

---