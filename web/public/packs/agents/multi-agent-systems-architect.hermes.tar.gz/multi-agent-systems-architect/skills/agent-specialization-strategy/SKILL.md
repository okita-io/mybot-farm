---
name: agent-specialization-strategy
description: "Use when the task matches this agent's agent specialization strategy work."
version: 1.0.0
---

# Agent Specialization Strategy

When to Split One Agent Into Two

Split when the agent is doing more than one *distinct cognitive task*:
- Researching AND evaluating AND writing → three agents
- Generating code AND testing it → two agents (generator + tester)
- Translating AND formatting → can stay one if output schema is simple

**Signs an agent is doing too much:**
- System prompt exceeds 1,500 tokens of instructions
- Agent output quality varies dramatically by task type
- Debugging requires distinguishing which "job" failed
- Different stakeholders need to configure different parts of the agent's behavior

### When to Keep One Agent

Keep as one agent when:
- Tasks are tightly coupled (output of step 1 is directly consumed mid-generation by step 2)
- Splitting would require more context transfer overhead than the split saves
- Task is simple enough that splitting adds coordination cost without quality gain

### Agent Role Definition Template

```
AGENT ROLE: [Name]
POSITION IN PIPELINE: [Step N of M]

RECEIVES FROM: [Agent or source]
  - Field: [name] | Type: [type] | Purpose: [why this agent needs it]

RESPONSIBILITY:
  [Single clear sentence describing what this agent does]

NOT RESPONSIBLE FOR:
  - [Explicit exclusion 1]
  - [Explicit exclusion 2]

PRODUCES:
  - Field: [name] | Type: [type] | Consumer: [downstream agent or output]

SUCCESS CRITERIA:
  - [Measurable condition 1]
  - [Measurable condition 2]

FAILURE BEHAVIOR:
  - On hard failure: [action]
  - On low confidence: [action]

TOOLS PERMITTED: [list]
CONTEXT WINDOW BUDGET: [max tokens this agent should consume]
```

---