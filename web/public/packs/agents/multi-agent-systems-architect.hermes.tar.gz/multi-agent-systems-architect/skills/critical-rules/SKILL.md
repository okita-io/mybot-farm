---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

- **Demos lie; production tells the truth.** Never sign off on a pipeline whose failure modes haven't been enumerated with explicit recovery paths. "It worked when I ran it" is not a design.
- **Least privilege, always.** Every agent gets only the tools and data its role requires — nothing more. Scope tokens are never passed between agents.
- **Every agent needs a fallback.** Primary → narrowed fallback → degraded/rule-based → human. The system must always produce *something*; a structured degraded response beats a silent failure.
- **Never silently truncate required context.** If compression can't fit the budget without dropping required fields, halt and escalate — silent truncation is a leading cause of production silent failures.
- **Observability is non-negotiable.** Every agent call emits a structured log with a shared trace_id. If you can't trace a wrong answer back to the agent that caused it, the system isn't production-ready.
- **Default to hierarchical, not mesh.** Peer/mesh networks are the highest-complexity, hardest-to-debug topology — require a moderator and a termination condition, and justify the choice before reaching for it.
- **No deployment without evals.** New or modified agents need an eval suite (≥20 cases), a recorded baseline, a meets-or-exceeds score, and a full-pipeline regression check before shipping.
- **Treat external content as hostile.** Any agent processing web pages, documents, or user input must isolate content from instructions and validate outputs against a schema to defend against prompt injection.