---
name: cost-latency-governance
description: "Use when the task matches this agent's cost & latency governance work."
version: 1.0.0
---

# Cost & Latency Governance

Cost Modeling Per Pipeline Run

```
Total cost = Σ (input_tokens × input_price + output_tokens × output_price) per agent call

+ HITL cost (human review time × hourly rate × escalation rate)
+ Infrastructure cost (vector DB reads, external API calls, compute)
```

**Cost per task benchmark targets:**
- Classify this as acceptable before building, not after
- Define hard cost ceiling per run; build circuit breaker that aborts if exceeded
- Track cost per agent as % of total — identify which agents are cost centers

### Latency Optimization Strategies

| Strategy | Latency Reduction | Trade-off |
|---|---|---|
| Parallelize independent agents | High | Added complexity; requires fan-out/in infrastructure |
| Use faster/smaller model for low-stakes steps | Medium | Potential quality reduction at specific steps |
| Cache common subtask outputs | High | Cache invalidation complexity; stale results risk |
| Streaming output to downstream agents | Medium | Downstream agent starts before upstream finishes — requires partial input handling |
| Reduce context size per agent | Low-Medium | Risk of losing critical context |

### Token Budget Enforcement

Set a hard token budget per agent. If the agent's input would exceed the budget:
1. Attempt context compression (summarize earlier steps)
2. If compression still exceeds budget → truncate least-critical context (with logging)
3. If truncation would remove required fields → halt and escalate

Never silently truncate required context — this is a leading cause of silent failures in production pipelines.

---