---
name: failure-mode-engineering
description: "Use when the task matches this agent's failure mode engineering work."
version: 1.0.0
---

# Failure Mode Engineering

Failure Taxonomy

| Failure Type | Description | Detection | Recovery |
|---|---|---|---|
| **Hard failure** | Agent returns error, exception, or times out | Error code / timeout | Retry with backoff → fallback agent → human escalation |
| **Silent failure** | Agent returns output but it's wrong or hallucinated | Evaluator agent; schema validation | Retry with explicit correction prompt → human review |
| **Partial failure** | Agent returns incomplete output (truncated, missing fields) | Schema validation; completeness check | Request specific missing fields → regenerate |
| **Contradiction** | Two agents return conflicting outputs | Explicit contradiction detector | Arbitration agent → human decision |
| **Cascade failure** | One agent's bad output poisons all downstream agents | Checkpoint validation; anomaly detection | Rollback to last checkpoint; re-run from failure point |
| **Loop failure** | Evaluator-optimizer never converges | Iteration counter; score plateau detection | Force exit; escalate with last best output |
| **Context failure** | Agent ignores instructions due to context overload | Output schema validation; instruction adherence check | Trim context; re-run with compressed state |

### Circuit Breaker Pattern

Apply to any agent that can be called repeatedly (retry loops, optimizer loops):

```
State: CLOSED (normal) → OPEN (failing) → HALF-OPEN (testing recovery)

CLOSED: Requests flow normally. Track failure rate over rolling window.
  → If failure rate > threshold (e.g., 3 failures in 5 attempts): trip to OPEN

OPEN: Requests immediately fail / escalate. Do not call the agent.
  → After cooldown period (e.g., 60 seconds): transition to HALF-OPEN

HALF-OPEN: Allow one test request.
  → If succeeds: return to CLOSED
  → If fails: return to OPEN
```

### Fallback Chain Design

For every agent in a production pipeline, define its fallback:

| Priority | Agent | Condition to Invoke |
|---|---|---|
| 1 (primary) | Full capability agent (e.g., GPT-4o, Claude Opus) | Default |
| 2 (fallback) | Lighter agent with narrowed scope | Primary fails or exceeds latency SLA |
| 3 (degraded) | Rule-based / template output | Fallback also fails |
| 4 (human) | Human review queue | All automated paths fail |

Design rule: the system must always produce *something* — even a "degraded mode" structured response is better than a silent failure.

### Rollback & Recovery

- **Checkpoint frequency**: after every agent that produces irreversible side effects (sends email, writes to DB, calls external API)
- **Idempotency requirement**: any agent that can be retried MUST be idempotent — running it twice must produce the same result or be safe to overwrite
- **Compensation actions**: for non-idempotent actions, define the compensation (e.g., send correction email, delete duplicate record)
- **Recovery point objective**: define how far back the pipeline can safely re-run from

---