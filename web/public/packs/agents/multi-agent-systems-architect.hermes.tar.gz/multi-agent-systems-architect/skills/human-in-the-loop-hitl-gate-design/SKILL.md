---
name: human-in-the-loop-hitl-gate-design
description: "Use when the task matches this agent's human-in-the-loop (hitl) gate design work."
version: 1.0.0
---

# Human-in-the-Loop (HITL) Gate Design

The Escalation Calibration Problem

**Over-escalation**: humans are interrupted constantly → they start rubber-stamping → HITL becomes theater, not safety.
**Under-escalation**: humans never see edge cases → system builds false confidence → catastrophic failure when it matters.

### HITL Gate Placement Framework

Place a HITL gate when the pipeline action meets one or more of these criteria:

| Criterion | Example | Gate Type |
|---|---|---|
| **Irreversibility** | Send bulk email; delete records; publish content | Blocking approval |
| **High blast radius** | Action affects >100 users / >$10k value | Blocking approval |
| **Low confidence** | Agent confidence score <0.7; contradictory outputs | Blocking review |
| **Novel situation** | Input pattern not seen in eval set; out-of-distribution | Advisory flag |
| **Regulatory exposure** | Output involves legal, medical, or financial advice | Blocking approval |
| **Explicit policy** | Business rule requires human sign-off | Blocking approval |

### Gate Types

**Blocking Approval Gate**
- Pipeline pauses; human receives structured summary with recommended action
- Human approves, rejects, or modifies
- Timeout behavior must be defined: default approve, default reject, or escalate further
- SLA: define maximum wait time before timeout triggers

**Advisory Flag Gate**
- Pipeline continues but flags the action for async human review
- Human can trigger rollback if they catch a problem within review window
- Use when: consequence is reversible; latency of blocking would harm user experience

**Sampling Gate**
- Human reviews X% of outputs randomly (not all)
- Use when: volume is too high for full review; quality monitoring is the goal
- Sampling rate should increase when error rate rises (adaptive sampling)

### HITL Interface Requirements

Every human review interface must show:
- What the agent decided and why (reasoning trace, not just conclusion)
- What alternatives were considered
- What the consequence of approving vs. rejecting is
- How confident the agent was
- One-click approve / reject / escalate — no interface friction

---