---
name: observability-debugging
description: "Use when the task matches this agent's observability & debugging work."
version: 1.0.0
---

# Observability & Debugging

The Multi-Hop Debugging Problem

When a 5-agent pipeline produces a wrong answer, the failure could be in any agent — or in the inter-agent context transfer. Without traces, root cause analysis is guesswork.

### Minimum Observability Requirements

**Per agent call, log:**
```json
{
  "trace_id": "uuid (shared across entire pipeline run)",
  "span_id": "uuid (this agent call)",
  "agent_id": "researcher_v2",
  "step": 2,
  "started_at": "ISO8601",
  "completed_at": "ISO8601",
  "latency_ms": 1243,
  "input_tokens": 1820,
  "output_tokens": 412,
  "total_cost_usd": 0.0087,
  "input_hash": "sha256 of input (for dedup/cache)",
  "output": { ... },
  "confidence": 0.82,
  "tools_called": ["web_search"],
  "errors": [],
  "model": "claude-opus-4-6",
  "status": "success | failure | partial | escalated"
}
```

**Per pipeline run, log:**
- Total latency; total cost; total tokens
- Which agents ran; which were skipped or failed
- Final output and status
- HITL gates triggered; human decisions made

### Root Cause Analysis Protocol

When a pipeline produces a bad output:

**Step 1 — Identify the blast radius**
Was the bad output a single wrong answer, or did it propagate downstream?

**Step 2 — Trace backward**
Start from the final output. Which agent produced the field that's wrong? Inspect that agent's input and output.

**Step 3 — Isolate the failure**
- If the agent's input was correct but output was wrong → agent failure (prompt, model, or context issue)
- If the agent's input was already wrong → upstream failure; continue tracing backward
- If the agent's input was correct and output was correct but downstream agent misused it → inter-agent contract failure

**Step 4 — Classify the root cause**
- Prompt ambiguity: agent instruction was unclear
- Context overload: agent context window was too full; instructions were deprioritized
- Model limitation: task exceeded model capability; try a stronger model or decompose further
- Schema mismatch: agent produced output that didn't match expected schema; downstream agent misinterpreted
- Missing information: agent didn't have necessary context to complete the task correctly

**Step 5 — Fix and regression test**
Fix the root cause. Add the failing case to your eval set. Run full pipeline eval before redeploying.

---