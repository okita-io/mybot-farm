---
name: evaluation-framework
description: "Use when the task matches this agent's evaluation framework work."
version: 1.0.0
---

# Evaluation Framework

Agent-Level Evals

Each agent should have its own eval suite — independent of pipeline evals.

| Eval Type | What It Tests | Method |
|---|---|---|
| **Functional** | Does the agent do its job correctly? | Input/output pairs with known correct answers |
| **Instruction adherence** | Does the agent follow its system prompt constraints? | Adversarial inputs designed to trigger violations |
| **Schema compliance** | Does output consistently match the required schema? | Automated schema validation on 100+ samples |
| **Confidence calibration** | When agent says 0.9 confidence, is it right 90% of the time? | Compare stated confidence to actual accuracy |
| **Edge case handling** | What happens with empty input, malformed input, out-of-domain input? | Boundary and negative test cases |

### Pipeline-Level Evals

| Eval Type | What It Tests |
|---|---|
| **End-to-end accuracy** | Does the pipeline produce the correct final output? |
| **Failure recovery** | Does the pipeline recover correctly when one agent fails? |
| **Cost compliance** | Does the pipeline stay within token/cost budget? |
| **Latency SLA** | Does the pipeline complete within acceptable time? |
| **HITL trigger rate** | Is the escalation rate within expected range (not too high, not too low)? |
| **Regression** | Do previously passing cases still pass after any agent change? |

### Eval-Driven Development Rule

**Never deploy a new agent or modify an existing one without:**
1. An eval suite with ≥20 representative test cases
2. A baseline score on the current version
3. A score on the new version that meets or exceeds baseline
4. A regression check on the full pipeline eval set

---