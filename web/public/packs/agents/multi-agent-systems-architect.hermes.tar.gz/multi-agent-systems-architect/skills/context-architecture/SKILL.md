---
name: context-architecture
description: "Use when the task matches this agent's context architecture work."
version: 1.0.0
---

# Context Architecture

The Context Budget Problem

Every agent in a pipeline consumes context. In a 5-agent sequential chain, context pressure compounds:
- Agent A receives: user input (500 tokens)
- Agent B receives: user input + Agent A output (1,500 tokens)
- Agent C receives: prior chain + Agent B output (3,500 tokens)
- Agent D receives: prior chain + Agent C output (7,500 tokens)
- Agent E receives: prior chain + Agent D output (15,000+ tokens)

Context budget exhaustion causes: hallucination, instruction-following failures, truncation of critical early context.

### Context Management Strategies

**1. Summarization Compression**
Each agent produces two outputs: full output + compressed summary (≤200 tokens).
Downstream agents receive summaries of prior steps, not full outputs.
Risk: lossy — critical details may be dropped in summary.
Mitigation: define what fields are always preserved verbatim (IDs, decisions, constraints).

**2. Structured State Object**
Define a shared state schema passed between agents. Each agent reads only its required fields and writes only its output fields.

```json
{
  "task_id": "uuid",
  "original_input": "...",
  "constraints": ["...", "..."],
  "agent_outputs": {
    "researcher": { "summary": "...", "sources": [...], "confidence": 0.85 },
    "analyst": { "findings": "...", "risks": [...] },
    "writer": { "draft": "..." }
  },
  "decisions": [],
  "current_step": "writer",
  "status": "in_progress"
}
```

Each agent receives only the fields relevant to its role — not the full object.

**3. External Memory Store**
Long-form outputs written to external storage (vector DB, key-value store).
Agents retrieve only what they need via targeted lookup, not full context injection.
Use when: pipeline produces large intermediate artifacts (research reports, codebases).

**4. Context Checkpointing**
At defined milestones, compress all prior state into a checkpoint summary.
Agents after the checkpoint receive only the checkpoint + their immediate inputs.
Enables pipelines that would otherwise exceed any context window.

### Context Scoping Rules
- Each agent's system prompt must specify exactly what it reads and writes
- Agents should never receive another agent's full system prompt
- Sensitive data (PII, credentials) must be explicitly excluded from inter-agent state
- Define a context ownership model: who can overwrite which fields

---