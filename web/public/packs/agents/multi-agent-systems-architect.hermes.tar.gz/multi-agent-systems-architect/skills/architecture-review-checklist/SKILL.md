---
name: architecture-review-checklist
description: "Use when the task matches this agent's architecture review checklist work."
version: 1.0.0
---

# Architecture Review Checklist

Before deploying a multi-agent pipeline to production:

### Design
- [ ] Topology is explicitly documented with data flow diagram
- [ ] Each agent has a defined role, input contract, and output contract
- [ ] No agent has access to tools or data beyond its defined scope
- [ ] Context budget has been calculated for worst-case input at each agent
- [ ] All failure modes are documented with recovery paths

### Failure Resilience
- [ ] Circuit breakers are in place for all retry-eligible agents
- [ ] Fallback chain is defined for every agent (fallback agent or human escalation)
- [ ] All side-effecting agents are idempotent or have compensation actions defined
- [ ] Checkpoint/rollback points are defined at every irreversible action

### Human-in-the-Loop
- [ ] All irreversible, high-blast-radius, and low-confidence actions have HITL gates
- [ ] Timeout behavior is defined for every blocking gate
- [ ] HITL interface surfaces reasoning trace, alternatives, and consequence — not just the decision
- [ ] Escalation rate target is defined; monitoring is in place to detect drift

### Observability
- [ ] Every agent call produces a structured log entry with trace_id
- [ ] Full pipeline run produces a consolidated trace
- [ ] Cost and latency are tracked per agent and per pipeline run
- [ ] Alert thresholds are set for: failure rate, cost ceiling, latency SLA, escalation rate

### Evaluation
- [ ] Each agent has an independent eval suite (≥20 cases)
- [ ] Pipeline has an end-to-end eval suite
- [ ] Baseline scores are recorded
- [ ] Deployment gate: new version must meet or exceed baseline before shipping

### Security
- [ ] Prompt injection mitigations are in place for any agent handling external content
- [ ] Agent identity and inter-agent message authenticity are verified
- [ ] Audit log covers all tool calls by all agents
- [ ] Sensitive data is excluded from inter-agent state objects