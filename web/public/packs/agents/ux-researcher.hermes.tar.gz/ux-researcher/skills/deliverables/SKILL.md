---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Research Deliverables

User Research Study Framework
```markdown
# User Research Study Plan

## Research Objectives
**Primary Questions**: [What we need to learn]
**Success Metrics**: [How we'll measure research success]
**Business Impact**: [How findings will influence product decisions]

## Methodology
**Research Type**: [Qualitative, Quantitative, Mixed Methods]
**Methods Selected**: [Interviews, Surveys, Usability Testing, Analytics]
**Rationale**: [Why these methods answer our questions]

## Participant Criteria
**Primary Users**: [Target audience characteristics]
**Sample Size**: [Number of participants with statistical justification]
**Recruitment**: [How and where we'll find participants]
**Screening**: [Qualification criteria and bias prevention]

## Study Protocol
**Timeline**: [Research schedule and milestones]
**Materials**: [Scripts, surveys, prototypes, tools needed]
**Data Collection**: [Recording, consent, privacy procedures]
**Analysis Plan**: [How we'll process and synthesize findings]
```

### User Persona Template
```markdown
# User Persona: [Persona Name]

## Demographics & Context
**Age Range**: [Age demographics]
**Location**: [Geographic information]
**Occupation**: [Job role and industry]
**Tech Proficiency**: [Digital literacy level]
**Device Preferences**: [Primary devices and platforms]

## Behavioral Patterns
**Usage Frequency**: [How often they use similar products]
**Task Priorities**: [What they're trying to accomplish]
**Decision Factors**: [What influences their choices]
**Pain Points**: [Current frustrations and barriers]
**Motivations**: [What drives their behavior]

## Goals & Needs
**Primary Goals**: [Main objectives when using product]
**Secondary Goals**: [Supporting objectives]
**Success Criteria**: [How they define successful task completion]
**Information Needs**: [What information they require]

## Context of Use
**Environment**: [Where they use the product]
**Time Constraints**: [Typical usage scenarios]
**Distractions**: [Environmental factors affecting usage]
**Social Context**: [Individual vs. collaborative use]

## Quotes & Insights
> "[Direct quote from research highlighting key insight]"
> "[Quote showing pain point or frustration]"
> "[Quote expressing goals or needs]"

**Research Evidence**: Based on [X] interviews, [Y] survey responses, [Z] behavioral data points
```

### Usability Testing Protocol
```markdown
# Usability Testing Session Guide

## Pre-Test Setup
**Environment**: [Testing location and setup requirements]
**Technology**: [Recording tools, devices, software needed]
**Materials**: [Consent forms, task cards, questionnaires]
**Team Roles**: [Moderator, observer, note-taker responsibilities]

## Session Structure (60 minutes)
### Introduction (5 minutes)
- Welcome and comfort building
- Consent and recording permission
- Overview of think-aloud protocol
- Questions about background

### Baseline Questions (10 minutes)
- Current tool usage and experience
- Expectations and mental models
- Relevant demographic information

### Task Scenarios (35 minutes)
**Task 1**: [Realistic scenario description]
- Success criteria: [What completion looks like]
- Metrics: [Time, errors, completion rate]
- Observation focus: [Key behaviors to watch]

**Task 2**: [Second scenario]
**Task 3**: [Third scenario]

### Post-Test Interview (10 minutes)
- Overall impressions and satisfaction
- Specific feedback on pain points
- Suggestions for improvement
- Comparative questions

## Data Collection
**Quantitative**: [Task completion rates, time on task, error counts]
**Qualitative**: [Quotes, behavioral observations, emotional responses]
**System Metrics**: [Analytics data, performance measures]
```