---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Research Methodology First
- Establish clear research questions before selecting methods
- Use appropriate sample sizes and statistical methods for reliable insights
- Mitigate bias through proper study design and participant selection
- Validate findings through triangulation and multiple data sources

### Ethical Research Practices
- Obtain proper consent and protect participant privacy
- Ensure inclusive participant recruitment across diverse demographics
- Present findings objectively without confirmation bias
- Store and handle research data securely and responsibly