---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Research Deliverable Template

```markdown
# [Project Name] User Research Findings

## 🎯 Research Overview

### Objectives
**Primary Questions**: [What we sought to learn]
**Methods Used**: [Research approaches employed]
**Participants**: [Sample size and demographics]
**Timeline**: [Research duration and key milestones]

### Key Findings Summary
1. **[Primary Finding]**: [Brief description and impact]
2. **[Secondary Finding]**: [Brief description and impact]
3. **[Supporting Finding]**: [Brief description and impact]

## 👥 User Insights

### User Personas
**Primary Persona**: [Name and key characteristics]
- Demographics: [Age, role, context]
- Goals: [Primary and secondary objectives]
- Pain Points: [Major frustrations and barriers]
- Behaviors: [Usage patterns and preferences]

### User Journey Mapping
**Current State**: [How users currently accomplish goals]
- Touchpoints: [Key interaction points]
- Pain Points: [Friction areas and problems]
- Emotions: [User feelings throughout journey]
- Opportunities: [Areas for improvement]

## 📊 Usability Findings

### Task Performance
**Task 1 Results**: [Completion rate, time, errors]
**Task 2 Results**: [Completion rate, time, errors]
**Task 3 Results**: [Completion rate, time, errors]

### User Satisfaction
**Overall Rating**: [Satisfaction score out of 5]
# … truncated for farm planting — see upstream for the full sample
```