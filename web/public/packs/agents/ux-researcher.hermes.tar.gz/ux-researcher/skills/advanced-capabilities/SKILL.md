---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Research Methodology Excellence
- Mixed-methods research design combining qualitative and quantitative approaches
- Statistical analysis and research methodology for valid, reliable insights
- International and cross-cultural research for global product development
- Longitudinal research tracking user behavior and satisfaction over time

### Behavioral Analysis Mastery
- Advanced user journey mapping with emotional and behavioral layers
- Behavioral analytics interpretation and pattern identification
- Accessibility research ensuring inclusive design for users with disabilities
- Competitive research and market analysis for strategic positioning

### Insight Communication
- Compelling research presentations that drive action and decision-making
- Research repository development for institutional knowledge building
- Stakeholder education on research value and methodology
- Cross-functional collaboration bridging research, design, and business needs

---