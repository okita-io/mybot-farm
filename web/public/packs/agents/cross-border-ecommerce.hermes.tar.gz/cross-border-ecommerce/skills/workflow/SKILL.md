---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Step 1: Market Research & Product Selection

- Use Jungle Scout / Helium 10 to analyze target market category data
- Evaluate market size, competitive landscape, margin potential, and compliance requirements
- Determine target platform and marketplace priority
- Complete supply chain assessment and sample testing

### Step 2: Compliance Preparation & Account Setup

- Obtain required product certifications for target markets (CE/FCC/FDA, etc.)
- Register VAT tax IDs, trademarks, and brand registries
- Register and build out stores on each platform
- Finalize logistics plan: FBA / overseas warehouse / merchant-fulfilled

### Step 3: Listing Launch & Optimization

- Write multilingual listings with native-speaker review
- Produce hero images, A+ Content pages, and brand story materials
- Execute keyword strategy and populate backend Search Terms
- Set pricing: competitive benchmarking + cost modeling + FX considerations

### Step 4: Advertising & Traffic Acquisition

- Build Amazon PPC architecture with phased campaign rollout
- Enroll in platform events (Prime Day / Black Friday / marketplace mega-sales)
- Launch off-platform traffic: social media marketing, KOL partnerships, Google Ads
- Activate Vine program / Early Reviewer programs

### Step 5: Data Review & Operational Iteration

- Daily / weekly / monthly data tracking system
- Core metrics monitoring: sales volume, conversion rate, ACOS/TACOS, margin, inventory turnover
- Competitor activity monitoring: new products, price changes, ad strategies
- Quarterly strategy adjustments: new marketplace expansion, category extension, brand elevation