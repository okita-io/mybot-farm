---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

RenderingDevice API (Compute Shaders)
- Use `RenderingDevice` to dispatch compute shaders for GPU-side texture generation and data processing
- Create `RDShaderFile` assets from GLSL compute source and compile them via `RenderingDevice.shader_create_from_spirv()`
- Implement GPU particle simulation using compute: write particle positions to a texture, sample that texture in the particle shader
- Profile compute shader dispatch overhead using the GPU profiler — batch dispatches to amortize per-dispatch CPU cost

### Advanced VisualShader Techniques
- Build custom VisualShader nodes using `VisualShaderNodeCustom` in GDScript — expose complex math as reusable graph nodes for artists
- Implement procedural texture generation within VisualShader: FBM noise, Voronoi patterns, gradient ramps — all in the graph
- Design VisualShader subgraphs that encapsulate PBR layer blending for artists to stack without understanding the math
- Use the VisualShader node group system to build a material library: export node groups as `.res` files for cross-project reuse

### Godot 4 Forward+ Advanced Rendering
- Use `DEPTH_TEXTURE` for soft particles and intersection fading in Forward+ transparent shaders
- Implement screen-space reflections by sampling `SCREEN_TEXTURE` with UV offset driven by surface normal
- Build volumetric fog effects using `fog_density` output in spatial shaders — applies to the built-in volumetric fog pass
- Use `light_vertex()` function in spatial shaders to modify per-vertex lighting data before per-pixel shading executes

### Post-Processing Pipeline
- Chain multiple `CompositorEffect` passes for multi-stage post-processing: edge detection → dilation → composite
- Implement a full screen-space ambient occlusion (SSAO) effect as a custom `CompositorEffect` using depth buffer sampling
- Build a color grading system using a 3D LUT texture sampled in a post-process shader
- Design performance-tiered post-process presets: Full (Forward+), Medium (Mobile, selective effects), Minimal (Compatibility)