---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Parameter Intake Table
Always present collected params before execution:

| Param | Required | Example |
|---|---|---|
| `topic` or `source_file` | ✅ | "YOLO11 Edge Deployment" or `article.md` |
| `target_platforms` | ✅ | `zhihu,csdn,bilibili` or "auto-decide" |
| `cover_image` | optional | `cover.png` |
| `tags` | optional | `AI,Python,EdgeAI` |
| `category` | optional (CSDN/B站专栏) | `AI` |
| `is_original` | ✅ | `true / false (translation/repost)` |

### Tool Invocation Templates

**Main channel (Wechatsync)**:
```bash
wechatsync auth                                                # check auth
wechatsync sync article.md -p zhihu,csdn,bilibili --cover cover.png
wechatsync extract -o article.md                                # from current browser tab
```

**小红书 fallback (xhs-mcp)**:
```bash
xiaohongshu-mcp -headless=false &  # start daemon
curl -X POST http://localhost:18060/api/v1/publish \
  -H 'Content-Type: application/json' \
  -d '{"title":"≤20 chars","content":"...","images":["/abs/img.jpg"],"tags":["..."],"is_original":true}'
```

**B 站 video (biliup)**:
```bash
biliup login                                                    # one-time scan
biliup upload --title "..." --tag "AI,Python" --tid 171 \
              --cover cover.jpg --copyright 1 video.mp4
```

**B 站 dynamic / programmatic article (bilibili-api-python)**:
```python
from bilibili_api import article, dynamic, Credential
credential = Credential(sessdata="...", bili_jct="...", buvid3="...")
# Cookies from F12 → Application → Cookies → bilibili.com
```

### Status Report Template
After execution, return a results table:

| Platform | Status | Draft URL | Notes |
|---|---|---|---|
| 知乎 | ✅ | https://zhuanlan.zhihu.com/... | adapted by @zhihu-strategist |
| CSDN | ✅ | https://mp.csdn.net/... | category=AI, tags=Python,YOLO |
| B站专栏 | ⚠️ | (cookie expired, see below) | suggest re-login |
| 小红书 | ✅ | https://creator.xiaohongshu.com/... | via xhs-mcp fallback |