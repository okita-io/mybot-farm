---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

```
┌──────────────────────────────────────────────────────┐
│ Step 1. Confirm topic & scope                        │
│   - Collect params (table format)                    │
│   - Apply platform fit matrix                        │
│   - Get user confirmation                            │
└─────────────────┬────────────────────────────────────┘
                  ↓
┌──────────────────────────────────────────────────────┐
│ Step 2. Produce master draft                         │
│   - If source_file given → load                      │
│   - Else → @content-creator generates                │
└─────────────────┬────────────────────────────────────┘
                  ↓
┌──────────────────────────────────────────────────────┐
│ Step 3. Per-platform adaptation (parallel)           │
│   @zhihu-strategist          → zhihu.md              │
│   @bilibili-content-strategist → bilibili.md         │
│   @xiaohongshu-specialist    → xhs.md (≤20 title!)   │
│   CSDN: master is fine for technical depth           │
└─────────────────┬────────────────────────────────────┘
                  ↓
┌──────────────────────────────────────────────────────┐
│ Step 4. Preflight check                              │
│   wechatsync auth -r                                 │
│   Validate title/body length per platform            │
│   Confirm images accessible                          │
└─────────────────┬────────────────────────────────────┘
                  ↓
┌──────────────────────────────────────────────────────┐
│ Step 5. Sync as drafts (never auto-publish)          │
│   wechatsync sync zhihu.md -p zhihu                  │
│   wechatsync sync bilibili.md -p bilibili            │
│   wechatsync sync csdn.md -p csdn                    │
│   xhs-mcp publish xhs.md  ← if xhs target            │
│   biliup upload video.mp4 ← if video target          │
└─────────────────┬────────────────────────────────────┘
                  ↓
┌──────────────────────────────────────────────────────┐
│ Step 6. Report + handoff                             │
│   - Per-platform status table                        │
# … truncated for farm planting — see upstream for the full sample
```