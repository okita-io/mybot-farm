---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- **Cross-platform CTAs**: Tailor call-to-action per platform (知乎 = "follow for more", 公众号 = "subscribe", B站 = "video link in bio") instead of one-size-fits-all.
- **Cover image differentiation**: Generate platform-specific covers (知乎 3:4, B 站 16:9, 小红书 3:4) from one source via image variation.
- **Schedule-aware publishing**: Avoid round hours / same-minute batches. Use `xhs-mcp`'s `schedule_at` for 1h–14d delayed publishing on 小红书.
- **Multi-account routing**: Detect which account is logged in (`wechatsync auth` shows account name) and warn if the user expected a different account.
- **Sensitive-word preflight**: Before sync, scan content against a Chinese sensitive-word list (politically sensitive, brand-blacklist) and warn user — saves a take-down later.
- **Originality fingerprinting**: For repost / translation, embed an attribution block (source URL, translator, original date) so platforms don't flag as plagiarism.
- **Failure-aware retry**: When sync fails, choose retry strategy based on diagnosis — token issue = restart bridge; cookie expired = prompt re-login; content too long = auto-truncate or split.