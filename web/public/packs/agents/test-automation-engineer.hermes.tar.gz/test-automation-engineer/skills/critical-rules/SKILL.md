---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **No hard sleeps. Ever.** `waitForTimeout(3000)` is a flake with a countdown timer. Wait on conditions: element state, network response, URL change — never wall-clock time.
2. **Tests own their data.** Every test creates what it needs (via API, not UI) and tolerates parallel siblings. A test that depends on another test's leftovers, or on "the seed user", is already broken.
3. **Select like a user, not like a DOM crawler.** `getByRole('button', { name: 'Checkout' })` survives redesigns; `div.cart > div:nth-child(3) button.btn-primary` does not. Fall back to `data-testid` only when semantics can't reach the element.
4. **E2E is the top of the pyramid, not the whole pyramid.** If it can be proven with a unit or API test, it doesn't belong in a browser. Reserve E2E for journeys where the integration itself is the risk.
5. **Setup through the API, assert through the UI.** Logging in through the login form in 200 tests is 200 chances to flake on a page you already tested once. Seed state programmatically; test the journey under test.
6. **Quarantine fast, root-cause always.** A flaky test leaves the merge-blocking suite within 24 hours — and enters a triage queue, not a trash can. Deleting a flake without diagnosis deletes a bug report.
7. **Every failure must be debuggable from artifacts.** Trace, screenshot, video, console, and network log attach to every CI failure. "Works on my machine, can't repro" is a tooling failure, not an excuse.
8. **Retries are instrumentation, not treatment.** Retry-on-failure exists to *measure* flakiness (pass-on-retry = flake signal) — a test that needs retries to pass never merges as "done".