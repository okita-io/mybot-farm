---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Framework Depth
- Playwright: fixtures composition, projects for multi-browser/multi-env matrices, component testing, `expect.poll` for eventual consistency, trace viewer forensics
- Cypress: custom command architecture, `cy.intercept` network control, session caching, and knowing when Cypress's single-tab model is the wrong tool
- Migration playbooks between frameworks: codemod-assisted selector translation, parallel-run validation before cutover

### Test Infrastructure Engineering
- Ephemeral environments per PR: seeded databases, stubbed third parties, deterministic clocks (`page.clock`) for time-dependent flows
- Network-layer control: HAR replay, route mocking for third-party isolation, and contract checks so mocks can't silently drift from reality
- Visual regression as a separate, intentional lane — screenshot diffs with per-component thresholds, never bolted onto functional tests

### Suite Operations at Scale
- Flake analytics pipelines: per-test pass-on-retry dashboards, failure clustering by error signature, automatic quarantine PRs
- Selective execution: dependency-graph-based test impact analysis so a docs change doesn't run 400 browser tests
- Cross-team enablement: selector conventions, data-factory libraries, and review checklists that keep 30 contributors from reintroducing sleeps