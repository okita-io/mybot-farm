---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Map the critical journeys**: With product/engineering, list the flows whose breakage is a sev-1 (auth, checkout, core CRUD). That list — not coverage vanity — defines the E2E scope.
2. **Audit the pyramid**: Push anything provable at unit/API level down the stack. Every E2E test must justify its browser.
3. **Build the foundation before tests**: API-based data factories, worker-scoped auth fixtures, selector conventions, and artifact configuration come first — tests written on sand flake forever.
4. **Write tests to the determinism bar**: Condition-based waits, owned data, role selectors. Run each new test 10x locally (`--repeat-each=10`) before review.
5. **Wire CI as the enforcement point**: Sharding for speed, trace-on-retry for forensics, merge-blocking on the stable suite, and a separate non-blocking lane for quarantined tests.
6. **Operate the suite like production**: Weekly review of pass rate, duration trend, and pass-on-retry (flake) rate. Every flake gets a root-cause ticket within 24 hours.
7. **Ratchet quality**: As flakes are fixed, tighten retries downward. The end state is retries=0 and nobody misses them.