---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Deterministic Playwright Test (No Sleeps, API Setup, Role Selectors)

```typescript
import { test, expect } from './fixtures';

test('customer can complete checkout', async ({ page, api }) => {
  // Setup through the API — fast, deterministic, parallel-safe
  const user = await api.createUser({ plan: 'free' });
  const product = await api.createProduct({ name: 'Widget', priceCents: 4999 });
  await page.context().addCookies(await api.sessionCookiesFor(user));

  await page.goto(`/products/${product.slug}`);

  // Role-based selectors survive redesigns; auto-waiting assertions replace sleeps
  await page.getByRole('button', { name: 'Add to cart' }).click();
  await page.getByRole('link', { name: 'Checkout' }).click();

  // Wait on the network response that matters, not on time
  const orderResponse = page.waitForResponse(
    (r) => r.url().includes('/api/orders') && r.status() === 201
  );
  await page.getByRole('button', { name: 'Place order' }).click();
  await orderResponse;

  // Web-first assertion: retries until true or timeout — no manual polling
  await expect(page.getByRole('heading', { name: 'Order confirmed' })).toBeVisible();
  await expect(page.getByTestId('order-total')).toHaveText('$49.99');
});
```

### Worker-Scoped Auth Fixture (Log In Once, Not 200 Times)

```typescript
// fixtures.ts — authentication happens once per worker, via API, then is reused
import { test as base } from '@playwright/test';
import { ApiClient } from './api-client';

export const test = base.extend<{ api: ApiClient }, { workerStorageState: string }>({
  api: async ({}, use) => {
    await use(new ApiClient(process.env.API_URL!));
  },
  workerStorageState: [
    async ({}, use, workerInfo) => {
      const fileName = `.auth/worker-${workerInfo.workerIndex}.json`;
      const api = new ApiClient(process.env.API_URL!);
      // Unique user per worker: parallel runs never share state
      const user = await api.createUser({ email: `w${workerInfo.workerIndex}@test.local` });
      await api.saveStorageState(user, fileName);
      await use(fileName);
    },
    { scope: 'worker' },
  ],
  storageState: ({ workerStorageState }, use) => use(workerStorageState),
});
```

### CI: Sharded, Traced, Merge-Blocking (GitHub Actions)

```yaml
jobs:
  e2e:
    strategy:
      fail-fast: false
      matrix:
        shard: [1/4, 2/4, 3/4, 4/4]
    steps:
      - uses: actions/checkout@v4
      - run: npm ci && npx playwright install --with-deps chromium
      - run: npx playwright test --shard=${{ matrix.shard }}
        env:
          # trace on first retry: zero overhead on green runs, full forensics on red
          PLAYWRIGHT_TRACE: on-first-retry
      - uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: traces-${{ strategy.job-index }}
          path: test-results/          # traces, screenshots, videos per failure
```

### Flake Triage Table

| Symptom | Likely root cause | The fix (not the workaround) |
|---------|-------------------|------------------------------|
| Passes locally, fails in CI | Timing: CI is slower, race exposed | Replace time-based waits with condition-based; audit for `waitForTimeout` |
| Fails only in parallel runs | Shared state: same user/record across tests | Per-test or per-worker data via API factories |
| Fails ~1 in 20 with element-not-found | Animation/render race, unstable selector | Web-first assertion on final state; role/test-id selector |
| Fails after "unrelated" merge | Hidden coupling to app-level fixture/seed data | Make the test own its data; delete the shared seed dependency |
| Timeout on navigation | Third-party script/analytics blocking load | Block third-party routes in test config; wait on app-ready signal, not `load` |