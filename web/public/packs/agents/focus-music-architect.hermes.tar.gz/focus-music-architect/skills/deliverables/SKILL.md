---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

1. The 7-Genre Focus Prompt Matrix

```markdown
### ☕ Genre 1: Lo-Fi Study Beats / Chillhop (75 BPM)
* **Prompt (Suno v3.5/v4 / Udio)**:
  `[Instrumental] Relaxed 75 bpm lo-fi hip hop, dusty vinyl crackle, warm rhodes electric piano chords, mellow upright bassline, gentle boom-bap drum groove, subtle tape flutter, cozy rainy evening coffee shop ambiance, study beats, no vocals, seamless loop`
* **Negative Prompt**: `vocals, singing, voice, speech, chorus, sharp treble, distorted bass`

### 🎹 Genre 2: Neo-Classical Minimalist / Felt Piano (65 BPM)
* **Prompt**:
  `[Instrumental] Intimate neo-classical minimalist felt piano, warm acoustic dampening, gentle expressive cello and violin quartet, spacious ambient room reverb, delicate cyclical arpeggios, emotionally grounding, contemplative, no drums, no percussion, no vocals, 65 bpm`
* **Negative Prompt**: `vocals, drums, percussion, electronic synths, harsh highs`

### 🌌 Genre 3: Warm Ambient & Space Drone (Continuous Flow)
* **Prompt**:
  `[Instrumental] Deep atmospheric space ambient drone, lush warm analog synthesizer pads, evolving harmonic textures, endless shimmer reverb, hypnotic slow progression, zero percussion, calming, peaceful meditation, no drums, no vocals`
* **Negative Prompt**: `vocals, rhythm, drums, fast tempo, harsh attacks`

### 🕹️ Genre 4: Chillsynth & Retrowave Coding Trance (95 BPM)
* **Prompt**:
  `[Instrumental] Melodic chillsynth, ambient retrowave, hypnotic 16th-note analog arpeggiator, warm driving saw bassline, clean tape-delayed electric guitar plucks, nostalgic 80s synthesizers, steady 95 bpm focus groove, programming flow state, no vocals`
* **Negative Prompt**: `vocals, aggressive leads, heavy distortion, dramatic drops`

### ⚡ Genre 5: Minimal Organic House / Deep Flow (120 BPM)
* **Prompt**:
  `[Instrumental] Deep minimal organic house, hypnotic sub bass pulse, soft muted four-on-the-floor kick, subtle wooden percussions, warm organic chords, gentle atmospheric pads, 120 bpm steady velocity, immersive coding trance, no vocals`
* **Negative Prompt**: `vocals, vocal chops, aggressive build-ups, EDM drops, harsh snare`

### 🎸 Genre 6: Ambient Post-Rock & Atmospheric Guitars (80 BPM)
* **Prompt**:
  `[Instrumental] Atmospheric post-rock, melodic clean electric guitars, volume swells, heavy tape delay and cavernous reverb, warm bass, soft downtempo drums, expansive cinematic crescendo without harsh distortion, inspiring, no vocals, 80 bpm`
* **Negative Prompt**: `vocals, metal guitar, aggressive screaming, fast tempos`

### 🧠 Genre 7: Neuroacoustic Alpha Waves & Brown Noise (10 Hz)
* **Prompt**:
  `[Instrumental] Pure deep brownian noise blended with 10Hz alpha wave binaural frequency, soothing rain on window textures, soft warm sub-bass hum, ultra-deep concentration soundscape, steady non-fatiguing mask for cognitive fatigue, zero percussion, no vocals`
* **Negative Prompt**: `vocals, music melodies, harsh white noise, abrupt shifts`
```

---

### 2. Audio DSP & Web Audio API Neuroacoustic Recipe

When designing real-time audio engines (e.g. Web Audio API), enforce exact DSP specifications:

```javascript
// Web Audio API: 10 Hz Binaural Beat Generator (Alpha Wave Inducer)
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

// Left Ear: 200 Hz Carrier
const oscLeft = audioCtx.createOscillator();
const panLeft = audioCtx.createStereoPanner();
oscLeft.frequency.value = 200.0;
panLeft.pan.value = -1.0;

// Right Ear: 210 Hz Carrier (210 - 200 = 10 Hz Alpha Modulation)
const oscRight = audioCtx.createOscillator();
const panRight = audioCtx.createStereoPanner();
oscRight.frequency.value = 210.0;
panRight.pan.value = 1.0;

// Connect & Start
oscLeft.connect(panLeft).connect(audioCtx.destination);
oscRight.connect(panRight).connect(audioCtx.destination);
```

---