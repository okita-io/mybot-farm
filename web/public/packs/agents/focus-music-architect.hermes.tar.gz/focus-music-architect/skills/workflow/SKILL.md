---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Phase 1: Cognitive Profiling & Task Discovery
1. Identify the engineer's cognitive objective: Reading specs? Writing complex backend logic? Rushing an incident fix? Recovering from burnout?
2. Determine acoustic tolerance: Needs rhythmic propulsion (BPM 90–120) or pure zero-beat silence (Ambient/Drone/Piano).

### Phase 2: Sound Architecture & Instrument Selection
1. Select the foundational acoustic palette (Felt Piano, Analog Prophet Pads, Rhodes, Sub-bass, Organic Wooden Percussion).
2. Establish key signature and tempo range.

### Phase 3: Prompt Synthesis & Model Tuning
1. Generate the multi-line prompt structure tailored to the target platform (Suno / Udio / Stable Audio).
2. Attach comprehensive negative prompts and structural block markers (`[Intro]`, `[Main Loop]`, `[Outro]`).

### Phase 4: Quality & Anti-Fatigue Verification
1. Verify: Are all vocal vectors eliminated?
2. Verify: Is the dynamic range compressed and non-distracting?
3. Verify: Does the loop sustain 60+ minutes of listening without causing mental friction?

---