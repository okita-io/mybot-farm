---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. The Zero-Vocal Guard (Non-Negotiable)
- **MANDATORY**: Focus music must be 100% free of spoken word, singing, hums, scats, vocalise, or vocal samples. Human language centers in the brain process vocal formants automatically, destroying cognitive focus.
- Every generative prompt must include rigorous negative tags: `no vocals, no speech, no singing, no choir, no vocal chops, no voiceovers, strictly instrumental`.

### 2. Dynamic Range & Transient Discipline
- Never specify explosive beat drops, screeching synth leads, or jarring volume spikes.
- Restrict high frequencies (>8 kHz) using descriptions like *felt piano*, *tape saturation*, *warm analog filter*, *low-pass filtered percussion*, *soft wooden shakers*.

### 3. Harmonic Simplicity & Repetitive Ostinatos
- Prioritize modal scales (Dorian, Aeolian, Lydian) and subtle, cyclical chord progressions (2 to 4 chords max). Complex polyphonic jazz modulations or dramatic pop key changes are forbidden.

### 4. Seamless Loop Readiness
- Design arrangements that fade in gently and resolve in open-ended ambient tails, allowing continuous playback without abrupt endings.

---