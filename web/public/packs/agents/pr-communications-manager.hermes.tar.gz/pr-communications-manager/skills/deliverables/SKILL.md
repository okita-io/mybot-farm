---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Press Release Framework

```
PRESS RELEASE STRUCTURE
───────────────────────────────────────
FOR IMMEDIATE RELEASE                          [or: EMBARGOED UNTIL: Date/Time ET]

[HEADLINE — active voice, newsworth angle, under 10 words]
[SUBHEADLINE — one sentence that adds context or a key data point]

[CITY, Date] — [Lead paragraph: the news, why it matters, who it affects —
answer who, what, when, where, why in the first 50 words]

[Body paragraph 1: Context and significance — why now, why this matters
to the industry or audience]

[Body paragraph 2: Executive quote — attributed to CEO or relevant leader.
Should add perspective, not just repeat the lead. Human voice, not corporate speak.]

[Body paragraph 3: Supporting detail — product specifics, partnership terms,
market context, data points]

[Body paragraph 4: Secondary quote — partner, customer, or analyst if available]

[Body paragraph 5: Forward-looking statement or availability/next steps]

About [Company]:
[2-3 sentence boilerplate — who you are, what you do, notable stats or recognition]

Media Contact:
[Name] | [Title]
[Email] | [Phone]
[Website]

###

Headline principles:
✅ Active voice: "Company Launches X" not "X is Launched by Company"
✅ Lead with the news value, not the company name
✅ Avoid jargon — write for a general business reader
✅ Numbers and specifics beat vague claims ("raises $40M" beats "raises significant funding")
❌ Never use superlatives ("world's first," "revolutionary") without proof
❌ Never bury the news below the fold
```

### Media Pitch Framework

```
MEDIA PITCH STRUCTURE
───────────────────────────────────────
Subject line:
  - Under 8 words
  - Lead with the story angle, not the company name
  - Specific, not generic
  Examples:
    "Why enterprise AI deployments keep failing — one company's fix"
    "New data: remote workers are more productive (but lonelier)"
    "Exclusive: [Company] raises $X to solve [specific problem]"

Pitch body (under 200 words):

Para 1 — THE HOOK (why this journalist, why now)
  "I've been following your coverage of [topic] — particularly your
  piece on [specific article]. I have a story angle I think fits
  your beat."

Para 2 — THE STORY (the news or idea, not the company)
  Lead with the trend, the data, the insight, or the conflict.
  The company is supporting evidence — not the story itself.

Para 3 — THE OFFER (what you're giving them)
  - Exclusive vs. embargo vs. open
  - Access to CEO/spokesperson
  - Data, research, or case study available
  - Customer reference available for interview

Para 4 — THE ASK (one specific, low-friction ask)
  "Would a 15-minute briefing this week work? Happy to
  share the full research deck in advance."

Sign-off:
  [Name] | [Title] | [Company]
  [Phone] — available for quick calls

Pitch rules:
✅ One story angle per pitch — never pitch multiple ideas at once
✅ Personalize the first paragraph every time — no templates visible
✅ Follow up once, 3-5 business days later — then move on
# … truncated for farm planting — see upstream for the full sample
```

### Crisis Communications Framework

```
CRISIS RESPONSE PROTOCOL
───────────────────────────────────────
FIRST 30 MINUTES — ASSESS & HOLD
  1. Gather facts: What happened? What do we know vs. not know?
  2. Assess severity: Local / industry / national / viral?
  3. Identify affected stakeholders: Customers? Employees? Partners? Public?
  4. Issue holding statement immediately (see template below)
  5. Convene crisis team: CEO, Legal, Communications, relevant ops leads
  6. Establish single spokesperson — no one else speaks to press

HOLDING STATEMENT TEMPLATE:
  "We are aware of [situation] and are taking it seriously. Our team
  is actively investigating and working to [resolve/understand] the
  situation. We will share a full update by [specific time]. The
  safety and [trust/wellbeing] of [customers/employees/partners] is
  our top priority."

  Rules for holding statements:
  ✅ Acknowledge the situation — never deny what's visible
  ✅ Show you're taking action
  ✅ Give a specific time for next update — and honor it
  ❌ Never speculate on cause or assign blame before facts are confirmed
  ❌ Never use "no comment"
  ❌ Never minimize: "this is a minor issue" always backfires

FIRST 2 HOURS — RESPOND & CONTROL
  1. Draft full response statement with Legal review
  2. Identify and brief all internal stakeholders before going external
  3. Prepare FAQ document for customer-facing teams…