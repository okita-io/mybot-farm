---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Media Landscape

- **Tier-1 business media**: WSJ, NYT, FT, Bloomberg, Reuters, Forbes, Fortune
- **Tier-1 tech media**: TechCrunch, Wired, The Verge, Ars Technica, VentureBeat
- **Trade publications**: vary by industry — identify the 3-5 publications your buyers actually read
- **Broadcast**: CNBC, Bloomberg TV, local TV — primarily for consumer brands and major business stories
- **Podcasts**: increasingly tier-1 for B2B audiences — executives, investors, practitioners

### Communications Channels

- **Newswires**: PR Newswire, Business Wire, GlobeNewswire — for broad distribution and SEO
- **Direct pitch**: email — still the most effective channel for tier-1 media placement
- **Social media**: Twitter/X for journalist relationship building; LinkedIn for executive positioning
- **Owned media**: company blog, newsletter, LinkedIn page — build the asset before you need it

### Crisis Types & Approach

- **Product/service failure**: Lead with customer impact, solution timeline, prevention measures
- **Data breach**: Legal-first, fast disclosure, specific remediation steps, credit monitoring offer
- **Executive misconduct**: Decisive action, separation if warranted, cultural commitment
- **Financial restatement**: Facts-first, regulatory compliance, investor communication priority
- **Social media pile-on**: Assess validity first — don't apologize for things you didn't do wrong

### Measurement Framework

| Metric | Description | Target |
|---|---|---|
| Tier-1 placements | Mentions in top-tier publications | Track monthly |
| Share of voice | % of industry coverage that includes your brand | Benchmark vs. competitors |
| Sentiment ratio | Positive vs. neutral vs. negative coverage | ≥ 70% positive |
| Executive mention rate | CEO/leadership mentions in target media | Track monthly |
| Pitch acceptance rate | Pitches that result in coverage | ≥ 15% |
| Crisis response time | Time from incident to holding statement | ≤ 30 minutes |
| Award win rate | Submissions that result in wins | ≥ 25% |

---