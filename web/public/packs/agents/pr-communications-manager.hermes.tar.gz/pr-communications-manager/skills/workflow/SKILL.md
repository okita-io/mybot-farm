---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Message Architecture

1. **Define the core narrative** — what is the overarching story the organization is telling this year?
2. **Identify key messages** — 3 messages maximum per initiative or campaign
3. **Map stakeholder audiences** — media, employees, investors, customers, partners, regulators
4. **Tailor messages by audience** — same core truth, different framing for each audience
5. **Build the proof points** — data, customer stories, and third-party validation for each message

### Step 2: Proactive Media Relations

1. **Map the media landscape** — identify tier-1, tier-2, and trade publications relevant to the beat
2. **Research target journalists** — read their work, understand their angles, identify fit
3. **Build the relationship before the pitch** — engage on social, provide background, be a resource
4. **Pitch the story, not the company** — journalists cover trends, conflicts, data, and people
5. **Follow up once** — then move on; never harass a journalist

### Step 3: Announcement Management

1. **Draft the press release** — news first, context second, quotes third
2. **Secure internal approvals** — Legal, executive team, relevant stakeholders
3. **Identify embargo vs. exclusive vs. open pitch strategy**
4. **Brief employees before external release**
5. **Distribute via newswire + direct journalist outreach simultaneously**
6. **Monitor coverage and respond to follow-up inquiries within the hour**

### Step 4: Crisis Response

1. **Assess and hold** — gather facts, issue holding statement, convene crisis team
2. **Establish single spokesperson** — no freelancing from executives or employees
3. **Draft and approve full response** — with Legal, under time pressure
4. **Brief internal stakeholders before external** — employees, board, key customers
5. **Monitor in real time** — media, social, analyst community
6. **Update on committed cadence** — communicate proactively even when the news isn't good

### Step 5: Measurement & Reporting

1. **Track tier-1 placements** — publications that matter to the target audience
2. **Measure share of voice** — how often is the company mentioned vs. competitors?
3. **Monitor sentiment** — positive, neutral, negative across media and social
4. **Track executive mentions** — thought leadership traction in target publications
5. **Report monthly** — what ran, what it reached, what it moved

---