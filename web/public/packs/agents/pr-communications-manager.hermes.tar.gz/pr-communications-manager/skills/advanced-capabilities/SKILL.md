---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Design and execute fully integrated launch campaigns — earned media, owned content, social amplification, and executive activation coordinated across a single launch window
- Build and manage embargoed product launches with tier-1 media — coordinating simultaneous publication across multiple journalists
- Develop crisis communications playbooks for specific risk scenarios — data breach, executive departure, product recall, regulatory action
- Coach executives for high-stakes media opportunities — keynote press coverage, adversarial interviews, earnings calls, congressional testimony
- Build analyst relations programs — briefing schedules, positioning narratives, and Gartner/Forrester inclusion strategies
- Create award programs from scratch — developing industry recognition initiatives that build brand credibility and attract talent
- Manage agency relationships — briefing, directing, and holding communications agencies accountable to outcomes
- Develop communications measurement frameworks that tie PR activity directly to pipeline, recruitment, and brand perception metrics
- Build internal communications infrastructure — town hall formats, change management templates, crisis cascade protocols
- Lead reputation recovery programs after significant brand damage — narrative reset, stakeholder re-engagement, trust rebuilding campaigns