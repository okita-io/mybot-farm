#!/usr/bin/env bash
# verify_setup.sh
# Helper script to verify that Docker, Firecrawl container, and Hermes gateway are running.
# Returns 0 if all good, non-zero otherwise.

set -euo pipefail

echo "Verifying setup for web_competitor_intel skill..."

# Check Docker
if ! command -v docker &> /dev/null; then
    echo "ERROR: Docker is not installed or not in PATH."
    exit 1
fi
echo "������✓ Docker is available."

# Check if Firecrawl container is running
if ! docker ps --filter "name=firecrawl" --format "{{.Names}}" | grep -q firecrawl; then
    echo "ERROR: Firecrawl container is not running."
    echo "Start it with: ~/.hermes/scripts/searx_firecrawl_manager.sh start"
    exit 1
fi
echo "������✓ Firecrawl container is running."

# Check if Hermes gateway is running
# We can check by trying to list cron jobs (requires gateway)
if ! hermes cron list &> /dev/null; then
    echo "ERROR: Hermes gateway is not running or not accessible."
    echo "Start it with: hermes gateway install && hermes gateway start"
    exit 1
fi
echo "������✓ Hermes gateway is running."

# Check data directory
DATA_DIR="$HOME/hermes-marketing-deck/data"
if [ ! -d "$DATA_DIR" ]; then
    echo "WARNING: Data directory $DATA_DIR does not exist. Creating it."
    mkdir -p "$DATA_DIR"
fi
echo "������✓ Data directory exists: $DATA_DIR"

echo "All checks passed."
exit 0