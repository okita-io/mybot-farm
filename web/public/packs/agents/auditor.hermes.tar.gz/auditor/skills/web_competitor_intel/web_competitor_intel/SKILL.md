---
name: web_competitor_intel
description: Automated competitor intel via Firecrawl and Hermes cron.
version: 1.0.0
author: [hermes-agent]
license: MIT
platforms: [linux, macos, windows]
prerequisites:
  commands: [docker, hermes]
setup:
  help: "Ensure Docker is installed and the Firecrawl container is running (see searx_firecrawl_manager.sh)."
metadata:
  hermes:
    tags: [web-scraping, competitor-intel, cron, firecrawl, automation]
    category: productivity
---

# Web Competitor Intelligence Skill

Automate regular collection of competitor intelligence from websites using Firecrawl and Hermes cron jobs. This skill encapsulates the pattern of scheduling periodic scrapes, storing structured results, and making them available for downstream analysis (e.g., content generation, campaign adjustments).

## When to Use

- You need to monitor competitors’ websites for new projects, case studies, pricing, or news.
- You want a lightweight, repeatable process that runs without manual intervention.
- You plan to use the scraped data to inform marketing content, sales enablement, or product strategy.

## How It Works

1. **Prepare the Firecrawl service** – Run the Firecrawl MCP server locally via Docker (or use a hosted Firecrawl API).  
   See the `searx_firecrawl_manager.sh` script in `~/.hermes/scripts/` for a simple start/stop wrapper.

2. **Ensure the Hermes gateway is running** – Cron jobs require the gateway to fire automatically.  
   ```bash
   hermes gateway install   # if not already installed
   hermes gateway start     # or rely on auto‑start if configured as a service
   ```

3. **Create a cron job** – Use `hermes cron create` with a schedule (e.g., every 6 hours) and a prompt that invokes Firecrawl via a delegate_task or directly via terminal.

4. **Store results** – Save each scrape’s output as a timestamped JSON file in a dedicated directory (e.g., `~/hermes-marketing-deck/data/`).  
   Include metadata such as scrape timestamp, source URL, and any extracted fields.

5. **Consume the data** – Later workflows (e.g., content‑generation sub‑agents, Obsidian notes, or performance‑review scripts) can read the JSON files to extract insights.

## Example: Scraping Three Sites Every 6 Hours

```bash
hermes cron create \
  --name "competitor_intel_every_6h" \
  --schedule "every 6h" \
  --prompt "Use Firecrawl to scrape competitor sites for latest projects and news. Sites: https://tactic.studio, https://www.unity.com, https://www.unrealengine.com. For each, extract main content and any visible project titles or case studies. Save combined results as JSON with timestamp to ~/hermes-marketing-deck/data/competitor_intel_$(date +%Y%m%d_%H%M%S).json. Ensure directory exists." \
  --deliver origin
```

This creates a job named `competitor_intel_every_6h` that runs every six hours, sends the result to the current chat (origin), and relies on the `delegate_task` skill to execute the Firecrawl command (via the terminal tool inside the delegate_task context).

## Pitfalls & Troubleshooting

- **Gateway not running** – If you see “Gateway is not running — jobs won't fire automatically.” in the cron create output, start the gateway with `hermes gateway install` and `hermes gateway start`.  
- **Firecrawl container not reachable** – Verify the Docker container is up with `docker ps`. Use the helper script:  
  `~/.hermes/scripts/searx_firecrawl_manager.sh start`  
  and check that port 3002 (or whatever you mapped) is responding.  
- **Directory missing** – The prompt includes “Ensure directory exists.” but you can also pre‑create it:  
  `mkdir -p ~/hermes-marketing-deck/data`  
- **Firecrawl API changes** – If the scrape endpoint or payload format changes, update the prompt accordingly. Check the Firecrawl documentation at https://docs.firecrawl.dev.  
- **Rate limiting / blocking** – Some sites may block scrapers. Adjust the Firecrawl parameters (e.g., use a longer timeout, enable JavaScript rendering) or add delays between requests.  
- **JSON parsing errors** – Ensure the saved file is valid JSON; you can validate with `jq . <file>` or a quick Python check.

## Reference Files

- `references/firecrawl_scrape_example.md` – Example curl command and expected JSON structure for a Firecrawl v2 scrape request.
- `templates/cron_competitor_intel.template` – A fill‑in‑the‑blank template for the `hermes cron create` command.

## Related Skills

- `comfyui` – For generating images from the scraped intel (e.g., turning project summaries into marketing visuals).
- `note-taking/obsidian` – Store swipe files, notes, and summaries of competitor intel in your `~/hermes` vault.
- `delegate_task` – Used under the hood to run terminal commands (like the Firecrawl scrape) in an isolated context.
- `cronjob` – The underlying Hermes tool that powers the scheduling (exposed via `hermes cron`).

## Version History

- **1.0.0** – Initial capture of the pattern for automated competitor intel collection using Firecrawl and Hermes cron.

---