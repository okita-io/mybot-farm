# Example Firecrawl v2 Scrape Request

## Endpoint
POST http://localhost:3002/v2/scrape

## Headers
Content-Type: application/json

## Payload (JSON)
{
  "url": "https://tactic.studio",
  "formats": ["markdown", "html"],
  "onlyMainContent": true,
  "waitFor": 2000
}

## Example Response (trimmed)
{
  "success": true,
  "data": {
    "content": "# Immersive • XR • Spatial • AI\\n\\n[TACTIC](https://tactic.studio/)\\n\\nWe turn larger-than-life ideas into transcendent experiences.\\n\\n...",
    "markdown": "Immersive • XR • Spatial • AI\\n\\n[TACTIC](https://tactic.studio/)\\n\\nWe turn larger-than-life ideas into transcendent experiences.\\n\\n...",
    "linksOnPage": [
      "https://tactic.studio/",
      "https://tactic.studio/about",
      "https://tactic.studio/team",
      "https://www.instagram.com/tactic_studio/",
      "https://www.linkedin.com/company/tactic/posts/?feedView=all"
    ],
    "metadata": {
      "url": "https://tactic.studio",
      "title": "TACTIC — Work",
      "description": "Select a Tactic project. Immersive, product-first marketing.",
      "language": "en",
      "viewport": "width=device-width, initial-scale=1, viewport-fit=cover",
      "favicon": "https://tactic.studio/favicon.png",
      "scrapeId": "019ff229-fcae-75ea-bbfe-61fa656bc550",
      "sourceURL": "https://tactic.studio",
      "creditsUsed": 1,
      "statusCode": 200,
      "contentType": "text/html; charset=utf-8"
    }
  },
  "returnCode": 200
}

## Notes
- `onlyMainContent`: true strips boilerplate (navigation, footers) to focus on the article/core content.
- `waitFor`: milliseconds to wait for JS rendering before scraping (adjust for SPA sites).
- The `metadata` field includes useful provenance info (scrapeId, creditsUsed, etc.).
- For bulk scraping of multiple URLs, consider using the `/v2/scrape/batch` endpoint or loop in a delegate_task script.