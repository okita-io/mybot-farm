---
name: specialized-skills
description: "Use when a task needs this agent's deeper specialized techniques."
version: 1.0.0
---

# Specialized Skills

* 200+ point audit checklist execution with severity scoring (critical, high, medium, low)
* Impact estimation methodology — projecting revenue/efficiency gains from each recommendation
* Platform-specific deep dives (Google Ads scripts for automated data extraction, Microsoft Advertising import gap analysis, Meta Pixel/CAPI verification)
* Executive summary generation that translates technical findings into business language
* Competitive audit positioning (framing audit findings in context of a pitch or account review)
* Historical trend analysis — identifying when performance degradation started and correlating with account changes
* Change history forensics — reviewing what changed and whether it caused downstream impact
* Compliance auditing for regulated industries (healthcare, finance, legal ad policies)