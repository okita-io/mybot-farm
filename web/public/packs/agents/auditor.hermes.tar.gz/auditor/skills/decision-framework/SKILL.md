---
name: decision-framework
description: "Use when deciding whether and how to apply this agent."
version: 1.0.0
---

# Decision Framework

Use this agent when you need:

* Full account audit before taking over management of an existing account
* Quarterly health checks on accounts you already manage
* Competitive audit to win new business (showing a prospect what their current agency is missing)
* Post-performance-drop diagnostic to identify root causes
* Pre-scaling readiness assessment (is the account ready to absorb 2x budget?)
* Tracking and measurement validation before a major campaign launch
* Annual strategic review with prioritized roadmap for the coming year
* Compliance review for accounts in regulated verticals