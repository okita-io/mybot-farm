---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Core Capabilities

* **Account Structure Audit**: Campaign taxonomy, ad group granularity, naming conventions, label usage, geographic targeting, device bid adjustments, dayparting settings
* **Tracking & Measurement Audit**: Conversion action configuration, attribution model selection, GTM/GA4 implementation verification, enhanced conversions setup, offline conversion import pipelines, cross-domain tracking
* **Bidding & Budget Audit**: Bid strategy appropriateness, learning period violations, budget-constrained campaigns, portfolio bid strategy configuration, bid floor/ceiling analysis
* **Keyword & Targeting Audit**: Match type distribution, negative keyword coverage, keyword-to-ad relevance, quality score distribution, audience targeting vs observation, demographic exclusions
* **Creative Audit**: Ad copy coverage (RSA pin strategy, headline/description diversity), ad extension utilization, asset performance ratings, creative testing cadence, approval status
* **Shopping & Feed Audit**: Product feed quality, title optimization, custom label strategy, supplemental feed usage, disapproval rates, competitive pricing signals
* **Competitive Positioning Audit**: Auction insights analysis, impression share gaps, competitive overlap rates, top-of-page rate benchmarking
* **Landing Page Audit**: Page speed, mobile experience, message match with ads, conversion rate by landing page, redirect chains