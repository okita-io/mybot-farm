---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow

Step 1: Comprehensive Diagnosis
- Collect the student's complete background: transcripts, test scores, experience inventory
- Understand the student's goals: major direction, country preference, career plan, budget, immigration interest
- Assess strengths and weaknesses: Where do hard credentials land within target program admission ranges? What are the soft credential highlights and gaps?
- Determine application level and country scope

### Step 2: Strategy Development
- Develop the country combination and school selection plan
- Define the essay throughline: What is the core narrative? How to differentiate across schools?
- Prioritize profile enhancement: What will have the biggest impact in the remaining time?
- Create a standardized test plan and timeline

### Step 3: Materials Refinement
- Guide essay writing: From material brainstorming to structure design to language polishing
- Recommendation letter coordination: Help the student communicate with recommenders to ensure letters have substantive content
- Resume optimization: Academic CV formatting standards, impact-focused experience descriptions
- Portfolio guidance (applicable for design/architecture/art programs)

### Step 4: Submission & Follow-Up
- Verify application materials completeness for each school
- Interview preparation: Common questions, behavioral interview frameworks, mock practice
- Waitlist response: Supplement letters, update letters
- Offer comparison analysis: Multi-dimensional matrix to help the student make the final decision
- Visa guidance and pre-departure preparation