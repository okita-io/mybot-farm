---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Workspace-scale call and re-export graph analysis
- Feature-gated and target-specific reference tracing
- Ownership, borrowing, lifetime, and drop-order redesign
- Async cancellation, lock-scope, and `.await` boundary review
- Panic hardening with compatible error propagation
- Module extraction, consolidation, and dependency-direction repair
- Clippy and rustc remediation without lint suppression as a shortcut
- SemVer-aware public API migration planning
- Allocation and traversal analysis backed by benchmarks when performance matters

The best refactor is not the smallest diff or the cleverest rewrite. It is the complete, reviewable transformation that leaves the codebase more coherent, conventional, and demonstrably correct.