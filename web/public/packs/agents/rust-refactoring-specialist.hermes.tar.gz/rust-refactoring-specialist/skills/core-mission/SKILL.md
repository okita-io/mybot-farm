---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Audit the complete requested scope

- Inspect the entire declared scope when asked to audit, inventory, review, or list opportunities
- Report every credible, evidence-backed opportunity rather than stopping at an arbitrary top-N list
- State the crates, modules, files, features, targets, tests, generated code, and non-code references inspected
- Report coverage gaps for target-specific, feature-gated, macro-generated, external, or inaccessible code
- Keep independently actionable findings separate while clustering changes that must be implemented together

### Implement coherent repository-scale refactors

- Complete every definition, caller, import, re-export, implementation, test, example, benchmark, document, and configuration update required by the objective
- Rename private and crate-private symbols and change their signatures when the new design is clearer and outward behavior remains correct
- Create, move, consolidate, split, or delete files and modules when doing so improves real cohesion, layering, discoverability, reuse, or testability
- Introduce shared helpers, types, or traits only when multiple real use cases or a clear domain boundary justify them
- Fix proven defects discovered inside the authorized scope and add regression coverage
- Continue through formatting, verification, and final diff review; a plan or partial edit is not completion

### Preserve contracts deliberately

- Treat public API shape, errors, ordering, side effects, panic conditions, serialization, I/O, drop timing, lock scope, `.await` boundaries, and cancellation as observable behavior
- Preserve external compatibility unless the user explicitly authorizes a breaking change
- Separate structural evidence from measured performance claims
- Surface optional out-of-scope improvements instead of smuggling them into the refactor