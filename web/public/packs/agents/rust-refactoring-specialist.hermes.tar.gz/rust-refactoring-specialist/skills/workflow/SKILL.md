---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. Interpret the request

- Classify it as audit, implementation, explanation, or plan
- Establish scope, objective, compatibility expectations, and authorized behavior changes
- Do not ask the user to enumerate every internal symbol required by one coherent implementation

### 2. Inspect constraints and architecture

- Read repository instructions, manifests, toolchain files, formatting and lint configuration, CI, feature definitions, and relevant documentation
- Inspect uncommitted work and never overwrite changes you did not make
- Understand crate and module boundaries before moving code

### 3. Map the affected surface

- Trace definitions, callers, data flow, traits, implementations, tests, re-exports, macros, features, errors, and side effects
- Determine external reachability through visibility and re-exports; `pub` alone does not prove an item is externally reachable
- Use LSP references first, then search macro input, attributes, `include_*` paths, build scripts, snapshots, configuration, CI, string dispatch, serialization names, FFI names, and doctests

### 4. Establish a baseline

- Run the narrowest useful existing tests and checks before editing
- Record pre-existing failures and warnings
- Add characterization tests where behavior is important but underspecified
- Capture a profile or benchmark before performance work

### 5. Design coherent batches

- Group mutually dependent opportunities into complete end states
- Order batches by dependency, risk, and verification cost
- Prefer transformations that simplify later batches
- Keep unrelated cleanup out of the diff

### 6. Implement end-to-end

- Update every required definition, caller, import, re-export, module declaration, test, example, benchmark, document, and configuration reference
- Preserve outward contracts unless change is authorized
- Add regression tests for proven defects
- Leave no duplicate old/new paths, stale migration notes, or commented-out implementations

### 7. Verify the relevant matrix

- Apply configured `rustfmt`
- Run targeted tests before crate or workspace tests
- Run relevant `cargo check`, Clippy, and rustdoc commands
- Derive feature coverage from manifests, `cfg` usage, documentation, and CI rather than blindly assuming `--all-features` is valid
- Check affected target triples and documented MSRV when relevant
- Run `cargo-semver-checks` when a meaningful baseline exists and external API may have changed
- Benchmark before and after when performance is the objective

### 8. Audit the resulting diff

- Confirm the objective is complete across all affected files and references
- Confirm every changed file belongs to the transformation
- Confirm file moves and deletions are represented in module and build configuration
- Confirm no generated output, lockfile, dependency, policy, user work, or unrelated formatting changed accidentally
- Report authorized public or behavior changes and remaining verification gaps