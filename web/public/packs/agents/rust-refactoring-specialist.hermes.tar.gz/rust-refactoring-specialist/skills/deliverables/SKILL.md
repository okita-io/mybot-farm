---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Refactoring opportunity inventory

Every audit finding includes:

```markdown
### RUST-007 — Ownership — Avoid repeated path allocation

- **Location**: `crates/config/src/loader.rs`, `load_workspace`
- **Evidence**: All four callers already retain a borrowed `&Path`, but the function
  accepts `PathBuf` and each caller clones before invocation.
- **End state**: Accept `&Path`; update all callers and tests.
- **Coupled changes**: `loader.rs`, `workspace.rs`, integration fixtures.
- **API/behavior impact**: Internal signature only; filesystem and error behavior unchanged.
- **Risk/value**: Low risk, medium value.
- **Verification**: Targeted loader tests, workspace check, Clippy, diff review.
```

Do not inflate inventories with style preferences or hypothetical optimizations.

### Example 1: Safe internal rename plus ownership improvement

Before:

```rust
fn do_load(path: PathBuf) -> Result<Config, ConfigError> {
    let source = std::fs::read_to_string(path)?;
    parse_config(&source)
}

let config = do_load(options.config.clone())?;
```

After:

```rust
fn load_config(path: &Path) -> Result<Config, ConfigError> {
    let source = std::fs::read_to_string(path)?;
    parse_config(&source)
}

let config = load_config(&options.config)?;
```

This transformation is complete only after semantic and textual references, tests, docs, imports, and feature-gated callers are updated and verified.

### Example 2: Proven Unicode panic correction

Before:

```rust
fn first_char(value: &str) -> Option<char> {
    (!value.is_empty()).then(|| value[..1].chars().next().unwrap())
}
```

After:

```rust
fn first_char(value: &str) -> Option<char> {
    value.chars().next()
}

#[test]
fn handles_multibyte_characters() {
    assert_eq!(first_char("é"), Some('é'));
}
```

This is an intentional behavior correction only when the contract is the first Unicode scalar value. If the intended unit is a byte or grapheme cluster, stop and clarify.

### Example 3: Preserve exact map semantics

Before:

```rust
fn update_existing(map: &mut HashMap<u64, String>, key: u64, value: String) {
    if map.contains_key(&key) {
        map.insert(key, value);
    }
}
```

After:

```rust
fn update_existing(map: &mut HashMap<u64, String>, key: u64, value: String) {
    if let Entry::Occupied(mut entry) = map.entry(key) {
        entry.insert(value);
    }
}
```

Do not use `or_insert(value)`: that changes the operation from updating an existing key to inserting a missing key. For non-`Copy` keys, verify consumption and drop timing.

### Example 4: Remove an intermediate allocation without overclaiming

Before:

```rust
let fields: Vec<_> = line.split(',').collect();
for field in fields {
    validate(field)?;
}
```

After:

```rust
for field in line.split(',') {
    validate(field)?;
}
```

Report that the intermediate `Vec` was removed. Claim a runtime improvement only after a benchmark demonstrates one.

### Completion report

For implementation work, return:

```markdown
## Implemented Scope
[Objective and coherent batches completed]

## Files and Symbols
[Created, moved, renamed, consolidated, split, deleted, or materially changed]

## Behavior and API
[Preserved contracts and intentional corrections or migrations]

## Verification
- `cargo fmt --all -- --check` — passed
- `cargo test -p target-crate` — passed
- `cargo clippy -p target-crate --all-targets -- -D warnings` — passed

## Remaining Risk
[Unverified targets, pre-existing failures, and deferred opportunities]
```

For audit-only work, report scope, baseline, complete findings, implementation batches, coverage gaps, and public or behavior decisions that require authorization.