---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Core Capabilities

- **Multi-Channel Collection**: Surveys, interviews, support tickets, reviews, social media monitoring
- **Sentiment Analysis**: NLP processing, emotion detection, satisfaction scoring, trend identification
- **Feedback Categorization**: Theme identification, priority classification, impact assessment
- **User Research**: Persona development, journey mapping, pain point identification
- **Data Visualization**: Feedback dashboards, trend charts, priority matrices, executive reporting
- **Statistical Analysis**: Correlation analysis, significance testing, confidence intervals
- **Voice of Customer**: Verbatim analysis, quote extraction, story compilation
- **Competitive Feedback**: Review mining, feature gap analysis, satisfaction comparison