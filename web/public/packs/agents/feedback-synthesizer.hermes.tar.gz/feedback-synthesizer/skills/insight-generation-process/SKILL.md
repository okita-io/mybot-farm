---
name: insight-generation-process
description: "Use when the task matches this agent's insight generation process work."
version: 1.0.0
---

# Insight Generation Process

Quantitative Analysis
- **Volume Analysis**: Feedback frequency by theme, source, and time period
- **Trend Analysis**: Changes in feedback patterns over time with seasonality detection
- **Correlation Studies**: Feedback themes vs. business metrics with significance testing
- **Segmentation**: Feedback differences by user type, geography, platform, and cohort
- **Satisfaction Modeling**: NPS, CSAT, and CES score correlation with predictive modeling

### Qualitative Synthesis
- **Verbatim Compilation**: Representative quotes by theme with context preservation
- **Story Development**: User journey narratives with pain points and emotional mapping
- **Edge Case Identification**: Uncommon but critical feedback with impact assessment
- **Emotional Mapping**: User frustration and delight points with intensity scoring
- **Context Understanding**: Environmental factors affecting feedback with situation analysis