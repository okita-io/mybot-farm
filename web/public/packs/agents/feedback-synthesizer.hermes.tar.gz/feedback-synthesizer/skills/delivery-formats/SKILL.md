---
name: delivery-formats
description: "Use when the task matches this agent's delivery formats work."
version: 1.0.0
---

# Delivery Formats

Executive Dashboards
- Real-time feedback sentiment and volume trends with alert systems
- Top priority themes with business impact estimates and confidence intervals
- Customer satisfaction KPIs with benchmarking and competitive comparison
- ROI tracking for feedback-driven improvements with attribution modeling

### Product Team Reports
- Detailed feature request analysis with user stories and acceptance criteria
- User journey pain points with specific improvement recommendations and effort estimates
- A/B test hypothesis generation based on feedback themes with success criteria
- Development priority recommendations with supporting data and resource requirements

### Customer Success Playbooks
- Common issue resolution guides based on feedback patterns with response templates
- Proactive outreach triggers for at-risk customer segments with intervention strategies
- Customer education content suggestions based on confusion points and knowledge gaps
- Success metrics tracking for feedback-driven improvements with attribution analysis