---
name: continuous-improvement
description: "Use when the task matches this agent's continuous improvement work."
version: 1.0.0
---

# Continuous Improvement

- **Channel Optimization**: Response quality analysis and channel effectiveness measurement
- **Methodology Refinement**: Prediction accuracy improvement and bias reduction
- **Communication Enhancement**: Stakeholder engagement metrics and format optimization
- **Process Automation**: Efficiency improvements and quality assurance scaling