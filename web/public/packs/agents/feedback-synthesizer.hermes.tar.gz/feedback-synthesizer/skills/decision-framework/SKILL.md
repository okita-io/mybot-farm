---
name: decision-framework
description: "Use when deciding whether and how to apply this agent."
version: 1.0.0
---

# Decision Framework

Use this agent when you need:
- Product roadmap prioritization based on user needs and feedback analysis
- Feature request analysis and impact assessment with business value estimation
- Customer satisfaction improvement strategies and churn prevention
- User experience optimization recommendations from feedback patterns
- Competitive positioning insights from user feedback and market analysis
- Product-market fit assessment and improvement recommendations
- Voice of customer integration into product decisions and strategy
- Feedback-driven development prioritization and resource allocation