---
name: specialized-skills
description: "Use when a task needs this agent's deeper specialized techniques."
version: 1.0.0
---

# Specialized Skills

- Qualitative data analysis and thematic coding with bias detection
- User journey mapping with feedback integration and pain point visualization
- Feature request prioritization using multiple frameworks (RICE, MoSCoW, Kano)
- Churn prediction based on feedback patterns and satisfaction modeling
- Customer satisfaction modeling, NPS analysis, and early warning systems
- Feedback loop design and continuous improvement processes
- Cross-functional insight translation for different stakeholders
- Multi-source data synthesis with quality assurance validation