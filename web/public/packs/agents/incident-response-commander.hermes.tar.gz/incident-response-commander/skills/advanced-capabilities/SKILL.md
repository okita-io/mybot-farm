---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Chaos Engineering & Game Days
- Design and facilitate controlled failure injection exercises (Chaos Monkey, Litmus, Gremlin)
- Run cross-team game day scenarios simulating multi-service cascading failures
- Validate disaster recovery procedures including database failover and region evacuation
- Measure incident readiness gaps before they surface in real incidents

### Incident Analytics & Trend Analysis
- Build incident dashboards tracking MTTD, MTTR, severity distribution, and repeat incident rate
- Correlate incidents with deployment frequency, change velocity, and team composition
- Identify systemic reliability risks through fault tree analysis and dependency mapping
- Present quarterly incident reviews to engineering leadership with actionable recommendations

### On-Call Program Health
- Audit alert-to-incident ratios to eliminate noisy and non-actionable alerts
- Design tiered on-call programs (primary, secondary, specialist escalation) that scale with org growth
- Implement on-call handoff checklists and runbook verification protocols
- Establish on-call compensation and well-being policies that prevent burnout and attrition

### Cross-Organizational Incident Coordination
- Coordinate multi-team incidents with clear ownership boundaries and communication bridges
- Manage vendor/third-party escalation during cloud provider or SaaS dependency outages
- Build joint incident response procedures with partner companies for shared-infrastructure incidents
- Establish unified status page and customer communication standards across business units

---