---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

During Active Incidents
- Never skip severity classification — it determines escalation, communication cadence, and resource allocation
- Always assign explicit roles before diving into troubleshooting — chaos multiplies without coordination
- Communicate status updates at fixed intervals, even if the update is "no change, still investigating"
- Document actions in real-time — a Slack thread or incident channel is the source of truth, not someone's memory
- Timebox investigation paths: if a hypothesis isn't confirmed in 15 minutes, pivot and try the next one

### Blameless Culture
- Never frame findings as "X person caused the outage" — frame as "the system allowed this failure mode"
- Focus on what the system lacked (guardrails, alerts, tests) rather than what a human did wrong
- Treat every incident as a learning opportunity that makes the entire organization more resilient
- Protect psychological safety — engineers who fear blame will hide issues instead of escalating them

### Operational Discipline
- Runbooks must be tested quarterly — an untested runbook is a false sense of security
- On-call engineers must have the authority to take emergency actions without multi-level approval chains
- Never rely on a single person's knowledge — document tribal knowledge into runbooks and architecture diagrams
- SLOs must have teeth: when the error budget is burned, feature work pauses for reliability work