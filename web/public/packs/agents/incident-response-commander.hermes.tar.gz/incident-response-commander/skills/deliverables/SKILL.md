---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Severity Classification Matrix
```markdown
# Incident Severity Framework

| Level | Name      | Criteria                                           | Response Time | Update Cadence | Escalation              |
|-------|-----------|----------------------------------------------------|---------------|----------------|-------------------------|
| SEV1  | Critical  | Full service outage, data loss risk, security breach | < 5 min       | Every 15 min   | VP Eng + CTO immediately |
| SEV2  | Major     | Degraded service for >25% users, key feature down   | < 15 min      | Every 30 min   | Eng Manager within 15 min|
| SEV3  | Moderate  | Minor feature broken, workaround available           | < 1 hour      | Every 2 hours  | Team lead next standup   |
| SEV4  | Low       | Cosmetic issue, no user impact, tech debt trigger    | Next bus. day  | Daily          | Backlog triage           |

## Escalation Triggers (auto-upgrade severity)
- Impact scope doubles → upgrade one level
- No root cause identified after 30 min (SEV1) or 2 hours (SEV2) → escalate to next tier
- Customer-reported incidents affecting paying accounts → minimum SEV2
- Any data integrity concern → immediate SEV1
```

### Incident Response Runbook Template
```markdown
# Runbook: [Service/Failure Scenario Name]

## Quick Reference
- **Service**: [service name and repo link]
- **Owner Team**: [team name, Slack channel]
- **On-Call**: [PagerDuty schedule link]
- **Dashboards**: [Grafana/Datadog links]
- **Last Tested**: [date of last game day or drill]

## Detection
- **Alert**: [Alert name and monitoring tool]
- **Symptoms**: [What users/metrics look like during this failure]
- **False Positive Check**: [How to confirm this is a real incident]

## Diagnosis
1. Check service health: `kubectl get pods -n <namespace> | grep <service>`
2. Review error rates: [Dashboard link for error rate spike]
3. Check recent deployments: `kubectl rollout history deployment/<service>`
4. Review dependency health: [Dependency status page links]

## Remediation

### Option A: Rollback (preferred if deploy-related)
```bash
# Identify the last known good revision
kubectl rollout history deployment/<service> -n production

# Rollback to previous version
kubectl rollout undo deployment/<service> -n production

# Verify rollback succeeded
kubectl rollout status deployment/<service> -n production
watch kubectl get pods -n production -l app=<service>
```

### Option B: Restart (if state corruption suspected)
```bash
# Rolling restart — maintains availability
kubectl rollout restart deployment/<service> -n production

# Monitor restart progress
kubectl rollout status deployment/<service> -n production
```

### Option C: Scale up (if capacity-related)
```bash
# Increase replicas to handle load
kubectl scale deployment/<service> -n production --replicas=<target>

# Enable HPA if not active
kubectl autoscale deployment/<service> -n production \
  --min=3 --max=20 --cpu-percent=70
```

## Verification
- [ ] Error rate returned to baseline: [dashboard link]
- [ ] Latency p99 within SLO: [dashboard link]
- [ ] No new alerts firing for 10 minutes
- [ ] User-facing functionality manually verified

## Communication
- Internal: Post update in #incidents Slack channel
- External: Update [status page link] if customer-facing
- Follow-up: Create post-mortem document within 24 hours
```

### Post-Mortem Document Template
```markdown
# Post-Mortem: [Incident Title]

**Date**: YYYY-MM-DD
**Severity**: SEV[1-4]
**Duration**: [start time] – [end time] ([total duration])
**Author**: [name]
**Status**: [Draft / Review / Final]

## Executive Summary
[2-3 sentences: what happened, who was affected, how it was resolved]

## Impact
- **Users affected**: [number or percentage]
- **Revenue impact**: [estimated or N/A]
- **SLO budget consumed**: [X% of monthly error budget]
- **Support tickets created**: [count]

## Timeline (UTC)
| Time  | Event                                           |
|-------|--------------------------------------------------|
| 14:02 | Monitoring alert fires: API error rate > 5%      |
| 14:05 | On-call engineer acknowledges page               |
| 14:08 | Incident declared SEV2, IC assigned              |
| 14:12 | Root cause hypothesis: bad config deploy at 13:55|
| 14:18 | Config rollback initiated                        |
| 14:23 | Error rate returning to baseline                 |
| 14:30 | Incident resolved, monitoring confirms recovery  |…