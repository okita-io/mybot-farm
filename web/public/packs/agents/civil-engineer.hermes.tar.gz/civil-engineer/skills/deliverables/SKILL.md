---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Structural Calculation — Steel Beam (AISC 360 LRFD)

```
Member: W18x35 A992 steel, simply supported, L = 6.1 m
Loading: wDL = 14.6 kN/m, wLL = 29.2 kN/m

Factored load (ASCE 7, LC2): wu = 1.2(14.6) + 1.6(29.2) = 64.2 kN/m
Mu = wu·L²/8 = 64.2 × 6.1² / 8 = 298 kN·m

Section properties (W18x35): Zx = 642,000 mm³, Iy = 11.1×10⁶ mm⁴
φMn = φ·Fy·Zx = 0.9 × 345 × 642,000 = 199 kN·m  ← INADEQUATE
→ Upsize to W21x44: Zx = 948,000 mm³
φMn = 0.9 × 345 × 948,000 = 294 kN·m  ← Check
298 > 294 kN·m  ← Still insufficient → W21x48: φMn = 325 kN·m ✓

Deflection (SLS): δLL = 5wLL·L⁴ / (384·E·Ix)
W21x48: Ix = 193×10⁶ mm⁴
δLL = 5 × (29.2/1000) × 6100⁴ / (384 × 200,000 × 193×10⁶) = 18.1 mm
Limit: L/360 = 6100/360 = 16.9 mm  ← EXCEEDS LIMIT
→ W24x55 (Ix = 277×10⁶ mm⁴): δLL = 12.6 mm < 16.9 mm ✓

GOVERNING SECTION: W24x55 — controlled by serviceability (deflection)
```

### Structural Calculation — RC Beam (Eurocode EN 1992-1-1)

```
Beam: b = 300 mm, h = 600 mm, d = 550 mm, fck = 30 MPa, fyk = 500 MPa
Design moment: MEd = 280 kN·m (ULS, EN 1990 LC: 1.35G + 1.5Q)

fcd = αcc·fck/γc = 0.85 × 30 / 1.5 = 17.0 MPa
fyd = fyk/γs = 500 / 1.15 = 435 MPa

K = MEd / (b·d²·fcd) = 280×10⁶ / (300 × 550² × 17.0) = 0.102
Kbal = 0.167 (without compression steel, C-class ductility)
K < Kbal → singly reinforced ✓

z = d[0.5 + √(0.25 - K/1.134)] = 550[0.5 + √(0.25 - 0.090)] = 480 mm
As,req = MEd / (fyd·z) = 280×10⁶ / (435 × 480) = 1,341 mm²

Provide: 3H25 (As = 1,473 mm²) ✓
Check minimum: As,min = 0.26·fctm/fyk·b·d = 0.26×2.9/500×300×550 = 249 mm² ✓

Shear: VEd = 180 kN
vEd = VEd / (b·z) = 180,000 / (300 × 480) = 1.25 MPa
→ Design shear links per EN 1992 cl. 6.2.3
```

### Geotechnical — Bearing Capacity (EN 1997 / Terzaghi)

```
Strip footing: B = 1.5 m, Df = 1.0 m
Soil: c' = 10 kPa, φ' = 28°, γ = 19 kN/m³

Terzaghi factors (φ' = 28°): Nc = 25.8, Nq = 14.7, Nγ = 16.7
qu = c'·Nc + q·Nq + 0.5·γ·B·Nγ
   = 10×25.8 + (19×1.0)×14.7 + 0.5×19×1.5×16.7
   = 258 + 279 + 239 = 776 kPa

Allowable (FS = 3.0): qa = 776/3 = 259 kPa

EN 1997 DA1 verification:
Rd/Ad ≥ 1.0 using characteristic values and partial factors γφ = 1.25, γc = 1.25
→ Design value of resistance checked against factored design action
```

### BIM Coordination Checklist

```
[ ] Structural model exported to IFC 4.x — all structural elements classified
[ ] Clash detection run vs. MEP and architectural models (0 hard clashes at tender)
[ ] Slab penetrations coordinated — all openings > 150mm shown with trimmer bars
[ ] Steel connection zones clear of ductwork (min. 150mm clearance)
[ ] Foundation depths coordinated with drainage, services, and piling platform level
[ ] Reinforcement cover zones not violated by embedded items
[ ] Fire stopping locations agreed at structural penetrations
[ ] Expansion joints aligned across all disciplines
```