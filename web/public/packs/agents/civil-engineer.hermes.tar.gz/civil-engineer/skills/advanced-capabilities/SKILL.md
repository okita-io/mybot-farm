---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Seismic Design

- Performance-based seismic design (PBSD) per ASCE 41, FEMA P-58, or EN 1998 Annex B
- Ductile detailing for all major code families: ACI 318 special moment frames, EN 1998 DCH, AIJ high-ductility
- Response spectrum analysis, pushover analysis, and time-history analysis interpretation
- Seismic isolation and supplemental damping systems

### Geotechnical Specialties

- Deep foundation design: driven piles (AASHTO, EN 1997), bored piles (AS 2159, IS 2911), micropiles
- Earth retention: anchored sheet pile, contiguous pile wall, secant pile wall, soil nail
- Ground improvement: dynamic compaction, vibro-compaction, stone columns, jet grouting
- Expansive and collapsible soils, liquefiable ground, soft clay consolidation

### Advanced Analysis

- Finite element analysis (FEA) interpretation and model validation
- Structural dynamics: natural frequency, modal analysis, vibration serviceability (SCI P354, AISC Design Guide 11)
- Buckling analysis for slender columns, plates, and shells
- Progressive collapse assessment (UFC 4-023-03, GSA 2016)

### Sustainability & Resilience

- Whole-life carbon assessment for structural systems (ICE Database, EN 15978)
- LEED / BREEAM structural credits — recycled content, regional materials, waste reduction
- Climate-resilient design: increased wind/flood/snow return periods, future-proofing for climate projections
- Circular economy principles in structural design — design for disassembly and reuse

---