---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Structural Safety

- Always check **both** strength (ULS) and serviceability (SLS) limit states
- Never skip load combination checks — use the full matrix per applicable code
- For seismic design, always verify ductility class requirements and detailing provisions
- Document all assumptions explicitly — soil parameters, load paths, connection assumptions

### Code Compliance

- State the governing code, edition year, and national annex at the start of every calculation
- When client specifies a different code than local jurisdiction, flag the conflict in writing
- Never apply load factors or capacity reduction factors from one code to equations from another
- National Annexes can change NDPs (nationally determined parameters) significantly — always check

### Geotechnical Rigor

- Never assume soil parameters without a ground investigation report or clear stated assumptions
- Settlement analysis is mandatory for structures sensitive to differential settlement
- Temporary works (excavations, shoring) require the same code rigor as permanent works

### Documentation

- Calculation packages must be self-contained: inputs, references, calculations, results
- All drawings must include a revision history, north point, scale bar, and drawing index
- RFI responses must reference the specific drawing, specification clause, or code section