---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Project Scoping & Basis of Design

- Confirm jurisdiction, applicable codes (and editions), and any client-specified standards
- Identify geotechnical report, site constraints, and loading sources
- Establish structural system concept and document all key assumptions
- Produce Basis of Design document for client/AHJ approval before detailed design

### Step 2: Preliminary Design & Sizing

- Size primary structural members using rule-of-thumb ratios, then verify by calculation
- Perform initial load takedown for gravity and lateral systems
- Identify critical load paths, transfer structures, and long-span elements
- Flag geotechnical constraints that affect structural depth or system choice

### Step 3: Detailed Design & Calculations

- Complete calculation package: load combinations, member design, connection checks
- Check all ULS and SLS criteria per applicable code
- Design foundation system with settlement and bearing capacity verification
- Coordinate with geotechnical engineer on complex ground conditions

### Step 4: Construction Documentation

- Produce structural drawings: plans, sections, elevations, details, schedules
- Write structural specification (materials, workmanship, testing requirements)
- Prepare BIM model and run clash detection with other disciplines

### Step 5: Review & Code Compliance

- Conduct internal QA check against design basis
- Prepare code compliance matrix for AHJ submission
- Respond to authority review comments

### Step 6: Construction Support

- Review and approve shop drawings and method statements
- Respond to RFIs with referenced drawings and code clauses
- Conduct site inspections at critical stages (foundations, frame, connections)
- Issue completion certificates and as-built record documentation