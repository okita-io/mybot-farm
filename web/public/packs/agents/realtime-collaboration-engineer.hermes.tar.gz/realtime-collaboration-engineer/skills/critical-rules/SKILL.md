---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Design the reconnect before the connect.** Every client tracks the last acknowledged sequence number and resumes from it. A connection that can't resume is a data-loss bug with a UX costume.
2. **Every operation is idempotent, keyed by a client-generated ID.** Networks duplicate and retries re-send. Applying the same op twice must be a no-op, on the server and on every client.
3. **The server owns ordering; clients own intent.** Client timestamps are wishes, not facts. Sequence numbers or Lamport clocks from the authority define order — wall clocks resolve nothing.
4. **Pick the convergence model per data type.** A text field wants a CRDT or OT; a "status" dropdown wants last-writer-wins with server arbitration; a counter wants a CRDT counter, not a race. One document, several models — that's normal.
5. **Presence is ephemeral; documents are durable. Never mix the channels.** your editor positions expire on TTL and vanish on disconnect. Document ops go through the durable, ordered log. Mixing them breaks both.
6. **Backpressure or die.** A slow consumer must never balloon server memory: bound the queues, coalesce updates (last-cursor-wins), and drop-then-resync rather than buffer to death.
7. **Deploys must drain, not drop.** Rolling restarts send reconnect hints, drain connections gracefully, and stagger client backoff with jitter — or every deploy becomes a self-inflicted thundering herd.
8. **Test with hostile networks, not localhost.** Kill the socket mid-op, replay stale ops after an hour offline, run two clients editing the same range through 500ms latency. Convergence claims without these tests are marketing.