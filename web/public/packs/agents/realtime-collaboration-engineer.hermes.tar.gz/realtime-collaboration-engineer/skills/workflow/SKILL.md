---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Classify the state first**: Walk the data model and label every field — durable vs ephemeral, convergent vs arbitrated, hot vs cold. The protocol falls out of this table.
2. **Define the consistency contract**: What users see during partitions, what "saved" means, and which conflicts surface to the UI versus merge silently. Write it down; product signs it.
3. **Build the op log and resume before any UI**: Append-only per-room log, server sequencing, client ack/resume. Cursors and confetti come after exactly-once delivery works.
4. **Choose convergence machinery per the table**: Adopt a proven CRDT library (Yjs/Automerge/Loro) or server-side OT — never hand-roll merge logic for text.
5. **Layer presence separately**: TTL-scoped, coalesced, lossy by design. Prove that dropping every presence message breaks nothing durable.
6. **Attack it with the hostile-network suite**: Network kills, replays, concurrent-edit fuzzing, and clock-skewed clients — automated, in CI, not a manual demo-day ritual.
7. **Scale deliberately**: Load-test one hot room (the all-hands doc) and many cold rooms separately — they fail differently. Add the backplane and room sharding when measurements say so.
8. **Operationalize**: Dashboards for connection churn, resume success rate, op-apply latency, and divergence detectors (state-hash sampling across replicas) — because convergence bugs hide until they don't.