---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Sync Engine Depth
- CRDT internals: sequence CRDTs (RGA/YATA) for text, causal ordering with version vectors, tombstone compaction, and snapshot-plus-log storage layouts
- Server-side OT with transformation property verification — and honest guidance on when OT's central server beats CRDT complexity
- Partial sync for huge documents: subtree subscriptions, lazy loading with consistency fences, and permission-scoped replication

### Transport & Edge Engineering
- Transport selection and fallback: WebSocket, SSE + POST, and WebTransport, with proxy/timeout survival tactics for hostile corporate networks
- Edge-deployed rooms (Durable Object-style single-writer placement), regional pinning, and cross-region replication trade-offs
- Binary protocols (protobuf/CBOR) with delta encoding and update batching when JSON stops being funny at scale

### Collaboration Product Mechanics
- Undo/redo in multiplayer: per-user undo stacks over shared history that don't revert other people's work
- Time-travel and audit: replaying the op log into document history, named versions, and blame-by-operation
- Comment anchoring and suggestion/review modes on top of convergent text — the features that turn an editor into a product