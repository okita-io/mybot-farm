---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Reconnect-Safe Client Protocol

```typescript
// The contract: server assigns seq to every op; client acks what it has applied;
// resume replays the gap. Duplicates are impossible by construction (opId dedupe).
class SyncConnection {
  private lastServerSeq = 0;                    // highest seq applied locally
  private pending = new Map<string, Op>();      // sent, not yet acked
  private backoff = 500;

  connect() {
    this.ws = new WebSocket(`${WS_URL}?resumeFrom=${this.lastServerSeq}`);
    this.ws.onmessage = (e) => this.receive(JSON.parse(e.data));
    this.ws.onclose = () => this.scheduleReconnect();
    this.ws.onopen = () => {
      this.backoff = 500;
      this.pending.forEach((op) => this.ws.send(JSON.stringify(op))); // safe: opId dedupes
    };
  }

  send(op: Omit<Op, 'opId'>) {
    const stamped = { ...op, opId: crypto.randomUUID() };  // client-generated identity
    this.pending.set(stamped.opId, stamped);
    this.queueLocally(stamped);                            // optimistic apply + offline queue
    if (this.ws.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(stamped));
  }

  private receive(msg: ServerMsg) {
    if (msg.type === 'op') {
      this.lastServerSeq = msg.seq;                        // server ordering is truth
      this.pending.delete(msg.opId);                       // ack of our own op, or...
      this.applyRemote(msg);                               // ...someone else's, transformed
    }
  }

  private scheduleReconnect() {
    const jitter = Math.random() * this.backoff;           // herd-proof
    setTimeout(() => this.connect(), this.backoff + jitter);
    this.backoff = Math.min(this.backoff * 2, 30_000);
  }
}
```

### Convergence Model Decision Table

| Data type | Right machinery | Why |
|-----------|-----------------|-----|
| Collaborative rich text | CRDT (Yjs/Loro) or OT (server-transformed) | Concurrent inserts in the same range must interleave, not overwrite |
| Form fields, settings, status | Server-arbitrated last-writer-wins + version check | Users expect "the last save wins"; a merged dropdown is nonsense |
| Counters (likes, votes, quotas) | CRDT counter / server increment op | LWW loses increments; send the *operation*, never the computed total |
| Lists with ordering (kanban) | Fractional indexing + server tiebreak | Move ops must merge without renumbering the world on every drag |
| Cursors, selections, presence | Ephemeral broadcast, TTL, last-state-wins | Nobody needs a durable, convergent history of cursor twitches |

### Presence System (ephemeral, TTL-scoped, coalesced)

```typescript
// Redis-backed presence: heartbeat refreshes TTL; silence means gone.
// Fan out at most ~10 presence updates/sec per room — coalesce, last write wins.
async function heartbeat(roomId: string, userId: string, state: PresenceState) {
  await redis.hset(`presence:${roomId}`, userId, JSON.stringify({
    ...state,                    // cursor, selection, viewport
    updatedAt: Date.now(),
  }));
  await redis.expire(`presence:${roomId}`, 60);            // room GC
  await redis.publish(`room:${roomId}:presence`, userId);  // subscribers re-read the hash
}
// Client rule: render peers whose updatedAt is fresh (< 30s); fade the rest.
// Presence NEVER writes to the document log — different channel, different guarantees.
```

### Fan-Out Architecture (one room, thousands of sockets)

```text
clients ──ws──▶ gateway nodes (stateless, any node serves any room)
                   │  subscribe room:{id}
                   ▼
             pub/sub backplane (Redis/NATS)          ordering + durability
                   ▲                                   ┌──────────────────┐
                   │  publish op(seq)                  │ op log (append-  │
             room authority ──────assign seq──────────▶│ only, per room)  │
             (sharded by roomId — single writer        └──────────────────┘
              per room = trivially correct ordering)      └─▶ resumeFrom replay
```

Single-writer-per-room makes ordering trivial and scales by sharding rooms, not by solving distributed consensus per keystroke. The op log gives you resume, audit, and time-travel debugging for free.

### Hostile-Network Test Checklist

| Scenario | Must hold |
|----------|-----------|
| Kill socket mid-op, reconnect | Op applies exactly once; no gap, no duplicate |…