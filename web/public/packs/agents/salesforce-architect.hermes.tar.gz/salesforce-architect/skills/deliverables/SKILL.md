---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Architecture Decision Record (ADR)

```markdown
# ADR-[NUMBER]: [TITLE]

## Status: [Proposed | Accepted | Deprecated]

## Context
[Business driver and technical constraint that forced this decision]

## Decision
[What we decided and why]

## Alternatives Considered
| Option | Pros | Cons | Governor Impact |
|--------|------|------|-----------------|
| A      |      |      |                 |
| B      |      |      |                 |

## Consequences
- Positive: [benefits]
- Negative: [trade-offs we accept]
- Governor limits affected: [specific limits and headroom remaining]

## Review Date: [when to revisit]
```

### Integration Pattern Template

```
┌──────────────┐     ┌───────────────┐     ┌──────────────┐
│  Source       │────▶│  Middleware    │────▶│  Salesforce   │
│  System       │     │  (MuleSoft)   │     │  (Platform    │
│              │◀────│               │◀────│   Events)     │
└──────────────┘     └───────────────┘     └──────────────┘
         │                    │                      │
    [Auth: OAuth2]    [Transform: DataWeave]  [Trigger → Handler]
    [Format: JSON]    [Retry: 3x exp backoff] [Bulk: 200/batch]
    [Rate: 100/min]   [DLQ: error__c object]  [Async: Queueable]
```

### Data Model Review Checklist

- [ ] Master-detail vs lookup decisions documented with reasoning
- [ ] Record type strategy defined (avoid excessive record types)
- [ ] Sharing model designed (OWD + sharing rules + manual shares)
- [ ] Large data volume strategy (skinny tables, indexes, archive plan)
- [ ] External ID fields defined for integration objects
- [ ] Field-level security aligned with profiles/permission sets
- [ ] Polymorphic lookups justified (they complicate reporting)

### Governor Limit Budget

```
Transaction Budget (Synchronous):
├── SOQL Queries:     100 total │ Used: __ │ Remaining: __
├── DML Statements:   150 total │ Used: __ │ Remaining: __
├── CPU Time:      10,000ms     │ Used: __ │ Remaining: __
├── Heap Size:     6,144 KB     │ Used: __ │ Remaining: __
├── Callouts:          100      │ Used: __ │ Remaining: __
└── Future Calls:       50      │ Used: __ │ Remaining: __
```