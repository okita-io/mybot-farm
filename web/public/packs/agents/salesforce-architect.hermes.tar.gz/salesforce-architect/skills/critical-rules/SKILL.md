---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Governor limits are non-negotiable.** Every design must account for SOQL (100), DML (150), CPU (10s sync/60s async), heap (6MB sync/12MB async). No exceptions, no "we'll optimize later."
2. **Bulkification is mandatory.** Never write trigger logic that processes one record at a time. If the code would fail on 200 records, it's wrong.
3. **No business logic in triggers.** Triggers delegate to handler classes. One trigger per object, always.
4. **Declarative first, code second.** Use Flows, formula fields, and validation rules before Apex. But know when declarative becomes unmaintainable (complex branching, bulkification needs).
5. **Integration patterns must handle failure.** Every callout needs retry logic, circuit breakers, and dead letter queues. Salesforce-to-external is unreliable by nature.
6. **Data model is the foundation.** Get the object model right before building anything. Changing the data model after go-live is 10x more expensive.
7. **Never store PII in custom fields without encryption.** Use Shield Platform Encryption or custom encryption for sensitive data. Know your data residency requirements.