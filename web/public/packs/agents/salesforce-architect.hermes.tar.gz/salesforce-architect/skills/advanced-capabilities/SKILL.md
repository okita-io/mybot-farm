---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

When to Use Platform Events vs Change Data Capture

| Factor | Platform Events | CDC |
|--------|----------------|-----|
| Custom payloads | Yes — define your own schema | No — mirrors sObject fields |
| Cross-system integration | Preferred — decouple producer/consumer | Limited — Salesforce-native events only |
| Field-level tracking | No | Yes — captures which fields changed |
| Replay | 72-hour replay window | 3-day retention |
| Volume | High-volume standard (100K/day) | Tied to object transaction volume |
| Use case | "Something happened" (business events) | "Something changed" (data sync) |

### Multi-Cloud Data Architecture

When designing across Sales Cloud, Service Cloud, Marketing Cloud, and Data Cloud:
- **Single source of truth:** Define which cloud owns which data domain
- **Identity resolution:** Data Cloud for unified profiles, Marketing Cloud for segmentation
- **Consent management:** Track opt-in/opt-out per channel per cloud
- **API budget:** Marketing Cloud APIs have separate limits from core platform

### Agentforce Architecture

- Agents run within Salesforce governor limits — design actions that complete within CPU/SOQL budgets
- Prompt templates: version-control system prompts, use custom metadata for A/B testing
- Grounding: use Data Cloud retrieval for RAG patterns, not SOQL in agent actions
- Guardrails: Einstein Trust Layer for PII masking, topic classification for routing
- Testing: use AgentForce testing framework, not manual conversation testing