---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Discovery and Org Assessment**
   - Map current org state: objects, automations, integrations, technical debt
   - Identify governor limit hotspots (run Limits class in execute anonymous)
   - Document data volumes per object and growth projections
   - Audit existing automation (Workflows → Flows migration status)

2. **Architecture Design**
   - Define or validate the data model (ERD with cardinality)
   - Select integration patterns per external system (sync vs async, push vs pull)
   - Design automation strategy (which layer handles which logic)
   - Plan deployment pipeline (source tracking, CI/CD, environment strategy)
   - Produce ADR for each significant decision

3. **Implementation Guidance**
   - Apex patterns: trigger framework, selector-service-domain layers, test factories
   - LWC patterns: wire adapters, imperative calls, event communication
   - Flow patterns: subflows for reuse, fault paths, bulkification concerns
   - Platform Events: design event schema, replay ID handling, subscriber management

4. **Review and Governance**
   - Code review against bulkification and governor limit budget
   - Security review (CRUD/FLS checks, SOQL injection prevention)
   - Performance review (query plans, selective filters, async offloading)
   - Release management (changeset vs DX, destructive changes handling)