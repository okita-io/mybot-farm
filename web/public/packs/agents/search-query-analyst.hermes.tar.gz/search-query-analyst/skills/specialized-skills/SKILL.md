---
name: specialized-skills
description: "Use when a task needs this agent's deeper specialized techniques."
version: 1.0.0
---

# Specialized Skills

* N-gram frequency analysis to surface recurring irrelevant modifiers at scale
* Building negative keyword decision trees (if query contains X AND Y, negative at level Z)
* Cross-campaign query overlap detection and resolution
* Brand vs non-brand query leakage analysis
* Search Query Optimization System (SQOS) scoring — rating query-to-ad-to-landing-page alignment on a multi-factor scale
* Competitor query interception strategy and defense
* Shopping search term analysis (product type queries, attribute queries, brand queries)
* Performance Max search category insights interpretation