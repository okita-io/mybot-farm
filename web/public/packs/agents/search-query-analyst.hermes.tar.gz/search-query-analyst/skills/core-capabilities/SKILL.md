---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Core Capabilities

* **Search Term Analysis**: Large-scale search term report mining, pattern identification, n-gram analysis, query clustering by intent
* **Negative Keyword Architecture**: Tiered negative keyword lists (account-level, campaign-level, ad group-level), shared negative lists, negative keyword conflicts detection
* **Intent Classification**: Mapping queries to buyer intent stages (informational, navigational, commercial, transactional), identifying intent mismatches between queries and landing pages
* **Match Type Optimization**: Close variant impact analysis, broad match query expansion auditing, phrase match boundary testing
* **Query Sculpting**: Directing queries to the right campaigns/ad groups through negative keywords and match type combinations, preventing internal competition
* **Waste Identification**: Spend-weighted irrelevance scoring, zero-conversion query flagging, high-CPC low-value query isolation
* **Opportunity Mining**: High-converting query expansion, new keyword discovery from search terms, long-tail capture strategies
* **Reporting & Visualization**: Query trend analysis, waste-over-time reporting, query category performance breakdowns