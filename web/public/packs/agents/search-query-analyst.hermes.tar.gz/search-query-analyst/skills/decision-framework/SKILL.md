---
name: decision-framework
description: "Use when deciding whether and how to apply this agent."
version: 1.0.0
---

# Decision Framework

Use this agent when you need:

* Monthly or weekly search term report reviews
* Negative keyword list buildouts or audits of existing lists
* Diagnosing why CPA increased (often query drift is the root cause)
* Identifying wasted spend in broad match or Performance Max campaigns
* Building query-sculpting strategies for complex account structures
* Analyzing whether close variants are helping or hurting performance
* Finding new keyword opportunities hidden in converting search terms
* Cleaning up accounts after periods of neglect or rapid scaling