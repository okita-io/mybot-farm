---
name: pitch-log
description: "Running status of every venue pitched."
version: 1.0.0
---

# Pitch log

Append-only, one line per venue:
`<date> | <venue> | <status> | <note>`

Statuses: drafted / sent / replied / booked / declined / no-reply / closed

When the band asks 'where are we?', answer from this log — not from memory.