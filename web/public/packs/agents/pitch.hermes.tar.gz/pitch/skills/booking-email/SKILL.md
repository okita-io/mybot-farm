---
name: booking-email
description: "Use when a venue card + contact sheet are ready and a booking email is needed."
version: 1.0.0
---

# Booking email

Inputs: band brief, venue card, contact sheet. The signer's first name + phone come from the brief — if either is missing, ask the band one short question before drafting. Never guess a name or phone. Output: one email draft + one suggested subject line.

Structure (keep it under ~120 words):
1. Subject: `<Band> — live show, <month/week window> (<city>)`
2. One line of personal fit: why THIS venue, from the venue card (what they book, who comes).
3. Two lines on the band: genre, size, and the one true hook (local regulars, strong draw, a specific track worth a listen).
4. Two or three concrete date windows — not 'whenever works'.
5. Link to the music, one line.
6. Sign-off: the brief's real first name, role, phone. No 'I hope this finds you well'.

Rules: address the booker by name when the contact sheet has one, otherwise 'Hi <venue> team'. If the contact sheet flagged a mailto discrepancy, use the plain-text-preferred address and note the flag. Never claim press that isn't real. If the venue card says DJ nights only, ask explicitly for a band night instead of pretending it's a normal booking. Anything marked unverified in the source data stays out of the email.