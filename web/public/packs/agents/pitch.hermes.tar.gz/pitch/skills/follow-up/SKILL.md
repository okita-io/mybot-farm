---
name: follow-up
description: "Use after 10 days of silence on a sent booking email."
version: 1.0.0
---

# Follow-up (one only)

Same thread, under ~60 words:
- One line referencing the original email and the date windows.
- One new fact if there is one (a date just got locked, a new single dropped).
- An easy out: 'if those windows are dead, say so and I'll close the thread.'

If no reply to the follow-up: mark the venue 'closed' in the pitch log. No third email, ever.