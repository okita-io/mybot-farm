---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Initial Contact Script

```
INITIAL CONTACT — PHONE / CHAT / WEB FORM RESPONSE
───────────────────────────────────────
Phone Opening:
  "Thank you for calling [Firm Name]. My name is [Agent], and I'm here
  to help you today. May I ask who I'm speaking with?

  [After name]
  Thank you, [Name]. I want to make sure we connect you with the right
  attorney for your situation. Could you tell me briefly what brings
  you in today?"

Web/Chat Opening:
  "Hi [Name], thank you for reaching out to [Firm Name]. I'm here to
  help you get connected with the right attorney. Could you tell me
  a little about what you're dealing with so I can make sure we're
  the right fit for your situation?"

Urgency Screen (always ask early):
  "Before we go further — is there anything time-sensitive about your
  situation? Any upcoming court dates, deadlines, or immediate concerns
  I should know about?"

Empathy Acknowledgment (when appropriate):
  "I'm sorry to hear you're going through this — that sounds incredibly
  difficult. I want to make sure we get you the right help. Let me ask
  you a few questions so I can connect you with the best attorney for
  your situation."
```

### Practice Area Qualification Guide

```
PRACTICE AREA QUALIFICATION
───────────────────────────────────────
Personal Injury:
  Qualifying questions:
  - Were you injured? When did the injury occur?
  - Was someone else responsible for the injury?
  - Have you sought medical treatment?
  - Have you spoken with the other party's insurance company?
  Statute of limitations flag: Most states 2-3 years from date of injury
  Disqualifiers: Injury more than 3 years ago (verify state SOL),
                 no identifiable at-fault party, workers' comp only

Family Law:
  Qualifying questions:
  - Are you married? How long?
  - Do you have children together?
  - Is this a divorce, custody, support, or protection order matter?
  - Which state do you and your spouse/partner currently live in?
  Urgency flag: Domestic violence, child safety concerns → immediate escalation
  Disqualifiers: Matter outside firm's jurisdiction

Business / Commercial:
  Qualifying questions:
  - Is this a business dispute or transaction?
  - What type of business entity is involved?
  - What is the approximate value of the dispute or transaction?
  - Is there an existing contract involved?
  Fee fit check: Minimum matter value threshold for litigation matters

Criminal Defense:
  Qualifying questions:
  - Have you been arrested or charged?
  - What is the charge or alleged offense?
  - When is your next court date?
  - Which jurisdiction (city/county/state/federal)?
  Urgency flag: Arraignment within 48 hours → immediate attorney notification
  Disqualifiers: Matter outside firm's practice jurisdiction

Estate Planning:
  Qualifying questions:
# … truncated for farm planting — see upstream for the full sample
```

### Conflict of Interest Screening

```
CONFLICT CHECK INTAKE
───────────────────────────────────────
Required information before scheduling:

Prospect Information:
  Full legal name: _______________
  Also known as (aliases): _______________
  Business name (if applicable): _______________
  Current address: _______________

Adverse Parties:
  "In order to make sure we don't have any conflicts that would
  prevent us from representing you, I need to ask about the other
  parties involved. Could you give me the full name(s) of anyone
  on the other side of this matter?"

  Adverse party #1: _______________
  Adverse party #2: _______________
  Other relevant parties: _______________

Prior Representation:
  "Have you or any of the parties you mentioned previously worked
  with our firm or any of our attorneys?"

  Response: _______________

Conflict Check Status:
  [ ] Pending — information submitted, awaiting attorney review
  [ ] Cleared — no conflicts identified, cleared to schedule
  [ ] Conflict identified — cannot represent, refer out
  [ ] Potential conflict — attorney review required before scheduling

Important: Never schedule a consultation until conflict check
is confirmed cleared by the responsible attorney or intake supervisor.
```

### Case Information Collection

```
INTAKE QUESTIONNAIRE — GENERAL MATTERS
───────────────────────────────────────
Section 1: Contact Information
  Full name: _______________
  Preferred name: _______________
  Phone (primary): _______________
  Phone (alternate): _______________
  Email: _______________…