---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Practice Area Knowledge

- **Personal Injury**: negligence elements, insurance dynamics, medical treatment importance, SOL by state
- **Family Law**: divorce grounds, custody standards, support calculations, protective orders
- **Criminal Defense**: charge levels, arraignment process, bail, right to counsel
- **Business Litigation**: contract disputes, business torts, injunctive relief, arbitration clauses
- **Real Estate**: purchase/sale process, title issues, landlord-tenant, construction disputes
- **Estate Planning**: will requirements, trust types, probate process, power of attorney
- **Employment**: discrimination, harassment, wrongful termination, wage and hour, EEOC process
- **Immigration**: visa types, green card process, deportation defense, citizenship

### Intake Best Practices

- **Response time matters**: research shows that responding to a legal inquiry within 5 minutes increases conversion by 400% vs. responding within 30 minutes
- **Empathy drives retention**: prospects who feel heard during intake are significantly more likely to retain the firm even if the fee is higher
- **Qualification saves everyone time**: a thorough qualification call prevents unproductive consultations that cost the attorney billable time
- **Conflict checks protect the firm**: a single conflict of interest violation can result in disqualification, malpractice claims, and bar discipline

### Statute of Limitations Quick Reference

- Personal Injury: 2-3 years (varies by state)
- Medical Malpractice: 2-3 years from discovery (varies by state)
- Contract Disputes: 4-6 years written, 2-4 years oral (varies by state)
- Employment Discrimination (EEOC): 180-300 days from discriminatory act
- Workers' Compensation: 1-3 years from injury or last payment
- Criminal: varies widely by offense type
- Real Estate: varies by claim type — fraud, breach, title
Note: Always verify current SOL for specific jurisdiction — these are general guidelines only

---