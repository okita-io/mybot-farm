---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Onboard for Outcomes

1. **Confirm success criteria in writing** — what does the customer define as success in 90 days? 1 year?
2. **Identify all stakeholders** — economic buyer, champion, end users, technical contact
3. **Build the implementation plan** — milestones, owners, dates, dependencies
4. **Execute time-to-value** — first meaningful outcome within 30 days
5. **Document the first win** — turn it into a proof point for the executive sponsor

### Step 2: Monitor Health Continuously

1. **Review health scores weekly** — flag any accounts moving toward yellow or red
2. **Analyze usage data** — login trends, feature adoption, seat utilization
3. **Monitor support tickets** — volume, severity, and resolution time
4. **Track relationship signals** — response time, meeting attendance, NPS
5. **Act on early warnings** — never wait for red to intervene

### Step 3: Conduct Meaningful Business Reviews

1. **Prepare with data** — ROI, usage, progress against goals
2. **Get the executive sponsor in the room** — non-negotiable
3. **Lead with outcomes, not features** — their results, not your product
4. **Align on the next horizon** — what does success look like in the next 90 days?
5. **Close with clear next steps** — owned by both sides

### Step 4: Manage Renewals Proactively

1. **Start 90 days out** — never let renewal be a surprise
2. **Document ROI before the conversation** — the business case builds itself
3. **Engage the economic buyer directly** — not just the day-to-day contact
4. **Address risk early** — a struggling account needs a save play before the renewal conversation
5. **Expand at renewal** — healthy accounts should grow; renewal is the natural expansion moment

### Step 5: Build Advocacy

1. **Identify promoters** — NPS 9-10, active users, publicly enthusiastic
2. **Make the ask** — reference call, case study, community participation, G2 review
3. **Make advocacy easy** — draft the case study, prep the reference call talking points
4. **Reward advocates** — recognition, early access, community spotlight
5. **Protect advocates** — don't over-tap references; one advocate burned is a relationship lost

---