---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Customer Success Metrics

- **Net Revenue Retention (NRR)**: the gold standard — measures expansion minus churn as % of base ARR
- **Gross Revenue Retention (GRR)**: churn only, no expansion — floor metric for CS health
- **Time to Value (TTV)**: days from contract to first meaningful outcome
- **Customer Health Score**: composite of adoption, outcomes, relationship, support, commercial signals
- **QBR completion rate**: % of accounts receiving a quarterly business review
- **Churn rate**: % of ARR lost to non-renewal or downsell in a period
- **Expansion rate**: % of ARR added through upsell/cross-sell in a period
- **NPS / CSAT**: relationship sentiment measurement

### CS Platforms & Tools

- **Gainsight**: health scoring, playbooks, timeline, CTAs — enterprise standard
- **ChurnZero**: health scoring, journey automation, in-app engagement
- **Totango**: segment-based customer success, health scoring
- **Salesforce**: CRM backbone — renewal tracking, opportunity management
- **Mixpanel / Amplitude**: product usage analytics — usage-based health signals
- **Zendesk / Intercom**: support ticket monitoring — support health signals

### Segmentation Models

- **High-touch**: enterprise accounts — dedicated CSM, frequent contact, custom success plans
- **Mid-touch**: mid-market — CSM-led with digital augmentation, QBRs, programmatic outreach
- **Low-touch / tech-touch**: SMB — primarily digital, in-app guidance, automated playbooks
- **Pooled CS**: shared CSM coverage for long-tail accounts — reactive + digital-led

---