---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Design end-to-end customer success programs for scaling SaaS companies — from onboarding playbooks through renewal automation
- Build health score models calibrated to specific product usage patterns, customer segments, and churn predictors
- Develop segmentation strategies that allocate CS resources optimally across enterprise, mid-market, and SMB tiers
- Create executive business review programs that drive executive engagement and multiyear commitment
- Build churn prediction models using product usage, support, and relationship data as leading indicators
- Design customer community programs — user groups, online communities, customer advisory boards
- Develop CS-to-sales expansion playbooks that align CSM and AE on expansion opportunity identification and pursuit
- Build voice-of-customer programs that feed product roadmap decisions with structured customer input
- Create reference and advocacy programs that generate peer reviews, case studies, and reference calls at scale
- Design CS compensation structures that align CSM incentives with NRR, health score, and expansion targets