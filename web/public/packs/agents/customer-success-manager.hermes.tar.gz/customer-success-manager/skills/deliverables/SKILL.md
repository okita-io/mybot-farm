---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Customer Health Score Framework

```
HEALTH SCORE MODEL
───────────────────────────────────────
Dimensions (customize weights by product and segment):

PRODUCT ADOPTION (30%)
  Login frequency:          Daily=10 / Weekly=7 / Monthly=4 / Rarely=1
  Feature breadth:          % of purchased features actively used
  User adoption rate:       Active users / licensed seats
  Recent activity trend:    Increasing=10 / Stable=7 / Declining=3

OUTCOMES ACHIEVEMENT (25%)
  Goal progress:            On track=10 / Partial=5 / Off track=1
  ROI realization:          Documented value vs. expected value
  Success milestone status: Completed / In Progress / Not Started

RELATIONSHIP QUALITY (20%)
  Executive engagement:     Active sponsor=10 / Passive=5 / No sponsor=1
  Meeting attendance rate:  % of scheduled calls attended
  Response time:            Hours to reply to CSM outreach
  NPS/CSAT score:           Promoter=10 / Passive=6 / Detractor=1

SUPPORT HEALTH (15%)
  Open ticket count:        0=10 / 1-2=7 / 3+=3
  Ticket severity:          P1/P2 open tickets = immediate flag
  Escalation history:       Recent escalations = risk signal

COMMERCIAL SIGNALS (10%)
  Renewal probability:      High=10 / Medium=6 / Low=2
  Expansion conversations:  Active=10 / None=5
  Invoice payment history:  Current=10 / Late=5 / Disputed=1

HEALTH SCORE THRESHOLDS:
  🟢 Green  (80-100): Healthy — maintain cadence, identify expansion
  🟡 Yellow (60-79):  At Risk — increase touch frequency, identify gaps
  🔴 Red    (0-59):   Critical — escalate, activate save play immediately
```

### Onboarding Framework

```
CUSTOMER ONBOARDING PLAN
───────────────────────────────────────
PHASE 1 — KICKOFF (Days 1-7)
  Kickoff meeting agenda:
    □ Introductions: CSM, implementation team, customer stakeholders
    □ Confirm business goals and success criteria (in writing)
    □ Review implementation timeline and milestones
    □ Identify technical contacts and admin users
    □ Set communication cadence and preferred channels
    □ Assign roles and responsibilities (RACI)

  CSM commitments at kickoff:
    "By our next meeting I will have: [specific deliverable]"
  Customer commitments at kickoff:
    "[Contact name] will complete [action] by [date]"

PHASE 2 — IMPLEMENTATION (Days 8-30)
  Weekly check-ins:
    □ Progress against implementation plan
    □ Blockers and how to resolve them
    □ User provisioning and admin setup
    □ Data migration or integration status
    □ Training schedule confirmed

  Time-to-value target: First meaningful outcome within 30 days
  Success signal: At least one user saying "this saved me X"

PHASE 3 — ADOPTION (Days 31-60)
  □ Core use case fully operational
  □ User training completed for primary team
  □ At least 60% of licensed seats active
  □ First success metric documented
  □ Executive sponsor updated on progress

PHASE 4 — VALUE REALIZATION (Days 61-90)
  □ ROI calculation prepared for executive review
  □ Success criteria assessment: on track / needs adjustment
  □ Expansion opportunity identified (if applicable)
  □ 90-day review meeting scheduled
  □ Ongoing cadence established
# … truncated for farm planting — see upstream for the full sample
```

### QBR / EBR Framework

```
QUARTERLY BUSINESS REVIEW STRUCTURE
───────────────────────────────────────
Pre-QBR Preparation (1 week before):
  □ Pull usage data and health score trends
  □ Document ROI achieved since last QBR
  □ Identify 2-3 wins to celebrate
  □ Prepare 1-2 strategic recommendations
  □ Confirm executive sponsor attendance
  □ Send agenda 3 days in advance

QBR AGENDA (60-90 minutes):

Opening (5 min):
  "Today I want to accomplish three things:
   1. Show you the value you've achieved this quarter
   2. Align on priorities for next quarter
   3. Discuss [one strategic opportunity]"

Section 1 — YOUR PROGRESS (20 min)
  "Here's what you set out to achieve and where you stand:"
  □ Original goals and success criteria (their words, not ours)
  □ Progress against each goal — with data
  □ ROI documented: time saved, revenue generated, cost reduced
  □ Wins to celebrate — specific, quantified, attributable

Section 2 — USAGE & ADOPTION (10 min)
  □ Active users vs. licensed seats
  □ Top features used and outcomes generated
  □ Features purchased but underutilized — and what they're missing
  □ Benchmarks vs. similar customers (if available)

Section 3 — LOOKING AHEAD (20 min)
  □ Their priorities for next quarter (ask, don't tell)…