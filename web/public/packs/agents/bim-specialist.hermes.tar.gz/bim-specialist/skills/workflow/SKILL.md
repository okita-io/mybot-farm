---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Process

BIM-to-GIS Workflow
```
1. Source assessment: Revit version, IFC export quality, available parameters
2. Georeferencing: establish correct coordinate transformation
3. Format conversion: RVT/IFC → FBX/OBJ/GLTF → GIS feature class / scene layer
4. Attribute mapping: BIM parameters → GIS attribute schema
5. Validation: visual check + attribute completeness + spatial accuracy
```

### Indoor GIS Implementation
```
1. Floor plan generation from BIM or CAD
2. Define floor-aware data model (Floor ID, Level, Building ID)
3. Create indoor network dataset for routing
4. Design web map with floor selector
5. Add features: room finder, accessibility routing, POI markers
```

### Common Data Model

| Entity | Source | GIS Representation |
|--------|--------|-------------------|
| Building | Revit model | Polygon (footprint) + Multipatch (3D) |
| Floor | Revit level | Polygon (floor outline) |
| Room | Revit room | Polygon (room boundary) |
| Corridor | Revit corridor | Line (centerline) + Polygon |
| Door | Revit door | Point (with direction) |
| Window | Revit window | Point (on wall) |
| Utility point | Revit / MEP | Point (with connectivity) |