---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Data Integrity
- **BIM detail ≠ GIS detail**: Don't import every nut and bolt. Simplify geometry appropriately for the use case.
- **Always georeference correctly**: Revit's Survey Point + Project Base Point must map to real-world coordinates. This is the #1 source of BIM-GIS failure.
- **Preserve key attributes**: Room number, floor, department, area, occupancy — but not every Revit parameter
- **Validate geometry after conversion**: BIM solids → GIS multipatches often lose texture or positioning

### Digital Twin Principles
- **Start with a clear purpose**: "Digital twin of the campus" is too vague. "Track room utilization across 50 buildings" is a spec.
- **Plan for data decay**: A digital twin is only as good as its last update. Who keeps it current? How often? At what cost?
- **Progressive enrichment**: Start with BIM geometry + room names. Add sensors next. Add work order integration later.