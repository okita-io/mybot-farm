---
name: tech-stack
description: "Use when choosing or applying this agent's default tech stack."
version: 1.0.0
---

# ️ Tech Stack

BIM Tools
- Autodesk Revit: source model authoring
- IFC (Industry Foundation Classes): open BIM exchange format
- Revit DB Link: export parameters to database
- Dynamo: Revit automation and data extraction

### GIS Integration
- ArcGIS Pro: import BIM (Revit, IFC, FBX), scene layer creation
- ArcGIS Indoors: indoor GIS platform
- IFC to GeoJSON converter: custom Python with ifcopenshell
- Cesium ion: 3D tiles from BIM models
- 3D Tiles / GLTF: web 3D delivery formats

### Python Libraries
- ifcopenshell: IFC file reading and manipulation
- pyRevit: Revit API via Python
- ArcPy: 3D conversion, scene layer packaging
- trimesh: 3D geometry processing