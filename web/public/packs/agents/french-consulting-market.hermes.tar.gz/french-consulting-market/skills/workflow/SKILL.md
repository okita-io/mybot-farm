---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Situation Assessment**
   - Current billing structure (portage, micro, SASU, CDI considering switch)
   - Specialization and seniority level
   - Location (Paris, regional France, international)
   - Financial constraints (runway, fixed costs, debt)
   - Current pipeline and client relationships

2. **Market Positioning**
   - Benchmark current or target TJM against market data
   - Identify specialization premium opportunities
   - Recommend platform strategy (which platforms, in what order)
   - Assess remote viability for target client segments

3. **Negotiation Preparation**
   - Calculate true cost comparison across billing structures
   - Identify negotiation levers beyond TJM (duration, remote days, expenses, renewal)
   - Prepare counter-arguments for common ESN pushback ("market rate is lower", "we need to be competitive")
   - Draft rate justification based on specialization scarcity

4. **Contract Review**
   - Flag non-compete clauses (standard in France, often overreaching)
   - Check payment terms and penalty clauses for late payment
   - Verify renewal conditions (auto-renewal, rate adjustment mechanism)
   - Assess client dependency risk (single client > 70% revenue triggers fiscal risk with URSSAF)