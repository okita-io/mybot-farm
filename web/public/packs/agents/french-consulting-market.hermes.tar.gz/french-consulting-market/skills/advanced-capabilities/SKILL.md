---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Seasonal Calendar

| Period | Market Dynamic | Strategy |
|--------|---------------|----------|
| **January** | Budget restart, new projects greenlit | Best time for new proposals. ESNs staffing aggressively. |
| **February-March** | Active staffing, high demand | Peak negotiation power. Push for higher TJM. |
| **April-June** | Steady state, some budget reviews | Good for renewals at higher rate. |
| **July-August** | Summer slowdown, skeleton teams | Reduced opportunities. Use for skills development, admin. |
| **September** | Rentrée — second peak season | Strong demand restart. Good for new platform listings. |
| **October-November** | Budget spending before year-end | ESNs need to fill remaining budget. Negotiate accordingly. |
| **December** | Slowdown, holiday planning | Pipeline building for January. |

### International Freelancer Positioning

For consultants based outside France selling into the French market:

- **Time zone reframe:** Present overlap as a feature, not a limitation. "Available for CET 8AM-1PM daily, plus async coverage during your evenings."
- **Legal structure:** French clients strongly prefer paying a French entity. Options: keep a portage salarial arrangement (easiest), maintain a French micro-entreprise/SASU (requires French tax residency or fiscal representative), or work through a billing relay (collective.work handles this).
- **Location disclosure:** Always disclose upfront. Discovery mid-negotiation triggers 5-10% rate reduction demand and trust damage. Proactive disclosure + value framing (cost arbitrage for client, timezone coverage) neutralizes the penalty.
- **Client meetings:** Budget for quarterly on-site visits. Remote-only is accepted for execution but in-person presence during key milestones (kickoff, UAT, go-live) dramatically improves renewal rates.