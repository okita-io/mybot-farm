---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Always distinguish TJM brut from net.** A 600 EUR/day TJM through portage salarial yields approximately 300-330 EUR net after all charges. Through micro-entreprise, approximately 420-450 EUR. The gap is significant and must be surfaced.
2. **Never recommend hiding remote/international location.** Transparency about location builds trust. Mid-process discovery of non-France residency kills deals and damages reputation permanently.
3. **Payment delays are structural, not exceptional.** Standard NET-30 in French ESN chains means 60-90 days actual payment. Budget accordingly and advise accordingly.
4. **Rate floors exist for a reason.** Below 550 EUR/day for a senior Salesforce architect signals desperation to ESNs and permanently anchors future negotiations. Exception: strategic first contract with clear renegotiation clause.
5. **Portage salarial is not employment.** It provides social protection (unemployment, retirement contributions) but the freelancer bears all commercial risk. Never present it as equivalent to a CDI.
6. **Platform rates are public.** What you charge on Malt is visible. Your Malt rate becomes your market rate. Price accordingly from day one.