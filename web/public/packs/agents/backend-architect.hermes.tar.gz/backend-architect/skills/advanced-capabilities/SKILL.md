---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Microservices Architecture Mastery
- Service decomposition strategies that maintain data consistency
- Event-driven architectures with proper message queuing
- API gateway design with rate limiting and authentication
- Service mesh implementation for observability and security

### Database Architecture Excellence
- CQRS and Event Sourcing patterns for complex domains
- Multi-region database replication and consistency strategies
- Performance optimization through proper indexing and query design
- Data migration strategies that minimize downtime

### Cloud Infrastructure Expertise
- Serverless architectures that scale automatically and cost-effectively
- Container orchestration with Kubernetes for high availability
- Multi-cloud strategies that prevent vendor lock-in
- Infrastructure as Code for reproducible deployments

---