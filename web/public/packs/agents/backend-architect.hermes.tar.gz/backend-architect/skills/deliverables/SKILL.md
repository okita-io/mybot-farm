---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Architecture Deliverables

System Architecture Design
```markdown
# System Architecture Specification

## High-Level Architecture
**Architecture Pattern**: [Monolith/Modular Monolith/Microservices/Serverless/Hybrid]
**Communication Pattern**: [REST/GraphQL/gRPC/Event-driven]
**Data Pattern**: [CQRS/Event Sourcing/Traditional CRUD]
**Deployment Pattern**: [Container/Serverless/Traditional]
**API Contract**: [OpenAPI/AsyncAPI/protobuf]
**Migration Strategy**: [Expand-contract/Blue-green/Shadow writes/Backfill]
**Reliability Pattern**: [Timeouts/Retries/Circuit breakers/Bulkheads/DLQ]
**Observability Pattern**: [Logs/Metrics/Tracing/SLOs]

## Service Decomposition
### Core Services
**User Service**: Authentication, user management, profiles
- Database: PostgreSQL with user data encryption
- APIs: REST endpoints for user operations
- Events: User created, updated, deleted events

**Product Service**: Product catalog, inventory management
- Database: PostgreSQL with read replicas
- Cache: Redis for frequently accessed products
- APIs: GraphQL for flexible product queries

**Order Service**: Order processing, payment integration
- Database: PostgreSQL with ACID compliance
- Queue: RabbitMQ for order processing pipeline
- APIs: REST with webhook callbacks
```

### Database Architecture
```sql
-- Example: E-commerce Database Schema Design

-- Users table with proper indexing and security
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL, -- bcrypt hashed
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    deleted_at TIMESTAMP WITH TIME ZONE NULL -- Soft delete
);

-- Indexes for performance
CREATE INDEX idx_users_email ON users(email) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_created_at ON users(created_at);

-- Products table with proper normalization
CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
    category_id UUID REFERENCES categories(id),
    inventory_count INTEGER DEFAULT 0 CHECK (inventory_count >= 0),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_active BOOLEAN DEFAULT true
);

-- Optimized indexes for common queries
CREATE INDEX idx_products_category ON products(category_id) WHERE is_active = true;
CREATE INDEX idx_products_price ON products(price) WHERE is_active = true;
CREATE INDEX idx_products_name_search ON products USING gin(to_tsvector('english', name));
```

### API Design Specification
```yaml
# API contract checklist
openapi: 3.1.0
paths:
  /api/users/{id}:
    get:
      operationId: getUserById
      security:
        - oauth2: [users:read]
      parameters:
        - name: id
          in: path
          required: true
          schema:
            type: string
            format: uuid
        - name: X-Correlation-ID
          in: header
          required: false
          schema:
            type: string
      responses:
        '200':
          description: User found
        '404':
          description: User not found
        '429':
          description: Rate limit exceeded
        '503':
          description: Dependency unavailable
```