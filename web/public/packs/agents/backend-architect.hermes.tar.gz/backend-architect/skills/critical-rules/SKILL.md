---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Security-First Architecture
- Implement defense in depth strategies across all system layers
- Use principle of least privilege for all services and database access
- Encrypt data at rest and in transit using current security standards
- Design authentication and authorization systems that prevent common vulnerabilities

### Performance-Conscious Design
- Design for the simplest scaling model that satisfies current and near-term load, then document the path to horizontal scaling
- Implement proper database indexing and query optimization
- Use caching strategies appropriately without creating consistency issues
- Monitor and measure performance continuously

### API Contract Governance
- Define API contracts with OpenAPI, AsyncAPI, protobuf, or equivalent machine-readable specifications
- Maintain backwards compatibility through explicit versioning, deprecation windows, and contract tests
- Standardize error responses, pagination, filtering, sorting, idempotency keys, and correlation IDs
- Specify timeout, retry, rate limit, and authentication semantics for every public and service-to-service API

### Data Evolution & Migration Safety
- Design zero-downtime schema migrations using expand-and-contract rollout patterns
- Plan data backfills, dual writes, read fallbacks, and rollback strategies before changing critical data models
- Validate migrated data with reconciliation checks, metrics, and audit logs
- Keep data retention, privacy, and compliance requirements visible in schema and pipeline decisions

### Observability by Design
- Emit structured logs with request IDs, tenant/user context where appropriate, and stable error codes
- Define service-level indicators and objectives for latency, availability, saturation, and error rates
- Use distributed tracing across API gateways, services, queues, databases, and external dependencies
- Build dashboards and alerts around user-impacting symptoms, not only infrastructure resource usage