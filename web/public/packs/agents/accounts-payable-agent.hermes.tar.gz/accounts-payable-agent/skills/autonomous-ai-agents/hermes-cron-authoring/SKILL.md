---
name: hermes-cron-authoring
description: "Author Hermes cron jobs, esp. no-agent script jobs."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [macos, linux]
metadata:
  hermes:
    tags: [cron, scheduling, no-agent, scripts, watchdog, hermes]
    category: autonomous-ai-agents
---

# Hermes Cron Job Authoring

Authoring `cronjob`-tool jobs — especially **no-agent script jobs** — where the
script IS the job, output delivery is stdout-driven, and the cost of a bad
pattern (file clobbering, missed slots, unverified runs) shows up days later.

## When to Use
- Creating a recurring scheduled job (reports, scans, watchdogs, digests).
- A job needs to run more than once per day and write to date-stamped files.
- Editing/retiring existing scheduled jobs.

## No-agent script jobs: the silent-output contract
- `script=` is a **bare path — no arguments are ever passed.** `script: "run.sh arg"` fails with `Script not found: .../run.sh arg`. If the same script must serve multiple jobs (or multiple hours), write one thin wrapper per job (`run_standup.sh` → `exec run.sh standup`) and point each job at its wrapper; keep the shared script as the source of logic. One wrapper ≈ 2 lines; this is cheaper than duplicating logic into N scripts.
`no_agent=true` + `script=` runs the script on schedule; its **stdout is the
delivery** — and empty stdout = **nothing delivered** (zero LLM tokens most
ticks). This is the right shape for deterministic checks/watchdogs:
- Print ONLY when there is something to say (intervention report, generated
  report). Healthy tick → no output → no delivery.
- Non-zero exit / timeout = error alert.
- Keep the job prompt a short description of what the script does; the script
  carries all logic.
- `.sh` runs via bash, everything else via Python; relative paths resolve under
  `~/.hermes/scripts/`.

**Editing a no-agent job = editing its script.** The cron prompt is inert
context; there is no agent to drift. A script edit takes effect at the next
tick — no re-scheduling needed.

## Multiple runs/day: make the script time-aware
When two runs share a day and a naive `OUT=News-$(date +%F).md` clobbers the
first run's output, put the time logic IN the script, not in two separate
scripts:
```bash
HOUR=$(date +%H)
if [ "$HOUR" -ge 11 ]; then SUFFIX="-pre-lunch"; TITLE="... (pre-lunch)"; fi
OUT="$DIR/News-$DATE$SUFFIX.md"
```
Then ONE shared script serves both jobs (each `cronjob` entry points at the
same `script=`). Keep a per-run extra instruction (e.g. "prioritize items new
since the morning run; end with ACTION ITEMS") as a conditional `EXTRA`
variable interpolated into the prompt the script builds. Verify the branch
logic by simulating hours: `for H in 08 11 15; do [ $H -ge 11 ] && echo "$H → suffix"; done`.

## Incremental monitoring jobs: per-source watermarks
When a job triages a live service continuously (crawler APIs, queues, feeds), do
NOT re-feed the whole table to the LLM every tick — keep **per-source watermarks**
in a state file and hand over only new rows. Pattern verified against a
ts-desc paginated API (5 collections, token-auth):
- State file = JSON: `{"BOOTSTRAPPED": true, "<source>": "<ts>", ...}` — one key
  per collection/table, never one global max (sources tick at different rates).
- The fetcher (python module next to the .sh) emits only rows newer than each
  source's watermark, plus a `@@STATE@@ <json>` line; the shell wrapper persists
  that line to the state file after a successful fetch.
- When the API returns ts-descending pages, stop paging once `ts <= watermark` —
  that marks the end of the new region (break, don't keep scanning).
- **Bootstrap**: first run seeds watermarks to the current max and hands over
  NOTHING — don't dump the full history into the first review. A `BOOTSTRAPPED`
  marker in the state lets the wrapper print a distinct "seeded" message instead
  of a false "no new items".
- **Legacy migration**: if an old job kept a single-line watermark, adopt it only
  for the sources it tracked; let newly added sources bootstrap.
- Cap new items per run (e.g. 25 per source) to bound prompt size; parse
  timestamps as datetimes, never string-compare ISO-8601.

Before the real tick, test both paths against a **temp copy of the state file**
(bootstrap, then incremental from the seeded state), confirm the real state file
was not advanced by the tests, and only then run the real script once to
bootstrap. This keeps the production watermark honest.

## Schedule pitfalls
1. **Check `next_run_at` in the create response.** If it is *tomorrow* when
   today's slot is still ahead, the scheduler is fine but you may have missed
   the slot while authoring (it can be minutes late): trigger the first run
   with `cronjob(action='run', job_id=…)` so the user still gets today's output.
2. **A second manual run while one is executing is refused** with "Job is
   already running" — that is a safe refusal, not an error. Don't loop retries.
3. Cron fields are local-timezone; a "11:30am PST" request on a PDT machine is
   just `30 11 * * *`.
4. For LLM-driven reports, keep each report self-contained ("each report stands
   alone — do not reference previous reports") so a missed day can't poison a
   later one.

## First-run verification gate (do all five)
1. `bash -n <script>` (syntax) + `grep` for the new section/strings you added.
2. Fire a manual run: `cronjob(action='run', job_id=…)` — it runs in the
   background; the completion re-enters the conversation as a message.
3. When it lands, check the **output file on disk**: mtime is fresh, size sane.
4. `grep` the file for the section headers/structure you expect (structure, not
   just existence — a file can be created with the wrong shape).
5. Only then report the job as working; note the next scheduled run.

## Pitfalls
- **Delivery target: `origin` from a desktop/CLI session can be local-only.**
  When the create response says "local-only cron job … will NOT be delivered
  back into this session", the user gets nothing at fire time. For
  user-facing reports/digests, set `deliver='all'` (resolves to all connected
  gateways at fire time) or a specific gateway platform. `origin` is only
  right when the originating chat has a live delivery channel.
- **Don't create near-duplicate jobs** for "morning vs evening" of the same
  scan — one time-aware script + two thin job entries beats two scripts that
  diverge.
- **Update, don't recreate**, when changing an existing job's schedule/script
  (`cronjob action='update'` with the `job_id` from `list` — never guess IDs).
- A script that exits non-zero on a benign "already running / no change" state
  will spam error alerts; make idempotent no-ops exit 0 silently.
- **no_agent scripts have a flat engine timeout (observed 3600s) — agent work is not exempt.** A script that invokes an LLM agent (`hermes -p X chat ...`) blocks the script slot until the agent finishes; deep reasoning runs legitimately exceed 1h, so the job FAILS with `Script timed out after 3600s` even when the agent already completed its work (the verdict was written; only the wrapper died). For agent-invoking no-agent jobs, DETACH: `nohup hermes -p P chat ... >> report.log 2>&1 &` + `echo "agent detached (pid $!)"` + exit 0 — the agent's artifacts land in the shared files regardless, and the job's stdout becomes the one-line dispatch receipt. Keep blocking (foreground) form only for quick deterministic checks.
- **Agent-invoking scripts: named sessions pin a stale model.** A script that
  DMs another agent via `hermes -p <profile> chat -c "<name>"` *resumes* that
  named session — which restores the model it last ran on (NOT the profile's
  current `config.yaml`) and keeps accumulating turns. A session created before
  a fleet-wide model migration keeps running on the old model, and a bloated
  session eventually fails the job with "Context length exceeded … cannot
  compress further". For scheduled invocations, start a FRESH session per run
  (drop the persistent session name or use a rotating one); if a persistent
  session is genuinely needed, first check the `model`/`provider` columns of
  that profile's `state.db` `sessions` table against the current config.
- Cross-reference: for on-wake repair paired with a periodic no-agent watchdog,
  see `hermes-plugin-authoring` (layered keep-alive pattern).
