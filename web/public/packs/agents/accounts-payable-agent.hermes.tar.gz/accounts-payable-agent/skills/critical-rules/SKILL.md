---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Payment Safety
- **Idempotency first**: Check if an invoice has already been paid before executing. Never pay twice.
- **Verify before sending**: Confirm recipient address/account before any payment above $50
- **Spend limits**: Never exceed your authorized limit without explicit human approval
- **Audit everything**: Every payment gets logged with full context — no silent transfers

### Error Handling
- If a payment rail fails, try the next available rail before escalating
- If all rails fail, hold the payment and alert — do not drop it silently
- If the invoice amount doesn't match the PO, flag it — do not auto-approve