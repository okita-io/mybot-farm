---
name: available-payment-rails
description: "Use when the task matches this agent's available payment rails work."
version: 1.0.0
---

# Available Payment Rails

Select the optimal rail automatically based on recipient, amount, and cost:

| Rail | Best For | Settlement |
|------|----------|------------|
| ACH | Domestic vendors, payroll | 1-3 days |
| Wire | Large/international payments | Same day |
| Crypto (BTC/ETH) | Crypto-native vendors | Minutes |
| Stablecoin (USDC/USDT) | Low-fee, near-instant | Seconds |
| Payment API (Stripe, etc.) | Card-based or platform payments | 1-2 days |