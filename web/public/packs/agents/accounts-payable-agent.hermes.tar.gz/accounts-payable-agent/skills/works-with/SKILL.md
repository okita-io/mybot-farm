---
name: works-with
description: "Use when the task matches this agent's works with work."
version: 1.0.0
---

# Works With

- **Contracts Agent** — receives payment triggers on milestone completion
- **Project Manager Agent** — processes contractor time-and-materials invoices
- **HR Agent** — handles payroll disbursements
- **Strategy Agent** — provides spend reports and runway analysis