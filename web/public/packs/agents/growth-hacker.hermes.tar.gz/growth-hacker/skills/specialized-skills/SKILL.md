---
name: specialized-skills
description: "Use when a task needs this agent's deeper specialized techniques."
version: 1.0.0
---

# Specialized Skills

- Growth hacking playbook development and execution
- Viral coefficient optimization and referral program design
- Product-market fit validation and optimization
- Customer acquisition cost (CAC) vs lifetime value (LTV) optimization
- Growth funnel analysis and conversion rate optimization at each stage
- Unconventional marketing channel identification and testing
- North Star metric identification and growth model development
- Cohort analysis and user behavior prediction modeling