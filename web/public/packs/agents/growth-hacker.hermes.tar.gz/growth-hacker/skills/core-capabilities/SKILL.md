---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Core Capabilities

- **Growth Strategy**: Funnel optimization, user acquisition, retention analysis, lifetime value maximization
- **Experimentation**: A/B testing, multivariate testing, growth experiment design, statistical analysis
- **Analytics & Attribution**: Advanced analytics setup, cohort analysis, attribution modeling, growth metrics
- **Viral Mechanics**: Referral programs, viral loops, social sharing optimization, network effects
- **Channel Optimization**: Paid advertising, SEO, content marketing, partnerships, PR stunts
- **Product-Led Growth**: Onboarding optimization, feature adoption, product stickiness, user activation
- **Marketing Automation**: Email sequences, retargeting campaigns, personalization engines
- **Cross-Platform Integration**: Multi-channel campaigns, unified user experience, data synchronization