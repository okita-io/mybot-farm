---
name: Grant narrative humanize
description: "Use when polishing a grant LOI or proposal draft so it sounds natural and human—strip AI tells, keep scholarly/fundable voice, match claims to evidence or feasibility, and preserve every number and citation. Not for detector evasion."
version: 1.0.0
---

# Grant narrative humanize

Post-draft pass to make grant prose sound **natural, precise, and fundable** — strip AI tells without casualizing, and match claims to evidence (papers) or **claims to feasibility** (proposals). Prefer the funder's format and page limits over this guide.

**Ethics:** clarity and voice editing only. Never change numbers, citations, results, eligibility facts, or partner names. Never invent preliminary data, prior awards, letters, or collaborators. Not for evading AI-detection products or hiding required AI-use disclosure.

**When:** after a draft LOI, narrative, Specific Aims, Project Summary, or foundation proposal section — before or alongside proposal review. For first drafts from scratch, use Grant narrative composition first.

Adapted (paraphrased) from open patterns in academic-humanizer (MIT) and general AI-tell catalogs; grant mode is the priority here.

## Process

1. **Read** — note document type (LOI / foundation narrative / NSF / NIH / other), agency, and any author voice sample.
2. **Audit (do not edit yet)** — list AI tells with locations; list empirical or ambition claims and their evidence/feasibility footing.
3. **Rewrite** — same structure and coverage; remove tells; align claim strength to evidence/feasibility; keep legitimate hedging in the Approach, not in the central hypothesis.
4. **Report** — cleaned text + short change log (patterns removed, claims softened or anchored, voice notes). Confirm no numbers/citations altered.

## Layer A — General AI tells (remove)

Fix inflated significance; fake-depth `-ing` tails; promotional words (*groundbreaking, vibrant, tapestry, delve, underscore, intricate, pivotal, seamless, leverage* as filler); vague “experts say” with no cite; “not just X but Y”; synonym cycling; filler (*it is worth noting*, *in order to*); clause-stacked sentences (split them); decorative em dashes (recast with commas/colons/parentheses/sentences).

## Layer B — Academic / proposal weak verbs

- Prefer *shows / provides evidence / improves by N* over *proves / revolutionizes / guarantees*.
- Drop empty significance (*paves the way, sheds light, of paramount importance*) unless replaced with a concrete cost-of-gap sentence.
- Keep calibrated hedging where evidence is limited; do not hedge the **central hypothesis** into mush.

## Layer C — Funding-proposal mode (use for grants)

A proposal sells **vision + feasibility**, not finished paper results. Ambition language (*long-term goal, establish a foundation*) is often appropriate **if** a plan and evidence back it. Do **not** flatten vision the way you would in a methods paper; enforce **claim ↔ feasibility** instead.

### First-page primacy
Reviewers score early. Edit the opening hardest.
- **Foundation / LOI:** who you are, need, project in brief, ask, why this funder — concrete, no fluff.
- **NSF-like:** Project Summary heads (Overview / Intellectual Merit / Broader Impacts); Description opens vision → goal → gap → thrusts → payoff quickly.
- **NIH-like Aims page:** problem → known → **gap/critical need** → long-term goal + **central hypothesis** → “The objective of this application is…” → 2–3 **parallel** Aims (goal + approach phrase + expected outcome) → payoff. Then Significance / Innovation / Approach as required.

By the end of page 1 (Aims) or ~pages 2–3 (NSF-style), the reader must hold: hook, gap, central idea, aims/thrusts, payoff.

### Proposal-specific fixes
- Vague importance → concrete cost of the gap.
- Method-as-aim → aim as question/outcome, not technique name alone.
- Dominoed aims → parallel, independently valuable aims; state fallbacks if dependent.
- Ambition without footing → attach preliminary data, prior result, collaborator, or stage de-risking **from supplied facts only**.
- Boilerplate broader impacts / training → concrete, enumerated, tied to the work.
- Hedged central hypothesis → falsifiable commitment on the Aims page.

### Keep / deploy (strengths)
Vision framing; scannable **Goal / Aim N** lead-ins; one running example; sharp aim-as-question; named classical foundations; real team track record placed early as feasibility (never invent it).

## Output checklist

- [ ] Cleaned text covers the same ground as the draft
- [ ] No numbers, citations, or factual claims silently changed
- [ ] Change log lists tell types removed and claim↔feasibility notes
- [ ] Gaps that need author input (missing prelim data, etc.) are flagged, not fabricated
- [ ] If funder forbids undisclosed AI assistance, remind the user to follow disclosure rules

## Don't

- Casualize into blog/marketing voice
- Game AI detectors
- Invent evidence, partners, budgets, or outcomes
- Contact or submit anything unless the user explicitly asks
