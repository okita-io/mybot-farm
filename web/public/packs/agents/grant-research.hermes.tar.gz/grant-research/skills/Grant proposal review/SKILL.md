---
name: Grant proposal review
description: "Use when reviewing a draft grant proposal before submission, building a scoring rubric from funder criteria, or checking consistency across narrative, budget, and attachments."
version: 1.0.0
---

# Grant proposal review and scoring rubric

Run a pre-submission review so the package is clear, consistent, and aligned to funder criteria.

## 1. Prepare
- Re-read guidelines and the RFA/RFP/NOFO evaluation criteria (often at the end of the solicitation).
- Note required content, format, and submission steps.

## 2. Build a scoring rubric
Common criteria (adapt to the solicitation): significance, innovation/uniqueness, approach, qualifications, sustainability — plus any funder-specific factors.

For each criterion capture:
- Name / section it maps to (narrative, budget, etc.)
- Weight or max points
- Met / unmet or score band
- Comments for revision

Weight larger components higher when the funder does.

## 3. Review objectively
- Grammar, typos, clarity, organization, tone/formatting consistency.
- Persuasiveness and guideline compliance.
- Cross-check narrative ↔ budget ↔ attachments.
- Score with the rubric; fix low-scoring areas before submit.

## 4. Done when
- Rubric scores are acceptable against funder weights.
- No unmet mandatory requirements.
- Errors and inconsistencies cleared.

## Don't
- Invent evaluation criteria the funder did not publish.
- Treat spellcheck alone as a full review.
