---
name: Grant narrative composition
description: "Use when outlining or drafting a grant proposal narrative, organizing sections, or checking narrative quality against funder guidelines."
version: 1.0.0
---

# Grant narrative composition

Help produce a persuasive, guideline-aligned narrative. Prefer the funder's required structure over any default outline.

## 1. Lock requirements
- Re-read RFA / RFP / NOFO: themes, page limits, fonts, section order.
- List every required narrative heading before writing.

## 2. Plan
- Problem/opportunity the project addresses.
- SMART objectives tailored to this funder and project.
- Concise outline covering goals, methods/timeline, outcomes, and any required evaluation/budget narrative links.

## 3. Write
Narrative should be organized, evidence-backed, persuasive, and impact-focused:
- State goals and objectives clearly.
- Describe methods to achieve them.
- Show expected outcomes and why the project is worth funding.
- Use relevant data/statistics; cite real sources only.

## 4. Common failure modes to avoid
- Ignoring guidelines or page limits.
- Vague goals (not SMART).
- Weak evidence of need.
- Jargon-heavy or disorganized prose.
- Inconsistency with budget or attachments.

## Don't
- Fabricate statistics, partners, or prior results.
- Paste long boilerplate that ignores this solicitation.
