---
name: Grant funder research and LOI
description: "Use when researching a grant maker, sizing fit and typical awards, drafting or sending a letter of inquiry (LOI), following up after an LOI or submission, preparing for presentations/negotiations, or handling decline/award stewardship — before full proposal drafting."
version: 1.0.0
---

# Grant funder research and LOI

Research-and-pursuit playbook for matching a project to a funder and opening the door with an LOI. Prefer the funder's published guidelines over this outline. **Research and draft only** unless the user explicitly asks to contact or submit.

Hand off to other grant skills when the work becomes a full proposal package:
- Process map / components → Grant proposal process
- Narrative draft → Grant narrative composition
- Budget → Grant budget development
- Attachments / LOS → Grant attachments and materials / Grant letters of support
- Pre-submit QA → Grant proposal review

## 1. Research the grant maker

Before any LOI, gather evidence (cite sources; never invent):

| Check | Why it matters |
|-------|----------------|
| How much they gave last year | Capacity and seriousness |
| Typical award size vs. your ask | Fit of dollar amount |
| Who they funded, and for what | Pattern match to your project |
| Board / income-producing investments | Stability and priorities |
| 990 / Foundation Directory / Guidestar-style listings | Official footprint |
| Fit: your need vs. their goals | Go / no-go |

Output a short **fit memo**: go / stretch / no-go, with sources and a recommended ask range.

## 2. Letter of inquiry (LOI)

### Style
- Short, clean, no fluff — substance over decoration.
- Individualize each ask. **Do not shotgun** identical LOIs to a list.
- Pick targets deliberately; quality over volume.

### Include vs. leave out
- Include: who you are (org), the need, the project in brief, ask amount/range if appropriate, why this funder, clear contact.
- Leave out: full proposal narrative, dense budgets, insider jargon, strategy details you would not want public.
- If you are a **paid grantwriter**, identify that role honestly when relevant.

### Sending paths
- Online LOI: draft in a word processor, then copy/paste into the portal (preserve plain language and limits).
- Stamped mailed LOI: same content discipline; follow any format rules.
- Personal contact first (when allowed and natural).
- Personal contact as follow-up to an LOI (when guidelines allow).

## 3. After the LOI

- Use LinkedIn / association networks professionally — relationship, not spam.
- Talk the project up without leaking competitive strategy or confidential details.

## 4. Rules and sector norms

### Universal
- Award money remains the funder's until the project is properly completed under their terms.
- Keep the grant maker informed with regular, unsolicited progress updates when appropriate.
- Manage awards with separate accounts, every penny tracked, restricted use honored, and public thanks only as they prefer.

### Public-sector grants
- Follow the letter of the solicitation; complete every required form.
- No private gifts / improper inducements.
- Find the **real** contact; search official government sites; verify eligibility.
- Packet completeness and deadlines are hard gates; use one designated contact.

### Corporate giving
- Motives may be profit, community, industry, or goodwill — match their interests, not only yours.
- Find makers via Foundation Center / AFP / Guidestar-style directories and corporate giving pages.
- Advisory notices, appeals, idea-asks, and out-of-the-box forums may apply — follow their channel.

## 5. Writing the proposal (bridge)

When research/LOI succeeds and a full proposal is required, switch to the dedicated proposal skills. Standing reminders from this playbook:

- Online or paper: follow guidelines, word limits, attachments, plain language.
- Easy to read: clear type; photos/charts only if they earn space; history, who you serve, why you exist, the need, staff picture without clutter.
- Close cleanly: no last-minute surprise money ask; include budget; org head signs.
- Only the hired grant writer (if any) writes it — no ghost confusion.
- Keep audit-ready backup of every claim.

### Proposal priorities
1. **Most important:** follow their instructions (fonts, length, no extras).
2. **Second:** put the request up front, then the rest of the packet.

## 6. Follow-up after submit

- Wait, then one polite status check — do not nag.
- Fix gaps promptly if they ask.
- Optional standalone project page: uncluttered, password if needed, photos/video, easy contact.
- Social outreach supports visibility; it is not a second proposal.

## 7. If they say no

- Personal contact is usually fine unless they banned it.
- Good impression: friendly, brief, purpose first — no family/small talk.
- Waiting windows often run ~1–6 weeks; bigger asks take longer.
- While waiting: gather materials; line up people with access for the next cycle.

## 8. In-person presentations

- Professional presenter look — not a “poor nonprofit” costume.
- Tie your need to **their** goals.
- Color slides, short deck, script you do not read aloud; leave-behind packet.
- Board members often follow funder rules — do not push them to break those.

## 9. House in order / accountability

Before and after awards: bookkeeping, multi-year budgets, tax returns, volunteer/project records, written org history, clear project definition, no insider jargon, donor database, prior awards, brick-and-mortar vs. program readiness, in-house vs. borrowed expertise, fund disbursement plan, dual-control checking, transparency, assume an audit.

## 10. Negotiations (if funded)

- Public thanks / plaque only if they want it.
- If the situation changes, tell them immediately.
- Unused funds, purpose drift, or poor bookkeeping can mean clawback, repayment, or legal trouble.

## 11. Audit

- Private and government funders can audit — assume it.
- Keep docs and a paper trail. Opacity or lost money can kill this award and the next.

## 12. Hiring a grantwriter

- Check AFP / GPPA-type affiliations; ask for samples and workload.
- Success-rate claims are often unverifiable — treat carefully.
- **No percentage-of-award / commission** (unethical and often banned).
- They should not be paid only if you win.

## 13. Celebrate (when appropriate)

- Scale thanks to the gift; invite their people; optional award moment or video.
- Press only if they want it — and it can double as fundraising.

## Don't

- Invent funder giving history, board facts, award sizes, or contacts.
- Mass-blast identical LOIs.
- Contact or submit without an explicit user ask.
- Treat social posts as a substitute proposal.

## Optional deliverable

When useful, produce a one-page **“where am I in the process”** checklist for a specific grant (research → LOI → proposal → follow-up → award/decline).
