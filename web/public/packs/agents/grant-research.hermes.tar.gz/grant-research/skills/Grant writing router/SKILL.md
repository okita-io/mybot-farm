---
name: Grant writing router
description: "Use when starting grant-writing help and you need to pick which grant skill to load, or when the task spans multiple grant-proposal steps."
version: 1.0.0
---

# Grant writing skill router

Choose the narrowest skill for the task. Prefer funder solicitation text over generic guidance.

| If the user needs… | Use |
|--------------------|-----|
| Open FOA/NOFO search, grants.gov shortlist | Grant opportunity search |
| One-page “where am I” checklist for a specific grant | Grant process checklist |
| Funder research, fit memo, LOI, post-LOI follow-up, decline/award stewardship | Grant funder research and LOI |
| Process map, eligibility, deadlines, component list | Grant proposal process |
| Drafting/outlining the narrative | Grant narrative composition |
| Humanize / de-AI-slop a draft (keep claims & numbers) | Grant narrative humanize |
| Line items, match, justification | Grant budget development |
| Resumes, charts, timelines, logic models, figures | Grant attachments and materials |
| Support / collaboration / commitment letters | Grant letters of support |
| Pre-submit QA and rubric scoring | Grant proposal review |

## Standing rules
- Research and draft only unless the user explicitly asks to submit or contact someone.
- Never invent eligibility, rates, partners, giving history, or evidence.
- Typical flow: opportunity search → funder research / LOI → checklist → draft (narrative/budget/…) → **humanize** → proposal review.
- Skip crypto/web3 “grants.”

## Output
Say which skill you are applying, then run its steps.
