---
name: Grant budget development
description: "Use when building or reviewing a grant project budget, line items, matching/in-kind, or budget justification."
version: 1.0.0
---

# Grant budget development

Build a project-specific grant budget (not an org operating budget) that shows where award funds go and supports compliance.

## 1. Purpose
- Plan/manage project finances; demonstrate responsibility; enable tracking and adjustments.
- Match funder cost categories and allowability rules.

## 2. Typical line items
- Personnel (headcount, rates, % effort or hours, duration)
- Fringe benefits (per org policy)
- Travel (transport, lodging, meals — follow funder travel rules)
- Equipment
- Supplies and materials
- Contractual / consultants
- Indirect costs (if allowed; use approved rate or funder cap)
- Matching and in-kind (if required or offered)

## 3. Budget justification
- Explain why each major cost is necessary and reasonable for the project.
- Tie personnel effort and big purchases to narrative activities.

## 4. Common mistakes to avoid
- Math errors; costs that don't match the narrative.
- Unallowable costs; missing required match.
- Inflated or unexplained line items.
- Treating the grant budget like a general ops budget.

## Don't
- Invent approved indirect rates or allowability.
- Hide costs that belong in the narrative scope.
