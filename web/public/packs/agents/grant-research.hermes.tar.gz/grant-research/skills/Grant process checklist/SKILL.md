---
name: Grant process checklist
description: "Use when tracking a specific grant through house-in-order, funder research, LOI/approach, proposal, follow-up, and award stewardship — or when the user wants a one-page “where am I” checklist."
version: 1.0.0
---

# Grant process checklist

One-page tracker for a **specific** grant. Fill the header, then work the boxes in order. Prefer the funder's published rules over this list. Research and draft only unless the user explicitly asks to contact or submit.

Pair with Grant funder research and LOI for how to do each section; use proposal skills when section 4 becomes a full package.

Copy this template into the reply (or a note) and mark items done.

```
# Grant process checklist

**Grant:** ________
**Funder:** ________
**Type:** public / corporate / foundation
**Deadline:** ________
**Ask:** $________
**Named contact:** ________

## 1. House in order
[ ] Books current
[ ] 5-year budget + tax returns ready
[ ] Org history written (plain language)
[ ] Project defined, no insider jargon
[ ] Prior awards / donor records in one place
[ ] Disbursement plan + dual-control checking

## 2. Research this funder
[ ] Last year's giving + typical award size
[ ] Who they funded, and for what
[ ] 990 / directory listing pulled
[ ] Their goals actually match this need
[ ] Eligibility confirmed (don't skip this)
[ ] Ask is in their range, not the lion's share

## 3. Approach
[ ] Real contact, not a general inbox
[ ] LOI fits their format (not a cloned blast)
[ ] Role disclosed if a paid grantwriter is sending it
[ ] Sent via: online / mail / personal — date: ________
[ ] Wait window on the calendar (often 1–6 weeks)
[ ] Backup materials + access people lined up while you wait

## 4. Proposal
[ ] Their instructions followed exactly (length, font, attachments)
[ ] The ask is on the first screen/page
[ ] Need + who you serve + why you exist
[ ] Budget and cost breakdown included
[ ] Signed by the org head
[ ] Only the authorized writer wrote it
[ ] Claims have audit-ready backup
[ ] Submitted ________ (online / paper)

## 5. After you submit
[ ] One polite status check scheduled — not a nagsheet
[ ] Anything they flagged, fixed
[ ] Clean project page/site if it helps (easy contact, no clutter)
[ ] If no: brief thanks, no argument
[ ] If they want a meeting: short deck, leave-behind, dress the part

## 6. If funded
[ ] Separate account; every dollar tracked
[ ] Restricted use respected
[ ] Regular unsolicited updates
[ ] Public thanks / plaque / press only if they want it
[ ] Situation changes → tell them the same day
[ ] Unused or mis-aimed funds handled their way
[ ] Audit file kept current
[ ] Celebration scaled to the gift
```

## How to use
1. Fill header fields from real solicitation / research (never invent).
2. Walk sections 1→6; leave future sections unchecked.
3. When blocking on research/LOI detail, load Grant funder research and LOI.
4. When drafting the full proposal, hand off to the matching proposal skills.
5. Re-emit the checklist on request with current checkmarks.

## Don't
- Invent funder facts, contacts, or eligibility.
- Mark items done without evidence.
- Contact or submit without an explicit user ask.
