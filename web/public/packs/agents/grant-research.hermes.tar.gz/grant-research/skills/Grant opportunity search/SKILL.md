---
name: Grant opportunity search
description: "Use when searching for open federal or public grant opportunities (grants.gov / NOFO / FOA), building a shortlist by keyword and eligibility, or feeding funder research with live opportunity cards."
version: 1.0.0
---

# Grant opportunity search

Find and shortlist **open funding opportunities** (federal FOA/NOFO and related public postings) for a stated project/org. Research only unless the user explicitly asks to contact or apply.

Feeds Grant funder research and LOI and Grant process checklist. Does not replace full foundation 990 fit work (use funder research / future 990 fit for that).

## Inputs to collect

- Project one-liner + keywords (include/exclude)
- Applicant type (nonprofit, museum, university, small org, etc.)
- Geography / eligibility constraints
- Rough ask range and timeline
- Preferred agencies or programs (optional)

Never invent eligibility. If unknown, mark **verify**.

## Sources (prefer official)

1. **Grants.gov Search2 API** (public JSON) — primary federal opportunity search  
   `POST https://api.grants.gov/v1/api/search2` with JSON body such as:
   ```json
   {
     "rows": 25,
     "keyword": "<keywords>",
     "oppStatuses": "posted",
     "startRecordNum": 0
   }
   ```
   Useful fields on hits: `title`, `number`, `agency`, `agencyCode`, `openDate`, `closeDate`, `oppStatus`, `cfdaList`, `id`.
2. **Simpler.Grants.gov** (HHS modernization) — track official API/schema as it rolls out; prefer documented endpoints over HTML scrape ([HHS/simpler-grants-gov](https://github.com/HHS/simpler-grants-gov)).
3. **XML extract fallback** — legacy daily grants.gov opportunity extract + keyword include/exclude lists when API is down (foa-finder-style pattern).
4. **Agency guides** — NIH Guide, NSF funding pages, IMLS, NEA/NEH, state portals when the project is clearly in-lane.
5. **USASpending** — for **past awards** landscape (“who got funded”), not as a substitute for open opportunities.

Skip crypto/DAO “grants,” random web3 treasuries, and unrelated OAuth projects named grant.

## Procedure

1. **Normalize keywords** — 3–8 search phrases; keep an exclude list (irrelevant CFDA/agency noise).
2. **Query** — call Search2 (or documented Simpler API) with `oppStatuses: posted` (add `forecasted` only if user wants pipeline).
3. **Dedupe** — by opportunity number / id.
4. **Screen** — for each hit, extract a card:
   - Title, agency, opportunity number, CFDA
   - Open / close dates
   - Status
   - URL (grants.gov opportunity page when id/number known)
   - Eligibility notes (**quoted or linked**, else `verify`)
   - Rough fit: strong / maybe / weak + one-line why
5. **Rank** — fit to org keywords, deadline urgency, ask-size plausibility, eligibility confidence.
6. **Hand off** — top 5–10 cards into funder research / checklist; flag which need LOI vs full package.

## Output template

```markdown
## Opportunity shortlist — <project>
**Query:** … | **Sources:** grants.gov Search2 | **As of:** <date>

| Fit | Opp # | Title | Agency | Close | CFDA | Notes |
|-----|-------|-------|--------|-------|------|-------|
| … | … | … | … | … | … | … |

### Next
- [ ] Verify eligibility on synopsis PDF
- [ ] Run funder research / LOI on top picks
- [ ] Add to grant process checklist
```

## Quality bar

- Every row cites a real opportunity number or URL from the API/page
- Deadlines copied from source, not guessed
- Crypto and non-grant “funding” excluded
- Fit scores are opinions labeled as such; eligibility is never invented

## Don't

- Scrape behind logins or paywalls when an official API exists
- Recommend applying without eligibility confirmation
- Confuse USASpending historical awards with open FOAs
- Mass-blast LOIs to the whole shortlist
