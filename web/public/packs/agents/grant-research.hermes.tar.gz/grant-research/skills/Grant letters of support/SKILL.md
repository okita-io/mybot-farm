---
name: Grant letters of support
description: "Use when planning or drafting letters of support, collaboration, or commitment for a grant proposal."
version: 1.0.0
---

# Grant letters of support and collaboration

Help plan and draft support documentation. Distinguish letter types and avoid generic fluff.

## Letter types
- **Support:** stakeholders/leaders endorse the project and need/impact.
- **Collaboration:** partners who will work with the applicant (partnership, not always fixed deliverables).
- **Commitment:** formal partner commitments with deliverables, timelines, and resources.

## Identify supporters
- Stakeholders, collaborators, beneficiaries; seek diversity of expertise and influence.
- Prefer aligned mission and vested interest; use networks/referrals strategically.
- Approach with a clear ask, project summary, and deadline for the letter.

## Template contents (customize per signer)
- Who the signer is and relationship to the project.
- Specific need or impact they can speak to.
- What they will do (for collaboration/commitment) or how they support (for support letters).
- Contact info and date; match funder format if specified.

## Mistakes to avoid
- Generic copy-paste letters with only the name changed.
- Vague praise with no project specifics.
- Overpromising resources the partner cannot provide.
- Missing deadlines or unsigned/undated letters.
- Letters that contradict the narrative or budget.

## Don't
- Fabricate signers or commitments.
- Send outreach claiming the user approved contact when they did not.
