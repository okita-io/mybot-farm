---
name: Grant proposal process
description: "Use when mapping the end-to-end grant application process, checking eligibility/deadlines, or outlining proposal components before drafting."
version: 1.0.0
---

# Grant proposal process

Paraphrased beginner grant-writing workflow for research and drafting help. Always follow the specific RFA / RFP / NOFO over this generic outline.

## 1. Prepare to apply
- Confirm eligibility, deadline, award floor/ceiling, and required documents.
- Read the full solicitation; note evaluation criteria if listed.

## 2. Project plan before prose
- Capture goals/objectives, approach/activities, and intended outcomes.
- Base the plan on a needs assessment and align with funder priorities.

## 3. Draft the proposal package
Typical components:
- Introduction and background (purpose, org mission, context)
- Needs assessment (evidence of problem/opportunity)
- Goals and objectives (prefer SMART: specific, measurable, achievable, relevant, time-bound)
- Approach / methods and timeline
- Evaluation plan
- Budget (+ justification when required)

## 4. After submit
- Expect possible follow-up questions or extra docs.
- If awarded: progress, financial, and final reports per funder rules.

## 5. Success checks
- Clear need, aligned goals, credible approach, strong evaluation, justified budget, and required attachments.

## Don't
- Invent funder rules, award amounts, or eligibility.
- Skip solicitation formatting, page limits, or mandatory sections.
