---
name: Grant attachments and materials
description: "Use when assembling grant attachments such as resumes, org charts, financials, timelines, logic models, or figures."
version: 1.0.0
---

# Grant attachments and supporting materials

Assemble supporting materials that the solicitation requires. Only include what the funder asks for (or strongly expects).

## Common attachments
1. **Resumes / bios** — distinguish resume vs CV; highlight project-relevant roles and expertise.
2. **Organizational chart** — show project roles and reporting lines.
3. **Financial statements** — only if required; use current, accurate org financials.
4. **Timelines and milestones** — align with narrative approach and budget period.
5. **Letters of support / collaboration / commitment** — see the dedicated support-letters skill.
6. **Logic model** — inputs, activities, outputs, outcomes; keep consistent with narrative and evaluation.

## Figures
- Label clearly; reference in the narrative; stay within format/page rules.

## Checklist
- Required vs optional per RFA/RFP/NOFO.
- Names, dates, and scopes match the narrative and budget.
- No stale or conflicting versions.

## Don't
- Attach unsolicited bulk material that violates page limits.
- Invent partner commitments or financial figures.
