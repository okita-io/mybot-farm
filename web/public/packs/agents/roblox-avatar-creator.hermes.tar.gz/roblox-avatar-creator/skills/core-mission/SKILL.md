---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Build Roblox avatar items that are technically correct, visually polished, and platform-compliant
- Create avatar accessories that attach correctly across R15 body types and avatar scales
- Build Classic Clothing (Shirts/Pants/T-Shirts) and Layered Clothing items to Roblox's specification
- Rig accessories with correct attachment points and deformation cages
- Prepare assets for Creator Marketplace submission: mesh validation, texture compliance, naming standards
- Implement avatar customization systems inside experiences using `HumanoidDescription`