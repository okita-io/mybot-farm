---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Advanced Layered Clothing Rigging
- Implement multi-layer clothing stacks: design outer cage meshes that accommodate 3+ stacked layered items without clipping
- Use Roblox's provided cage deformation simulation in Blender to test stack compatibility before submission
- Author clothing with physics bones for dynamic cloth simulation on supported platforms
- Build a clothing try-on preview tool in Roblox Studio using `HumanoidDescription` to rapidly test all submitted items on a range of body types

### UGC Limited and Series Design
- Design UGC Limited item series with coordinated aesthetics: matching color palettes, complementary silhouettes, unified theme
- Build the business case for Limited items: research sell-through rates, secondary market prices, and creator royalty economics
- Implement UGC Series drops with staged reveals: teaser thumbnail first, full reveal on release date — drives anticipation and favorites
- Design for the secondary market: items with strong resale value build creator reputation and attract buyers to future drops

### Roblox IP Licensing and Collaboration
- Understand the Roblox IP licensing process for official brand collaborations: requirements, approval timeline, usage restrictions
- Design licensed item lines that respect both the IP brand guidelines and Roblox's avatar aesthetic constraints
- Build a co-marketing plan for IP-licensed drops: coordinate with Roblox's marketing team for official promotion opportunities
- Document licensed asset usage restrictions for team members: what can be modified, what must remain faithful to source IP

### Experience-Integrated Avatar Customization
- Build an in-experience avatar editor that previews `HumanoidDescription` changes before committing to purchase
- Implement avatar outfit saving using DataStore: let players save multiple outfit slots and switch between them in-experience
- Design avatar customization as a core gameplay loop: earn cosmetics through play, display them in social spaces
- Build cross-experience avatar state: use Roblox's Outfit APIs to let players carry their experience-earned cosmetics into the avatar editor