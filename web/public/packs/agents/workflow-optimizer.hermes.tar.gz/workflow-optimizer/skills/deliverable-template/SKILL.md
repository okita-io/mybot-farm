---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Deliverable Template

```markdown
# [Process Name] Workflow Optimization Report

## 📈 Optimization Impact Summary
**Cycle Time Improvement**: [X% reduction with quantified time savings]
**Cost Savings**: [Annual cost reduction with ROI calculation]
**Quality Enhancement**: [Error rate reduction and quality metrics improvement]
**Employee Satisfaction**: [User satisfaction improvement and adoption metrics]

## 🔍 Current State Analysis
**Process Mapping**: [Detailed workflow visualization with bottleneck identification]
**Performance Metrics**: [Baseline measurements for time, cost, quality, satisfaction]
**Pain Point Analysis**: [Root cause analysis of inefficiencies and user frustrations]
**Automation Assessment**: [Tasks suitable for automation with potential impact]

## 🎯 Optimized Future State
**Redesigned Workflow**: [Streamlined process with automation integration]
**Performance Projections**: [Expected improvements with confidence intervals]
**Technology Integration**: [Automation tools and system integration requirements]
**Resource Requirements**: [Staffing, training, and technology needs]

## 🛠 Implementation Roadmap
**Phase 1 - Quick Wins**: [4-week improvements requiring minimal effort]
**Phase 2 - Process Optimization**: [12-week systematic improvements]
**Phase 3 - Strategic Automation**: [26-week technology implementation]
**Success Metrics**: [KPIs and monitoring systems for each phase]

## 💰 Business Case and ROI
**Investment Required**: [Implementation costs with breakdown by category]
**Expected Returns**: [Quantified benefits with 3-year projection]
**Payback Period**: [Break-even analysis with sensitivity scenarios]
**Risk Assessment**: [Implementation risks with mitigation strategies]

---
**Workflow Optimizer**: [Your name]
**Optimization Date**: [Date]
**Implementation Priority**: [High/Medium/Low with business justification]
**Success Probability**: [High/Medium/Low based on complexity and change readiness]
```