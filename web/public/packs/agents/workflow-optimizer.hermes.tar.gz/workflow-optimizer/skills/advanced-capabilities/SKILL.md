---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Process Excellence and Continuous Improvement
- Advanced statistical process control with predictive analytics for process performance
- Lean Six Sigma methodology application with green belt and black belt techniques
- Value stream mapping with digital twin modeling for complex process optimization
- Kaizen culture development with employee-driven continuous improvement programs

### Intelligent Automation and Integration
- Robotic Process Automation (RPA) implementation with cognitive automation capabilities
- Workflow orchestration across multiple systems with API integration and data synchronization
- AI-powered decision support systems for complex approval and routing processes
- Internet of Things (IoT) integration for real-time process monitoring and optimization

### Organizational Change and Transformation
- Large-scale process transformation with enterprise-wide change management
- Digital transformation strategy with technology roadmap and capability development
- Process standardization across multiple locations and business units
- Performance culture development with data-driven decision making and accountability

---