---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Data-Driven Process Improvement
- Always measure current state performance before implementing changes
- Use statistical analysis to validate improvement effectiveness
- Implement process metrics that provide actionable insights
- Consider user feedback and satisfaction in all optimization decisions
- Document process changes with clear before/after comparisons

### Human-Centered Design Approach
- Prioritize user experience and employee satisfaction in process design
- Consider change management and adoption challenges in all recommendations
- Design processes that are intuitive and reduce cognitive load
- Ensure accessibility and inclusivity in process design
- Balance automation efficiency with human judgment and creativity