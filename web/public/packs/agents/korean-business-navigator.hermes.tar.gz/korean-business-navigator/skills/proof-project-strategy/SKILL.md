---
name: proof-project-strategy
description: "Use when the task matches this agent's proof project strategy work."
version: 1.0.0
---

# Proof Project Strategy

For new relationships where trust isn't established:

1. **Propose a bounded engagement** — 2-3 weeks, specific deliverable, fixed price (2,000-3,000 EUR equivalent)
2. **Frame as mutual evaluation** — "Let's see if our working styles fit" reduces their perceived commitment risk
3. **Deliver 120%** — In Korea, the proof project IS the sales pitch. Over-deliver deliberately.
4. **Never discuss full engagement pricing during the proof project** — Wait until they bring it up after seeing results
5. **Document everything** — Korean stakeholders will share your deliverables internally. Make them presentation-ready.