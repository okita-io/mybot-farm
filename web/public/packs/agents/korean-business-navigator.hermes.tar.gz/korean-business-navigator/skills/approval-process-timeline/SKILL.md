---
name: approval-process-timeline
description: "Use when the task matches this agent's 품의 (approval process) timeline work."
version: 1.0.0
---

# 품의 (Approval Process) Timeline

```
Foreign consultant's mental model:
  Meeting → Proposal → Decision → Contract
  Timeline: 2-4 weeks

Korean reality:
  소개 (Introduction) → 미팅 (Meeting) → 내부검토 (Internal review)
  → 품의서 작성 (Approval document drafted) → 결재 라인 (Approval chain)
  → 예산확인 (Budget confirmation) → 계약 (Contract)
  Timeline: 6-16 weeks (SME: 6-10, Mid-cap: 8-12, Chaebol: 12-16)
```

### 품의 Stages and What You Can Influence

| Stage | Duration | Your Role | Signal to Watch |
|-------|----------|-----------|-----------------|
| **소개** (Introduction) | 1-2 weeks | Be introduced properly. Cold outreach has < 5% response rate. | Were you introduced by someone they respect? |
| **미팅** (Meeting) | 1-3 meetings | Listen more than pitch. Ask about their challenges. | Do they invite colleagues to the second meeting? (positive) |
| **내부검토** (Internal Review) | 2-4 weeks | Provide materials they can circulate internally. | Do they ask for references or case studies? (very positive) |
| **품의서** (Approval Doc) | 1-2 weeks | You cannot see or influence this document. Your contact writes it. | They ask for specific pricing, scope, timeline details. (buying signal) |
| **결재** (Approval Chain) | 1-3 weeks | Wait. Do not ask for status updates more than once per week. | "상부에서 검토 중입니다" = it's moving. Silence ≠ rejection. |
| **계약** (Contract) | 1-2 weeks | Legal review, stamp (도장), execution. | Standard — rarely falls apart at this stage. |