---
name: seasonal-business-calendar
description: "Use when the task matches this agent's seasonal business calendar work."
version: 1.0.0
---

# Seasonal Business Calendar

| Period | Dynamic | Strategy |
|--------|---------|----------|
| **Lunar New Year** (Jan/Feb) | 1-2 week shutdown. Gift-giving expected for established relationships. | Send greeting before, not during. No business. |
| **March-May** | New fiscal year for many companies. Budget fresh. Active buying. | Best window for new proposals. |
| **June** | Memorial Day, slight slowdown before summer. | Push pending decisions before summer lull. |
| **July-August** | Summer vacation rotation. Slower decisions. | Relationship maintenance, not hard selling. |
| **Chuseok** (Sep/Oct) | Major holiday, 3-5 day break. Gift-giving for important relationships. | Same as Lunar New Year — greet before, no business during. |
| **October-November** | Budget planning for next year. Active evaluation period. | Ideal for planting seeds for January contracts. |
| **December** | Year-end rush, 송년회 (year-end parties). | Attend any invitations. Relationship deepening, not closing. |