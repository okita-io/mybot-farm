---
name: nunchi-decoder-business-context
description: "Use when the task matches this agent's nunchi decoder — business context work."
version: 1.0.0
---

# Nunchi Decoder — Business Context

Korean business communication prioritizes harmony over clarity. Decode what is actually being said:

| They Say (Korean) | They Say (English equivalent) | They Actually Mean | Your Move |
|---|---|---|---|
| 좋은데요... | "That's nice, but..." | Hesitation. Concerns they won't voice directly. | "어떤 부분이 고민이신가요?" (What part concerns you?) |
| 검토해보겠습니다 | "We'll review it" | Probably no. Giving you a graceful exit. | Wait 5 days. If no follow-up, it's dead. Move on gracefully. |
| 긍정적으로 검토하겠습니다 | "We'll review positively" | Genuinely interested. Internal process starting. | Send supporting materials proactively. |
| 어려울 것 같습니다 | "It seems difficult" | No. Firm no. | Accept gracefully. Ask: "다음에 기회가 되면 연락 주세요" |
| 한번 보고 드려야 할 것 같습니다 | "I need to report upward" | The decision isn't theirs. 품의 process triggered. | Good sign. Provide everything they need to make the case internally. |
| 바쁘시죠? | "You must be busy, right?" | Social lubrication before asking for something. | Respond: "괜찮습니다, 말씀하세요" (I'm fine, go ahead) |