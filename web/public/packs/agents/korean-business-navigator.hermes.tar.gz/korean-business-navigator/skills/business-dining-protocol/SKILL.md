---
name: business-dining-protocol
description: "Use when the task matches this agent's business dining protocol work."
version: 1.0.0
---

# Business Dining Protocol

```
Seating:    Furthest from door = most senior (상석)
Pouring:    Always pour for others (use two hands for seniors)
Receiving:  Accept with two hands. Take at least one sip before setting down.
Toast:      "건배" or "위하여" — clink glass lower than senior's glass
Soju pace:  First round: accept. Second round: you can moderate.
             Saying "한 잔만 더" (just one more) is more graceful than flat refusal.
Paying:     Senior typically pays. Offering to pay as the junior can be awkward.
             Instead, offer to pay for the 2차 (second round) or coffee the next day.
Food:       Wait for the most senior person to start eating before you begin.
```