---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

ERC-20 Token with Access Control
```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC20Burnable} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import {ERC20Permit} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";

/// @title ProjectToken
/// @notice ERC-20 token with role-based minting, burning, and emergency pause
/// @dev Uses OpenZeppelin v5 contracts — no custom crypto
contract ProjectToken is ERC20, ERC20Burnable, ERC20Permit, AccessControl, Pausable {
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");

    uint256 public immutable MAX_SUPPLY;

    error MaxSupplyExceeded(uint256 requested, uint256 available);

    constructor(
        string memory name_,
        string memory symbol_,
        uint256 maxSupply_
    ) ERC20(name_, symbol_) ERC20Permit(name_) {
        MAX_SUPPLY = maxSupply_;

        _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
        _grantRole(MINTER_ROLE, msg.sender);
        _grantRole(PAUSER_ROLE, msg.sender);
    }

    /// @notice Mint tokens to a recipient
    /// @param to Recipient address
    /// @param amount Amount of tokens to mint (in wei)
    function mint(address to, uint256 amount) external onlyRole(MINTER_ROLE) {
        if (totalSupply() + amount > MAX_SUPPLY) {
            revert MaxSupplyExceeded(amount, MAX_SUPPLY - totalSupply());
        }
        _mint(to, amount);
# … truncated for farm planting — see upstream for the full sample
```

### UUPS Upgradeable Vault Pattern
```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {UUPSUpgradeable} from "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";
import {OwnableUpgradeable} from "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import {ReentrancyGuardUpgradeable} from "@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol";
import {PausableUpgradeable} from "@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

/// @title StakingVault
/// @notice Upgradeable staking vault with timelock withdrawals
/// @dev UUPS proxy pattern — upgrade logic lives in implementation
contract StakingVault is
    UUPSUpgradeable,
    OwnableUpgradeable,
    ReentrancyGuardUpgradeable,
    PausableUpgradeable
{
    using SafeERC20 for IERC20;

    struct StakeInfo {
        uint128 amount;       // Packed: 128 bits
        uint64 stakeTime;     // Packed: 64 bits — good until year 584 billion
        uint64 lockEndTime;   // Packed: 64 bits — same slot as above
    }

    IERC20 public stakingToken;
    uint256 public lockDuration;
    uint256 public totalStaked;
    mapping(address => StakeInfo) public stakes;

    event Staked(address indexed user, uint256 amount, uint256 lockEndTime);
    event Withdrawn(address indexed user, uint256 amount);
    event LockDurationUpdated(uint256 oldDuration, uint256 newDuration);

    error ZeroAmount();
    error LockNotExpired(uint256 lockEndTime, uint256 currentTime);
    error NoStake();

# … truncated for farm planting — see upstream for the full sample
```

### Foundry Test Suite
```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test, console2} from "forge-std/Test.sol";
import {StakingVault} from "../src/StakingVault.sol";
import {ERC1967Proxy} from "@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol";
import {MockERC20} from "./mocks/MockERC20.sol";

contract StakingVaultTest is Test {
    StakingVault public vault;
    MockERC20 public token;
    address public owner = makeAddr("owner");
    address public alice = makeAddr("alice");
    address public bob = makeAddr("bob");

    uint256 constant LOCK_DURATION = 7 days;
    uint256 constant STAKE_AMOUNT = 1000e18;

    function setUp() public {
        token = new MockERC20("Stake Token", "STK");

        // Deploy behind UUPS proxy
        StakingVault impl = new StakingVault();
        bytes memory initData = abi.encodeCall(
            StakingVault.initialize,…