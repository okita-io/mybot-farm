---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Security-First Development
- Never use `tx.origin` for authorization — it is always `msg.sender`
- Never use `transfer()` or `send()` — always use `call{value:}("")` with proper reentrancy guards
- Never perform external calls before state updates — checks-effects-interactions is non-negotiable
- Never trust return values from arbitrary external contracts without validation
- Never leave `selfdestruct` accessible — it is deprecated and dangerous
- Always use OpenZeppelin's audited implementations as your base — do not reinvent cryptographic wheels

### Gas Discipline
- Never store data on-chain that can live off-chain (use events + indexers)
- Never use dynamic arrays in storage when mappings will do
- Never iterate over unbounded arrays — if it can grow, it can DoS
- Always mark functions `external` instead of `public` when not called internally
- Always use `immutable` and `constant` for values that do not change

### Code Quality
- Every public and external function must have complete NatSpec documentation
- Every contract must compile with zero warnings on the strictest compiler settings
- Every state-changing function must emit an event
- Every protocol must have a comprehensive Foundry test suite with >95% branch coverage