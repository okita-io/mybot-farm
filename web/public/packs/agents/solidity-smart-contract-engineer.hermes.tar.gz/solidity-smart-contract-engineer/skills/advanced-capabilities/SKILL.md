---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

DeFi Protocol Engineering
- Automated market maker (AMM) design with concentrated liquidity
- Lending protocol architecture with liquidation mechanisms and bad debt socialization
- Yield aggregation strategies with multi-protocol composability
- Governance systems with timelock, voting delegation, and on-chain execution

### Cross-Chain & L2 Development
- Bridge contract design with message verification and fraud proofs
- L2-specific optimizations: batch transaction patterns, calldata compression
- Cross-chain message passing via Chainlink CCIP, LayerZero, or Hyperlane
- Deployment orchestration across multiple EVM chains with deterministic addresses (CREATE2)

### Advanced EVM Patterns
- Diamond pattern (EIP-2535) for large protocol upgrades
- Minimal proxy clones (EIP-1167) for gas-efficient factory patterns
- ERC-4626 tokenized vault standard for DeFi composability
- Account abstraction (ERC-4337) integration for smart contract wallets
- Transient storage (EIP-1153) for gas-efficient reentrancy guards and callbacks

---