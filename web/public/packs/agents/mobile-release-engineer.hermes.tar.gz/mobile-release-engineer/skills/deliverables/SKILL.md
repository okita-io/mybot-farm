---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

fastlane: Tagged Commit → Store-Ready, No Clicking

```ruby
# Fastfile — one command per platform, reproducible, secrets pulled from match/CI
platform :ios do
  desc "Build, sign, and ship iOS to TestFlight"
  lane :beta do
    setup_ci                                   # ephemeral keychain on CI runners
    match(type: "appstore", readonly: true)    # certs/profiles from the shared encrypted store
    increment_build_number(build_number: latest_testflight_build_number + 1)
    build_app(scheme: "App", export_method: "app-store")
    upload_to_testflight(
      distribute_external: true,
      groups: ["QA", "Stakeholders"],
      changelog: File.read("../CHANGELOG_LATEST.md")
    )
    upload_symbols_to_crashlytics(dsym_path: lane_context[SharedValues::DSYM_OUTPUT_PATH])
  end
end

platform :android do
  desc "Build AAB and ship to Play internal track"
  lane :internal do
    gradle(task: "bundle", build_type: "Release")   # signed via Play App Signing upload key
    upload_to_play_store(
      track: "internal",
      aab: lane_context[SharedValues::GRADLE_AAB_OUTPUT_PATH],
      release_status: "draft"                        # human promotes to phased production
    )
    upload_symbols_to_crashlytics                    # mapping.txt for deobfuscation
  end
end
```

### iOS Signing Model (the thing that breaks the most)

| Piece | What it is | Failure mode when wrong |
|-------|-----------|-------------------------|
| Distribution certificate | Your team's signing identity | Expired/revoked ⇒ every build fails; revoking one used by CI breaks all pipelines |
| Provisioning profile | Binds app ID + certificate + capabilities + devices | Stale after adding a capability ⇒ "provisioning profile doesn't include entitlement" |
| App ID capabilities | Push, App Groups, Sign in with Apple, etc. | Enabled in code but not in the profile ⇒ install/runtime failure |
| fastlane match | Git-stored, encrypted certs + profiles shared across the team/CI | The fix: one source of truth, `readonly: true` on CI so runners never mint new identities |

### Phased Rollout with Halt Criteria

```text
iOS (App Store phased release, 7-day default ramp)     Android (Play staged rollout, you set %)
  Day 1:   1%      ┐                                     internal → closed testing → open testing
  Day 2:   2%      │  monitor crash-free ≥ 99.5%,        production: 1% → 5% → 20% → 50% → 100%
  Day 3:   5%      │  ANR ≤ 0.47%, no spike in           halt + fix-forward if:
  Day 4:  10%      ├─ 1-star reviews or support tickets    · crash-free drops below threshold
  Day 5:  25%      │                                       · ANR/error rate spikes
  Day 6:  50%      │  ANY red signal ⇒ PAUSE (both        · a P0 functional regression reported
  Day 7: 100%      ┘  stores support pausing a rollout)  resume only after the fix rides the next build
```

### Pre-Submission Checklist (release-blocking)

```markdown
## Release <version> (<build>) — go/no-go
- [ ] Version + build number bumped, monotonic, matches store expectation
- [ ] Signed with the correct distribution identity / upload key (verified, not assumed)
- [ ] Entitlements/capabilities match the provisioning profile (iOS)
- [ ] Privacy: iOS privacy manifest + nutrition labels current; Android Data safety form current
- [ ] Required reason APIs declared (iOS); no undeclared background modes
- [ ] dSYMs (iOS) / mapping.txt (Android) uploaded to crash reporter
- [ ] Store metadata, screenshots, what's-new copy reviewed and localized
- [ ] Min OS version + supported device families correct
- [ ] Release candidate (not debug build) smoke-tested by internal track
- [ ] Rollback/forward-fix plan written; on-call owner assigned for the rollout window
```