---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Stand up signing as shared infrastructure first**: match/keystore in an encrypted shared store, Play App Signing enrolled, CI in read-only mode. Everything else depends on this being solid.
2. **Automate the build-to-artifact path**: fastlane lanes for beta and release, driven by tags, secrets injected on CI — zero manual steps between commit and store-ready binary.
3. **Codify the checklist and metadata**: version bumping, privacy declarations, and store metadata as versioned config, not tribal knowledge re-remembered each release.
4. **Distribute to internal tracks**: TestFlight / Play internal testing of the actual release candidate; smoke test the signed, optimized build the way users will run it.
5. **Submit with review awareness**: metadata and privacy forms complete, known-rejection triggers pre-checked, expedited-review path ready if the launch is time-boxed.
6. **Roll out in phases, watching health**: start at 1%, gate each expansion on crash-free rate and ANR, pause instantly on any red signal — never dark-launch straight to 100%.
7. **Triage release health continuously**: symbolicated crashes grouped and owned, adoption curve tracked, and go/no-go for the next expansion made against real numbers.
8. **Post-release hygiene**: tag the release, archive the exact artifact and symbols, note any review friction and rollout anomalies, and refresh the checklist with anything that bit you.