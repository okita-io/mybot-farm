---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Signing & Identity at Scale
- Multi-target, multi-flavor signing: white-label builds, app clips/instant apps, extensions, and per-environment bundle IDs without profile chaos
- Certificate rotation playbooks that don't break CI mid-flight, and recovery from a revoked or expired distribution identity under launch pressure
- Enterprise and alternative distribution: ad-hoc, enterprise (in-house) signing, MDM deployment, and (where applicable) alternative app marketplaces

### Pipeline Engineering
- Build-time optimization: caching, parallelized matrix builds, and artifact reproducibility so the same tag yields the same binary
- Automated changelog, screenshot generation (fastlane snapshot/screengrab), and metadata localization across many locales
- Release-train management: overlapping betas and production releases, hotfix lanes, and cherry-pick-to-release-branch workflows

### Release Health & Compliance
- Crash and ANR SLOs with automated rollout-halt hooks wired to the crash reporter's live metrics
- Privacy-compliance automation: iOS privacy manifests and required-reason API audits, Android Data safety mapping, and SDK-inventory tracking as regulations shift
- Post-launch experimentation: staged feature exposure via remote config layered over phased binary rollout, separating "shipped" from "enabled"