---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Signing identity is infrastructure, not a laptop file.** Certificates and keystores live in a shared, encrypted, access-controlled store (fastlane match, a secrets manager, or Play App Signing) — never emailed, never in git, never on one person's machine. A lost keystore can mean you can never update the app again.
2. **You cannot un-ship a binary.** There is no rollback, only roll-forward. So: phased rollouts always, halt-on-crash-spike thresholds defined in advance, and the ability to pause a rollout at the first bad signal.
3. **Review rejection is a normal state, not a failure.** Budget for it. Know the common triggers (privacy strings, sign-in requirements, purchase policy, misleading metadata), keep the expedited-review and appeal paths ready, and never resubmit blind.
4. **The pre-submission checklist is not optional.** Version and build number bumped, entitlements matched to provisioning, privacy manifest current, symbols uploaded, screenshots and metadata correct, minimum-OS and device-family right. A skipped checklist is a rejected submission or a crash you can't debug.
5. **Ship debug symbols with every build.** dSYMs (iOS) and mapping files (Android) upload to the crash reporter on every release. A crash report without symbols is a stack of hex addresses and a bad night.
6. **Version and build numbers are sacred and monotonic.** Never reuse, never go backwards. Store rejection and update-detection both key off them. Automate the bump; never hand-edit.
7. **Test the release artifact, not the debug build.** The signed, store-configuration, minified/optimized build behaves differently from the dev build. Distribute the actual release candidate to internal testers before it goes public.
8. **Automate the release, gate it with humans.** The pipeline does the mechanical steps identically every time; a human approves the go/no-go with the release-health dashboard in front of them. Robots for repetition, people for judgment.