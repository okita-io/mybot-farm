---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Identity Resolution Schema

Every resolve call should return a structure like this:

```json
{
  "entity_id": "a1b2c3d4-...",
  "confidence": 0.94,
  "is_new": false,
  "canonical_data": {
    "email": "wsmith@acme.com",
    "first_name": "William",
    "last_name": "Smith",
    "phone": "+15550142"
  },
  "version": 7
}
```

The engine matched "Bill" to "William" via nickname normalization. The phone was normalized to E.164. Confidence 0.94 based on email exact match + name fuzzy match + phone match.

### Merge Proposal Structure

When proposing a merge, always include per-field evidence:

```json
{
  "entity_a_id": "a1b2c3d4-...",
  "entity_b_id": "e5f6g7h8-...",
  "confidence": 0.87,
  "evidence": {
    "email_match": { "score": 1.0, "values": ["wsmith@acme.com", "wsmith@acme.com"] },
    "name_match": { "score": 0.82, "values": ["William Smith", "Bill Smith"] },
    "phone_match": { "score": 1.0, "values": ["+15550142", "+15550142"] },
    "reasoning": "Same email and phone. Name differs but 'Bill' is a known nickname for 'William'."
  }
}
```

Other agents can now review this proposal before it executes.

### Decision Table: Direct Mutation vs. Proposals

| Scenario | Action | Why |
|----------|--------|-----|
| Single agent, high confidence (>0.95) | Direct merge | No ambiguity, no other agents to consult |
| Multiple agents, moderate confidence | Propose merge | Let other agents review the evidence |
| Agent disagrees with prior merge | Propose split with member_ids | Don't undo directly - propose and let others verify |
| Correcting a data field | Direct mutate with expected_version | Field update doesn't need multi-agent review |
| Unsure about a match | Simulate first, then decide | Preview the outcome without committing |

### Matching Techniques

```python
class IdentityMatcher:
    """
    Core matching logic for identity resolution.
    Compares two records field-by-field with type-aware scoring.
    """

    def score_pair(self, record_a: dict, record_b: dict, rules: list) -> float:
        total_weight = 0.0
        weighted_score = 0.0

        for rule in rules:
            field = rule["field"]
            val_a = record_a.get(field)
            val_b = record_b.get(field)

            if val_a is None or val_b is None:
                continue

            # Normalize before comparing
            val_a = self.normalize(val_a, rule.get("normalizer", "generic"))
            val_b = self.normalize(val_b, rule.get("normalizer", "generic"))

            # Compare using the specified method
            score = self.compare(val_a, val_b, rule.get("comparator", "exact"))
            weighted_score += score * rule["weight"]
            total_weight += rule["weight"]

        return weighted_score / total_weight if total_weight > 0 else 0.0

    def normalize(self, value: str, normalizer: str) -> str:
        if normalizer == "email":
            return value.lower().strip()
        elif normalizer == "phone":
            return re.sub(r"[^\d+]", "", value)  # Strip to digits
        elif normalizer == "name":
            return self.expand_nicknames(value.lower().strip())
        return value.lower().strip()

    def expand_nicknames(self, name: str) -> str:
        nicknames = {
# … truncated for farm planting — see upstream for the full sample
```