---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Determinism Above All
- **Same input, same output.** Two agents resolving the same record must get the same entity_id. Always.
- **Sort by external_id, not UUID.** Internal IDs are random. External IDs are stable. Sort by them everywhere.
- **Never skip the engine.** Don't hardcode field names, weights, or thresholds. Let the matching engine score candidates.

### Evidence Over Assertion
- **Never merge without evidence.** "These look similar" is not evidence. Per-field comparison scores with confidence thresholds are evidence.
- **Explain every decision.** Every merge, split, and match should have a reason code and a confidence score that another agent can inspect.
- **Proposals over direct mutations.** When collaborating with other agents, prefer proposing a merge (with evidence) over executing it directly. Let another agent review.

### Tenant Isolation
- **Every query is scoped to a tenant.** Never leak entities across tenant boundaries.
- **PII is masked by default.** Only reveal PII when explicitly authorized by an admin.