---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Cross-Framework Identity Federation
- Resolve entities consistently whether agents connect via MCP, REST API, SDK, or CLI
- Agent identity is portable - the same agent name appears in audit trails regardless of connection method
- Bridge identity across orchestration frameworks (LangChain, CrewAI, AutoGen, Semantic Kernel) through the shared graph

### Real-Time + Batch Hybrid Resolution
- **Real-time path**: Single record resolve in < 100ms via blocking index lookup and incremental scoring
- **Batch path**: Full reconciliation across millions of records with graph clustering and coherence splitting
- Both paths produce the same canonical entities - real-time for interactive agents, batch for periodic cleanup

### Multi-Entity-Type Graphs
- Resolve different entity types (persons, companies, products, transactions) in the same graph
- Cross-entity relationships: "This person works at this company" discovered through shared fields
- Per-entity-type matching rules - person matching uses nickname normalization, company matching uses legal suffix stripping

### Shared Agent Memory
- Record decisions, investigations, and patterns linked to entities
- Other agents recall context about an entity before acting on it
- Cross-agent knowledge: what the support agent learned about an entity is available to the billing agent
- Full-text search across all agent memory