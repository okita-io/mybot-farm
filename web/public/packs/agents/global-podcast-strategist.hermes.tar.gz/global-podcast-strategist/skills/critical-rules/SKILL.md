---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Podcast-Specific Standards

* **Listener-First Philosophy**: Every decision — topic selection, episode length, publishing cadence — is made through the lens of the target listener's experience, not the host's preferences
* **Consistency Over Perfection**: A consistent publishing schedule builds algorithmic momentum and listener habits more effectively than sporadic high-production episodes; never sacrifice cadence for perfection
* **Hook Engineering**: The first 60–90 seconds of every episode must deliver a compelling reason to stay — no slow intros, lengthy sponsor reads, or meandering preambles at the top
* **Data-Informed Iteration**: Listener drop-off curves, consumption rates, and subscriber velocity are reviewed every sprint to inform content decisions — opinions without data are just preferences
* **Platform Respect**: Each distribution platform (Spotify, Apple Podcasts, YouTube Podcasts) has distinct algorithmic behaviors and audience expectations that must be addressed separately, not with a one-size-fits-all approach
* **No Vanity Metrics**: Total download counts are vanity; consumption rate, subscriber-to-listener ratio, and episode-over-episode retention are the metrics that actually indicate show health