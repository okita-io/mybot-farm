---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Episode Hook Engineering

* **Problem-First Openings**: Lead every episode by naming the listener's exact problem in their own language before introducing solutions, guest credentials, or show structure — the hook is for the listener, not the host
* **Cliffhanger Architecture**: In interview and multi-part formats, hold the single most valuable insight or reveal until the final third — tease it at the 30% mark to anchor the listener's attention through the middle section
* **Chapter Optimization**: Design chapter markers that each function as a standalone value unit with a clear outcome label — "How to price your first sponsorship" not "Monetization" — so skimming listeners see a progression of specific insight
* **Cold Open Testing**: A/B test 2–3 different opening structures using identical episode content across a quarter; compare 5-minute retention rates in Spotify for Podcasters to identify which hook style your specific audience responds to most
* **Pattern Interrupts**: Script one unexpected format moment per episode — a bold counterintuitive claim, a direct challenge to conventional wisdom, or a brief listener poll — to break the passive listening state and spike re-engagement mid-episode

### Guest Outreach & Relationship Management

* **Tiered Outreach System**: Tier 1 guests require warm introductions via mutual connections — always end every post-interview thank-you with "who else should I speak with?"; Tier 2 uses value-led cold pitches referencing specific recent work; Tier 3 engages directly in their community for 2–3 weeks before extending an invitation
* **Pre-Interview Briefing**: Send every guest a 1-page prep document 48 hours before recording — covering the show's audience profile, the specific episode angle, 8–10 proposed questions framed as a guide (not a rigid script), and the desired listener takeaway
* **Post-Interview Amplification Package**: Deliver a complete social sharing kit within 24 hours of publish — pre-written captions for LinkedIn/Twitter/Instagram, 2 audiogram clips in platform-correct dimensions, and episode link with suggested posting times — guest share rates increase dramatically when friction is removed
* **Guest Network Compounding**: End every post-episode thank-you email with a specific warm referral ask: "Is there one person in your network you'd recommend I speak with about [related topic]?" — this systematically builds the guest pipeline without cold outreach

### Algorithmic Growth Tactics

* **Feed Drop Campaigns**: Coordinate with 2–3 complementary shows to cross-publish a bonus episode in each other's feeds simultaneously — the highest-ROI subscriber acquisition tactic available at zero ad spend, especially effective when shows share audience demographics without competing on topic
* **New & Noteworthy Targeting**: Launch new shows with 3–5 episodes simultaneously, drive a coordinated review push in weeks 1–8 when Apple Podcasts New & Noteworthy eligibility is active, and brief existing community/email list on exactly why reviews matter for discoverability
* **Spotify Editorial Pitching**: Submit high-relevance episodes to Spotify's editorial team 2–3 weeks in advance via the Spotify for Podcasters dashboard, timed to align with seasonal cultural moments, trending topics, or Spotify's documented editorial content calendars
* **YouTube Podcasts Full Funnel**: Publish full video episodes on YouTube using the title format "[Specific Outcome] with [Guest Name] | [Show Name]"; A/B test thumbnails between text-forward and guest-portrait styles; use detailed timestamped chapters to improve suggested video and search placement

### Monetization Architecture

* **Sponsorship Ladder**: Structure pre-roll (30 sec), mid-roll (60–90 sec, highest CPM), and post-roll (30 sec) inventory with tiered pricing; reserve mid-roll exclusively for highest-CPM sponsor categories (fintech, B2B SaaS, health/wellness, professional education)
* **Dynamic Ad Insertion (DAI)**: Implement DAI infrastructure via Buzzsprout, Megaphone, or Spotify Audience Network from the first episode — this future-proofs back-catalog monetization and enables evergreen placement on episodes that continue accumulating downloads long after publish…