---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Phase 1: Show Concept & Positioning

1. **Target Listener Definition**: Build a detailed listener persona — demographics, psychographics, what shows they already listen to, what problems or aspirations drive their listening, and what gap currently goes unserved in their audio diet
2. **Competitive Audit**: Survey the top 20 shows in the niche; for each document format, episode length, cadence, average review score, recurring listener complaints in reviews, and content areas they avoid or handle poorly
3. **Unique Angle Identification**: Define the single thing this show does that no competing show does — format innovation (e.g., every episode ends with a live experiment), guest access tier, host perspective, depth of niche, or production quality standard
4. **Show Bible Creation**: Document show name, tagline, elevator pitch, episode format options, standard segment structure, target episode length, publishing frequency, brand voice adjectives, and off-limits topics
5. **Platform Primary Strategy**: Determine primary growth platform based on listener persona — Spotify for music-adjacent audiences and 18–34 demographic; Apple for business/premium audiences; YouTube for visual-friendly formats and search-driven discovery

### Phase 2: Content Engine Development

1. **Flagship Format Design**: Establish the core episode template — intro hook structure, segment order, interview framework or solo narrative arc, sponsor placement positions, and outro CTA sequence; document it so any producer can execute it consistently
2. **Episode Brief System**: Build standardized pre-production docs for every episode type (interview, solo, panel) so no episode goes to recording without a clear hook, core promise, and repurposing plan already defined
3. **Topic Sourcing Pipeline**: Identify 3 content layers — (1) evergreen pillar topics that are always relevant to the listener, (2) trending news hooks tied to the niche, (3) listener question pools sourced from community, reviews, and social comments
4. **Guest Tier Strategy**: Tier 1: dream guests with large audiences (pursue via warm intros from existing guests); Tier 2: accessible authorities with niche credibility (cold outreach with personalized pitch); Tier 3: rising voices with fresh takes (direct community engagement before inviting)
5. **Batch Production Planning**: Structure recording blocks to maintain 4–6 weeks of buffer inventory at all times, preventing publish gaps during illness, travel, or editing backlogs that break listener habits and algorithmic momentum

### Phase 3: Distribution & Discoverability

1. **Platform Optimization**: Craft keyword-rich show titles, episode titles, show descriptions, and episode descriptions tuned to Apple Podcasts and Spotify search — treat episode titles like blog post headlines that answer a specific listener question, not creative art titles
2. **Clip Strategy**: Identify 3–5 shareable moments per episode during the editing pass — target moments of surprise, genuine disagreement, strong opinion, or quotable insight for TikTok, Reels, and YouTube Shorts with 3-second hook captions
3. **Newsletter Integration**: Design episode announcement email with a 3-sentence episode hook (not a full summary), a clear listener benefit statement, and a single CTA — send within 2 hours of episode publish to capture peak engagement window
4. **Cross-Promotion Partnerships**: Identify 10–15 complementary shows for guest swap or feed-drop partnerships; script a mutual value proposition that explains exact audience overlap without positioning as direct competition
5. **SEO Companion Content**: Produce episode show notes of 400–800 words optimized for 2–3 long-tail keywords per episode — this drives Google-sourced discovery and provides platforms with structured metadata to improve episode indexing
6. **Review Generation Flywheel**: Script a review ask at the 80% mark of the first 3 episodes every new listener encounters; reinforce in the welcome email sequence; run a quarterly community challenge tied to review milestones — reviews compound platform visibility over time

### Phase 4: Community & Monetization

1. **Listener Community Setup**: Establish a community hub matched to audience type — Discord for younger/tech audiences with voice channel Q&As; Circle for structured course communities; Slack for B2B professional shows — seed with weekly discussion prompts tied to each new episode topic…