---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Show Strategy Documents

* **Show Bible**: Comprehensive positioning document covering target listener persona, unique value proposition, episode format, tone, competitive differentiation, and brand voice guidelines
* **Episode Brief Templates**: Standardized pre-production structure with hook, narrative arc, key takeaways, guest questions, and CTA placement — used for every episode to ensure production consistency
* **Content Calendar**: 8–12 week editorial pipeline with episode topics, guest lineup, tie-ins to news cycles or seasonal moments, and repurposing plan across social and email
* **Competitive Landscape Audit**: Analysis of top 10–20 competing shows covering format, cadence, guest quality, review sentiment, listener complaints, and identifiable content gaps to exploit
* **Guest Outreach Pipeline**: Tiered prospect list with contact details, warm introduction paths, and personalized pitch angles for each target guest

### Growth & Analytics Frameworks

* **Funnel Metrics Dashboard**: Downloads per episode, unique listeners, subscriber growth rate, 30-day consumption rate, and platform-by-platform breakdown updated weekly
* **Guest Outreach Templates**: Personalized pitch frameworks for cold outreach, follow-up sequences, and pre-interview briefing docs tailored to each guest tier
* **Cross-Promotion Playbook**: Podcast swap scripts, newsletter integration copy, social clip briefs, and audiogram specs by platform for consistent multi-channel amplification
* **Monetization Roadmap**: CPM benchmarks by category, sponsorship tier pricing, listener support model options (Patreon/memberships), and course/product upsell sequencing tied to download milestones

### Production Templates

**Episode Brief (Standard Format)**:
```
EPISODE BRIEF
─────────────────────────────────────────
Title (working): [Keyword-rich, listener-benefit-forward title]
Hook (first 90 sec): [The single problem/tension that makes someone stay]
Core Promise: [What the listener will know/be able to do after this episode]
Format: [Interview / Solo / Panel / Narrative]
Target Length: [XX minutes]
Guest: [Name, title, why them, warm intro or cold outreach]

KEY QUESTIONS / NARRATIVE BEATS:
1.
2.
3.
4.
5.

Sponsor Placement: [Pre-roll slot / Mid-roll slot / Post-roll slot]
Outro CTA: [Subscribe prompt / Community / Lead magnet / Product]
Repurposing Plan: [3 clip moments / newsletter angle / LinkedIn post hook]
─────────────────────────────────────────
```

**Guest Cold Outreach Template**:
```
Subject: [Show Name] — [Guest's topic] episode?

Hi [First Name],

[1 sentence personalizing why you're reaching out — reference their recent
work, a specific thing they said publicly, or a position they hold.]

I host [Show Name], a podcast for [target listener description] covering
[niche topic]. Recent episodes included [2 relevant recent topics].

I'd love to have you on to discuss [specific angle relevant to their expertise].
Our listeners would especially value your perspective on [specific sub-topic].

Format is [length]-minute [interview/conversation], recorded remotely.
I handle all editing and promotion — you receive a full social sharing kit
within 24 hours of publish.

Would [Month] work for a 30-minute recording? Happy to send available times.

[Your name]
[Show name + listener stats if relevant]
```