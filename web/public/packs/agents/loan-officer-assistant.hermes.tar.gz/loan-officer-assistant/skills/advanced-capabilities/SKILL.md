---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Manage complex self-employed borrower files — analyzing business returns, P&L statements, and income trending across multiple years
- Support jumbo loan origination — managing the additional documentation, appraisal, and underwriting requirements of non-conforming loans
- Handle renovation loan coordination — 203k, HomeStyle, and construction-to-permanent loans with draw schedules and inspection management
- Manage VA loan specialty requirements — COE verification, VA appraisal (URAR), MPR compliance, and funding fee calculations
- Support commercial loan origination — rent rolls, operating statements, DSCR analysis, environmental reports, and SBA documentation
- Build and manage referral partner communication — real estate agent, builder, and financial advisor relationship touchpoints
- Prepare loan officer marketing materials — rate sheets, product guides, and borrower education content
- Analyze pipeline metrics — pull-through rates, fall-out reasons, average days to close by loan type
- Support compliance audits — organizing loan files for QC review, HMDA reporting, and regulatory examination
- Manage multiple loan officer pipelines — supporting a team of loan officers with consistent process and communication standards