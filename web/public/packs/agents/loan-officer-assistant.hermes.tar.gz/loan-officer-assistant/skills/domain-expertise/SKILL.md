---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Loan Products

**Conventional Loans**
- Conforming: FNMA/FHLMC guidelines, loan limits by county
- High-balance conforming: higher limits in designated high-cost areas
- Jumbo: non-conforming, portfolio or private label, stricter guidelines

**Government Loans**
- FHA: 3.5% down, MIP requirements, lower credit score flexibility
- VA: 0% down for eligible veterans, funding fee, no PMI
- USDA: rural eligible areas, income limits, 0% down

**Specialty Products**
- Bank statement loans: self-employed borrowers, 12-24 months statements
- DSCR loans: investment properties, debt service coverage ratio qualifying
- Bridge loans: short-term financing, purchase before sale
- Construction: single-close and two-close options

**Commercial Lending**
- SBA 7(a) and 504 loans
- Commercial real estate — owner-occupied and investment
- Business lines of credit and term loans

### Compliance Framework

- **TRID (TILA-RESPA Integrated Disclosure)**: LE and CD timing requirements
- **RESPA**: anti-kickback, affiliated business disclosure, settlement statement
- **ECOA / Regulation B**: adverse action notices, fair lending requirements
- **HMDA**: data collection, reporting, and fair lending analysis
- **SAFE Act**: loan officer licensing requirements by state
- **GLBA**: borrower privacy notice and data protection requirements
- **CRA**: Community Reinvestment Act for depository institutions
- **ATR/QM Rule**: ability-to-repay and qualified mortgage standards

### Key Calculations

```
Debt-to-Income (DTI):
  Front-end = PITI ÷ Gross Monthly Income
  Back-end = (PITI + All Monthly Debts) ÷ Gross Monthly Income

Loan-to-Value (LTV):
  LTV = Loan Amount ÷ Appraised Value (or Purchase Price, lower of two)

Combined LTV (CLTV):
  CLTV = (First Mortgage + Second Mortgage) ÷ Appraised Value

Maximum Loan Amount (from income):
  Max PITI = Gross Income × Front-end DTI limit
  Max Debt = Gross Income × Back-end DTI limit
  Max Loan = Work backward from max PITI using rate and term

Cash to Close:
  Down payment + Closing costs + Prepaid items + Reserves
  - Lender credits - Seller concessions - Gift funds
```

---