---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Borrower Intake & Pre-Qualification

1. **Respond within 5 minutes** to all new inquiries — speed-to-lead wins loans
2. **Identify loan purpose** — purchase, refinance, construction, commercial, or consumer
3. **Collect basic qualification data** — income, assets, credit, property, timeline
4. **Run pre-qualification analysis** — DTI, LTV, credit score, product match
5. **Match to loan program** — conventional, FHA, VA, USDA, jumbo, or portfolio
6. **Set expectations** — timeline, process, next steps, and what to expect

### Step 2: Application & Disclosure

1. **Collect completed 1003** — all sections, all borrowers, all properties
2. **Issue Loan Estimate** — within 3 business days of application (TRID requirement)
3. **Deliver document checklist** — customized to loan type and borrower profile
4. **Order credit report** — tri-merge from all three bureaus
5. **Verify licensing** — confirm loan officer is licensed in the property state
6. **Set up borrower portal** — document upload, status tracking, communication

### Step 3: Processing & Document Collection

1. **Track document collection** — follow up on outstanding items every 48 hours
2. **Review documents for completeness** — catch issues before underwriting does
3. **Order appraisal** — coordinate access and track delivery timeline
4. **Order title** — confirm title commitment received and reviewed
5. **Verify employment** — VOE completed before submission to underwriting
6. **Monitor document expiration** — flag any documents approaching expiration

### Step 4: Underwriting Management

1. **Submit complete file** — no incomplete files to underwriting
2. **Track condition list** — every condition logged, assigned, and followed up
3. **Collect condition documentation** — follow up with borrowers on outstanding items
4. **Respond to UW inquiries** — same-day response to underwriter questions
5. **Monitor re-submission** — track file back to UW after condition clearing
6. **Alert on suspension** — immediate escalation if file is suspended

### Step 5: Closing Coordination

1. **Issue Closing Disclosure** — at least 3 business days before closing (TRID)
2. **Confirm closing date, time, and location** with all parties
3. **Calculate cash to close** — confirm wire instructions or certified check amount
4. **Coordinate final conditions** — any PTC conditions must be cleared before closing
5. **Confirm final verification of employment** — required within 10 business days of closing
6. **Send closing reminder** — 24 hours before closing with all logistics

---