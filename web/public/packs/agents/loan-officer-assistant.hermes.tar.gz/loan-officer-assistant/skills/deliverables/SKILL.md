---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Borrower Intake Script

```
BORROWER INTAKE — INITIAL INQUIRY
───────────────────────────────────────
Phone/Chat Opening:
  "Thank you for reaching out to [Lender Name]. My name is [Agent],
  and I'm here to help you with your financing needs. May I ask
  who I'm speaking with?

  [After name]
  Great to meet you, [Name]! What type of financing are you
  looking for today?"

Loan Purpose Identification:
  [ ] Purchase — primary residence, second home, or investment property?
  [ ] Refinance — rate/term or cash-out? Current rate and payment?
  [ ] Construction — lot owned? Builder selected?
  [ ] Home equity — HELOC or fixed second mortgage?
  [ ] Commercial — property type and loan amount?
  [ ] Consumer — auto, personal, or other?

Initial Qualification Screen:
  "To make sure I connect you with the right loan program,
  I have a few quick questions:

  1. What is the approximate purchase price / property value?
  2. How much are you looking to put down / borrow?
  3. Are you currently working with a real estate agent?
  4. What is your target closing date?
  5. Have you had your credit reviewed recently?"

Urgency Assessment:
  "Do you have a signed purchase contract? If so, what is
  your closing date? I want to make sure we have enough time
  to get this done properly."
```

### Pre-Qualification Worksheet

```
PRE-QUALIFICATION ANALYSIS
───────────────────────────────────────
Borrower:           [Name]
Co-Borrower:        [Name if applicable]
Date:               [Date]
Loan Officer:       [Name]

LOAN PARAMETERS
───────────────────────────────────────
Purchase Price:     $___________
Down Payment:       $___________  ([  ]%)
Loan Amount:        $___________
Loan Type:          [ ] Conventional  [ ] FHA  [ ] VA  [ ] USDA
                    [ ] Jumbo  [ ] Commercial  [ ] Other
Property Type:      [ ] SFR  [ ] Condo  [ ] Multi-family  [ ] Commercial
Occupancy:          [ ] Primary  [ ] Second Home  [ ] Investment

INCOME ANALYSIS
───────────────────────────────────────
Borrower Employment:    [Employer]  [Years]
Borrower Income:        $___________/month (gross)
Co-Borrower Employment: [Employer]  [Years]
Co-Borrower Income:     $___________/month (gross)
Other Income:           $___________/month  Source: ___________
Total Qualifying Income: $___________/month

DEBT ANALYSIS (Monthly Obligations)
───────────────────────────────────────
Proposed PITI:          $___________
Auto loans:             $___________
Student loans:          $___________
Credit cards (min):     $___________
Other installment:      $___________
Other mortgage(s):      $___________
Total Monthly Debt:     $___________

DEBT-TO-INCOME RATIOS
───────────────────────────────────────
Front-End DTI:  [PITI ÷ Gross Income]    _______%
                Conventional max: 28% | FHA max: 31%
# … truncated for farm planting — see upstream for the full sample
```

### Document Checklist by Loan Type

```
DOCUMENT CHECKLIST — RESIDENTIAL PURCHASE
───────────────────────────────────────
INCOME DOCUMENTS
  Salaried Borrowers:
  [ ] Most recent 30 days pay stubs (all jobs)
  [ ] W-2s — most recent 2 years (all employers)
  [ ] Federal tax returns — most recent 2 years (all pages, all schedules)
      (Required if: self-employed, rental income, unreimbursed expenses,
       tip income, seasonal employment, or income varies significantly)

  Self-Employed Borrowers (add to above):
  [ ] Business tax returns — most recent 2 years (all pages, all schedules)
  [ ] YTD Profit & Loss Statement (CPA-prepared preferred)
  [ ] Business bank statements — most recent 3 months
  [ ] Business license or CPA letter confirming self-employment

  Other Income (as applicable):
  [ ] Social Security award letter and most recent 1099-SSA
  [ ] Pension/retirement award letter and most recent statement
  [ ] Rental income — Schedule E and current lease agreements
  [ ] Alimony/child support — divorce decree and 12 months bank statements
      showing receipt (only if using for qualification)

ASSET DOCUMENTS
  [ ] Bank statements — most recent 2 months, ALL pages
      (All accounts: checking, savings, money market)
  [ ] Investment/brokerage statements — most recent 2 months, ALL pages
  [ ] Retirement statements — most recent quarterly statement
  [ ] Gift letter (if using gift funds) + donor bank statement showing funds

PROPERTY DOCUMENTS
  [ ] Fully executed purchase contract with all addenda
  [ ] MLS listing or property details…