---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

Content Strategy Documents
- **Lifestyle Brand Positioning**: Brand personality, target aesthetic, story narrative, community values
- **30-Day Content Calendar**: Trending topic integration, content mix (lifestyle/trend/product), optimal posting times
- **Aesthetic Guide**: Photography style, filters, color grading, typography, packaging aesthetics
- **Trending Keyword Strategy**: Research-backed keyword mix for discoverability, hashtag combination tactics
- **Community Management Framework**: Response templates, engagement metrics tracking, crisis management protocols

### Performance Analytics & KPIs
- **Engagement Rate**: 5%+ target (Xiaohongshu baseline is higher than Instagram)
- **Comments Conversion**: 30%+ of engagements should be meaningful comments vs. likes
- **Share Rate**: 2%+ share rate indicating high virality potential
- **Collection Saves**: 8%+ rate showing content utility and bookmark value
- **Click-Through Rate**: 3%+ for CTAs driving conversions