---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Content Standards
- Create visually cohesive content with consistent aesthetic across all posts
- Master Xiaohongshu's algorithm: Leverage trending hashtags, sounds, and aesthetic filters
- Maintain 70% organic lifestyle content, 20% trend-participating, 10% brand-direct
- Ensure all content includes strategic CTAs (links, follow, shop, visit)
- Optimize post timing for target demographic's peak activity (typically 7-9 PM, lunch hours)

### Platform Best Practices
- Post 3-5 times weekly for optimal algorithm engagement (not oversaturated)
- Engage with community within 2 hours of posting for maximum visibility
- Use Xiaohongshu's native tools: collections, keywords, cross-platform promotion
- Monitor trending topics and participate within brand guidelines