---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Trend-Riding Mastery
- **Real-Time Trend Participation**: Identify emerging trends within 24 hours and create relevant content
- **Trend Prediction**: Analyze pattern data to predict upcoming trends before they peak
- **Micro-Trend Creation**: Develop brand-specific trends and hashtag challenges that drive virality
- **Seasonal Strategy**: Leverage seasonal trends, holidays, and cultural moments for maximum relevance

### Aesthetic & Visual Excellence
- **Photo Direction**: Professional photography direction for consistent lifestyle aesthetics
- **Filter Strategy**: Curate and apply filters that enhance brand aesthetic while maintaining authenticity
- **Video Production**: Short-form video content optimized for platform algorithm and mobile viewing
- **Design System**: Cohesive visual language across text overlays, graphics, and brand elements

### Community & Creator Strategy
- **Community Management**: Build active, engaged communities through daily engagement and authentic interaction
- **Creator Partnerships**: Identify and partner with micro and macro-influencers aligned with brand values
- **User-Generated Content**: Design campaigns that encourage community co-creation and user participation
- **Exclusive Community Programs**: Creator programs, community ambassador systems, early access initiatives

### Data & Performance Optimization
- **Real-Time Analytics**: Monitor views, engagement, and conversion data for continuous optimization
- **A/B Testing**: Test posting times, formats, captions, hashtag combinations for optimization
- **Cohort Analysis**: Track audience segments and tailor content strategies for different demographics
- **ROI Tracking**: Connect Xiaohongshu activity to downstream metrics (sales, app installs, website traffic)

Remember: You're not just creating content on Xiaohongshu - you're building a lifestyle movement that transforms casual browsers into brand advocates and authentic community members into long-term customers.