---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Phase 1: Brand Lifestyle Positioning
1. **Audience Deep Dive**: Demographic profiling, interests, lifestyle aspirations, pain points
2. **Lifestyle Narrative Development**: Brand story, values, aesthetic personality, unique positioning
3. **Aesthetic Framework Creation**: Photography style (minimalist/maximal), filter preferences, color psychology
4. **Competitive Landscape**: Analyze top lifestyle brands in category, identify differentiation opportunities

### Phase 2: Content Strategy & Calendar
1. **Trending Topic Research**: Weekly trend analysis, upcoming seasonal opportunities, viral content patterns
2. **Content Mix Planning**: 70% lifestyle, 20% trend-participation, 10% product/brand promotion balance
3. **Content Pillars**: Define 4-5 core content categories that align with brand and audience interests
4. **Content Calendar**: 30-day rolling calendar with timing, trend integration, hashtag strategy

### Phase 3: Content Creation & Optimization
1. **Micro-Content Production**: Efficient content creation systems for consistent output (10+ posts per week capacity)
2. **Visual Consistency**: Apply aesthetic framework consistently across all content
3. **Copywriting Optimization**: Emotional hooks, trend-relevant language, strategic CTA placement
4. **Technical Optimization**: Image format (9:16 priority), video length (15-60s optimal), hashtag placement

### Phase 4: Community Building & Growth
1. **Active Engagement**: Comment on trending posts, respond to community within 2 hours
2. **Influencer Collaboration**: Partner with micro-influencers (10k-100k followers) for authentic amplification
3. **UGC Campaign**: Branded hashtag challenges, customer feature programs, community co-creation
4. **Data-Driven Iteration**: Weekly performance analysis, trend adaptation, audience feedback incorporation

### Phase 5: Performance Analysis & Scaling
1. **Weekly Performance Review**: Top-performing content analysis, trending topics effectiveness
2. **Algorithm Optimization**: Posting time refinement, hashtag performance tracking, engagement pattern analysis
3. **Conversion Tracking**: Link click tracking, e-commerce integration, downstream metric measurement
4. **Scaling Strategy**: Identify viral content patterns, expand successful content series, platform expansion