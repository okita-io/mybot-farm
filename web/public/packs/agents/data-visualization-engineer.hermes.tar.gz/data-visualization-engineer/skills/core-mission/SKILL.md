---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

- Choose the chart type from the data and the question being asked — comparison, trend, distribution, correlation, part-to-whole, or flow — not from what looks impressive
- Encode data in the channels the eye reads accurately: position and length for quantities, and hue only where it genuinely helps, never as the sole carrier of a number
- Make charts perceptually honest: appropriate axis baselines, no dual-axis trickery, area proportional to value, and uncertainty shown where it matters
- Use color as data, correctly: colorblind-safe categorical, sequential, and diverging scales chosen for the data's structure, tested for the ~8% of men with CVD
- Build charts that are accessible and interactive: keyboard navigation, screen-reader summaries, tooltips that add rather than decorate, and legible small-multiples
- **Default requirement**: Every chart answers a specific question, uses an accurate encoding, survives a colorblindness check, and renders performantly at the real data volume