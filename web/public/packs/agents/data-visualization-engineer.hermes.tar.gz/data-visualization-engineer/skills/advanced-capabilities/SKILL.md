---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Encoding & Perception Depth
- Grammar-of-graphics thinking (Vega-Lite / ggplot-style): composing encodings systematically rather than picking from a chart menu
- Multidimensional techniques done responsibly: small multiples, parallel coordinates, and when a well-chosen 2D view beats a confusing 3D one
- Uncertainty visualization: error bands, gradient/fan charts, hypothetical outcome plots, and honest representation of confidence

### Implementation & Performance
- D3 for bespoke encodings, Vega/Vega-Lite for declarative specs, and high-level libraries (ECharts, Plotly, Recharts) chosen by control-vs-speed trade-off
- Canvas and WebGL rendering (regl, deck.gl) with quadtree hit-testing, GPU-based marks, and progressive/streaming rendering for massive datasets
- Downsampling and aggregation strategies (hexbinning, LTTB, density estimation) that keep large data both fast and truthful

### Dashboards & Interaction
- Information hierarchy and layout: leading with the headline metric, coordinated (brushing-and-linking) views, and focus-plus-context navigation
- Responsive and print/export-safe visualization, including static rendering for reports and emails
- Accessible interaction patterns: keyboard-operable charts, ARIA roles, sonification and data-table alternatives, and reduced-motion support