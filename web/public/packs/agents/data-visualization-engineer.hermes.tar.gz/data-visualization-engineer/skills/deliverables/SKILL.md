---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Chart-Type Selection (question → encoding)

| The question | Right chart | Why (and the trap to avoid) |
|--------------|-------------|------------------------------|
| How do categories compare? | Sorted horizontal bars | Position/length read accurately; sorting is half the insight. Not a pie past 3 slices |
| How does a value change over time? | Line chart | Connection implies continuity; slope reads trend. Not bars for many time points |
| What's the distribution? | Histogram / box / violin | Shows spread, skew, outliers. Not a bar of the mean, which hides all of it |
| Are two variables related? | Scatter plot | Position-position is the most accurate 2-var encoding. Add a trend line, not a dual axis |
| Part-to-whole, few parts? | Stacked bar (or pie ≤3) | Whole is visible; parts comparable. Avoid many-slice pies |
| Compare many groups on the same metric? | Small multiples | Same scale, shared axis, eye scans a grid. Not one cluttered overlay |
| Flow / relationship between nodes? | Sankey / chord / node-link | Encodes magnitude of flow. Choose by whether direction and volume matter |

### Perceptual Honesty Checklist (before any chart ships)

```text
□ Baseline: bars start at zero; line-axis choice is labeled and defensible
□ Encoding: quantities in position/length, not area/angle; no 3D on 2D data
□ Dual axis: none, or explicitly justified and signposted
□ Aspect ratio: slopes not exaggerated by a squashed/stretched frame (bank to ~45°)
□ Aggregation: the mean isn't hiding a bimodal distribution or outliers
□ Sampling: any downsampling preserves the shape it claims to show
□ Uncertainty: error bars / bands shown where the data has real variance
□ Labels: axes, units, and a title that states the takeaway — not "Chart 1"
```

### Color as Data (colorblind-safe, structure-matched)

```javascript
// Match the SCALE TYPE to the data, and keep it CVD-safe.
import { scaleOrdinal, scaleSequential, scaleDiverging } from 'd3-scale';
import { interpolateViridis, interpolateRdBu } from 'd3-scale-chromatic';

// Categorical: distinct, colorblind-safe hues — cap at ~7 or the eye can't hold them
const category = scaleOrdinal()
  .range(['#4E79A7','#F28E2B','#59A14F','#E15759','#B07AA1','#76B7B2','#EDC948']);

// Sequential (ordered magnitude): perceptually-uniform, safe in grayscale + CVD
const magnitude = scaleSequential(interpolateViridis).domain([0, maxValue]);
//   ↑ viridis, not rainbow: rainbow has false luminance bands that invent boundaries

// Diverging (deviation from a meaningful midpoint, e.g. profit vs loss around 0)
const deviation = scaleDiverging(interpolateRdBu).domain([-max, 0, max]);

// RULE: never encode a category by hue ALONE — pair with shape, label, or direct labeling,
// and run the final chart through a CVD simulator (deuteranopia/protanopia) before shipping.
```

### Performance: Know the SVG → Canvas → WebGL Crossover

```text
Rendering budget by element count (interactive, 60fps target):
  ~1–1,000 marks      → SVG (crisp, easy interaction, accessible DOM nodes)
  ~1,000–50,000 marks → Canvas (one node; hit-test via quadtree for hover/tooltip)
  50,000+ marks       → WebGL / regl / deck.gl (GPU) OR aggregate first
Aggregate before you render when points overlap indistinguishably:
  scatter of 1M rows  → hexbin / density heatmap (the reader can't see 1M dots anyway)
  long time series    → largest-triangle-three-buckets downsampling (keeps the shape)
Measure frame time at the REAL row count, not the 200-row sample in the ticket.
```