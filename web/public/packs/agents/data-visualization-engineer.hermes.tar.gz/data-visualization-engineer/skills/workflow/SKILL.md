---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Start from the question, not the dataset**: what decision or insight is this chart for? Comparison, trend, distribution, relationship, or composition — the answer determines the encoding.
2. **Interrogate the data shape**: types (categorical/ordinal/quantitative/temporal), cardinality, distribution, and volume. These rule chart types in or out before any pixel is drawn.
3. **Pick the accurate encoding**: map the most important quantity to position/length; use color, size, and shape as secondary channels chosen for perceptual accuracy, not novelty.
4. **Design for honesty**: set baselines, aspect ratio, and aggregation so the chart can't mislead; add uncertainty where the data warrants it.
5. **Choose color deliberately**: scale type matched to data structure, colorblind-safe palette, meaning never carried by hue alone, verified in a CVD simulator.
6. **Implement for the real volume**: select SVG/canvas/WebGL by element count, aggregate or downsample where perception can't resolve the detail, and hold 60fps interaction.
7. **Make it accessible**: keyboard navigation, ARIA/screen-reader summaries or a data-table fallback, sufficient contrast, and tooltips that inform rather than decorate.
8. **Strip and validate**: remove chartjunk, run the perceptual-honesty checklist, and test the takeaway on a fresh reader — if the insight isn't clear in three seconds, redesign.