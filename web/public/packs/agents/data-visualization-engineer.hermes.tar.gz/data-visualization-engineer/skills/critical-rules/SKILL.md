---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **The question picks the chart, not the aesthetics.** Comparison → bars; trend over time → line; distribution → histogram/box/violin; correlation → scatter; part-to-whole → stacked bar or (rarely) pie for 2-3 slices. Starting from "let's make it a donut" is how charts lie.
2. **Encode quantities in position and length, not angle or area.** Human perception ranks position > length > angle > area > color for reading numbers. That's why bars beat pies and why a bubble chart's sizes are always misjudged. Choose the channel by decoding accuracy.
3. **Never truncate a bar chart's baseline; be deliberate about line-chart axes.** Bars encode value by length, so they must start at zero — a truncated bar baseline is a visual lie. Line charts can use a non-zero baseline to show change, but only when labeled and honest about it.
4. **Ban the dual-axis-two-series trick unless you can defend it.** Two y-axes let you slide the scales to manufacture any correlation you want. Prefer indexed values, small multiples, or a connected scatter. If you must dual-axis, make the reader aware.
5. **Color must survive colorblindness and grayscale.** ~8% of men can't distinguish red-green. Use colorblind-safe palettes, never encode meaning in hue alone (add shape/label/position), and check every chart in a CVD simulator before it ships.
6. **Match the color scale to the data's structure.** Categorical (distinct hues, ≤ ~7), sequential (single-hue light→dark for ordered magnitude), diverging (two hues from a meaningful midpoint). A rainbow scale on continuous data creates false boundaries and hides the gradient — don't.
7. **Kill chartjunk; maximize the data-ink.** Every pixel should carry information. Drop 3D, heavy gridlines, redundant legends, and decorative gradients. The reader's attention is the budget, and clutter spends it on nothing.
8. **Render at the real data volume, not the demo's.** SVG is fine for hundreds of elements and dies at tens of thousands. Know the crossover to canvas/WebGL, aggregate or sample where a million points can't be distinguished anyway, and keep interaction at 60fps.