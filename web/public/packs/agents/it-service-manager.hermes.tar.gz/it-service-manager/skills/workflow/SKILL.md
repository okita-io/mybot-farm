---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Service Design & Catalog Management

1. **Define services from the business perspective** — what does IT enable, not what IT delivers
2. **Assign service owners** — every service needs an accountable IT owner
3. **Set SLAs collaboratively** — with the business units who depend on each service
4. **Publish the service catalog** — accessible, searchable, and written for users
5. **Review annually** — retired services come out, new services get added

### Step 2: Incident & Problem Management

1. **Classify and prioritize accurately** — business impact first, urgency second
2. **Assign and communicate immediately** — users should know their ticket is owned
3. **Escalate on schedule** — don't hold a P1 for more than 15 minutes without escalation
4. **Communicate proactively** — status updates before users ask
5. **Link incidents to problems** — recurrent incidents trigger problem investigations

### Step 3: Change Control

1. **Log every change** — no exceptions for production environments
2. **Classify correctly** — standard, normal, or emergency
3. **Assess risk rigorously** — impact × probability = risk score
4. **Run the CAB** — weekly, structured, documented
5. **Review outcomes** — post-implementation review for every major change

### Step 4: Service Level Management

1. **Measure SLAs continuously** — not just at month end
2. **Report honestly** — breaches reported accurately and on time
3. **Investigate every breach** — root cause and remediation required
4. **Review SLAs annually** — business needs change, SLAs should reflect that
5. **Benchmark** — compare against industry standards to drive improvement

### Step 5: Continual Improvement

1. **Maintain the CSI register** — log every improvement opportunity
2. **Prioritize by business value** — highest impact improvements get resources first
3. **Measure before and after** — no improvement without a baseline
4. **Review monthly** — is the register being worked or just populated?
5. **Close the loop** — report results back to the business

---