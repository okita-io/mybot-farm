---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Service Catalog Framework

```
SERVICE CATALOG DESIGN TEMPLATE
───────────────────────────────────────
SERVICE RECORD
  Service Name:         [User-friendly name — not IT jargon]
  Service Description:  [What it does and who it's for — plain language]
  Service Owner:        [IT role responsible for this service]
  Service Category:     [Infrastructure / Application / End User / Business]

SERVICE DETAILS
  Business Value:       [Why this service matters to the business]
  Target Users:         [Who can request/use this service]
  Hours of Operation:   [24/7 / Business hours / Defined schedule]
  Support Hours:        [When support is available]
  Dependencies:         [Other services this depends on]

SERVICE LEVELS
  Availability target:  [e.g., 99.9% uptime]
  Recovery Time Obj:    RTO: [Hours to restore after outage]
  Recovery Point Obj:   RPO: [Maximum acceptable data loss]
  Response time:        [How fast IT responds to issues]
  Resolution time:      [How fast IT resolves issues]

REQUEST FULFILLMENT
  How to request:       [Portal URL / email / phone]
  Fulfillment time:     [Standard: X hours / Expedited: Y hours]
  Approvals required:   [Manager / Security / Finance / None]
  Cost to business:     [Chargeback amount if applicable]
  Inputs required:      [What the user must provide to request]

MAINTENANCE
  Last reviewed:        [Date]
  Next review:          [Date — no service should go unreviewed > 12 months]
  Review owner:         [Name]
```

### Incident Management Framework

```
INCIDENT MANAGEMENT PROTOCOL
───────────────────────────────────────
INCIDENT PRIORITY MATRIX:
              │ High Impact  │ Medium Impact │ Low Impact
  ────────────┼──────────────┼───────────────┼───────────
  High Urgency│ P1 — CRIT   │ P2 — HIGH     │ P3 — MED
  Med Urgency │ P2 — HIGH   │ P3 — MED      │ P4 — LOW
  Low Urgency │ P3 — MED    │ P4 — LOW      │ P4 — LOW

PRIORITY DEFINITIONS:
  P1 — Critical:
    - Complete service outage affecting all users
    - Core business process stopped (revenue, safety, compliance)
    - Response: 15 min | Resolution target: 4 hours
    - Escalation: Incident Commander + VP IT within 15 min
    - Status updates: Every 30 minutes

  P2 — High:
    - Major service degradation (significant user impact)
    - Single department or key system affected
    - Response: 30 min | Resolution target: 8 hours
    - Escalation: IT Manager within 30 min
    - Status updates: Every 60 minutes

  P3 — Medium:
    - Service impairment (workaround available)
    - Single user or small group affected
    - Response: 2 hours | Resolution target: 24 hours
    - Status updates: At significant milestones

  P4 — Low:
    - Minor issue with minimal business impact
    - Workaround readily available
    - Response: 8 hours | Resolution target: 72 hours

INCIDENT RECORD FIELDS (required):
  □ Incident ID (auto-generated)
  □ Reporter name and contact
  □ Date/time reported
  □ Priority (P1-P4)
# … truncated for farm planting — see upstream for the full sample
```

### Problem Management Framework

```
PROBLEM MANAGEMENT PROTOCOL
───────────────────────────────────────
PROBLEM TRIGGERS:
  □ Major incident (P1) — always triggers problem record
  □ Recurring incident pattern (same service, same symptoms, 3+ times in 30 days)
  □ Proactive discovery (monitoring, trend analysis, audit)
  □ External intelligence (vendor advisory, security bulletin)

PROBLEM RECORD FIELDS:
  □ Problem ID
  □ Linked incident records
  □ Affected service and CIs
  □ Problem statement (symptom description)
  □ Priority and business impact
  □ Problem owner and team
  □ Root cause analysis method used
  □ Root cause (when identified)
  □ Workaround (interim fix — documented in known error database)
  □ Permanent fix (proposed and implemented)
  □ Status (Open / Known Error / Fix In Progress / Resolved / Closed)

ROOT CAUSE ANALYSIS TOOLS:
  5 Whys:
    Symptom: [What happened]
    Why 1: [First level cause]
    Why 2: [Cause of Why 1]
    Why 3: [Cause of Why 2]
    Why 4: [Cause of Why 3]
    Why 5 (Root): [Fundamental cause]
    Fix: [What would prevent this at the root level]

  Fishbone (Ishikawa):
    Effect: [The problem]
    Causes by category:
      People:    [Human factors]
      Process:   [Process failures]
      Technology:[System/tool failures]
      Environment:[Infrastructure/environmental]
      Data:      [Data quality/availability]
      External:  [Third-party or external factors]…