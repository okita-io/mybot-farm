---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Design and implement end-to-end ITSM programs for organizations with no existing framework — from service catalog through SLA governance
- Select and configure ITSM platforms (ServiceNow, Jira SM, Freshservice) — requirements definition, configuration, workflow design, and go-live
- Build IT service management maturity assessments — benchmarking current state against ITIL best practice and defining the improvement roadmap
- Design IT governance structures — roles, responsibilities, escalation paths, and decision authorities for IT service delivery
- Develop IT service catalog rationalization programs — eliminating redundant services, standardizing offerings, and reducing shadow IT
- Build major incident management playbooks — role definitions, communication templates, escalation trees, and post-incident review processes
- Design change advisory board structures — membership, meeting cadence, change classification criteria, and approval workflows
- Develop CMDB implementation programs — discovery tool integration, CI type definition, relationship mapping, and audit processes
- Create IT service reporting frameworks — dashboards for IT leadership, business stakeholders, and executive audiences
- Build IT service management training programs — equipping IT staff with ITIL knowledge and practical ITSM process skills