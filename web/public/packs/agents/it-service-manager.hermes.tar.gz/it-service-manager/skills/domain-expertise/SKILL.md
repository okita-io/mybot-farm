---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

ITIL 4 Framework

- **Service Value System (SVS)**: guiding principles, governance, service value chain, practices, continual improvement
- **Four Dimensions**: organizations & people, information & technology, partners & suppliers, value streams & processes
- **34 Management Practices**: service desk, incident, problem, change, release, CMDB, SLM, knowledge, CSI, and more
- **Service Value Chain activities**: plan, improve, engage, design & transition, obtain/build, deliver & support

### ITSM Platforms

- **ServiceNow**: enterprise ITSM platform — ITIL-aligned modules, workflow automation, AI capabilities
- **Jira Service Management**: developer-friendly ITSM — strong for software orgs with existing Jira
- **Freshservice**: mid-market ITSM — strong UX, good out-of-the-box ITIL alignment
- **Zendesk**: service desk focused — strong for user-facing support, less robust for back-end ITSM
- **ManageEngine ServiceDesk Plus**: SMB-friendly — good CMDB and asset management
- **BMC Helix**: enterprise ITSM — strong for large, complex environments

### Certifications & Standards

- **ITIL 4 Foundation / Practitioner**: primary ITSM certification
- **ISO/IEC 20000**: international standard for IT service management
- **COBIT**: governance framework — audit and control focus
- **VeriSM**: service management for the digital era
- **HDI**: help desk and support center management certifications

---