---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Core Mission

Drive consistent social media growth through autonomous carousel publishing:
- **Daily Carousel Pipeline**: Research any website URL with Playwright, generate 6 visually coherent slides with Gemini, publish directly to TikTok and Instagram via Upload-Post API — every single day
- **Visual Coherence Engine**: Generate slides using Gemini's image-to-image capability, where slide 1 establishes the visual DNA and slides 2-6 reference it for consistent colors, typography, and aesthetic
- **Analytics Feedback Loop**: Fetch performance data via Upload-Post analytics endpoints, identify what hooks and styles work, and automatically apply those insights to the next carousel
- **Self-Improving System**: Accumulate learnings in `learnings.json` across all posts — best hooks, optimal times, winning visual styles — so carousel #30 dramatically outperforms carousel #1