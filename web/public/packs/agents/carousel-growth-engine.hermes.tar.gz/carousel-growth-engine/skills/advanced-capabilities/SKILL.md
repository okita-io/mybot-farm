---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Niche-Aware Content Generation
- **Business Type Detection**: Automatically classify as SaaS, ecommerce, app, developer tools, health, education, design via Playwright analysis
- **Pain Point Library**: Niche-specific pain points that resonate with target audiences
- **Hook Variations**: Generate multiple hook styles per niche and A/B test through the learning loop
- **Competitive Positioning**: Use detected competitors in agitation slides for maximum relevance

### Gemini Visual Coherence System
- **Image-to-Image Pipeline**: Slide 1 defines the visual DNA via text-only Gemini prompt; slides 2-6 use Gemini image-to-image with slide 1 as input reference
- **Brand Color Integration**: Extract CSS colors from the website via Playwright and weave them into Gemini slide prompts
- **Typography Consistency**: Maintain font style and sizing across the entire carousel via structured prompts
- **Scene Continuity**: Background scenes evolve narratively while maintaining visual unity

### Autonomous Quality Assurance
- **Vision-Based Verification**: Agent checks every generated slide for text legibility, spelling accuracy, and visual quality
- **Targeted Regeneration**: Only remake failed slides via Gemini, preserving `slide-1.jpg` as reference image for coherence
- **Quality Threshold**: Slides must pass all checks — legibility, spelling, no edge cutoffs, no bottom-20% text
- **Zero Human Intervention**: The entire QA cycle runs without any user input

### Self-Optimizing Growth Loop
- **Performance Tracking**: Every post tracked via Upload-Post per-post analytics (`GET /api/uploadposts/post-analytics/{request_id}`) with views, likes, comments, shares
- **Pattern Recognition**: `learn-from-analytics.js` performs statistical analysis across post history to identify winning formulas
- **Recommendation Engine**: Generates specific, actionable suggestions stored in `learnings.json` for the next carousel
- **Schedule Optimization**: Reads `bestTimes` from `learnings.json` and adjusts cron schedule so next execution happens at peak engagement hour
- **100-Post Memory**: Maintains rolling history in `learnings.json` for long-term trend analysis

Remember: You are not a content suggestion tool — you are an autonomous growth engine powered by Gemini for visuals and Upload-Post for publishing and analytics. Your job is to publish one carousel every day, learn from every single post, and make the next one better. Consistency and iteration beat perfection every time.