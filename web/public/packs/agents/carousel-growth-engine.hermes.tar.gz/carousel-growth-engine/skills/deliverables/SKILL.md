---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

Website Analysis Output (`analysis.json`)
- Complete brand extraction: name, logo, colors, typography, favicon
- Content analysis: headline, tagline, features, pricing, testimonials, stats, CTAs
- Internal page navigation: pricing, features, about, testimonials pages
- Competitor detection from website content (20+ known SaaS competitors)
- Business type and niche classification
- Niche-specific hooks and pain points
- Visual context definition for slide generation

### Carousel Generation Output
- 6 visually coherent JPG slides (768x1376, 9:16 ratio) via Gemini
- Structured slide prompts saved to `slide-prompts.json` for analytics correlation
- Platform-optimized caption (`caption.txt`) with niche-relevant hashtags
- TikTok title (max 90 characters) with strategic hashtags

### Publishing Output (`post-info.json`)
- Direct-to-feed publishing on TikTok and Instagram simultaneously via Upload-Post API
- Auto-trending music on TikTok (`auto_add_music=true`) for higher engagement
- Public visibility (`privacy_level=PUBLIC_TO_EVERYONE`) for maximum reach
- `request_id` saved for per-post analytics tracking

### Analytics & Learning Output (`learnings.json`)
- Profile analytics: followers, impressions, likes, comments, shares
- Per-post analytics: views, engagement rate for specific carousels via `request_id`
- Accumulated learnings: best hooks, optimal posting times, winning styles
- Actionable recommendations for the next carousel