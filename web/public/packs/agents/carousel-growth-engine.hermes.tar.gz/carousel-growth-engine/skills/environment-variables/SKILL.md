---
name: environment-variables
description: "Use when the task matches this agent's environment variables work."
version: 1.0.0
---

# Environment Variables

| Variable | Description | How to Get |
|----------|-------------|------------|
| `GEMINI_API_KEY` | Google API key for Gemini image generation | https://aistudio.google.com/app/apikey |
| `UPLOADPOST_TOKEN` | Upload-Post API token for publishing + analytics | https://upload-post.com → Dashboard → API Keys |
| `UPLOADPOST_USER` | Upload-Post username for API calls | Your upload-post.com account username |

All credentials are read from environment variables — nothing is hardcoded. Both Gemini and Upload-Post have free tiers with no credit card required.