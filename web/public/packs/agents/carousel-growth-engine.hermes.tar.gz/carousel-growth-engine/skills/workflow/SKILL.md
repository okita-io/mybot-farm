---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Phase 1: Learn from History
1. **Fetch Analytics**: Call Upload-Post analytics endpoints for profile metrics and per-post performance via `check-analytics.sh`
2. **Extract Insights**: Run `learn-from-analytics.js` to identify best-performing hooks, optimal posting times, and engagement patterns
3. **Update Learnings**: Accumulate insights into `learnings.json` persistent knowledge base
4. **Plan Next Carousel**: Read `learnings.json`, pick hook style from top performers, schedule at optimal time, apply recommendations

### Phase 2: Research & Analyze
1. **Website Scraping**: Run `analyze-web.js` for full Playwright-based analysis of the target URL
2. **Brand Extraction**: Colors, typography, logo, favicon for visual consistency
3. **Content Mining**: Features, testimonials, stats, pricing, CTAs from all internal pages
4. **Niche Detection**: Classify business type and generate niche-appropriate storytelling
5. **Competitor Mapping**: Identify competitors mentioned in website content

### Phase 3: Generate & Verify
1. **Slide Generation**: Run `generate-slides.sh` which calls `generate_image.py` via `uv` to create 6 slides with Gemini (`gemini-3.1-flash-image-preview`)
2. **Visual Coherence**: Slide 1 from text prompt; slides 2-6 use Gemini image-to-image with `slide-1.jpg` as `--input-image`
3. **Vision Verification**: Agent uses its own vision model to check each slide for text legibility, spelling, quality, and no text in bottom 20%
4. **Auto-Regeneration**: If any slide fails, regenerate only that slide with Gemini (using `slide-1.jpg` as reference), re-verify until all 6 pass

### Phase 4: Publish & Track
1. **Multi-Platform Publishing**: Run `publish-carousel.sh` to push 6 slides to Upload-Post API (`POST /api/upload_photos`) with `platform[]=tiktok&platform[]=instagram`
2. **Trending Music**: `auto_add_music=true` adds trending music on TikTok for algorithmic boost
3. **Metadata Capture**: Save `request_id` from API response to `post-info.json` for analytics tracking
4. **User Notification**: Report published TikTok + Instagram URLs only after everything succeeds
5. **Self-Schedule**: Read `learnings.json` bestTimes and set next cron execution at the optimal hour