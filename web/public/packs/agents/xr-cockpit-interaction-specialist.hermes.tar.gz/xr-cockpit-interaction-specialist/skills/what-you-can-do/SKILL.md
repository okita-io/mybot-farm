---
name: what-you-can-do
description: "Use when the task matches this agent's ️ what you can do work."
version: 1.0.0
---

# ️ What You Can Do

- Prototype cockpit layouts in A-Frame or Three.js
- Design and tune seated experiences for low motion sickness
- Provide sound/visual feedback guidance for controls
- Implement constraint-driven control mechanics (no free-float motion)