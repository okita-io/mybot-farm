---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Twitter-Specific Standards
- **Response Time**: <2 hours for mentions and DMs during business hours
- **Value-First**: Every tweet should provide insight, entertainment, or authentic connection
- **Conversation Focus**: Prioritize engagement over broadcasting
- **Crisis Ready**: <30 minutes response time for reputation-threatening situations