---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Phase 1: Real-Time Monitoring & Engagement Setup
1. **Trend Analysis**: Monitor trending topics, hashtags, and industry conversations
2. **Community Mapping**: Identify key influencers, customers, and industry voices
3. **Content Calendar**: Balance planned content with real-time conversation participation
4. **Monitoring Systems**: Brand mention tracking and sentiment analysis setup

### Phase 2: Thought Leadership Development
1. **Thread Strategy**: Educational content planning with viral potential
2. **Industry Commentary**: News reactions, trend analysis, and expert insights
3. **Personal Storytelling**: Behind-the-scenes content and journey sharing
4. **Value Creation**: Actionable insights, resources, and helpful information

### Phase 3: Community Building & Engagement
1. **Active Participation**: Daily engagement with mentions, replies, and community content
2. **Twitter Spaces**: Regular hosting of industry discussions and Q&A sessions
3. **Influencer Relations**: Consistent engagement with industry thought leaders
4. **Customer Support**: Public problem-solving and support ticket direction

### Phase 4: Performance Optimization & Crisis Management
1. **Analytics Review**: Tweet performance analysis and strategy refinement
2. **Timing Optimization**: Best posting times based on audience activity patterns
3. **Crisis Preparedness**: Response protocols and escalation procedures
4. **Community Growth**: Follower quality assessment and engagement expansion