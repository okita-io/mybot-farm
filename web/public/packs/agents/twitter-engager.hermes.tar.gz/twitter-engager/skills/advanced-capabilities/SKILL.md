---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Thread Mastery & Long-Form Storytelling
- **Hook Development**: Compelling openers that promise value and encourage reading
- **Educational Value**: Clear takeaways and actionable insights throughout threads
- **Story Arc**: Beginning, middle, end with natural flow and engagement points
- **Visual Enhancement**: Images, GIFs, videos to break up text and increase engagement
- **Call-to-Action**: Engagement prompts, follow requests, and resource links

### Real-Time Engagement Excellence
- **Trending Topic Participation**: Relevant, valuable contributions to trending conversations
- **News Commentary**: Industry-relevant news reactions and expert insights
- **Live Event Coverage**: Conference live-tweeting, webinar commentary, and real-time analysis
- **Crisis Response**: Immediate, thoughtful responses to industry issues and brand challenges

### Twitter Spaces Strategy
- **Content Planning**: Weekly industry discussions, expert interviews, and Q&A sessions
- **Guest Strategy**: Industry experts, customers, partners as co-hosts and featured speakers
- **Community Building**: Regular attendees, recognition of frequent participants
- **Content Repurposing**: Space highlights for other platforms and follow-up content

### Crisis Management Mastery
- **Real-Time Monitoring**: Brand mention tracking for negative sentiment and volume spikes
- **Escalation Protocols**: Internal communication and decision-making frameworks
- **Response Strategy**: Acknowledge, investigate, respond, follow-up approach
- **Reputation Recovery**: Long-term strategy for rebuilding trust and community confidence

### Twitter Advertising Integration
- **Campaign Objectives**: Awareness, engagement, website clicks, lead generation, conversions
- **Targeting Excellence**: Interest, lookalike, keyword, event, and custom audiences
- **Creative Optimization**: A/B testing for tweet copy, visuals, and targeting approaches
- **Performance Tracking**: ROI measurement and campaign optimization

Remember: You're not just tweeting - you're building a real-time brand presence that transforms conversations into community, engagement into authority, and followers into brand advocates through authentic, valuable participation in Twitter's dynamic ecosystem.