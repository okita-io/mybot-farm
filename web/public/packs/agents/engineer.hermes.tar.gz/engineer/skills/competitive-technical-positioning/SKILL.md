---
name: competitive-technical-positioning
description: "Use when the task matches this agent's competitive technical positioning work."
version: 1.0.0
---

# Competitive Technical Positioning

FIA Framework — Fact, Impact, Act
For every competitor, build technical battlecards using the FIA structure. This keeps positioning fact-based and actionable instead of emotional and reactive.

* **Fact**: An objectively true statement about the competitor's product or approach. No spin, no exaggeration. Credibility is the SE's most valuable asset — lose it once and the technical evaluation is over.
* **Impact**: Why this fact matters to the buyer. A fact without business impact is trivia. "Competitor X requires a dedicated ETL layer for data ingestion" is a fact. "That means your team maintains another integration point, adding 2-3 weeks to implementation and ongoing maintenance overhead" is impact.
* **Act**: What to say or do. The specific talk track, question to ask, or demo moment to engineer that makes this point land.

### Repositioning Over Attacking
Never trash the competition. Buyers respect SEs who acknowledge competitor strengths while clearly articulating differentiation. The pattern:

* "They're great for [acknowledged strength]. Our customers typically need [different requirement] because [business reason], which is where our approach differs."
* This positions you as confident and informed. Attacking competitors makes you look insecure and raises the buyer's defenses.

### Landmine Questions for Discovery
During technical discovery, ask questions that naturally surface requirements where your product excels. These are legitimate, useful questions that also happen to expose competitive gaps:

* "How do you handle [scenario where your architecture is uniquely strong] today?"
* "What happens when [edge case that your product handles natively and competitors don't]?"
* "Have you evaluated how [requirement that maps to your differentiator] will scale as your team grows?"

The key: these questions must be genuinely useful to the buyer's evaluation. If they feel planted, they backfire. Ask them because understanding the answer improves your solution design — the competitive advantage is a side effect.

### Winning / Battling / Losing Zones — Technical Layer
For each competitor in an active deal, categorize technical evaluation criteria:

* **Winning**: Your architecture, performance, or integration capability is demonstrably superior. Build demo moments around these. Make them weighted heavily in the evaluation.
* **Battling**: Both products handle it adequately. Shift the conversation to implementation speed, operational overhead, or total cost of ownership where you can create separation.
* **Losing**: The competitor is genuinely stronger here. Acknowledge it. Then reframe: "That capability matters — and for teams focused primarily on [their use case], it's a strong choice. For your environment, where [buyer's priority] is the primary driver, here's why [your approach] delivers more long-term value."