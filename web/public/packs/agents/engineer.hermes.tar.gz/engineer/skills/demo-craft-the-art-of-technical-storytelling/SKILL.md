---
name: demo-craft-the-art-of-technical-storytelling
description: "Use when the task matches this agent's demo craft — the art of technical storytelling work."
version: 1.0.0
---

# Demo Craft — The Art of Technical Storytelling

Lead With Impact, Not Features
A demo is not a product tour. A demo is a narrative where the buyer sees their problem solved in real time. The structure:

1. **Quantify the problem first**: Before touching the product, restate the buyer's pain with specifics from discovery. "You told us your team spends 6 hours per week manually reconciling data across three systems. Let me show you what that looks like when it's automated."
2. **Show the outcome**: Lead with the end state — the dashboard, the report, the workflow result — before explaining how it works. Buyers care about what they get before they care about how it's built.
3. **Reverse into the how**: Once the buyer sees the outcome and reacts ("that's exactly what we need"), then walk back through the configuration, setup, and architecture. Now they're learning with intent, not enduring a feature walkthrough.
4. **Close with proof**: End on a customer reference or benchmark that mirrors their situation. "Company X in your space saw a 40% reduction in reconciliation time within the first 30 days."

### Tailored Demos Are Non-Negotiable
A generic product overview signals you don't understand the buyer. Before every demo:

* Review discovery notes and map the buyer's top three pain points to specific product capabilities
* Identify the audience — technical evaluators need architecture and API depth; business sponsors need outcomes and timelines
* Prepare two demo paths: the planned narrative and a flexible deep-dive for the moment someone says "can you show me how that works under the hood?"
* Use the buyer's terminology, their data model concepts, their workflow language — not your product's vocabulary
* Adjust in real time. If the room shifts interest to an unplanned area, follow the energy. Rigid demos lose rooms.

### The "Aha Moment" Test
Every demo should produce at least one moment where the buyer says — or clearly thinks — "that's exactly what we need." If you finish a demo and that moment didn't happen, the demo failed. Plan for it: identify which capability will land hardest for this specific audience and build the narrative arc to peak at that moment.