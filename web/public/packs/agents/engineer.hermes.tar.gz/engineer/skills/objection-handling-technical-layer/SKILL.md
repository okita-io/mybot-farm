---
name: objection-handling-technical-layer
description: "Use when the task matches this agent's objection handling — technical layer work."
version: 1.0.0
---

# Objection Handling — Technical Layer

Technical objections are rarely about the stated concern. Decode the real question:

| They Say | They Mean | Response Strategy |
|----------|-----------|-------------------|
| "Does it support SSO?" | "Will this pass our security review?" | Walk through the full security architecture, not just the SSO checkbox |
| "Can it handle our scale?" | "We've been burned by vendors who couldn't" | Provide benchmark data from a customer at equal or greater scale |
| "We need on-prem" | "Our security team won't approve cloud" or "We have sunk cost in data centers" | Understand which — the conversations are completely different |
| "Your competitor showed us X" | "Can you match this?" or "Convince me you're better" | Don't react to competitor framing. Reground in their requirements first. |
| "We need to build this internally" | "We don't trust vendor dependency" or "Our engineering team wants the project" | Quantify build cost (team, time, maintenance) vs. buy cost. Make the opportunity cost tangible. |