---
name: poc-scoping-where-deals-are-won-or-lost
description: "Use when the task matches this agent's poc scoping — where deals are won or lost work."
version: 1.0.0
---

# POC Scoping — Where Deals Are Won or Lost

Design Principles
A proof of concept is not a free trial. It's a structured evaluation with a binary outcome: pass or fail, against criteria defined before the first configuration.

* **Start with the problem statement**: "This POC will prove that [product] can [specific capability] in [buyer's environment] within [timeframe], measured by [success criteria]." If you can't write that sentence, the POC isn't scoped.
* **Define success criteria in writing before starting**: Ambiguous success criteria produce ambiguous outcomes, which produce "we need more time to evaluate," which means you lost. Get explicit: what does pass look like? What does fail look like?
* **Scope aggressively**: The single biggest risk in a POC is scope creep. A focused POC that proves one critical thing beats a sprawling POC that proves nothing conclusively. When the buyer asks "can we also test X?", the answer is: "Absolutely — in phase two. Let's nail the core use case first so you have a clear decision point."
* **Set a hard timeline**: Two to three weeks for most POCs. Longer POCs don't produce better decisions — they produce evaluation fatigue and competitor counter-moves. The timeline creates urgency and forces prioritization.
* **Build in checkpoints**: Midpoint review to confirm progress and catch misalignment early. Don't wait until the final readout to discover the buyer changed their criteria.

### POC Execution Template
```markdown
# Proof of Concept: [Account Name]

## Problem Statement
[One sentence: what this POC will prove]

## Success Criteria (agreed with buyer before start)
| Criterion                        | Target              | Measurement Method         |
|----------------------------------|---------------------|----------------------------|
| [Specific capability]            | [Quantified target] | [How it will be measured]  |
| [Integration requirement]        | [Pass/Fail]         | [Test scenario]            |
| [Performance benchmark]          | [Threshold]         | [Load test / timing]       |

## Scope — In / Out
**In scope**: [Specific features, integrations, workflows]
**Explicitly out of scope**: [What we're NOT testing and why]

## Timeline
- Day 1-2: Environment setup and configuration
- Day 3-7: Core use case implementation
- Day 8: Midpoint review with buyer
- Day 9-12: Refinement and edge case testing
- Day 13-14: Final readout and decision meeting

## Decision Gate
At the final readout, the buyer will make a GO / NO-GO decision based on the success criteria above.
```