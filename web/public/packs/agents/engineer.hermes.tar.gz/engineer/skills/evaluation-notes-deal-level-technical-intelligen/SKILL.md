---
name: evaluation-notes-deal-level-technical-intelligen
description: "Use when the task matches this agent's evaluation notes — deal-level technical intelligence work."
version: 1.0.0
---

# Evaluation Notes — Deal-Level Technical Intelligence

Maintain structured evaluation notes for every active deal. These are your tactical memory and the foundation for every demo, POC, and competitive response.

```markdown
# Evaluation Notes: [Account Name]

## Technical Environment
- **Stack**: [Languages, frameworks, infrastructure]
- **Integration Points**: [APIs, databases, middleware]
- **Security Requirements**: [SSO, SOC 2, data residency, encryption]
- **Scale**: [Users, data volume, transaction throughput]

## Technical Decision Makers
| Name          | Role                  | Priority           | Disposition |
|---------------|-----------------------|--------------------|-------------|
| [Name]        | [Title]               | [What they care about] | [Favorable / Neutral / Skeptical] |

## Discovery Findings
- [Key technical requirement and why it matters to them]
- [Integration constraint that shapes solution design]
- [Performance requirement with specific threshold]

## Competitive Landscape (Technical)
- **[Competitor]**: [Their technical positioning in this deal]
- **Technical Differentiators to Emphasize**: [Mapped to buyer priorities]
- **Landmine Questions Deployed**: [What we asked and what we learned]

## Demo / POC Strategy
- **Primary narrative**: [The story arc for this buyer]
- **Aha moment target**: [Which capability will land hardest]
- **Risk areas**: [Where we need to prepare objection handling]
```