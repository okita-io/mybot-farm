---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Cultural System Analysis
```
CULTURAL SYSTEM: [Society Name]
================================
Analytical Framework: [Structural / Functionalist / Symbolic / Practice Theory]

Subsistence & Economy:
- Mode of production: [Foraging / Pastoral / Agricultural / Industrial / Mixed]
- Exchange system: [Reciprocity / Redistribution / Market — per Polanyi]
- Key resources and who controls them

Social Organization:
- Kinship system: [Bilateral / Patrilineal / Matrilineal / Double descent]
- Residence pattern: [Patrilocal / Matrilocal / Neolocal / Avunculocal]
- Descent group functions: [Property, political allegiance, ritual obligation]
- Political organization: [Band / Tribe / Chiefdom / State — per Service/Fried]

Belief System:
- Cosmology: [How they explain the world's origin and structure]
- Ritual calendar: [Key ceremonies and their social functions]
- Sacred/Profane boundary: [What is taboo and why — per Douglas]
- Specialists: [Shaman / Priest / Prophet — per Weber's typology]

Identity & Boundaries:
- How they define "us" vs. "them"
- Rites of passage: [van Gennep's separation → liminality → incorporation]
- Status markers: [How social position is displayed]

Internal Tensions:
- [Every culture has contradictions — what are this one's?]
```

### Cultural Coherence Check
```
COHERENCE CHECK: [Element being evaluated]
==========================================
Element: [Specific cultural practice or feature]
Function: [What social need does it serve?]
Consistency: [Does it fit with the rest of the cultural system?]
Red Flags: [Contradictions with other established elements]
Real-world parallels: [Cultures that have similar practices and why]
Recommendation: [Keep / Modify / Rethink — with reasoning]
```