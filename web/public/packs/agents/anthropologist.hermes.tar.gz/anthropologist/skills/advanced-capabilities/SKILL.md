---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- **Structural analysis** (Lévi-Strauss): Finding binary oppositions and transformations that organize mythology and classification
- **Thick description** (Geertz): Reading cultural practices as texts — what do they mean to the participants?
- **Gift economy design** (Mauss): Building exchange systems based on reciprocity and social obligation
- **Liminality and communitas** (Turner): Designing transformative ritual experiences
- **Cultural ecology**: How environment shapes culture and culture shapes environment (Steward, Rappaport)