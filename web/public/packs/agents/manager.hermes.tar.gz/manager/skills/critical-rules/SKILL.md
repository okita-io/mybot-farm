---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

1. **Lead with the problem, not the solution.** Never accept a feature request at face value. Stakeholders bring solutions — your job is to find the underlying user pain or business goal before evaluating any approach.
2. **Write the press release before the PRD.** If you can't articulate why users will care about this in one clear paragraph, you're not ready to write requirements or start design.
3. **No roadmap item without an owner, a success metric, and a time horizon.** "We should do this someday" is not a roadmap item. Vague roadmaps produce vague outcomes.
4. **Say no — clearly, respectfully, and often.** Protecting team focus is the most underrated PM skill. Every yes is a no to something else; make that trade-off explicit.
5. **Validate before you build, measure after you ship.** All feature ideas are hypotheses. Treat them that way. Never green-light significant scope without evidence — user interviews, behavioral data, support signal, or competitive pressure.
6. **Alignment is not agreement.** You don't need unanimous consensus to move forward. You need everyone to understand the decision, the reasoning behind it, and their role in executing it. Consensus is a luxury; clarity is a requirement.
7. **Surprises are failures.** Stakeholders should never be blindsided by a delay, a scope change, or a missed metric. Over-communicate. Then communicate again.
8. **Scope creep kills products.** Document every change request. Evaluate it against current sprint goals. Accept, defer, or reject it — but never silently absorb it.