---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Phase 1 — Discovery
- Run structured problem interviews (minimum 5, ideally 10+ before evaluating solutions)
- Mine behavioral analytics for friction patterns, drop-off points, and unexpected usage
- Audit support tickets and NPS verbatims for recurring themes
- Map the current end-to-end user journey to identify where users struggle, abandon, or work around the product
- Synthesize findings into a clear, evidence-backed problem statement
- Share discovery synthesis broadly — design, engineering, and leadership should see the raw signal, not just the conclusions

### Phase 2 — Framing & Prioritization
- Write the Opportunity Assessment before any solution discussion
- Align with leadership on strategic fit and resource appetite
- Get rough effort signal from engineering (t-shirt sizing, not full estimation)
- Score against current roadmap using RICE or equivalent
- Make a formal build / explore / defer / kill recommendation — and document the reasoning

### Phase 3 — Definition
- Write the PRD collaboratively, not in isolation — engineers and designers should be in the room (or the doc) from the start
- Run a PRFAQ exercise: write the launch email and the FAQ a skeptical user would ask
- Facilitate the design kickoff with a clear problem brief, not a solution brief
- Identify all cross-team dependencies early and create a tracking log
- Hold a "pre-mortem" with engineering: "It's 8 weeks from now and the launch failed. Why?"
- Lock scope and get explicit written sign-off from all stakeholders before dev begins

### Phase 4 — Delivery
- Own the backlog: every item is prioritized, refined, and has unambiguous acceptance criteria before hitting a sprint
- Run or support sprint ceremonies without micromanaging how engineers execute
- Resolve blockers fast — a blocker sitting for more than 24 hours is a PM failure
- Protect the team from context-switching and scope creep mid-sprint
- Send a weekly async status update to stakeholders — brief, honest, and proactive about risks
- No one should ever have to ask "What's the status?" — the PM publishes before anyone asks

### Phase 5 — Launch
- Own GTM coordination across marketing, sales, support, and CS
- Define the rollout strategy: feature flags, phased cohorts, A/B experiment, or full release
- Confirm support and CS are trained and equipped before GA — not the day of
- Write the rollback runbook before flipping the flag
- Monitor launch metrics daily for the first two weeks with a defined anomaly threshold
- Send a launch summary to the company within 48 hours of GA — what shipped, who can use it, why it matters

### Phase 6 — Measurement & Learning
- Review success metrics vs. targets at 30 / 60 / 90 days post-launch
- Write and share a launch retrospective doc — what we predicted, what actually happened, why
- Run post-launch user interviews to surface unexpected behavior or unmet needs
- Feed insights back into the discovery backlog to drive the next cycle
- If a feature missed its goals, treat it as a learning, not a failure — and document the hypothesis that was wrong