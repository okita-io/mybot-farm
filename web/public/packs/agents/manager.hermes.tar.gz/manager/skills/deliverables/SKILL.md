---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# ️ Technical Deliverables

Product Requirements Document (PRD)

```markdown
# PRD: [Feature / Initiative Name]
**Status**: Draft | In Review | Approved | In Development | Shipped
**Author**: [PM Name]  **Last Updated**: [Date]  **Version**: [X.X]
**Stakeholders**: [Eng Lead, Design Lead, Marketing, Legal if needed]

---

## 1. Problem Statement
What specific user pain or business opportunity are we solving?
Who experiences this problem, how often, and what is the cost of not solving it?

**Evidence:**
- User research: [interview findings, n=X]
- Behavioral data: [metric showing the problem]
- Support signal: [ticket volume / theme]
- Competitive signal: [what competitors do or don't do]

---

## 2. Goals & Success Metrics
| Goal | Metric | Current Baseline | Target | Measurement Window |
|------|--------|-----------------|--------|--------------------|
| Improve activation | % users completing setup | 42% | 65% | 60 days post-launch |
| Reduce support load | Tickets/week on this topic | 120 | <40 | 90 days post-launch |
| Increase retention | 30-day return rate | 58% | 68% | Q3 cohort |

---

## 3. Non-Goals
Explicitly state what this initiative will NOT address in this iteration.
- We are not redesigning the onboarding flow (separate initiative, Q4)
- We are not supporting mobile in v1 (analytics show <8% mobile usage for this feature)
- We are not adding admin-level configuration until we validate the base behavior

---

## 4. User Personas & Stories
**Primary Persona**: [Name] — [Brief context, e.g., "Mid-market ops manager, 200-employee company, uses the product daily"]

Core user stories with acceptance criteria:
# … truncated for farm planting — see upstream for the full sample
```

---

### Opportunity Assessment

```markdown
# Opportunity Assessment: [Name]
**Submitted by**: [PM]  **Date**: [date]  **Decision needed by**: [date]

---

## 1. Why Now?
What market signal, user behavior shift, or competitive pressure makes this urgent today?
What happens if we wait 6 months?

---

## 2. User Evidence
**Interviews** (n=X):
- Key theme 1: "[representative quote]" — observed in X/Y sessions
- Key theme 2: "[representative quote]" — observed in X/Y sessions

**Behavioral Data**:
- [Metric]: [current state] — indicates [interpretation]
- [Funnel step]: X% drop-off — [hypothesis about cause]

**Support Signal**:
- X tickets/month containing [theme] — [% of total volume]
- NPS detractor comments: [recurring theme]

---

## 3. Business Case
- **Revenue impact**: [Estimated ARR lift, churn reduction, or upsell opportunity]
- **Cost impact**: [Support cost reduction, infra savings, etc.]
- **Strategic fit**: [Connection to current OKRs — quote the objective]
- **Market sizing**: [TAM/SAM context relevant to this feature space]

---

## 4. RICE Prioritization Score
| Factor | Value | Notes |
|--------|-------|-------|
| Reach | [X users/quarter] | Source: [analytics / estimate] |
| Impact | [0.25 / 0.5 / 1 / 2 / 3] | [justification] |
| Confidence | [X%] | Based on: [interviews / data / analogous features] |
# … truncated for farm planting — see upstream for the full sample
```

---

### Roadmap (Now / Next / Later)

```markdown
# Product Roadmap — [Team / Product Area] — [Quarter Year]

## 🌟 North Star Metric
[The single metric that best captures whether users are getting value and the business is healthy]
**Current**: [value]  **Target by EOY**: [value]

## Supporting Metrics Dashboard
| Metric | Current | Target | Trend |
|--------|---------|--------|-------|
| [Activation rate] | X% | Y% | ↑/↓/→ |
| [Retention D30] | X% | Y% | ↑/↓/→ |
| [Feature adoption] | X% | Y% | ↑/↓/→ |
| [NPS] | X | Y | ↑/↓/→ |

---

## 🟢 Now — Active This Quarter
Committed work. Engineering, design, and PM fully aligned.

| Initiative | User Problem | Success Metric | Owner | Status | ETA |
|------------|-------------|----------------|-------|--------|-----|
| [Feature A] | [pain solved] | [metric + target] | [name] | In Dev | Week X |
| [Feature B] | [pain solved] | [metric + target] | [name] | In Design | Week X |
| [Tech Debt X] | [engineering health] | [metric] | [name] | Scoped | Week X |

---

## 🟡 Next — Next 1–2 Quarters
Directionally committed. Requires scoping before dev starts.

| Initiative | Hypothesis | Expected Outcome | Confidence | Blocker |
|------------|------------|-----------------|------------|---------|
| [Feature C] | [If we build X, users will Y] | [metric target] | High | None |…