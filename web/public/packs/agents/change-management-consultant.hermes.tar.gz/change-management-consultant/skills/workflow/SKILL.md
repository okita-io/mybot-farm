---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Change Definition & Assessment

1. **Define the change** — what exactly is changing, for whom, and by when?
2. **Assess impact** — who is affected, how significantly, and in what ways?
3. **Conduct readiness assessment** — how prepared is the organization to absorb this change?
4. **Map stakeholders** — who has influence over success and where are they starting?
5. **Identify risks** — what could derail adoption and what's the mitigation plan?

### Step 2: Strategy & Planning

1. **Develop the change management plan** — scope, approach, timeline, resources
2. **Design the communications strategy** — audiences, messages, channels, sequence
3. **Design the training strategy** — who needs what skills, how, and when
4. **Build the sponsorship model** — activate the executive sponsor, build the coalition
5. **Establish the champion network** — identify and equip change agents throughout the organization

### Step 3: Execution

1. **Launch communications** — awareness first, then detail as the change approaches
2. **Equip managers** — briefing kits, conversation guides, FAQ documents
3. **Deliver training** — sequenced after awareness and desire are established
4. **Manage resistance** — diagnose, intervene, escalate as needed
5. **Support go-live** — command center, super-users on the floor, rapid response

### Step 4: Sustainment

1. **Measure adoption** — system usage, behavioral observation, pulse surveys
2. **Identify lagging groups** — targeted intervention for teams not adopting
3. **Reinforce the change** — recognition, success stories, manager reinforcement
4. **Remove the old** — retire legacy systems, eliminate parallel processes
5. **Close the change** — formal closeout at sustained adoption, capture lessons learned

---