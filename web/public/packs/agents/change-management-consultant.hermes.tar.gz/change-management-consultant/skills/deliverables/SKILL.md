---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

ADKAR Model Application

```
ADKAR ASSESSMENT & INTERVENTION GUIDE
───────────────────────────────────────
ADKAR = Awareness → Desire → Knowledge → Ability → Reinforcement
Each person must move through all five in sequence.
A barrier at any stage blocks adoption — regardless of progress on others.

AWARENESS — Do people know WHY the change is happening?
  Assessment questions:
    - Can employees articulate why this change is necessary?
    - Do they understand the consequences of not changing?
    - Have they heard the message from credible sources?

  Gap indicators:
    - "I don't understand why we're doing this"
    - Rumors and misinformation spreading
    - People unaware the change is happening at all

  Interventions:
    □ Sponsor communications explaining the business case
    □ Town halls with Q&A to address confusion
    □ Manager briefing kits for team conversations
    □ FAQ documents addressing common questions

DESIRE — Do people WANT to support and participate?
  Assessment questions:
    - Are employees motivated to make the change work?
    - Do they see personal benefit in the change?
    - Are they actively resisting or passively complying?

  Gap indicators:
    - "I know why we're doing this but I don't agree with it"
    - Visible resistance or workarounds being created
    - Champions and sponsors not engaged

  Interventions:
    □ Address WIIFM (What's In It For Me) explicitly by audience
    □ Involve resistors in design to build ownership
    □ Peer influence through change champion network
    □ Incentives aligned to adoption behaviors

# … truncated for farm planting — see upstream for the full sample
```

### Stakeholder Analysis Framework

```
STAKEHOLDER MAPPING
───────────────────────────────────────
For each major stakeholder group:

Group:              [Name / Department / Role]
Size:               [# of people affected]
Impact level:       High / Medium / Low (how much does this change affect them?)
Influence level:    High / Medium / Low (how much can they influence adoption?)
Current state:      Unaware / Aware / Resistant / Neutral / Supportive / Champion
Target state:       [Where they need to be by go-live]
Gap:                [What needs to happen to move them from current to target]
Key concerns:       [What they're worried about — specific, not assumed]
WIIFM:              [What's actually in it for this group?]
Engagement approach:[How and when we engage this group]
Owner:              [Who manages this relationship]

STAKEHOLDER GRID (Influence × Support):
  ┌─────────────────────┬─────────────────────┐
  │  HIGH INFLUENCE     │  HIGH INFLUENCE     │
  │  LOW SUPPORT        │  HIGH SUPPORT       │
  │  → Manage closely   │  → Leverage as      │
  │  → Address concerns │    champions        │
  ├─────────────────────┼─────────────────────┤
  │  LOW INFLUENCE      │  LOW INFLUENCE      │
  │  LOW SUPPORT        │  HIGH SUPPORT       │
  │  → Monitor          │  → Keep informed    │
  │  → Don't ignore     │  → Show appreciation│
  └─────────────────────┴─────────────────────┘

RESISTANCE RISK REGISTER:
  Individual/Group:   [Name or group]
  Resistance type:    Active / Passive / Vocal / Silent
  Root cause:         [Why are they resistant? — specific]
  Risk to project:    High / Medium / Low
  Intervention:       [Specific action plan]
  Owner:              [Who handles this]
  Status:             [Open / In progress / Resolved]
```

### Change Communications Plan

```
COMMUNICATIONS PLANNING FRAMEWORK
───────────────────────────────────────
CORE MESSAGING ARCHITECTURE:
  The Change:         [What is changing — specific, not vague]
  Why Now:            [The business case — honest and specific]
  What Stays Same:    [What is NOT changing — anchors and reduces anxiety]
  Impact on You:      [By audience — role-specific consequences]
  Timeline:           [When things happen]
  Where to Get Help:  [Specific channel, name, contact]

COMMUNICATIONS CALENDAR:
  Phase          Audience     Message          Channel      Owner    Date
  ─────────────────────────────────────────────────────────────────────
  Announcement   All staff    What/Why/When    Email+Town   Exec     [Date]
  Detail         Managers     How to lead it   Briefing     HR       [Date]
  Training        Users       How to do it     LMS invite   PM       [Date]
  Go-live         Users       It's live/help   Email+Slack  CM       [Date]…