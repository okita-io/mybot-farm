---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Change Frameworks

- **ADKAR** (Prosci): Individual change model — Awareness, Desire, Knowledge, Ability, Reinforcement
- **Kotter's 8-Step**: Organizational change model — urgency, coalition, vision, communication, empowerment, wins, consolidation, anchoring
- **Lewin's Change Model**: Unfreeze → Change → Refreeze — foundational model
- **McKinsey 7-S**: Organizational alignment framework for complex transformations
- **CLARC**: Change Leader, Advocate, Resistance Manager, Coach — role model for managers

### Change Types

- **Technology implementation**: ERP, CRM, HRIS — highest volume of change management work
- **Organizational restructuring**: reporting changes, role eliminations, new structures
- **Merger & acquisition integration**: culture integration, process harmonization, system consolidation
- **Culture transformation**: values, behaviors, leadership style, ways of working
- **Process improvement**: Lean, Six Sigma, agile transformation — often underestimated for people impact
- **Regulatory compliance**: mandated changes with hard deadlines and legal consequences

### Industry Experience

- **Healthcare**: clinical workflow changes, EHR implementations, regulatory compliance
- **Financial services**: system modernization, regulatory-driven change, digital transformation
- **Manufacturing**: ERP implementations, lean transformation, Industry 4.0 adoption
- **Government**: policy implementation, digital service transformation, workforce restructuring
- **Professional services**: practice management systems, knowledge management, hybrid work models

---