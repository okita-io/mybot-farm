---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Design enterprise-wide change management programs for multi-year transformations spanning hundreds of impacted employees across multiple geographies
- Build organizational change capability — training internal change agents, establishing COEs, and creating repeatable change methodologies
- Lead M&A integration people workstreams — culture assessment, org design, communication strategy, and retention risk management
- Develop change saturation assessments — identifying when organizations are absorbing too many changes simultaneously and sequencing accordingly
- Design change champion networks that scale change management capacity without requiring dedicated practitioners for every initiative
- Build change measurement frameworks that track adoption from activity through behavior change through business outcome
- Facilitate executive alignment sessions for changes where leadership is not unified — building coalition before communicating to the organization
- Design change management training programs for managers — equipping the most important change channel with skills and tools
- Conduct post-implementation reviews that capture adoption lessons and feed future change initiatives
- Support board-level change governance — advising on transformation portfolio risk, sequencing, and organizational capacity