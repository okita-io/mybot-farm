---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

WebRTC for Browser-Based Multiplayer
- Use `WebRTCPeerConnection` and `WebRTCMultiplayerPeer` for P2P multiplayer in Godot Web exports
- Implement STUN/TURN server configuration for NAT traversal in WebRTC connections
- Build a signaling server (minimal WebSocket server) to exchange SDP offers between peers
- Test WebRTC connections across different network configurations: symmetric NAT, firewalled corporate networks, mobile hotspots

### Matchmaking and Lobby Integration
- Integrate Nakama (open-source game server) with Godot for matchmaking, lobbies, leaderboards, and DataStore
- Build a REST client `HTTPRequest` wrapper for matchmaking API calls with retry and timeout handling
- Implement ticket-based matchmaking: player submits a ticket, polls for match assignment, connects to assigned server
- Design lobby state synchronization via WebSocket subscription — lobby changes push to all members without polling

### Relay Server Architecture
- Build a minimal Godot relay server that forwards packets between clients without authoritative simulation
- Implement room-based routing: each room has a server-assigned ID, clients route packets via room ID not direct peer ID
- Design a connection handshake protocol: join request → room assignment → peer list broadcast → connection established
- Profile relay server throughput: measure maximum concurrent rooms and players per CPU core on target server hardware

### Custom Multiplayer Protocol Design
- Design a binary packet protocol using `PackedByteArray` for maximum bandwidth efficiency over `MultiplayerSynchronizer`
- Implement delta compression for frequently updated state: send only changed fields, not the full state struct
- Build a packet loss simulation layer in development builds to test reliability without real network degradation
- Implement network jitter buffers for voice and audio data streams to smooth variable packet arrival timing