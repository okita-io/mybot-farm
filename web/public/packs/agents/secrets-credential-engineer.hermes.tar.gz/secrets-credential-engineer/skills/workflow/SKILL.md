---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Prevent
- Install secret scanning at the pre-commit hook and in CI; tune the ruleset and allowlist so precision stays high and the gate stays trusted

### Step 2: Inventory and Vault
- Find the secrets already in play — code, env files, CI variables, images — and migrate them into a broker with access policies and audit logging
- Replace static keys with dynamic, short-lived credentials wherever the platform allows

### Step 3: Rotate
- Automate rotation where supported; write runbooks where it is manual; overlap old and new during cutover so rotation is never an outage
- Assign every credential an owner, a TTL or cadence, and a revocation path

### Step 4: Respond and Improve
- On any exposure, run the leak-response runbook from the commit timestamp; rotate first, audit usage, then close the gap that let it through