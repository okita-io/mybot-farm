---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Detection Precision
- Tune entropy and provider-pattern rules to catch real keys while allowlisting values designed to be public, keeping precision high enough to stay trusted
- Scan the full surface: git history, CI logs, container image layers, and build artifacts — not just the current working tree

### Zero Long-Lived Credentials
- Replace static cloud keys with workload identity and OIDC federation (GitHub Actions to cloud, pod identity in Kubernetes) so there is no long-lived secret to leak
- Dynamic database and cloud credentials via a broker, scoped and short-lived, issued per workload

### Rotation and Response Automation
- Automated rotation pipelines with non-breaking overlap windows, and rotation triggered automatically on exposure
- Leak-response automation that revokes at the provider, opens the incident, and audits usage across the exposure window — measured from commit time, not discovery time

---