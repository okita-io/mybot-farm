---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Secret Scanning at the Commit and CI Gate

```yaml
# .pre-commit-config.yaml — block the commit before the secret ever lands
repos:
  - repo: https://github.com/gitleaks/gitleaks
    rev: v8.18.0
    hooks:
      - id: gitleaks  # scans staged changes; a hit fails the commit

# .github/workflows/secret-scan.yml — belt-and-suspenders in CI
name: secret-scan
on: [push, pull_request]
jobs:
  gitleaks:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }   # full history so an old leak is caught too
      - uses: gitleaks/gitleaks-action@v2
        env: { GITLEAKS_CONFIG: .gitleaks.toml }  # allowlist known-public test fixtures
```

### Static Key → Dynamic, Short-Lived Credential

```hcl
# BEFORE: a long-lived static DB password in an env var — one leak = full, permanent access.
# DATABASE_URL=[REDACTED]db.internal:5432/app   # never rotated, everywhere

# AFTER: Vault issues a database credential that lives 15 minutes and is auto-revoked.
vault write database/roles/app \
  db_name=appdb \
  creation_statements="CREATE ROLE \"{{name}}\" WITH LOGIN PASSWORD '{{password}}' VALID UNTIL '{{expiration}}'; \
                       GRANT SELECT, INSERT, UPDATE ON app.* TO \"{{name}}\";" \
  default_ttl="15m" max_ttl="1h"
# The app fetches a fresh, least-privilege credential per session; a leaked one is dead in minutes.
```

### Leak-Response Runbook (the clock started at commit)

```markdown
## Exposed credential — response order (do NOT stop at step 2)
1. ROTATE at the provider now — revoke the exposed key, issue a replacement. This is the fix.
2. Replace the value in code with a broker reference; deploy.
3. Purge from git history (filter-repo/BFG) and coordinate the rewrite with the team — history and clones still hold it.
4. AUDIT usage during the exposure window (commit time → revocation time). Widen response if the key was used.
5. Post-incident: why did the gate miss it? Add the pattern to the scanner; make the secure path easier.
# Removing the secret from the latest commit is step 2 of 5 — never the whole job.
```