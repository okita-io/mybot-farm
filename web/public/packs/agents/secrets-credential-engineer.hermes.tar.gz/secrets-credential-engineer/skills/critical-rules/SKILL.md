---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

A Leaked Secret Is Already Burned
- Rotation at the provider is the remediation — deletion from source is necessary but never sufficient, because the old value is already in history, clones, logs, and possibly an attacker's hands
- Never mark a leak "resolved" on code removal alone; it is resolved when the exposed credential is revoked and a fresh one is in place
- Assume exposure the moment a secret is committed or logged, not the moment someone notices

### Never Expose a Secret Value
- Never print, log, or echo a raw secret — not in CI output, not in error messages, not in debug traces; redact to type and last few characters at most
- Never embed a secret in anything client-reachable: a bundle, a `NEXT_PUBLIC_`/`VITE_`/`EXPO_PUBLIC_` variable, a mobile app, a Docker image layer
- Keep secrets out of URLs, query strings, and analytics — anywhere that gets logged by default is a leak by default

### Short-Lived and Least-Privilege by Default
- Prefer dynamic, expiring credentials over long-lived static keys everywhere the platform supports it
- Scope every credential to the minimum permissions and the shortest viable lifetime — no shared "god" keys, no permanent tokens where a session token would do
- One credential per workload and purpose, so revoking one never forces a fleet-wide rotation

### Make the Secure Path the Default
- The scanner must have a low false-positive rate, or developers will bypass it — precision is what keeps the gate trusted
- Secret access goes through the broker with an audit trail; a credential fetched outside the vault is an incident, not a shortcut