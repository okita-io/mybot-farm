---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Sigma Detection Rule
```yaml
# Sigma Rule: Suspicious PowerShell Execution with Encoded Command
title: Suspicious PowerShell Encoded Command Execution
id: f3a8c5d2-7b91-4e2a-b6c1-9d4e8f2a1b3c
status: stable
level: high
description: |
  Detects PowerShell execution with encoded commands, a common technique
  used by attackers to obfuscate malicious payloads and bypass simple
  command-line logging detections.
references:
  - https://attack.mitre.org/techniques/T1059/001/
  - https://attack.mitre.org/techniques/T1027/010/
author: Detection Engineering Team
date: 2025/03/15
modified: 2025/06/20
tags:
  - attack.execution
  - attack.t1059.001
  - attack.defense_evasion
  - attack.t1027.010
logsource:
  category: process_creation
  product: windows
detection:
  selection_parent:
    ParentImage|endswith:
      - '\cmd.exe'
      - '\wscript.exe'
      - '\cscript.exe'
      - '\mshta.exe'
      - '\wmiprvse.exe'
  selection_powershell:
    Image|endswith:
      - '\powershell.exe'
      - '\pwsh.exe'
    CommandLine|contains:
      - '-enc '
      - '-EncodedCommand'
      - '-ec '
      - 'FromBase64String'
# … truncated for farm planting — see upstream for the full sample
```

### Compiled to Splunk SPL
```spl
| Suspicious PowerShell Encoded Command — compiled from Sigma rule
index=windows sourcetype=WinEventLog:Sysmon EventCode=1
  (ParentImage="*\\cmd.exe" OR ParentImage="*\\wscript.exe"
   OR ParentImage="*\\cscript.exe" OR ParentImage="*\\mshta.exe"
   OR ParentImage="*\\wmiprvse.exe")
  (Image="*\\powershell.exe" OR Image="*\\pwsh.exe")
  (CommandLine="*-enc *" OR CommandLine="*-EncodedCommand*"
   OR CommandLine="*-ec *" OR CommandLine="*FromBase64String*")
| eval risk_score=case(
    ParentImage LIKE "%wmiprvse.exe", 90,
    ParentImage LIKE "%mshta.exe", 85,
    1=1, 70
  )
| where NOT match(CommandLine, "(?i)(SCCM|ConfigMgr|Intune)")
| table _time Computer User ParentImage Image CommandLine risk_score
| sort - risk_score
```

### Compiled to Microsoft Sentinel KQL
```kql
// Suspicious PowerShell Encoded Command — compiled from Sigma rule
DeviceProcessEvents
| where Timestamp > ago(1h)
| where InitiatingProcessFileName in~ (
    "cmd.exe", "wscript.exe", "cscript.exe", "mshta.exe", "wmiprvse.exe"
  )
| where FileName in~ ("powershell.exe", "pwsh.exe")
| where ProcessCommandLine has_any (
    "-enc ", "-EncodedCommand", "-ec ", "FromBase64String"
  )
// Exclude known legitimate automation
| where ProcessCommandLine !contains "SCCM"
    and ProcessCommandLine !contains "ConfigMgr"
| extend RiskScore = case(
    InitiatingProcessFileName =~ "wmiprvse.exe", 90,
    InitiatingProcessFileName =~ "mshta.exe", 85,
    70
  )
| project Timestamp, DeviceName, AccountName,
    InitiatingProcessFileName, FileName, ProcessCommandLine, RiskScore
| sort by RiskScore desc
```

### MITRE ATT&CK Coverage Assessment Template
```markdown
# MITRE ATT&CK Detection Coverage Report

**Assessment Date**: YYYY-MM-DD
**Platform**: Windows Endpoints
**Total Techniques Assessed**: 201
**Detection Coverage**: 67/201 (33%)

## Coverage by Tactic

| Tactic              | Techniques | Covered | Gap  | Coverage % |
|---------------------|-----------|---------|------|------------|
| Initial Access      | 9         | 4       | 5    | 44%        |
| Execution           | 14        | 9       | 5    | 64%        |
| Persistence         | 19        | 8       | 11   | 42%        |
| Privilege Escalation| 13        | 5       | 8    | 38%        |
| Defense Evasion     | 42        | 12      | 30   | 29%        |
| Credential Access   | 17        | 7       | 10   | 41%        |
| Discovery           | 32        | 11      | 21   | 34%        |
| Lateral Movement    | 9         | 4       | 5    | 44%        |
| Collection          | 17        | 3       | 14   | 18%        |
| Exfiltration        | 9         | 2       | 7    | 22%        |
| Command and Control | 16        | 5       | 11   | 31%        |
| Impact              | 14        | 3       | 11   | 21%        |

## Critical Gaps (Top Priority)
Techniques actively used by threat actors in our industry with ZERO detection:

| Technique ID | Technique Name        | Used By          | Priority  |
|--------------|-----------------------|------------------|-----------|
| T1003.001    | LSASS Memory Dump     | APT29, FIN7      | CRITICAL  |
| T1055.012    | Process Hollowing     | Lazarus, APT41   | CRITICAL  |
| T1071.001    | Web Protocols C2      | Most APT groups  | CRITICAL  |…