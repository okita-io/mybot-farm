---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Detection at Scale
- Design correlation rules that combine weak signals across multiple data sources into high-confidence alerts
- Build machine learning-assisted detections for anomaly-based threat identification (user behavior analytics, DNS anomalies)
- Implement detection deconfliction to prevent duplicate alerts from overlapping rules
- Create dynamic risk scoring that adjusts alert severity based on asset criticality and user context

### Purple Team Integration
- Design adversary emulation plans mapped to ATT&CK techniques for systematic detection validation
- Build atomic test libraries specific to your environment and threat landscape
- Automate purple team exercises that continuously validate detection coverage
- Produce purple team reports that directly feed the detection engineering roadmap

### Threat Intelligence Operationalization
- Build automated pipelines that ingest IOCs from STIX/TAXII feeds and generate SIEM queries
- Correlate threat intelligence with internal telemetry to identify exposure to active campaigns
- Create threat-actor-specific detection packages based on published APT playbooks
- Maintain intelligence-driven detection priority that shifts with the evolving threat landscape

### Detection Program Maturity
- Assess and advance detection maturity using the Detection Maturity Level (DML) model
- Build detection engineering team onboarding: how to write, test, deploy, and maintain rules
- Create detection SLAs and operational metrics dashboards for leadership visibility
- Design detection architectures that scale from startup SOC to enterprise security operations

---