---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Financial Management Deliverables

Comprehensive Budget Framework
```sql
-- Annual Budget with Quarterly Variance Analysis
WITH budget_actuals AS (
  SELECT
    department,
    category,
    budget_amount,
    actual_amount,
    DATE_TRUNC('quarter', date) as quarter,
    budget_amount - actual_amount as variance,
    (actual_amount - budget_amount) / budget_amount * 100 as variance_percentage
  FROM financial_data
  WHERE fiscal_year = YEAR(CURRENT_DATE())
),
department_summary AS (
  SELECT
    department,
    quarter,
    SUM(budget_amount) as total_budget,
    SUM(actual_amount) as total_actual,
    SUM(variance) as total_variance,
    AVG(variance_percentage) as avg_variance_pct
  FROM budget_actuals
  GROUP BY department, quarter
)
SELECT
  department,
  quarter,
  total_budget,
  total_actual,
  total_variance,
  avg_variance_pct,
  CASE
    WHEN ABS(avg_variance_pct) <= 5 THEN 'On Track'
    WHEN avg_variance_pct > 5 THEN 'Over Budget'
    ELSE 'Under Budget'
  END as budget_status,
  total_budget - total_actual as remaining_budget
FROM department_summary
ORDER BY department, quarter;
```

### Cash Flow Management System
```python
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib.pyplot as plt

class CashFlowManager:
    def __init__(self, historical_data):
        self.data = historical_data
        self.current_cash = self.get_current_cash_position()

    def forecast_cash_flow(self, periods=12):
        """
        Generate 12-month rolling cash flow forecast
        """
        forecast = pd.DataFrame()

        # Historical patterns analysis
        monthly_patterns = self.data.groupby('month').agg({
            'receipts': ['mean', 'std'],
            'payments': ['mean', 'std'],
            'net_cash_flow': ['mean', 'std']
        }).round(2)

        # Generate forecast with seasonality
        for i in range(periods):
            forecast_date = datetime.now() + timedelta(days=30*i)
            month = forecast_date.month

            # Apply seasonality factors
            seasonal_factor = self.calculate_seasonal_factor(month)

            forecasted_receipts = (monthly_patterns.loc[month, ('receipts', 'mean')] *
                                 seasonal_factor * self.get_growth_factor())
            forecasted_payments = (monthly_patterns.loc[month, ('payments', 'mean')] *
                                 seasonal_factor)

            net_flow = forecasted_receipts - forecasted_payments

            forecast = forecast.append({
                'date': forecast_date,
# … truncated for farm planting — see upstream for the full sample
```

### Investment Analysis Framework
```python
class InvestmentAnalyzer:
    def __init__(self, discount_rate=0.10):
        self.discount_rate = discount_rate

    def calculate_npv(self, cash_flows, initial_investment):
        """
        Calculate Net Present Value for investment decision
        """
        npv = -initial_investment
        for i, cf in enumerate(cash_flows):
            npv += cf / ((1 + self.discount_rate) ** (i + 1))
        return npv

    def calculate_irr(self, cash_flows, initial_investment):
        """
        Calculate Internal Rate of Return
        """
        from scipy.optimize import fsolve

        def npv_function(rate):
            return sum([cf / ((1 + rate) ** (i + 1)) for i, cf in enumerate(cash_flows)]) - initial_investment

        try:
            irr = fsolve(npv_function, 0.1)[0]
            return irr
        except:
            return None

    def payback_period(self, cash_flows, initial_investment):
        """
        Calculate payback period in years
        """
        cumulative_cf = 0
        for i, cf in enumerate(cash_flows):
            cumulative_cf += cf
            if cumulative_cf >= initial_investment:
                return i + 1 - ((cumulative_cf - initial_investment) / cf)
        return None

    def investment_analysis_report(self, project_name, initial_investment, annual_cash_flows, project_life):
# … truncated for farm planting — see upstream for the full sample
```