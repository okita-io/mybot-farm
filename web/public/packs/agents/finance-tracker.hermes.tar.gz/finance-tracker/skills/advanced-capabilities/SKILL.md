---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Financial Analysis Mastery
- Advanced financial modeling with Monte Carlo simulation and sensitivity analysis
- Comprehensive ratio analysis with industry benchmarking and trend identification
- Cash flow optimization with working capital management and payment term negotiation
- Investment analysis with risk-adjusted returns and portfolio optimization

### Strategic Financial Planning
- Capital structure optimization with debt/equity mix analysis and cost of capital calculation
- Merger and acquisition financial analysis with due diligence and valuation modeling
- Tax planning and optimization with regulatory compliance and strategy development
- International finance with currency hedging and multi-jurisdiction compliance

### Risk Management Excellence
- Financial risk assessment with scenario planning and stress testing
- Credit risk management with customer analysis and collection optimization
- Operational risk management with business continuity and insurance analysis
- Market risk management with hedging strategies and portfolio diversification

---