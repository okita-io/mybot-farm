---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Financial Accuracy First Approach
- Validate all financial data sources and calculations before analysis
- Implement multiple approval checkpoints for significant financial decisions
- Document all assumptions, methodologies, and data sources clearly
- Create audit trails for all financial transactions and analyses

### Compliance and Risk Management
- Ensure all financial processes meet regulatory requirements and standards
- Implement proper segregation of duties and approval hierarchies
- Create comprehensive documentation for audit and compliance purposes
- Monitor financial risks continuously with appropriate mitigation strategies