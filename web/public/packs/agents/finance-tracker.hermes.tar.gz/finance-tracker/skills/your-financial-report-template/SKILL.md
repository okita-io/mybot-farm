---
name: your-financial-report-template
description: "Use when the task matches this agent's your financial report template work."
version: 1.0.0
---

# Your Financial Report Template

```markdown
# [Period] Financial Performance Report

## 💰 Executive Summary

### Key Financial Metrics
**Revenue**: $[Amount] ([+/-]% vs. budget, [+/-]% vs. prior period)
**Operating Expenses**: $[Amount] ([+/-]% vs. budget)
**Net Income**: $[Amount] (margin: [%], vs. budget: [+/-]%)
**Cash Position**: $[Amount] ([+/-]% change, [days] operating expense coverage)

### Critical Financial Indicators
**Budget Variance**: [Major variances with explanations]
**Cash Flow Status**: [Operating, investing, financing cash flows]
**Key Ratios**: [Liquidity, profitability, efficiency ratios]
**Risk Factors**: [Financial risks requiring attention]

### Action Items Required
1. **Immediate**: [Action with financial impact and timeline]
2. **Short-term**: [30-day initiatives with cost-benefit analysis]
3. **Strategic**: [Long-term financial planning recommendations]

## 📊 Detailed Financial Analysis

### Revenue Performance
**Revenue Streams**: [Breakdown by product/service with growth analysis]
**Customer Analysis**: [Revenue concentration and customer lifetime value]
**Market Performance**: [Market share and competitive position impact]
**Seasonality**: [Seasonal patterns and forecasting adjustments]

### Cost Structure Analysis
**Cost Categories**: [Fixed vs. variable costs with optimization opportunities]
**Department Performance**: [Cost center analysis with efficiency metrics]
**Vendor Management**: [Major vendor costs and negotiation opportunities]
**Cost Trends**: [Cost trajectory and inflation impact analysis]

### Cash Flow Management
**Operating Cash Flow**: $[Amount] (quality score: [rating])
**Working Capital**: [Days sales outstanding, inventory turns, payment terms]
**Capital Expenditures**: [Investment priorities and ROI analysis]
**Financing Activities**: [Debt service, equity changes, dividend policy]
# … truncated for farm planting — see upstream for the full sample
```