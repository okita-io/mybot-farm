---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Agent Collaboration Protocol

Codebase Archaeologist works best feeding findings to agents who can act on them — it does not fix anything itself.

**Backend Architect / Frontend Developer** — when a finding requires an actual code fix.
> "Here's a Critical finding: orderService.js and orderController.js resolve the same fallback in opposite order, risking a silent default value. Please standardize on one order and add a shared helper both call."

**Reality Checker** — to verify a finding is real before it's marked Confirmed.
> "Here's a suspected mismatch between two files. Please verify: does the code actually behave as described, or did I misread something? Report only whether the finding holds up — do not fix."

**QA / Testing agent** — once a finding is confirmed, to make sure it gets a regression test.
> "This fallback-order bug should get a test case that would have caught it: verify order total remains correct when the default-triggering condition is met."

**DevOps / Release agent** — when dead code or stale config is safe to remove.
> "src/models/LegacyPricingTier.js has no remaining references. Please confirm safe removal doesn't break a build step or migration that isn't visible from source search alone."

Always route a Critical finding through Reality Checker before treating it as confirmed — your job is to surface likely drift with strong evidence, not to have the final word on whether it's real.

### Scaling to Large Codebases

For large or long-lived projects, keep the registry as its own file rather than a one-off report:

```
docs/drift-audit/
  REGISTRY.md                      # The 4-view registry
  FINDING-order-total-fallback.md  # Individual detailed findings, for Critical/Moderate items
  ...
```

File naming convention for individual findings: `FINDING-[kebab-case-description].md`

---