---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Discover Drift That Nobody Flagged

Drift is never announced. Nobody commits a message that says "this contradicts what I wrote in March." Your first job on any project is discovery — reconstructing the codebase's history well enough to see where sessions disagree with each other.

- **Read the commit history in chunks, not as one long scroll.** Group commits into rough "eras" — a burst of commits close together is usually one session or one short project phase.
- **Diff the same *kind* of file across eras.** If there are five API route handlers, five form components, five data-access files — compare how each era wrote that same kind of thing.
- **Grep for repeated concepts with inconsistent names.** The same idea (a status field, a retry counter, a cache key) often gets a slightly different name each time it's reimplemented.
- **Check for parallel implementations of the same responsibility** — two validation functions, two date-formatting helpers, two error-response shapes, all doing roughly the same job in roughly different ways.
- **Read config and environment files for orphaned keys** — settings nothing references anymore, or settings referenced by dead code paths.
- Ask: *"Does this file assume something about the rest of the system that used to be true, but might not be anymore?"*

When you find drift that nobody flagged, document it — even if nobody asked. **A silent mismatch between two files is a liability whether or not it has broken yet.** It will eventually get touched by a session that trusts one side of the mismatch, and something will fail in a way that looks unrelated to the actual cause.

### Maintain a Drift Registry

The registry is the running reference for everything you've found — not a one-time report. It should let anyone answer "is this file safe to build on top of?" at a glance.

The registry is organized into four cross-referenced views:

#### View 1: By Finding (the master list)

```markdown
## Findings

| Finding | Files | Type | Severity | Status |
|---|---|---|---|---|
| Reversed fallback order | orderService.js, orderController.js | Logic mismatch | High | Open |
| Duplicate validation logic | validators/email.js, utils/checkEmail.js | Duplicate implementation | Medium | Open |
| Orphaned pricing model | models/LegacyPricingTier.js | Dead code | Low | Open |
| Stale webhook docs | README.md §Webhook Handling | Doc/code mismatch | Medium | Open |
```

Status values: `Open` | `Confirmed` | `Fixed` | `Won't Fix` (with a one-line reason required for "Won't Fix")

#### View 2: By File Era (timeline -> what was true then)

```markdown
## Eras

| Era | Approx. date range | Dominant pattern | Files following it |
|---|---|---|---|
| Era 1 (initial build) | Jan–Feb | Callback-based error handling | authController.js, legacyRoutes.js |
| Era 2 (refactor) | Mar | Async/await + centralized error middleware | orderController.js, userController.js |
| Era 3 (feature add) | Apr–May | Mixed — new files use Era 2 pattern, edits to old files keep Era 1 pattern | paymentController.js (mixed) |
```

This view exists so a finding can be explained as "this file never got migrated" rather than just "this file is wrong."

#### View 3: By Responsibility (concept -> every place it's implemented)

```markdown
## Responsibilities

| Responsibility | Implementations found | Are they consistent? |
|---|---|---|
| Email validation | validators/email.js, utils/checkEmail.js | No — different regex, different edge-case handling |
| Currency formatting | utils/formatMoney.js | Yes — single implementation |
| Retry logic | jobs/retryQueue.js, services/httpClient.js | No — different backoff strategies, no shared constant |
```

This view catches duplicate-logic drift that File Era view won't — two implementations can both be "current" and still disagree.

#### View 4: By Risk (severity -> what's actually dangerous right now)

```markdown
## Risk Priority

### Critical (breaks data or money)
- Reversed fallback order in orderService.js / orderController.js

### Moderate (breaks under specific conditions)
- Retry backoff inconsistency between jobs/retryQueue.js and services/httpClient.js

### Cosmetic (inconsistent but not dangerous)
- Mixed callback/async style in payment flow files
```

#### Registry Maintenance Rules

- **Update the registry every time a new finding surfaces** — never optional, even mid-audit.…