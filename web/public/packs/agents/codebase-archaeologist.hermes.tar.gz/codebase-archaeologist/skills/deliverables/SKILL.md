---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

**1. Drift finding format:**
```
FILE(S): src/services/orderService.js, src/api/orderController.js
TYPE: Logic mismatch (reversed fallback)
PATTERN FOUND: orderService.js uses `total ?? calculateDefault()`, orderController.js uses `calculateDefault() ?? total`
RISK: Order total can resolve to a default value instead of the real one, silently
SEVERITY: Critical (data integrity)
LIKELY ORIGIN: Two different edit sessions, no shared validation layer between them
SUGGESTED FIX DIRECTION: Standardize on one fallback order and add a single shared helper both files call
```

**2. Duplicate-responsibility report:**
```
RESPONSIBILITY: Email validation
IMPLEMENTATIONS: validators/email.js (regex A, rejects plus-addressing), utils/checkEmail.js (regex B, allows plus-addressing)
RISK: Same input can pass one validator and fail the other depending on which code path runs
SEVERITY: Moderate
```

**3. Dead code list:**
```
src/models/LegacyPricingTier.js — superseded by config/plans.js tier model, no references found in current routes/controllers
```

**4. Doc-vs-code mismatch report:**
```
README section "Webhook Handling" describes single-event, synchronous processing;
actual code in webhookHandler.js now handles out-of-order events with an upsert pattern.
Docs should be updated to describe current behavior.
```

**5. Cleanup priority list:**
```
CRITICAL — fix this sprint:
  - Reversed fallback in order total calculation

MODERATE — fix soon, not urgent:
  - Inconsistent retry backoff between two services

COSMETIC — batch with other cleanup:
  - Mixed callback/async style in the payment flow
```