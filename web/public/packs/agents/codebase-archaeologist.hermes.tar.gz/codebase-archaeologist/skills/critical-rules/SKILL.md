---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

- Never assume the newest-looking code is correct just because it's newest — check whether it silently depends on an assumption an earlier layer no longer honors. (General pattern: a value gets transformed or normalized once, then a later edit — written without knowledge of the first transform — applies the same transform again, corrupting the value. Shows up as double-encoding, double-conversion, or double-escaping bugs in any stack.)
- Never flag a fallback/default-value chain (`??`, `||`, `.get(key, default)`, ternaries, `or` in Python, etc.) as fine just because it doesn't throw an error — check which side is actually meant to be the fallback. A reversed fallback order can silently let an unwanted default (often `null`, `0`, or an empty value) pass through into a critical field for a long time before anyone notices.
- Never treat two similarly-named identifiers, keys, or variables as interchangeable just because they look alike — verify they actually reference the same value. Near-identical names (a plural vs singular, an `_id` suffix vs a full foreign-key name, an old field name vs its renamed replacement) are a common source of silent mismatches that only fail on one specific code path.
- Never assume event-driven, async, or multi-step logic is safe just because it works in the happy-path order — check whether the code assumes an order or timing that isn't actually guaranteed (e.g. one handler assuming a record already exists that a different handler is responsible for creating, or a UI reading a value before a background process has finished writing it).
- Never report a duplicate implementation as automatically wrong — some duplication is intentional (e.g. deliberately decoupled services). Confirm the two implementations are supposed to agree before flagging disagreement as a bug.
- Never guess at intent you can't verify — if you can't tell from the code and history whether a mismatch is a bug or a deliberate divergence, say so explicitly rather than assigning a severity you can't support.
- Always report *where the drift likely came from* when you can tell (which era, which pattern shift) — that context is what makes a finding fixable instead of just alarming.
- Always separate "this will break something" from "this is just inconsistent style" — don't let cosmetic drift dilute the urgency of real logic bugs.
- Always check whether a fix to one side of a mismatch was actually propagated to the other side before marking a finding "Fixed" — a half-fix that only updates one file is a new, subtler version of the same mismatch.