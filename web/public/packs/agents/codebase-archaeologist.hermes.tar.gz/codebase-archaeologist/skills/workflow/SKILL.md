---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow

Step 0: Gather Discovery Signal

```bash
# Get a rough sense of build phases from commit density over time
git log --pretty=format:"%ad" --date=short | sort | uniq -c

# Find every file touching a given responsibility (example: "validation")
grep -rln "valid" src/ --include="*.js" --include="*.ts" --include="*.py"

# Compare how a responsibility is implemented across files
git log --oneline -- path/to/file_a path/to/file_b

# Find likely-orphaned files (defined but never imported/referenced elsewhere)
grep -rL "require(.*fileName\|import.*fileName" src/
```

Build the registry entry BEFORE writing any findings. Know what you're working with.

### Step 1: Reconstruct the Eras

Group commits or file-modification dates into rough phases. You don't need exact boundaries — "early build," "mid-project refactor," "recent feature work" is enough resolution to explain drift later.

### Step 2: Identify Every Responsibility With More Than One Implementation

List every concept implemented more than once across the codebase (validation, formatting, retries, error shapes, auth checks). These are your highest-yield search targets — duplication is where drift hides.

### Step 3: Trace Fallback and Default-Value Logic Specifically

For every money-, state-, or identity-critical field, trace every fallback chain end to end. This is a high-value check — reversed fallbacks are common, silent, and expensive.

### Step 4: Trace State-Existence Assumptions Across Every Event Handler (mandatory, standalone)

Do not skip this because Step 2/3 found nothing — this category will not surface from comparing similar-looking files. For every event/webhook/async handler, list what state it reads that it didn't create, identify what's supposed to create that state first, and confirm whether a real guarantee exists (existence check, upsert, ordering contract) — not just a naming convention or a comment implying order. Report both confirmed-safe handlers and unguarded ones explicitly.

### Step 5: Trace What Every Money/Quantity Value Represents, End to End (mandatory, standalone)

Do not skip this because nothing "looked" like a duplicate. Pick every money-, quantity-, or measurement-critical value, note its unit/representation where it's created (cents vs dollars, UTC vs local, fraction vs percent), and follow it through every downstream read — including reads with completely different variable names — checking whether each usage is consistent with that original representation.

### Step 6: Cross-Check Names Against Actual References

For every pair of similarly-named identifiers, keys, or config values, confirm they resolve to the same thing. Don't trust naming similarity as a proxy for equivalence.

### Step 7: Compare Docs Against Current Behavior

Read documentation and comments as claims about the code, then verify each claim against what the code currently does — not against what it did when the doc was written.

### Step 8: Before Flagging Any Duplication, Confirm Shared Purpose

For every pair of similar-looking implementations found in Steps 2-7, confirm they're meant to answer the same question before calling them drift. If they're intentionally distinct (different callers, different requirements), say so explicitly instead of flagging them.

### Step 9: Separate Critical, Moderate, and Cosmetic Findings

Every finding gets one of three severities before it goes in the report. If you're unsure, say so rather than picking a severity to sound confident.

### Step 10: Deliver the Registry, Not Just a List

Present findings through all four registry views so the report is useful from multiple angles — someone auditing a specific file, someone triaging by risk, and someone trying to understand the codebase's history all get what they need from the same output.