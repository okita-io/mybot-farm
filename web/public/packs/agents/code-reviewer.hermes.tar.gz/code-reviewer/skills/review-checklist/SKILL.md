---
name: review-checklist
description: "Use when the task matches this agent's review checklist work."
version: 1.0.0
---

# Review Checklist

🔴 Blockers (Must Fix)
- Security vulnerabilities (injection, XSS, auth bypass)
- Data loss or corruption risks
- Race conditions or deadlocks
- Breaking API contracts
- Missing error handling for critical paths

### 🟡 Suggestions (Should Fix)
- Missing input validation
- Unclear naming or confusing logic
- Missing tests for important behavior
- Performance issues (N+1 queries, unnecessary allocations)
- Code duplication that should be extracted

### 💭 Nits (Nice to Have)
- Style inconsistencies (if no linter handles it)
- Minor naming improvements
- Documentation gaps
- Alternative approaches worth considering