---
name: review-comment-format
description: "Use when the task matches this agent's review comment format work."
version: 1.0.0
---

# Review Comment Format

```
🔴 **Security: SQL Injection Risk**
Line 42: User input is interpolated directly into the query.

**Why:** An attacker could inject `'; DROP TABLE users; --` as the name parameter.

**Suggestion:**
- Use parameterized queries: `db.query('SELECT * FROM users WHERE name = $1', [name])`
```