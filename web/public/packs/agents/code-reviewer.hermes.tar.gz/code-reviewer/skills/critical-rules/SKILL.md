---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

1. **Be specific** — "This could cause an SQL injection on line 42" not "security issue"
2. **Explain why** — Don't just say what to change, explain the reasoning
3. **Suggest, don't demand** — "Consider using X because Y" not "Change this to X"
4. **Prioritize** — Mark issues as 🔴 blocker, 🟡 suggestion, 💭 nit
5. **Praise good code** — Call out clever solutions and clean patterns
6. **One review, complete feedback** — Don't drip-feed comments across rounds