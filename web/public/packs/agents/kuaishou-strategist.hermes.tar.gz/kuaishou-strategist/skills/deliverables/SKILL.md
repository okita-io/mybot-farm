---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Kuaishou Account Strategy Blueprint
```markdown
# [Brand/Creator] Kuaishou Growth Strategy

## 账号定位 (Account Positioning)
**Target Audience**: [Demographic profile - city tier, age, interests, income level]
**Creator Persona**: [Authentic character that resonates with 老铁 culture]
**Content Style**: [Raw/authentic aesthetic, NOT polished studio content]
**Value Proposition**: [What 老铁 get from following - entertainment, knowledge, deals]
**Differentiation from Douyin**: [Why this approach is Kuaishou-specific]

## 内容策略 (Content Strategy)
**Daily Short Videos** (70%): Life snapshots, product showcases, behind-the-scenes
**Trust-Building Content** (20%): Factory visits, product testing, honest reviews
**Community Content** (10%): Fan shoutouts, Q&A responses, 老铁 stories

## 直播规划 (Live Commerce Planning)
**Frequency**: [Minimum 4-5 sessions per week for algorithm consistency]
**Duration**: [3-6 hours per session for Kuaishou optimization]
**Peak Slots**: [Evening 7-10pm for maximum 下沉市场 audience]
**Product Mix**: [High-value daily necessities + emotional impulse buys]
```

### Live Commerce Operations Playbook
```markdown
# Kuaishou Live Commerce Session Blueprint

## 开播前 (Pre-Live) - 2 Hours Before
- [ ] Post 3 short videos teasing tonight's deals and products
- [ ] Send fan group notifications with session preview
- [ ] Prepare product samples, pricing cards, and demo materials
- [ ] Test streaming equipment: ring light, mic, phone/camera
- [ ] Brief team: host, product handler, customer service, backend ops

## 直播中 (During Live) - Session Structure
| Time Block   | Activity                          | Goal                    |
|-------------|-----------------------------------|-------------------------|
| 0-15 min    | Warm-up chat, greet 老铁 by name   | Build room momentum     |
| 15-30 min   | First product: low-price hook item | Spike viewer count      |
| 30-90 min   | Core products with demonstrations  | Primary GMV generation  |
| 90-120 min  | Audience Q&A and product revisits  | Handle objections       |
| 120-150 min | Flash deals and limited offers     | Urgency conversion      |
| 150-180 min | Gratitude session, preview next live| Retention and loyalty   |

## 话术框架 (Script Framework)
### Product Introduction (3-2-1 Formula)
1. **3 Pain Points**: "老铁们，你们是不是也遇到过..."
2. **2 Demonstrations**: Live product test showing quality/effectiveness
3. **1 Irresistible Offer**: Price reveal with clear value comparison

### Trust-Building Phrases
- "老铁们放心，这个东西我自己家里也在用"
- "不好用直接来找我，我给你退"
- "今天这个价格我跟厂家磨了两个星期"

## 下播后 (Post-Live) - Within 1 Hour
- [ ] Review session data: peak viewers, GMV, conversion rate, avg view time
- [ ] Respond to all unanswered questions in comment section
- [ ] Post highlight clips from the live session as short videos
- [ ] Update inventory and coordinate fulfillment with logistics team
- [ ] Send thank-you message to fan group with next session preview
```

### Kuaishou vs Douyin Strategy Differentiation
```markdown
# Platform Strategy Comparison

## Why Kuaishou ≠ Douyin

| Dimension          | Kuaishou (快手)              | Douyin (抖音)                |
|--------------------|------------------------------|------------------------------|
| Core Algorithm     | 均衡分发 (equal distribution) | 中心化推荐 (centralized push) |
| Audience           | 下沉市场, 30-50 age group     | 一二线城市, 18-35 age group   |
| Content Aesthetic  | Raw, authentic, unfiltered   | Polished, trendy, high-production|
| Creator-Fan Bond   | Deep 老铁 loyalty relationship| Shallow, algorithm-dependent  |
| Commerce Model     | Trust-based repeat purchases | Impulse discovery purchases   |
| Growth Pattern     | Slow build, lasting loyalty  | Fast viral, hard to retain    |
| Live Commerce      | Relationship-driven sales    | Entertainment-driven sales    |

## Strategic Implications
- Do NOT repurpose Douyin content directly to Kuaishou
- Invest in daily consistency rather than viral attempts
- Prioritize fan retention over new follower acquisition
- Build private domain (私域) through fan groups early
- Product selection should focus on practical daily necessities
```