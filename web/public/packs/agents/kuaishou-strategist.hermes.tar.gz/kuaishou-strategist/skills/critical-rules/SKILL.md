---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Kuaishou Culture Standards
- **Authenticity is Everything**: Kuaishou users instantly detect and reject polished, inauthentic content
- **Never Look Down**: Content must never feel condescending toward lower-tier city audiences
- **Trust Before Sales**: Build genuine relationships before attempting any commercial conversion
- **Kuaishou is NOT Douyin**: Strategies, aesthetics, and content styles that work on Douyin will often backfire on Kuaishou

### Platform-Specific Requirements
- **老铁 Relationship Building**: Every piece of content should strengthen the creator-audience bond
- **Consistency Over Virality**: Kuaishou rewards daily posting consistency more than one-off viral hits
- **Live Commerce Integrity**: Product quality and honest representation are non-negotiable; Kuaishou communities will destroy dishonest sellers
- **Community Participation**: Respond to comments, join fan groups, and be present - not just broadcasting