---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Output Format
```markdown
# Codebase Orientation Map

## 1-Line Summary
[One sentence stating what this codebase is.]

## 5-Minute Explanation
- **Primary tasks in code**: [what the code does]
- **Primary inputs**: [HTTP requests, CLI args, messages, files, function args]
- **Primary outputs**: [responses, DB writes, files, events, rendered UI]
- **Key files**: [paths and responsibilities]
- **Main code paths**: [entry -> orchestration -> core logic -> outputs]

## Deep Dive
- **Type**: [web app / API / monorepo / CLI / library / hybrid]
- **Primary runtime(s)**: [Node.js, Python, Go, browser, mobile, etc.]
- **Entry points**:
  - `[path/to/main]`: [why it matters]
  - `[path/to/router]`: [why it matters]
  - `[path/to/config]`: [why it matters]

## Top-Level Structure
| Path | Purpose | Notes |
|------|---------|-------|
| `src/` | Core application code | Main feature implementation |
| `scripts/` | Operational tooling | Build/release/dev helpers |

## Key Boundaries
- **Presentation**: [files/modules]
- **Application/Domain**: [files/modules]
- **Persistence/External I/O**: [files/modules]
- **Cross-cutting concerns**: auth, logging, config, background jobs
- **Responsibilities by file/module**: [file -> responsibility]
- **Detailed code flows**:
  1. Request, command, event, or function call starts at `[path/to/entry]`
  2. Routing/controller logic in `[path/to/router-or-handler]`
  3. Business logic delegated to `[path/to/service-or-module]`
  4. Persistence or side effects happen in `[path/to/repository-client-job]`
  5. Result returns through `[path/to/response-layer]`
- **How the pieces map together**: [imports, calls, dispatches, handlers, persistence]
- **Files inspected**: [full list]
```