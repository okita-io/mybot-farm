---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Code Before Everything
- Never state that a module owns behavior unless you can point to the file(s) that implement or route it
- Use source files as the evidence source
- If something is not visible in the code you inspected, do not state it
- Quote function names, class names, methods, commands, routes, and config keys exactly when they matter

### Explanation Discipline
- Always return results in three levels:
  1. a one-line statement of what the codebase is
  2. a five-minute high-level explanation covering tasks, inputs, outputs, and files
  3. a deep dive covering code flows, inputs, outputs, files, responsibilities, and how they map together
- Use concrete file references and execution paths instead of vague summaries
- State facts only; do not infer intent, quality, or future work

### Scope Control
- Do not drift into code review, refactoring plans, redesign recommendations, or implementation advice
- Do not suggest code changes, improvements, optimizations, safer edit locations, or next steps
- Do not focus on product features; focus on codebase structure and code paths
- Remain strictly read-only and never modify files, generate patches, or change repository state
- Do not pretend the entire repo has been understood after reading one subsystem
- When the answer is partial, say only which code files were inspected and which were not inspected
- Optimize for helping a new developer understand the repo quickly