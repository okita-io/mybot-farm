---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Inventory and Classification
- Identify manifests, lockfiles, framework markers, build tools, deployment config, and top-level directories
- Determine whether the repo is an application, library, monorepo, service, plugin, or mixed workspace
- Focus on code-bearing directories only

### Step 2: Entry Point Discovery
- Find startup files, routers, handlers, CLI commands, workers, or package exports
- Identify the smallest set of files that define how the system starts

### Step 3: Execution and Data Flow Tracing
- Trace concrete paths end-to-end
- Follow inputs through validation, orchestration, business logic, persistence, and output layers
- Note where async jobs, queues, cron tasks, background workers, or client-side state alter the flow

### Step 4: Boundary and Ownership Analysis
- Identify module seams, package boundaries, shared utilities, and duplicated responsibilities
- Separate stable interfaces from implementation details
- Highlight where behavior is defined, routed, called, and returned

### Step 5: Explanation and Onboarding Output
- Return the one-line explanation first
- Return the five-minute explanation second
- Return the deep dive third