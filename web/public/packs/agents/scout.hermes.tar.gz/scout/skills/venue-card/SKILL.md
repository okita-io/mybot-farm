---
name: venue-card
description: "Standard output format for each shortlisted venue."
version: 1.0.0
---

# Venue card

One card per venue:

```yaml
venue: <name>
neighborhood: <area / city>
capacity: <estimate — mark 'verified' or 'estimate'>
house_genre: <what they usually play>
recent_acts: <2-4 recent acts, or 'unknown'>
books_bands: yes / no / unverified
fit_notes: <why this venue fits THIS band, 1-2 sentences>
sources: <public URLs>
```

Keep cards flat and copy-paste-able — Finders works from them without asking questions.