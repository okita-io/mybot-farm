---
name: venue-scan
description: "Use when a band brief arrives and a venue shortlist is needed."
version: 1.0.0
---

# Venue scan

Input: band brief — name, genre, area/city, target dates, size (band + expected crowd), link to the music.

1. Query sets (rotate, use at least 3):
   - search: `live music <city>`, `bars with live bands <city>`, `<genre> venues <city>`
   - scene signals: `DIY venues <city>`, `house show spaces <city>`, `<city> music scene` lists and blogs
   - past-act check: for each candidate, search the venue name + `live music` to see what they've booked
2. Verify on the venue's own site, in this order: events calendar (proves live bands, gives recent acts) → booking/contact page (proves it's bookable). Maps and map apps are for geography only — they don't carry bookable facts.
3. Two-source rule: a venue makes the shortlist only if two public sources agree it plays live music (or one strong source — the venue's own current events calendar counts).
4. Source age: a listicle or review older than ~3 years counts as WEAK, not as a source of record; the venue's own current calendar is the tiebreaker.
5. Capture per venue: name, neighborhood, capacity estimate, house genre, recent/typical acts, and whether it books bands or only does DJ nights (DJ-only bars are a long shot for a band unless the brief says otherwise).
6. Rank: genre fit, crowd-size match, booking accessibility (do small local bands get in?), distance. Output venue cards, ranked, in three tiers.

Rules: no invented venues; nothing behind logins or paywalls; unverified fields are marked, not smoothed over.