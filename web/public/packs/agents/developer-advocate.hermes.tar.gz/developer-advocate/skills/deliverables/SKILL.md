---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Developer Onboarding Audit Framework
```markdown
# DX Audit: Time-to-First-Success Report

## Methodology
- Recruit 5 developers with [target experience level]
- Ask them to complete: [specific onboarding task]
- Observe silently, note every friction point, measure time
- Grade each phase: 🟢 <5min | 🟡 5-15min | 🔴 >15min

## Onboarding Flow Analysis

### Phase 1: Discovery (Goal: < 2 minutes)
| Step | Time | Friction Points | Severity |
|------|------|-----------------|----------|
| Find docs from homepage | 45s | "Docs" link is below fold on mobile | Medium |
| Understand what the API does | 90s | Value prop is buried after 3 paragraphs | High |
| Locate Quick Start | 30s | Clear CTA — no issues | ✅ |

### Phase 2: Account Setup (Goal: < 5 minutes)
...

### Phase 3: First API Call (Goal: < 10 minutes)
...

## Top 5 DX Issues by Impact
1. **Error message `AUTH_FAILED_001` has no docs** — developers hit this in 80% of sessions
2. **SDK missing TypeScript types** — 3/5 developers complained unprompted
...

## Recommended Fixes (Priority Order)
1. Add `AUTH_FAILED_001` to error reference docs + inline hint in error message itself
2. Generate TypeScript types from OpenAPI spec and publish to `@types/your-sdk`
...
```

### Viral Tutorial Structure
```markdown
# Build a [Real Thing] with [Your Platform] in [Honest Time]

**Live demo**: [link] | **Full source**: [GitHub link]

<!-- Hook: start with the end result, not with "in this tutorial we will..." -->
Here's what we're building: a real-time order tracking dashboard that updates every
2 seconds without any polling. Here's the [live demo](link). Let's build it.

## What You'll Need
- [Platform] account (free tier works — [sign up here](link))
- Node.js 18+ and npm
- About 20 minutes

## Why This Approach

<!-- Explain the architectural decision BEFORE the code -->
Most order tracking systems poll an endpoint every few seconds. That's inefficient
and adds latency. Instead, we'll use server-sent events (SSE) to push updates to
the client as soon as they happen. Here's why that matters...

## Step 1: Create Your [Platform] Project

```bash
npx create-your-platform-app my-tracker
cd my-tracker
```

Expected output:
```
✔ Project created
✔ Dependencies installed
ℹ Run `npm run dev` to start
```

> **Windows users**: Use PowerShell or Git Bash. CMD may not handle the `&&` syntax.

<!-- Continue with atomic, tested steps... -->

## What You Built (and What's Next)

You built a real-time dashboard using [Platform]'s [feature]. Key concepts you applied:
- **Concept A**: [Brief explanation of the lesson]
- **Concept B**: [Brief explanation of the lesson]

Ready to go further?
- → [Add authentication to your dashboard](link)
- → [Deploy to production on Vercel](link)
- → [Explore the full API reference](link)
```

### Conference Talk Proposal Template
```markdown
# Talk Proposal: [Title That Promises a Specific Outcome]

**Category**: [Engineering / Architecture / Community / etc.]
**Level**: [Beginner / Intermediate / Advanced]
**Duration**: [25 / 45 minutes]

## Abstract (Public-facing, 150 words max)

[Start with the developer's pain or the compelling question. Not "In this talk I will..."
but "You've probably hit this wall: [relatable problem]. Here's what most developers
do wrong, why it fails at scale, and the pattern that actually works."]

## Detailed Description (For reviewers, 300 words)

[Problem statement with evidence: GitHub issues, Stack Overflow questions, survey data.
Proposed solution with a live demo. Key takeaways developers will apply immediately.
Why this speaker: relevant experience and credibility signal.]

## Takeaways
1. Developers will understand [concept] and know when to apply it
2. Developers will leave with a working code pattern they can copy
3. Developers will know the 2-3 failure modes to avoid

## Speaker Bio
[Two sentences. What you've built, not your job title.]

## Previous Talks
- [Conference Name, Year] — [Talk Title] ([recording link if available])
```

### GitHub Issue Response Templates
```markdown
<!-- For bug reports with reproduction steps -->
Thanks for the detailed report and reproduction case — that makes debugging much faster.

I can reproduce this on [version X]. The root cause is [brief explanation].

**Workaround (available now)**:
```code
workaround code here
```

**Fix**: This is tracked in #[issue-number]. I've bumped its priority given the number…