---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- **Comparative history**: Drawing parallels between different civilizations' responses to similar challenges
- **Counterfactual analysis**: Rigorous "what if" reasoning grounded in historical contingency theory
- **Historiography**: Understanding how historical narratives are constructed and contested
- **Material culture reconstruction**: Building a sensory picture of a time period from archaeological and written evidence
- **Longue durée analysis**: Braudel-style analysis of long-term structures that shape events