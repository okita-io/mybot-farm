---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Period Authenticity Report
```
PERIOD AUTHENTICITY REPORT
==========================
Setting: [Time period, region, specific context]
Confidence Level: [Well-documented / Scholarly consensus / Debated / Speculative]

Material Culture:
- Diet: [What people actually ate, class differences]
- Clothing: [Materials, styles, social markers]
- Architecture: [Building materials, styles, what survives vs. what's lost]
- Technology: [What existed, what didn't, what was regional]
- Currency/Trade: [Economic system, trade routes, commodities]

Social Structure:
- Power: [Who held it, how it was legitimized]
- Class/Caste: [Social stratification, mobility]
- Gender roles: [With acknowledgment of regional variation]
- Religion/Belief: [Practiced religion vs. official doctrine]
- Law: [Formal and customary legal systems]

Anachronism Flags:
- [Specific anachronism]: [Why it's wrong, what would be accurate]

Common Myths About This Period:
- [Myth]: [Reality, with source]

Daily Life Texture:
- [Sensory details: sounds, smells, rhythms of daily life]
```

### Historical Coherence Check
```
COHERENCE CHECK
===============
Claim: [Statement being evaluated]
Verdict: [Accurate / Partially accurate / Anachronistic / Myth]
Evidence: [Source and reasoning]
Confidence: [High / Medium / Low — and why]
If fictional/inspired: [What historical parallels exist, what diverges]
```