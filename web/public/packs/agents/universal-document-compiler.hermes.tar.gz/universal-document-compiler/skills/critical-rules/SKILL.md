---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. Zero Schema Discrimination
Never discard, truncate, or reject an unknown YAML key. If an incoming document contains `clinical_trials`, `server_benchmarks`, or `grandma_recipes`, the compiler must ingest the node, extract its topological shape, and synthesize an appropriate visual layout archetype. Hardcoded domain interfaces must only serve as optional semantic presets, never as gatekeepers.

### 2. Non-Destructive Sidecar Persistence (Decoupled View-Model)
Never pollute the raw YAML/JSON source code with visual presentation metadata (e.g., injecting `_layout: card` or `_color: blue` into the user's data). The user's code is the immutable source of truth. All visual overrides, dimensions, and typography choices must persist in an external **Layout Manifest Sidecar**, indexed by Identity-Stabilized Semantic Path Pointers.

### 3. Transactional Provenance Routing
To prevent recursive state cascades:
- Every edit must carry a provenance tag: `origin: 'editor' | 'canvas' | 'tree' | 'inspector' | 'system'`.
- Code editor keystrokes must update the AST off the main thread without re-serializing text back into the editor.
- Visual canvas or layer tree reordering must perform surgical, in-place AST mutations using Concrete Syntax Tree (CST) range tokens (`[start, value-end, node-end]`), preserving comments, indentation, and caret positions.

### 4. Euclidean Paged Boundary Enforcement
The physical page is finite. Every inferred layout archetype must declare its fragmentation policy:
- Headers and titles must strictly enforce `break-after: avoid`.
- Atomic cards and key-value rows must enforce `break-inside: avoid`.
- Multi-column tracks must never exceed the fragmentainer block budget ($297\text{mm} = 1122.52\text{px}$ for A4 at 96 DPI).
- If dynamic content overflows the Euclidean boundary, the engine must execute automated binary bisection or insert clean, deterministic page breaks.

### 5. Dual-Engine Backward Compatibility
When an incoming payload matches the canonical JSON Resume schema (`basics`, `work`, `education`, `skills`), the compiler must seamlessly activate the **High-Density ATS Preset**. It must preserve ATS-friendly microdata and keyword hierarchies while still allowing the user to extend the document with arbitrary custom sections.

---