---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

1. Canonical Universal Document AST (`UniversalDocumentAST.ts`)

```typescript
export type LayoutArchetype =
  | 'block_group'       // Structural section container (H1-H4)
  | 'card_grid'         // Homogeneous sequence of mappings (cards/boxes)
  | 'timeline'          // Chronological sequence with temporal anchors
  | 'badge_list'        // Compact horizontal clusters of short scalars
  | 'key_value_table'   // Associative tabular definition pairs
  | 'prose_flow'        // Continuous multi-line narrative typography
  | 'leaf_item';        // Terminal scalar value

export interface SemanticPathPointer {
  rawPath: string;            // e.g. "/work/0/company"
  semanticPredicate: string;  // e.g. "/work/[company='Acme Corp']/role"
  depth: number;
}

export interface NodeShapeDescriptor {
  nodeType: 'scalar' | 'sequence' | 'mapping';
  childCount: number;
  jaccardUniformity?: number;  // 0.0 to 1.0 for sequences of mappings
  meanStringLength?: number;
  hasTemporalTokens: boolean;
  hasNumericMetrics: boolean;
}

export interface LayoutBlockNode {
  id: string;
  pointer: SemanticPathPointer;
  title?: string;
  archetype: LayoutArchetype;
  shape: NodeShapeDescriptor;
  cstRange: [start: number, valueEnd: number, nodeEnd: number];
  depth: number;
  children?: LayoutBlockNode[];
  data: any;
  overrides?: LayoutOverrideProperties;
}

export interface LayoutOverrideProperties {
  forcedArchetype?: LayoutArchetype;
  fontScale?: number;         // Multiplier (0.7 to 1.5)
# … truncated for farm planting — see upstream for the full sample
```

---

### 2. Algorithmic Data-Shape Classifier (`DataShapeClassifier.ts`)

```typescript
export class DataShapeClassifier {
  private static TEMPORAL_KEYS = new Set([
    'date', 'period', 'year', 'startdate', 'enddate', 'until', 'ano', 'inicio', 'fim', 'data'
  ]);

  private static METRIC_KEYS = new Set([
    'value', 'metric', 'total', 'amount', 'score', 'valor', 'total', 'kpi', 'delta'
  ]);

  /**
   * Calculates the average pairwise Jaccard similarity across a collection of mappings.
   */
  public static calculateJaccardUniformity(records: Record<string, any>[]): number {
    if (records.length <= 1) return 1.0;
    let totalJaccard = 0;
    let pairs = 0;

    const keySets = records.map(r => new Set(Object.keys(r || {})));

    for (let i = 0; i < keySets.length; i++) {
      for (let j = i + 1; j < keySets.length; j++) {
        const intersection = new Set([...keySets[i]].filter(k => keySets[j].has(k)));
        const union = new Set([...keySets[i], ...keySets[j]]);
        totalJaccard += union.size === 0 ? 1 : intersection.size / union.size;
        pairs++;
      }
    }
    return pairs === 0 ? 1.0 : totalJaccard / pairs;
  }

  /**
   * Infers the optimal layout archetype for any arbitrary data node.
   */
  public static inferArchetype(data: any): LayoutArchetype {
    // 1. Primitive Scalars
    if (typeof data !== 'object' || data === null) {
      return typeof data === 'string' && data.length > 120 ? 'prose_flow' : 'leaf_item';
    }

    // 2. Sequences
# … truncated for farm planting — see upstream for the full sample
```

---

### 3. Bidirectional In-Place AST Mutator (`ASTSequenceMutator.ts`)

```typescript
import { Document, YAMLSeq, isSeq, parseDocument } from 'yaml';

export interface LayerReorderIntent {
  sourcePointer: string; // e.g. "/projects/2"
  targetSequencePointer: string; // e.g. "/projects"
  targetIndex: number;
}

/**
 * Performs atomic in-place CST mutation preserving comments and carets.
 */
export function executeReorderTransaction(
  yamlSource: string,
  intent: LayerReorderIntent
): { updatedYaml: string; changedRange: [number, number] } {
  const doc = parseDocument(yamlSource, { keepSourceTokens: true });

  const seqPath = intent.targetSequencePointer.split('/').filter(Boolean);
  const targetSeq = doc.getIn(seqPath);

  if (!isSeq(targetSeq)) {
    throw new Error(`Target at pointer ${intent.targetSequencePointer} is not a valid sequence.`);
  }

  const sourceIndex = parseInt(intent.sourcePointer.split('/').pop() || '0', 10);
  const [movedNode] = targetSeq.items.splice(sourceIndex, 1);
  targetSeq.items.splice(intent.targetIndex, 0, movedNode);

  const updatedYaml = doc.toString();
  return {
    updatedYaml,
    changedRange: targetSeq.range ? [targetSeq.range[0], targetSeq.range[2]] : [0, updatedYaml.length]
  };
}
```

---