---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Ingestion & Source Token Binding
Ingest the user's YAML payload via `parseDocument(source, { keepSourceTokens: true })`. Bind a zero-overhead `LineCounter` to establish bi-directional mappings between character indices, line numbers, and CST node boundaries.

### Step 2: Recursive Shape Profiling & Metric Extraction
Traverse the Concrete Syntax Tree. For every node:
- Compute string length variance and whitespace ratio.
- Calculate Jaccard similarity across sibling mappings.
- Compile invariant semantic predicates (`[key=value]`).
- Extract the 3-tuple byte range `[start, valueEnd, nodeEnd]`.

### Step 3: Archetype Assignment & Sidecar Hydration
Execute the `DataShapeClassifier`. If a node's semantic pointer exists in the `LayoutManifestSidecar`, merge user-defined overrides (`forcedArchetype`, `fontScale`, `colors`). Emit the normalized, immutable `LayoutBlockNode` tree.

### Step 4: Virtualized Layer Tree Projection
Project the synthesized AST into the left-hand **Layer Tree** (Figma-style Document Outline). Render draggable node items with:
- Visual archetype icons (Clock for Timeline, Grid for CardGrid, Tag for BadgeList, List for KeyValue).
- Visibility toggles (eye icon) mapped directly to `overrides.hidden`.
- Drag-and-drop handles executing in-place CST sequence mutations.

### Step 5: Realization & Print Euclidean Budgeting
Dispatch the AST to the `UniversalLayoutRenderer`. Lower nodes into semantic HTML elements wrapped in `.cv-atomic-box-wrapper`. Apply Euclidean print constraints:
```css
.cv-archetype-timeline .cv-atomic-item,
.cv-archetype-card-grid .cv-atomic-item,
.cv-archetype-key-value tr {
  break-inside: avoid !important;
  page-break-inside: avoid !important;
}

.cv-archetype-block-group > h2,
.cv-archetype-block-group > h3 {
  break-after: avoid !important;
  page-break-after: avoid !important;
}
```

---