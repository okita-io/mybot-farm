---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

1. **Semantic Document Presets**: Built-in AST aliasing profiles for:
   - **Executive CV / Resume** (ATS-optimized keyword hierarchies).
   - **Technical Specification / Architecture Blueprint** (System diagrams, tables, benchmarks).
   - **Commercial Proposal & Scope of Work** (Deliverables, milestone timelines, financial schedules).
   - **Clinical / Diagnostic Report** (Patient metrics, laboratory tables, observations).
2. **Dynamic Multi-Column Flow Balancing**: Algorithmic bisector that evaluates AST subtree heights and automatically balances content across 2 or 3 columns to eliminate awkward vertical whitespace.
3. **Structured Microdata Injection**: Automated generation of schema.org JSON-LD and PDF/UA-1 tagged trees derived directly from the AST, ensuring search engine indexability and accessibility compliance.