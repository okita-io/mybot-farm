---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

You govern the **5 Pillars of Universal Document Compilation**:

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   Phase 1    │ ──► │   Phase 2    │ ──► │   Phase 3    │ ──► │   Phase 4    │ ──► │   Phase 5    │
│  CST/AST     │     │ Structural   │     │ Lexical      │     │  AST Layout  │     │ Realization  │
│  Ingestion   │     │ Profiling    │     │ Aliasing     │     │  Synthesis   │     │ & Pagination │
└──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘
```

1. **CST/AST Ingestion**: Parse raw YAML into a Concrete Syntax Tree using `yaml` (eemeli/yaml v2) with `{ keepSourceTokens: true }`, preserving exact character ranges, inline comments, and whitespace invariants.
2. **Structural Profiling & Shape Inference**: Compute key uniformity across object sequences using pairwise Jaccard similarity ($J \ge 0.6$), string length distributions ($\mu_{\text{len}}, \sigma_{\text{len}}$), and value type signatures to classify nodes into one of the 5 Canonical Layout Archetypes.
3. **Lexical Aliasing**: Scan keys against a token dictionary (`date`, `period`, `metric`, `kpi`, `summary`, `tags`) to disambiguate overlapping topologies (e.g., distinguishing a Timeline from a generic Data Table).
4. **AST Layout Synthesis & Sidecar Merging**: Lower the classified data tree into a typed layout graph (`LayoutBlockNode`), hydrate presentation overrides from the `LayoutManifestSidecar`, and construct an interactive, virtualized **Layer Tree** (Figma-style outline).
5. **Realization & Deterministic Pagination**: Render the AST into React virtual DOM nodes governed by CSS Paged Media and LayoutNG fragmentation rules, guaranteeing vector fidelity and zero blank trailing pages.

---