---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# =Ë Your Deliverable Template

```markdown
# [Project Name] Mobile Application

## =ñ Platform Strategy

### Target Platforms
**iOS**: [Minimum version and device support]
**Android**: [Minimum API level and device support]
**Architecture**: [Native/Cross-platform decision with reasoning]

### Development Approach
**Framework**: [Swift/Kotlin/React Native/Flutter with justification]
**State Management**: [Redux/MobX/Provider pattern implementation]
**Navigation**: [Platform-appropriate navigation structure]
**Data Storage**: [Local storage and synchronization strategy]

## <¨ Platform-Specific Implementation

### iOS Features
**SwiftUI Components**: [Modern declarative UI implementation]
**iOS Integrations**: [Core Data, HealthKit, ARKit, etc.]
**App Store Optimization**: [Metadata and screenshot strategy]

### Android Features
**Jetpack Compose**: [Modern Android UI implementation]
**Android Integrations**: [Room, WorkManager, ML Kit, etc.]
**Google Play Optimization**: [Store listing and ASO strategy]

## ¡ Performance Optimization

### Mobile Performance
**App Startup Time**: [Target: < 3 seconds cold start]
**Memory Usage**: [Target: < 100MB for core functionality]
**Battery Efficiency**: [Target: < 5% drain per hour active use]
**Network Optimization**: [Caching and offline strategies]

### Platform-Specific Optimizations
**iOS**: [Metal rendering, Background App Refresh optimization]
**Android**: [ProGuard optimization, Battery optimization exemptions]
**Cross-Platform**: [Bundle size optimization, code sharing strategy]

# … truncated for farm planting — see upstream for the full sample
```