---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# =Ë Your Technical Deliverables

iOS SwiftUI Component Example
```swift
// Modern SwiftUI component with performance optimization
import SwiftUI
import Combine

struct ProductListView: View {
    @StateObject private var viewModel = ProductListViewModel()
    @State private var searchText = ""

    var body: some View {
        NavigationView {
            List(viewModel.filteredProducts) { product in
                ProductRowView(product: product)
                    .onAppear {
                        // Pagination trigger
                        if product == viewModel.filteredProducts.last {
                            viewModel.loadMoreProducts()
                        }
                    }
            }
            .searchable(text: $searchText)
            .onChange(of: searchText) { _ in
                viewModel.filterProducts(searchText)
            }
            .refreshable {
                await viewModel.refreshProducts()
            }
            .navigationTitle("Products")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Filter") {
                        viewModel.showFilterSheet = true
                    }
                }
            }
            .sheet(isPresented: $viewModel.showFilterSheet) {
                FilterView(filters: $viewModel.filters)
            }
        }
        .task {
            await viewModel.loadInitialProducts()
# … truncated for farm planting — see upstream for the full sample
```

### Android Jetpack Compose Component
```kotlin
// Modern Jetpack Compose component with state management
@Composable
fun ProductListScreen(
    viewModel: ProductListViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    Column {
        SearchBar(
            query = searchQuery,
            onQueryChange = viewModel::updateSearchQuery,
            onSearch = viewModel::search,
            modifier = Modifier.fillMaxWidth()
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(
                items = uiState.products,
                key = { it.id }
            ) { product ->
                ProductCard(
                    product = product,
                    onClick = { viewModel.selectProduct(product) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateItemPlacement()
                )
            }

            if (uiState.isLoading) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
# … truncated for farm planting — see upstream for the full sample
```

### Cross-Platform React Native Component
```typescript
// React Native component with platform-specific optimizations
import React, { useMemo, useCallback } from 'react';
import {
  FlatList,
  StyleSheet,
  Platform,
  RefreshControl,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useInfiniteQuery } from '@tanstack/react-query';

interface ProductListProps {
  onProductSelect: (product: Product) => void;
}

export const ProductList: React.FC<ProductListProps> = ({ onProductSelect }) => {
  const insets = useSafeAreaInsets();

  const {
    data,
    fetchNextPage,
    hasNextPage,
    isLoading,
    isFetchingNextPage,
    refetch,
    isRefetching,
  } = useInfiniteQuery({
    queryKey: ['products'],
    queryFn: ({ pageParam = 0 }) => fetchProducts(pageParam),
    getNextPageParam: (lastPage, pages) => lastPage.nextPage,
  });

  const products = useMemo(
    () => data?.pages.flatMap(page => page.products) ?? [],
    [data]
  );

  const renderItem = useCallback(({ item }: { item: Product }) => (
    <ProductCard
      product={item}
# … truncated for farm planting — see upstream for the full sample
```