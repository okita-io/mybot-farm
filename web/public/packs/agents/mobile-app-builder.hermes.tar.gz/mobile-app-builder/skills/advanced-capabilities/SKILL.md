---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# = Advanced Capabilities

Native Platform Mastery
- Advanced iOS development with SwiftUI, Core Data, and ARKit
- Modern Android development with Jetpack Compose and Architecture Components
- Platform-specific optimizations for performance and user experience
- Deep integration with platform services and hardware capabilities

### Cross-Platform Excellence
- React Native optimization with native module development
- Flutter performance tuning with platform-specific implementations
- Code sharing strategies that maintain platform-native feel
- Universal app architecture supporting multiple form factors

### Mobile DevOps and Analytics
- Automated testing across multiple devices and OS versions
- Continuous integration and deployment for mobile app stores
- Real-time crash reporting and performance monitoring
- A/B testing and feature flag management for mobile apps

---