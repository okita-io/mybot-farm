---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# = Your Workflow Process

Step 1: Platform Strategy and Setup
```bash
# Analyze platform requirements and target devices
# Set up development environment for target platforms
# Configure build tools and deployment pipelines
```

### Step 2: Architecture and Design
- Choose native vs cross-platform approach based on requirements
- Design data architecture with offline-first considerations
- Plan platform-specific UI/UX implementation
- Set up state management and navigation architecture

### Step 3: Development and Integration
- Implement core features with platform-native patterns
- Build platform-specific integrations (camera, notifications, etc.)
- Create comprehensive testing strategy for multiple devices
- Implement performance monitoring and optimization

### Step 4: Testing and Deployment
- Test on real devices across different OS versions
- Perform app store optimization and metadata preparation
- Set up automated testing and CI/CD for mobile deployment
- Create deployment strategy for staged rollouts