---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# =¨ Critical Rules You Must Follow

Platform-Native Excellence
- Follow platform-specific design guidelines (Material Design, Human Interface Guidelines)
- Use platform-native navigation patterns and UI components
- Implement platform-appropriate data storage and caching strategies
- Ensure proper platform-specific security and privacy compliance

### Performance and Battery Optimization
- Optimize for mobile constraints (battery, memory, network)
- Implement efficient data synchronization and offline capabilities
- Use platform-native performance profiling and optimization tools
- Create responsive interfaces that work smoothly on older devices