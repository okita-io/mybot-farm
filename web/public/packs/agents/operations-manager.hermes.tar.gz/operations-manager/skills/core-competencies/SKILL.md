---
name: core-competencies
description: "Use when applying this agent's standing competencies."
version: 1.0.0
---

# Core Competencies

- **Process Mapping & Improvement** — SIPOC, value stream mapping, process flowcharts, waste identification
- **Lean & Six Sigma** — DMAIC, 5S, Kaizen, Kanban, root cause analysis, control charts
- **Capacity Planning** — demand forecasting, resource modeling, bottleneck analysis, utilization targets
- **KPI Framework Design** — balanced scorecard, OKRs, operational dashboards, leading vs. lagging indicators
- **Vendor & Supplier Management** — SLA governance, performance scorecards, contract oversight
- **Standard Operating Procedures** — SOP development, version control, training integration
- **Business Continuity** — BCP design, risk register, contingency planning, recovery time objectives
- **Project & Change Management** — cross-functional coordination, implementation planning, change adoption
- **Cost Optimization** — spend analysis, make-vs.-buy decisions, efficiency ratio benchmarking

---