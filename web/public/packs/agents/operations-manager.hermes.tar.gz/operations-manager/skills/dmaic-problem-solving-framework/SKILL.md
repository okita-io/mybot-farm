---
name: dmaic-problem-solving-framework
description: "Use when the task matches this agent's dmaic problem-solving framework work."
version: 1.0.0
---

# DMAIC Problem-Solving Framework

Define
- **Problem statement**: What is wrong? Where? How much? Since when?
- **Business case**: What is the cost of this problem (time, money, quality)?
- **Project scope**: In scope / out of scope boundaries
- **SIPOC**: Process boundaries
- **Voice of Customer (VOC)**: What does the customer need? (CTQ — Critical to Quality)

### Measure
- **Data collection plan**: What data, from where, how often, who collects?
- **Baseline performance**: Current process capability (Cp, Cpk, defect rate, DPMO)
- **Measurement system analysis (MSA)**: Is the measurement system reliable? (Gage R&R)
- **Process map**: Detailed swimlane map of current state

### Analyze
- **Root cause analysis tools**:
  - 5 Whys: Ask "why" 5 times to surface root cause from symptom
  - Fishbone / Ishikawa diagram: Categories — Man, Machine, Method, Material, Measurement, Mother Nature
  - Pareto chart: 80/20 analysis of defect or failure categories
  - Scatter plot / correlation: test hypotheses about cause-effect relationships
- **Statistical analysis**: hypothesis testing, regression, ANOVA (if data supports it)
- **Root cause validation**: confirm cause-effect with data, not just logic

### Improve
- **Solution generation**: brainstorm; evaluate against impact/effort matrix
- **Pilot design**: small-scale test; define success criteria before starting
- **Implementation plan**: owner, timeline, dependencies, risk mitigation
- **Error-proofing (Poka-yoke)**: build in checks to prevent defects from occurring or escaping

### Control
- **Control plan**: document what to monitor, frequency, who monitors, reaction plan if out of control
- **Control charts**: Statistical Process Control (SPC) — identify special vs. common cause variation
- **Updated SOPs**: capture the new process in documented procedures
- **Training and handoff**: ensure operational team owns the improved process
- **Project closure**: document results vs. baseline; hand off to process owner; celebrate wins

---