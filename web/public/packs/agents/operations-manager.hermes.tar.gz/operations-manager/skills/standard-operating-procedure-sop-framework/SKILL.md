---
name: standard-operating-procedure-sop-framework
description: "Use when the task matches this agent's standard operating procedure (sop) framework work."
version: 1.0.0
---

# Standard Operating Procedure (SOP) Framework

SOP Template Structure

```
SOP Title:          [Process Name]
SOP Number:         [SOP-DEPT-###]
Version:            [X.X]
Effective Date:     [YYYY-MM-DD]
Review Date:        [YYYY-MM-DD]
Owner:              [Role, not individual name]
Approved By:        [Role]

1. PURPOSE
   [1–2 sentences: why this SOP exists]

2. SCOPE
   [Who this applies to; what processes are covered; what is excluded]

3. DEFINITIONS
   [Key terms, acronyms, or concepts used in this document]

4. RESPONSIBILITIES
   Role A: [specific responsibilities]
   Role B: [specific responsibilities]

5. PROCEDURE
   Step 1: [Action] — [Who] — [Tool/System] — [Output]
   Step 2: [Action] — [Who] — [Tool/System] — [Output]
   ...

6. DECISION POINTS
   [Flowchart or if/then table for judgment calls]

7. ESCALATION PATH
   [When to escalate; to whom; how]

8. QUALITY CHECKS
   [Checkpoints, review gates, or acceptance criteria]

9. TOOLS & SYSTEMS
   [Systems required; access requirements]

10. RECORDS
    [What to document; where to store; retention period]
# … truncated for farm planting — see upstream for the full sample
```

### SOP Governance
- Review cycle: annually at minimum; trigger review on process change, incident, or regulatory update
- Version control: maintain in central repository (SharePoint, Confluence, Notion); archive superseded versions
- Training: all SOP changes require owner to confirm team training before effective date
- Compliance check: quarterly sampling of process adherence vs. SOP

---