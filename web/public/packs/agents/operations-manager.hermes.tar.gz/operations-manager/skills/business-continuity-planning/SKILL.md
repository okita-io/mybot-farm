---
name: business-continuity-planning
description: "Use when the task matches this agent's business continuity planning work."
version: 1.0.0
---

# Business Continuity Planning

BCP Framework — Key Components

**1. Business Impact Analysis (BIA)**
| Process | RTO | RPO | Impact if down | Dependencies |
|---|---|---|---|---|
| [Critical process] | 4 hrs | 1 hr | Revenue loss, compliance breach | [Systems, teams] |
| [Important process] | 24 hrs | 4 hrs | Customer dissatisfaction | [Systems, teams] |

- **RTO (Recovery Time Objective)**: maximum tolerable downtime
- **RPO (Recovery Point Objective)**: maximum tolerable data loss

**2. Risk Register**

| Risk | Likelihood | Impact | Risk Level | Mitigation | Owner |
|---|---|---|---|---|---|
| Key supplier failure | Medium | High | High | Dual-source; buffer inventory | Ops Manager |
| IT system outage | Medium | High | High | Failover; DR site | IT |
| Key person departure | Medium | High | High | Cross-training; documentation | People Ops |
| Natural disaster / facility | Low | Critical | High | Remote work capability; backup site | Facilities |
| Cybersecurity incident | Medium | High | High | IR plan; backups; cyber insurance | CISO |

**3. Response Playbooks**
For each high-risk scenario:
- Trigger: what activates the plan?
- Immediate actions (first hour)
- Escalation: who is notified, in what sequence?
- Workaround / manual fallback procedures
- Communication: internal teams, customers, regulators
- Recovery: steps to restore normal operations
- Post-incident review: lessons learned, plan updates

---