---
name: capacity-planning-model
description: "Use when the task matches this agent's capacity planning model work."
version: 1.0.0
---

# Capacity Planning Model

Demand Forecasting Inputs
- Historical volume (minimum 12 months; seasonal adjustment if applicable)
- Pipeline / backlog data
- Growth rate assumptions from business plan
- Seasonal index calculation: Monthly volume / Annual average monthly volume

### Resource Capacity Calculation

**Step 1 — Available Capacity**
```
Available hours per FTE = Working days × Hours per day × (1 − Absence rate)
Example: 250 days × 8 hrs × (1 − 10%) = 1,800 hours/year
```

**Step 2 — Productive Capacity**
```
Productive hours = Available hours × Utilization target
Example: 1,800 hrs × 80% = 1,440 productive hours/year
```
Utilization target by role type:
- Customer-facing / transactional: 80–85%
- Knowledge workers: 70–75%
- Management: 50–60% (reserve for unplanned work and leadership)

**Step 3 — Demand vs. Capacity**
```
FTEs required = Forecast volume × Average handle time / Productive hours per FTE
```

**Step 4 — Headcount Plan**
| Period | Forecast Volume | Avg Handle Time | FTEs Required | FTEs Available | Gap |
|---|---|---|---|---|---|
| Q1 | | | | | |
| Q2 | | | | | |
| Q3 | | | | | |
| Q4 | | | | | |

**Capacity Levers** (in order of preference):
1. Efficiency improvement (reduce handle time via process/tooling)
2. Cross-training existing staff (expand capacity without headcount)
3. Overtime / temporary staffing (flex for peaks)
4. Outsourcing (cost/quality trade-off analysis required)
5. Hiring (longest lead time; last resort for short-term peaks)

### Bottleneck Analysis (Theory of Constraints)
1. **Identify the constraint**: which step limits overall throughput?
2. **Exploit the constraint**: maximize output from the bottleneck (eliminate waste within it)
3. **Subordinate everything else**: pace non-bottleneck steps to feed the constraint, not faster
4. **Elevate the constraint**: add capacity to the bottleneck only if needed after exploitation
5. **Repeat**: once the constraint is resolved, find the next one

---