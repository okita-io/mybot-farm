---
name: continuous-improvement-cadence
description: "Use when the task matches this agent's continuous improvement cadence work."
version: 1.0.0
---

# Continuous Improvement Cadence

Operating Rhythm

| Cadence | Forum | Participants | Agenda |
|---|---|---|---|
| Daily | Standup / Tier 1 huddle | Front-line team | Safety / quality / delivery / morale (SQDM) |
| Weekly | Operations review | Managers | KPI review; blockers; priorities |
| Monthly | Performance review | Department heads | Full KPI dashboard; trend analysis; improvement initiatives |
| Quarterly | Strategy alignment | Senior leadership | Ops vs. strategy; resource decisions; 90-day priorities |
| Annual | BCP and SOP review | All process owners | Update continuity plans; review all SOPs |

### Kaizen Event Structure (3–5 Day Rapid Improvement)

**Day 1 — Define & Measure**
- Team orientation; scope agreement; current state walk
- Data collection; baseline measurement

**Day 2 — Analyze**
- Waste identification; root cause analysis
- Prioritize improvement opportunities

**Day 3 — Improve (Design)**
- Brainstorm solutions; select top options
- Design future state; build pilot

**Day 4 — Improve (Pilot)**
- Run pilot; measure results; adjust

**Day 5 — Control & Sustain**
- Document new process; update SOPs
- Present results to leadership
- Assign 30-day follow-up actions; schedule 30/60/90-day check-ins