---
name: process-mapping-framework
description: "Use when the task matches this agent's process mapping framework work."
version: 1.0.0
---

# Process Mapping Framework

SIPOC Analysis Template

Use SIPOC to define process boundaries before diving into improvement work.

| Element | Definition | Questions to Answer |
|---|---|---|
| **S**uppliers | Who/what provides inputs? | Which teams, vendors, or systems feed this process? |
| **I**nputs | What materials/information enters? | What triggers the process? What data is required? |
| **P**rocess | What are the high-level steps? | What are the 5–7 major steps at a macro level? |
| **O**utputs | What does the process produce? | What deliverable, decision, or state change results? |
| **C**ustomers | Who receives the output? | Internal teams, external customers, downstream processes? |

### Value Stream Mapping (VSM) Protocol

**Step 1 — Select the Value Stream**
Choose one product family or service line. Map current state first; never map future state without current state baseline.

**Step 2 — Walk the Process**
Physically or digitally trace each step from customer demand to delivery. Capture:
- Process steps and sequence
- Cycle time (CT): time to complete one unit of work
- Lead time (LT): total elapsed time from start to finish
- Inventory / queue between steps (work in progress)
- Push vs. pull triggers
- Number of operators per step

**Step 3 — Calculate Key VSM Metrics**
- **Value-Added Time (VAT)**: time spent on steps customers would pay for
- **Non-Value-Added Time (NVAT)**: waste (waiting, rework, transport, overprocessing)
- **Process Efficiency**: VAT / Total Lead Time × 100%
- **Takt Time**: Available production time / Customer demand rate (the "heartbeat" of demand)

**Step 4 — Identify Waste (8 Wastes of Lean — TIMWOODS)**
| Waste | Description | Example |
|---|---|---|
| **T**ransportation | Unnecessary movement of materials/information | Emailing files back and forth |
| **I**nventory | Excess WIP or finished goods beyond immediate need | Backlog of unreviewed tickets |
| **M**otion | Unnecessary movement of people | Walking to retrieve approvals |
| **W**aiting | Idle time between steps | Waiting for approvals, data, or decisions |
| **O**verproduction | Producing more than needed | Reports no one reads |
| **O**verprocessing | More effort than required | Triple-checking low-risk work |
| **D**efects | Errors requiring rework or scrapping | Data entry errors; incorrect invoices |
| **S**kills | Underutilizing people's capabilities | Expert staff doing administrative work |

**Step 5 — Design Future State**
Apply improvements: level the flow, pull signals, reduce batch sizes, eliminate non-value-added steps, implement poka-yoke (error-proofing).

---