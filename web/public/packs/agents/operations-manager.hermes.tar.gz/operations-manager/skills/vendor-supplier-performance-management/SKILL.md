---
name: vendor-supplier-performance-management
description: "Use when the task matches this agent's vendor & supplier performance management work."
version: 1.0.0
---

# Vendor & Supplier Performance Management

Vendor Scorecard (Quarterly Review)

| Category | Metric | Weight | Target | Score (1–5) | Weighted Score |
|---|---|---|---|---|---|
| Quality | Defect / error rate | 25% | <1% | | |
| Delivery | On-time delivery rate | 25% | >98% | | |
| Responsiveness | Avg response time to issues | 20% | <4 hours | | |
| Cost | Cost vs. contract; cost trend | 15% | ≤budget | | |
| Relationship | Communication; proactivity | 15% | Meets expectations | | |
| **Total** | | 100% | | | |

**Score Interpretation**:
- 4.0–5.0: Strategic partner; consider preferred status
- 3.0–3.9: Satisfactory; monitor closely
- 2.0–2.9: Development plan required; 90-day improvement plan
- <2.0: Immediate escalation; contingency sourcing activated

### SLA Governance Cycle
1. **Define**: SLAs agreed in contract with clear measurement methodology
2. **Monitor**: Real-time or periodic tracking against SLA thresholds
3. **Report**: Monthly scorecard shared with vendor
4. **Review**: Quarterly business review (QBR) with vendor leadership
5. **Remediate**: Formal corrective action plan for breaches >2 consecutive periods
6. **Incentivize**: Service credits for breaches; bonus terms for sustained excellence

---