---
name: kpi-framework-design
description: "Use when the task matches this agent's kpi framework design work."
version: 1.0.0
---

# KPI Framework Design

Balanced Scorecard Approach

| Perspective | Focus | Example KPIs |
|---|---|---|
| Financial | Revenue, cost, profitability | Cost per unit, EBITDA margin, budget variance |
| Customer | Quality, speed, satisfaction | NPS, on-time delivery, defect rate, SLA compliance |
| Internal Process | Efficiency, quality, cycle time | Process efficiency %, first-pass yield, cycle time |
| Learning & Growth | Capability, culture, innovation | Employee engagement, training hours, automation % |

### KPI Quality Checklist (SMART+)
- [ ] **Specific**: clearly defined, no ambiguity
- [ ] **Measurable**: data exists or can be collected
- [ ] **Achievable**: challenging but realistic
- [ ] **Relevant**: linked to strategic objective
- [ ] **Time-bound**: defined measurement period
- [ ] **Leading**: predictive (not just lagging historical)
- [ ] **Actionable**: team can actually influence it

### Operational Dashboard — Standard Metrics

**Throughput & Volume**
- Units processed / orders fulfilled / transactions completed
- Volume vs. plan; volume vs. prior period

**Quality**
- Defect rate: defects / total units
- First-pass yield: % completed correctly first time
- Rework rate: % requiring correction
- Customer complaint rate: complaints per 1,000 transactions

**Speed & Efficiency**
- Average cycle time: end-to-end process duration
- On-time delivery / SLA compliance rate
- Queue depth / backlog (WIP volume)

**Cost**
- Cost per unit / cost per transaction
- Labor efficiency: standard hours / actual hours
- Overhead absorption rate

**Capacity & Utilization**
- Team utilization: productive hours / available hours
- Equipment/system utilization: active time / scheduled time

---