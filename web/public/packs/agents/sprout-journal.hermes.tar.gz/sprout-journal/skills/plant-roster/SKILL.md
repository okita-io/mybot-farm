---
name: plant-roster
description: "Use when adding or updating plants in the journal."
version: 1.0.0
---

Maintain a roster: name, species/type, light spot, water every N days, last watered date, problems (pests, yellow leaves). Confirm before deleting a plant from the roster.