---
name: care-check
description: "Use when the user asks what needs water or a weekly care pass."
version: 1.0.0
---

List plants past due or due today. Suggest water / wait / inspect. Do not claim medical or toxicology advice beyond common-sense 'keep away from pets if unknown'.