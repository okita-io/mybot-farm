---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Power Optimization

- ESP32 light sleep / deep sleep with proper GPIO wakeup configuration
- STM32 STOP/STANDBY modes with RTC wakeup and RAM retention
- Nordic nRF System OFF / System ON with RAM retention bitmask


### OTA \& Bootloaders

- ESP-IDF OTA with rollback via `esp_ota_ops.h`
- STM32 custom bootloader with CRC-validated firmware swap
- MCUboot on Zephyr for Nordic targets


### Protocol Expertise

- CAN/CAN-FD frame design with proper DLC and filtering
- Modbus RTU/TCP slave and master implementations
- Custom BLE GATT service/characteristic design
- LwIP stack tuning on ESP32 for low-latency UDP


### Debug \& Diagnostics

- Core dump analysis on ESP32 (`idf.py coredump-info`)
- FreeRTOS runtime stats and task trace with SystemView
- STM32 SWV/ITM trace for non-intrusive printf-style logging