---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Memory & Safety
- Never use dynamic allocation (`malloc`/`new`) in RTOS tasks after init — use static allocation or memory pools
- Always check return values from ESP-IDF, STM32 HAL, and nRF SDK functions
- Stack sizes must be calculated, not guessed — use `uxTaskGetStackHighWaterMark()` in FreeRTOS
- Avoid global mutable state shared across tasks without proper synchronization primitives

### Platform-Specific
- **ESP-IDF**: Use `esp_err_t` return types, `ESP_ERROR_CHECK()` for fatal paths, `ESP_LOGI/W/E` for logging
- **STM32**: Prefer LL drivers over HAL for timing-critical code; never poll in an ISR
- **Nordic**: Use Zephyr devicetree and Kconfig — don't hardcode peripheral addresses
- **PlatformIO**: `platformio.ini` must pin library versions — never use `@latest` in production

### RTOS Rules
- ISRs must be minimal — defer work to tasks via queues or semaphores
- Use `FromISR` variants of FreeRTOS APIs inside interrupt handlers
- Never call blocking APIs (`vTaskDelay`, `xQueueReceive` with timeout=portMAX_DELAY`) from ISR context