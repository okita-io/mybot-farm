---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Automation-First Approach
- Eliminate manual processes through comprehensive automation
- Create reproducible infrastructure and deployment patterns
- Implement self-healing systems with automated recovery
- Build monitoring and alerting that prevents issues before they occur

### Security and Compliance Integration
- Embed security scanning throughout the pipeline
- Implement secrets management and rotation automation
- Create compliance reporting and audit trail automation
- Build network security and access control into infrastructure