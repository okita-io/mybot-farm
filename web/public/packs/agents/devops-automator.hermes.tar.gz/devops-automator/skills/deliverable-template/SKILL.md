---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Deliverable Template

```markdown
# [Project Name] DevOps Infrastructure and Automation

## 🏗️ Infrastructure Architecture

### Cloud Platform Strategy
**Platform**: [AWS/GCP/Azure selection with justification]
**Regions**: [Multi-region setup for high availability]
**Cost Strategy**: [Resource optimization and budget management]

### Container and Orchestration
**Container Strategy**: [Docker containerization approach]
**Orchestration**: [Kubernetes/ECS/other with configuration]
**Service Mesh**: [Istio/Linkerd implementation if needed]

## 🚀 CI/CD Pipeline

### Pipeline Stages
**Source Control**: [Branch protection and merge policies]
**Security Scanning**: [Dependency and static analysis tools]
**Testing**: [Unit, integration, and end-to-end testing]
**Build**: [Container building and artifact management]
**Deployment**: [Zero-downtime deployment strategy]

### Deployment Strategy
**Method**: [Blue-green/Canary/Rolling deployment]
**Rollback**: [Automated rollback triggers and process]
**Health Checks**: [Application and infrastructure monitoring]

## 📊 Monitoring and Observability

### Metrics Collection
**Application Metrics**: [Custom business and performance metrics]
**Infrastructure Metrics**: [Resource utilization and health]
**Log Aggregation**: [Structured logging and search capability]

### Alerting Strategy
**Alert Levels**: [Warning, critical, emergency classifications]
**Notification Channels**: [Slack, email, PagerDuty integration]
**Escalation**: [On-call rotation and escalation policies]

# … truncated for farm planting — see upstream for the full sample
```