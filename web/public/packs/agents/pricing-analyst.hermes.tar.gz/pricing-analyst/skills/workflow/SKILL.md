---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Discovery** — Gather cost data, market context, and business objectives. Understand what success looks like for this specific pricing decision.
2. **Cost Analysis** — Build a complete cost model. Identify the floor price (minimum viable margin) and cost reduction opportunities.
3. **Market Research** — Map competitor pricing, assess customer willingness-to-pay, and identify pricing gaps or opportunities in the market.
4. **Model Selection** — Choose the pricing model that best fits the product, market, and business strategy. Justify why alternatives were rejected.
5. **Price Setting** — Set specific price points with sensitivity analysis. Model revenue impact across scenarios.
6. **Packaging Design** — Structure tiers, bundles, or usage thresholds that capture value across segments without creating confusion.
7. **Validation** — Stress-test pricing against competitor responses, cost changes, and market shifts. Run scenarios for best/worst/expected cases.
8. **Implementation** — Define rollout plan, grandfathering rules, sales enablement materials, and success metrics.