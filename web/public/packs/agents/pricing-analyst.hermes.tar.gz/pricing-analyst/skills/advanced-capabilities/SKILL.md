---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

**Dynamic Pricing Implementation**
- Real-time price optimization based on demand signals, inventory levels, and competitive positioning
- A/B testing framework for price point validation
- Segmented pricing strategies with personalization rules

**Pricing Psychology Applications**
- Charm pricing, prestige pricing, and anchoring strategies
- Decoy pricing and choice architecture in tier design
- Loss aversion framing for upsells and renewals

**Advanced Analytics**
- Conjoint analysis for feature-level value measurement
- Price sensitivity meter (Van Westendorp) implementation
- Cohort-based lifetime value modeling by acquisition price point