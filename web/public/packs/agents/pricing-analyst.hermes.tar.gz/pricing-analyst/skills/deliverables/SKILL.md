---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

The Pricing Analysis Framework

Every pricing decision should be grounded in four pillars. Skip one and you're guessing.

#### Pillar 1 — Cost Structure Analysis

Before pricing anything, understand what it actually costs to deliver.
```
COST STRUCTURE BREAKDOWN
├── Direct Costs (COGS)
│   ├── Raw materials / component costs
│   ├── Manufacturing / production labor
│   ├── Packaging and fulfillment
│   └── Third-party services / licensing fees
├── Indirect Costs (Overhead)
│   ├── R&D amortization per unit
│   ├── Customer support cost per user
│   ├── Infrastructure / hosting per unit
│   └── Sales & marketing cost per acquisition
├── Variable vs Fixed Cost Split
│   ├── Variable: scales with volume
│   └── Fixed: stays constant regardless of volume
└── Cost Reduction Opportunities
    ├── Supplier negotiation leverage points
    ├── Scale economies at volume thresholds
    ├── Process optimization targets
    └── Make vs buy decisions
```

**Critical rule**: Never set a price without knowing your fully-loaded unit cost. Contribution margin is non-negotiable — track it per product, per segment, per channel.

#### Pillar 2 — Market & Competitor Analysis

Understand the pricing landscape you're operating in.

**Competitor Pricing Intelligence**
- Direct competitors: exact pricing, packaging, and discount patterns
- Indirect competitors: alternative solutions customers consider
- Substitute products: what the customer does if they buy nothing
- Price positioning map: where each player sits on price vs. perceived value

**Market Dynamics**
- Price sensitivity by segment (run Van Westendorp or Gabor-Granger when possible)
- Willingness-to-pay distribution across customer segments
- Industry pricing norms and buyer expectations
- Regulatory or contractual pricing constraints

#### Pillar 3 — Value-Based Pricing

The most defensible pricing strategy anchors to customer value, not cost-plus.
```
VALUE METRIC IDENTIFICATION
1. What outcome does the customer pay for?
2. How do they measure success with your product?
3. What is the economic value of that outcome to them?
4. What would they pay for the next-best alternative?

PRICE = (Customer's Economic Value) × (Value Capture Ratio)

Value Capture Ratio guidelines:
- New market, no alternatives:     30-50% of value created
- Competitive market:              10-25% of value created
- Commodity market:                 5-15% of value created
- Premium/differentiated:          25-40% of value created
```

#### Pillar 4 — Historical Pricing & Elasticity

Past data reveals how customers actually respond to price changes.

- Price elasticity measurement: % volume change / % price change
- Historical win/loss rates by price point
- Discount frequency and depth analysis (are you training buyers to wait?)
- Seasonal and cyclical pricing patterns
- Cohort analysis: do customers acquired at different price points retain differently?

### Pricing Models & When to Use Them

| Model | Best For | Watch Out For |
|-------|----------|---------------|
| **Cost-Plus** | Commodities, government contracts, simple products | Ignores willingness-to-pay; leaves money on the table |
| **Value-Based** | Differentiated products, B2B SaaS, consulting | Requires deep customer research; harder to implement |
| **Competitive** | Crowded markets, price-sensitive segments | Race to bottom risk; assumes competitors priced correctly |
| **Dynamic** | Perishable inventory, marketplace, travel | Customer trust issues; needs real-time data infrastructure |
| **Freemium** | PLG SaaS, consumer apps, network-effect products | Conversion rate risk; free tier cannibalization |
| **Tiered/Usage** | SaaS, APIs, cloud services | Tier boundary friction; overage bill shock |
| **Penetration** | New market entry, land-and-expand strategy | Must have credible path to price increases |
| **Skimming** | Innovative products, luxury, early adopter capture | Invites competition; narrow window before commoditization |

### Pricing Strategy Document Template
```markdown
# Pricing Strategy: [Product/Service Name]

## Executive Summary
- Recommended price point(s) and rationale
- Expected revenue impact vs current pricing
- Key risks and mitigation strategies

## Cost Analysis
- Fully-loaded unit cost: $X
- Target contribution margin: Y%
- Break-even volume: Z units

## Market Context
- Competitor pricing range: $low - $high
- Our positioning: [premium/competitive/value]
- Price sensitivity assessment: [high/medium/low]…