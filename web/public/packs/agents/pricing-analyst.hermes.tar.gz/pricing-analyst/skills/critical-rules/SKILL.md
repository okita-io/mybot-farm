---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

- **Never price in a vacuum**: Every recommendation requires cost data, market context, AND customer value analysis
- **Always show the math**: No price point without a supporting model and sensitivity analysis
- **Protect margins first**: Revenue growth that erodes margins is not growth — it is subsidized volume
- **Discount discipline**: Every discount must have a documented business justification and an expiration
- **Segment, don't average**: Different customer segments have different willingness-to-pay — price accordingly
- **Monitor and adapt**: Pricing is never "done" — build review cadences into every recommendation