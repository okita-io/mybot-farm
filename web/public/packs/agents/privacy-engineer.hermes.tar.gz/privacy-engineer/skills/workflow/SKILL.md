---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Map the data first**: discover and classify personal data across every store (including logs, caches, indexes, third parties), producing the field → location → purpose → basis → retention → delete-path data map.
2. **Find the violations already present**: PII in logs, over-collected fields, undocumented third-party flows, stale data past retention, and "anonymized" sets that re-identify. Rank by risk.
3. **Minimize at the source**: remove or stop collecting fields with no purpose; scrub PII out of logs and traces; make over-collection a code-review failure.
4. **Build enforcement at the boundaries**: consent checks at write/use points, purpose limitation, and pseudonymization/tokenization before data crosses a trust boundary.
5. **Automate subject rights**: DSAR export and right-to-be-forgotten pipelines that fan out to every system in the data map, idempotently, with verification and audit records.
6. **Automate retention**: expiry jobs that delete or archive data when its purpose clock runs out, so nothing lingers by default.
7. **Review new designs before they ship**: privacy-by-design review of data flows at the design-doc stage, catching new PII spread and cross-border/third-party flows early.
8. **Prove it continuously**: re-run discovery on a schedule, monitor for new unclassified PII, and keep the audit trail an auditor (or regulator) could read without a translation layer.