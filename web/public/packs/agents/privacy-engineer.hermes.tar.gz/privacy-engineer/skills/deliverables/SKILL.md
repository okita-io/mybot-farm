---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

PII Discovery & Classification (find it before you protect it)

```text
Scan EVERY store, not just the obvious databases:
  primary DBs · read replicas · warehouses/lakes · search indexes · caches (Redis)
  message queues · object storage · application + access LOGS · error/trace data
  analytics event streams · backups · third-party systems (via DPA inventory)

Classify each field by sensitivity and purpose:
  direct identifiers   → name, email, phone, SSN, device id      (highest control)
  quasi-identifiers    → zip, birthdate, gender, job title        (re-identification risk!)
  sensitive categories → health, biometric, financial, location   (special-category rules)
  → output a DATA MAP: field → store(s) → purpose → legal basis → retention → delete path
This map is the source of truth every other control depends on. Regenerate it on a schedule;
free-text and log fields drift and quietly start holding PII nobody classified.
```

### Consent Enforced at the Write Path (not just stored)

```python
# WRONG: consent is recorded but never checked — the analytics write happens anyway
def track_event(user, event):
    analytics.write(user.id, event)   # ships regardless of the user's choice = violation

# RIGHT: the enforcement point gates the operation on purpose-specific consent
def track_event(user, event):
    if not consent.has(user.id, purpose="analytics"):
        return  # the opt-out actually blocks the write, at the point it matters
    # pseudonymize before the data leaves our trust boundary for the vendor
    analytics.write(pseudonymize(user.id), event)

# Consent is purpose-scoped and versioned: "marketing", "analytics", "personalization"
# are separate grants, each with a timestamp and the policy version it was given under.
```

### Right-to-Be-Forgotten Pipeline (distributed, proven)

```text
Deletion request for user U → orchestrated fan-out, tracked to completion:
  1. Resolve every location of U's data from the DATA MAP (not a guess)
  2. Dispatch delete to each system as an idempotent, retried job:
       primary DB · replicas · warehouse · search index · cache · queues
       third parties (via their deletion API + DPA obligation)
       backups → tombstone + delete-on-restore policy (per retention rules)
  3. Each system ACKs completion; the orchestrator tracks partial progress
  4. Verify: re-query the identifiers; a follow-up scan confirms nothing remains
  5. Emit an audit record: what was deleted, from where, when, request-to-done SLA
Legal basis exceptions (e.g. financial records you must retain) are documented and
excluded explicitly, not silently skipped — the record shows what was kept and why.
```

### Anonymization vs Pseudonymization (know which you actually have)

| Technique | Reversible? | Re-identification risk | Use when |
|-----------|-------------|------------------------|----------|
| Pseudonymization (tokenize id, keep mapping) | Yes, with the key | Real if mapping leaks — still "personal data" under GDPR | Internal processing where you may need to re-link |
| Encryption | Yes, with the key | Protected at rest/in transit; key management is everything | Storage and transport of PII you must keep usable |
| Aggregation / k-anonymity | No | Low if k and quasi-identifiers are handled | Reporting, dashboards, sharing group-level stats |
| Differential privacy | No | Provably bounded by the privacy budget | Statistics/ML over sensitive data with a formal guarantee |
| "Removed the name" | No | HIGH — quasi-identifiers re-identify | Never call this anonymized; test it first |