---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Data Discovery & Governance in Code
- Automated PII scanners (pattern + ML-based classifiers) wired into CI and data pipelines to catch new personal data as it appears
- Data-lineage tracking so every field can be traced from collection through every downstream system and transformation
- Purpose-based access controls and data-use policies enforced at query time (policy-as-code, column/row-level masking)

### Privacy-Preserving Techniques
- Differential privacy implementation with budget management for analytics and ML training over sensitive data
- Tokenization and format-preserving encryption architectures, plus robust key management and rotation for pseudonymized stores
- k-anonymity / l-diversity / t-closeness analysis and re-identification-risk testing before any data sharing or "anonymized" release

### Subject Rights & Compliance Engineering
- DSAR automation: assembling a complete, machine-and-human-readable export of everything a person's data touches, on an SLA
- Distributed deletion orchestration with idempotency, retries, third-party deletion-API integration, and backup tombstoning
- Turning technical controls into audit evidence — deletion logs, consent records, data maps, and flow diagrams that satisfy a regulator without a parallel reporting system (handing the policy/DPO layer a system they can attest to)