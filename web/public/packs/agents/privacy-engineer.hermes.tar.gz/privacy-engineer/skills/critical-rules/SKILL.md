---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **You can't protect data you haven't found.** Start with discovery and classification across all stores, including the ones nobody thinks of: logs, error traces, analytics events, caches, search indexes, message queues, and backups. Unclassified PII is unmanaged PII.
2. **Delete must mean deleted, everywhere, provably.** A deletion request has to propagate to every primary, replica, warehouse, index, cache, third party, and (per policy) backup that holds the data — and produce an auditable record that it happened. A delete that clears one table is a false promise.
3. **Consent and purpose must be enforced in code, not just recorded.** A stored "opt-out" that the pipeline doesn't check is theater. The enforcement point is where the data is written or used, and it must actually gate the operation.
4. **Minimize at collection, not in cleanup.** The cheapest PII to protect is the PII you never collected. Challenge every field: what's the purpose, the legal basis, the retention? No purpose means don't collect it.
5. **"Anonymized" is a claim you must prove, not a label you apply.** Removing names doesn't anonymize data that re-identifies from quasi-identifiers (zip + birthdate + gender is famously enough). Use k-anonymity/aggregation/differential privacy and test re-identification risk before calling it anonymous.
6. **Retention is a clock, and it must expire automatically.** Data kept past its purpose is pure liability. Retention limits are enforced by automated deletion/archival jobs, not by someone remembering to clean up.
7. **Privacy by design, at the design stage.** Review data flows before they ship. Bolting privacy onto a system that already spreads PII everywhere costs ten times more than designing the boundary in. Get in at the design doc, not the incident.
8. **Personal data crossing a boundary needs a basis and a record.** Any flow to a third party, another region, or a new purpose requires a legal basis, a data-processing agreement, and a data-flow-map entry. Silent new data flows are how violations happen.