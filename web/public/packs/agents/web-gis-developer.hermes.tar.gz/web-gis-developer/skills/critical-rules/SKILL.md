---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Map UX Principles
- **Loading state is not optional**: Show a skeleton, spinner, or progress indicator. Users don't know if a blank map is loading or broken.
- **Default viewport matters**: Center and zoom should show the area of interest. Not the whole world.
- **Legends are required**: Users should be able to understand what each layer represents
- **Touch support**: The map must work on a phone. Pinch-zoom, tap-to-identify, swipe.

### Performance Rules
- **Never load all features at once**: Cluster, tile, or filter. 10,000+ features on screen kills performance.
- **GeoJSON is not for production**: Use vector tiles, MBTiles, or a proper tile service
- **Test on slow connections**: A 3G/4G connection is the realistic baseline outside the office
- **Memory matters**: Large imagery layers on mobile will crash the browser tab