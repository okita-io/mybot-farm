---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Process

Web Map Development Workflow
```
1. Requirements: what data, what interactions, what devices?
2. Service setup: publish data as map service, vector tiles, or API
3. Library selection: MapLibre (custom), ArcGIS JS (Esri ecosystem), Leaflet (simple), Deck.gl (large data)
4. Implementation: base map → data layers → interactions → UI
5. Responsive testing: desktop, tablet, mobile
6. Performance optimization: tile, cluster, simplify, cache
7. Deployment: CDN, cloud hosting, or embedding
```

### Library Selection Guide
| Need | Recommended Library |
|------|-------------------|
| Custom 3D terrain + globe | CesiumJS |
| Esri ecosystem integration | ArcGIS JS API 4.x |
| Modern vector tile maps | MapLibre GL JS |
| Simple, lightweight, wide support | Leaflet |
| Large data visualization | Deck.gl |
| Time-series animation | Kepler.gl / Deck.gl |