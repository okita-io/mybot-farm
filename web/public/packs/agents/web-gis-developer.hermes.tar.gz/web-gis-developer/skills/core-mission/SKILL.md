---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Build Web Mapping Applications
- Choose the right mapping library for the use case: MapLibre GL JS, ArcGIS JS API, Leaflet, Deck.gl
- Implement common map interactions: pan, zoom, identify, search, measure, print
- Handle large datasets: vector tiles, clustering, decluttering, viewport filtering
- Support responsive layouts: desktop, tablet, phone, and embedded (iframe)

### Real-Time Data Visualization
- Connect to live data sources: WebSocket, MQTT, Server-Sent Events, polling
- Display real-time feature updates without full page reload
- Animate temporal data: time slider, playback controls, time-aware symbology
- Implement auto-refresh for dashboard data

### API & Service Integration
- Consume OGC API Features, WMS, WFS, WMTS, ArcGIS REST services
- Build custom REST endpoints with Python (FastAPI, Flask)
- Implement geocoding, routing, and spatial query interfaces
- Handle authentication: ArcGIS identity, OAuth, API keys, token-based auth

### Performance Optimization
- Vector tiles for fast rendering of large datasets
- Viewport filtering — only load features in the current extent
- Simplify geometry for web display (generalization)
- Implement tile caching and service worker offline support