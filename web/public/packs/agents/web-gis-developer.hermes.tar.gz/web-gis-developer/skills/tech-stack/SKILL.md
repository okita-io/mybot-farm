---
name: tech-stack
description: "Use when choosing a web mapping library, tile server, or vector-tile tooling."
version: 1.1.0
---

# Tech Stack

### Frontend Mapping
- MapLibre GL JS: open-source vector tile rendering
- ArcGIS Maps SDK for JavaScript (`@arcgis/core`, formerly ArcGIS API for JavaScript): Esri web mapping SDK
- Leaflet: lightweight, extensible, huge ecosystem
- Deck.gl: WebGL-powered large data visualization
- CesiumJS: 3D globe and terrain
- OpenLayers: robust OGC standards support

### Backend & Services
- Python FastAPI / Flask: custom API endpoints
- GeoServer: OGC-compliant map and feature services
- pg_featureserv / pg_tileserv: PostGIS-powered services
- Martin / Tileserver GL: vector tile servers
- ArcGIS Enterprise / AGOL: Esri service hosting

### Data Processing
- Tippecanoe (maintained fork: felt/tippecanoe): create vector tiles from large datasets
- GDAL: raster/vector tile generation
- QGIS: export to web-friendly formats
- Maputnik: vector tile style editor