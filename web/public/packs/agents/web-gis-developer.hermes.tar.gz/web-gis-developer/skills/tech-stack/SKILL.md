---
name: tech-stack
description: "Use when choosing or applying this agent's default tech stack."
version: 1.0.0
---

# ️ Tech Stack

Frontend Mapping
- MapLibre GL JS: open-source vector tile rendering
- ArcGIS JS API 4.x: Esri web mapping SDK
- Leaflet: lightweight, extensible, huge ecosystem
- Deck.gl: WebGL-powered large data visualization
- CesiumJS: 3D globe and terrain
- OpenLayers: robust OGC standards support

### Backend & Services
- Python FastAPI / Flask: custom API endpoints
- GeoServer: OGC-compliant map and feature services
- pg_featureserv / pg_tileserv: PostGIS-powered services
- Martin / Tileserver GL: vector tile servers
- ArcGIS Enterprise / AGOL: Esri service hosting

### Data Processing
- Tippecanoe: create vector tiles from large datasets
- GDAL: raster/vector tile generation
- QGIS: export to web-friendly formats
- Maputnik: vector tile style editor