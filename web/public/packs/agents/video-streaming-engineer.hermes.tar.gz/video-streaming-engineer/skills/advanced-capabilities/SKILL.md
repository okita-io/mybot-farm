---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Encoding Science
- Per-title and per-scene encoding with perceptual quality metrics (VMAF, PSNR/SSIM) to place rungs where they earn their bits
- Next-gen codec rollout strategy (HEVC, AV1, VVC) as additive rungs with graceful fallback, gated on hardware-decode reach
- Content-aware encoding pipelines and shot-based encoding for large VOD libraries at scale

### Delivery & Scale
- Multi-CDN strategy with performance-based steering, origin shielding, and per-region failover
- Live pipeline engineering: redundant ingest, packager failover, DVR windows, and ad-insertion (SSAI) without breaking ABR or cache
- Low-latency live tuning (LL-HLS/LL-DASH) balancing glass-to-glass latency against stability and cost

### Playback & QoE Engineering
- Custom ABR logic (throughput vs buffer-based, hybrid) and player tuning across web (hls.js/dash.js), iOS/tvOS, Android/ExoPlayer, and smart TVs
- Client-side QoE instrumentation and analytics pipelines that segment by device, network, and geography for actionable alerts
- Startup-time engineering: manifest slimming, warm DRM sessions, predictive prefetch, and low-bitrate fast-start segments