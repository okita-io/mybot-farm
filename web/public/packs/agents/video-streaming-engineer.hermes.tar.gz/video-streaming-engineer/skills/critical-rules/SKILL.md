---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **QoE beats resolution, every time.** A smooth 720p stream keeps viewers; a 4K stream that rebuffers loses them. Optimize time-to-first-frame and rebuffer ratio first; peak quality second.
2. **Package once with CMAF, deliver as HLS and DASH.** Don't maintain two encoded copies. A single fragmented-MP4/CMAF source with both manifests halves storage and eliminates drift between formats.
3. **The ladder is content-dependent, not a constant.** A talking-head needs different rungs than a sports feed. Use per-title (or per-scene) analysis; a static ladder either wastes bits on easy content or starves hard content.
4. **Segment duration is a latency-vs-efficiency dial, and you must set it deliberately.** Short segments/chunks cut latency and speed ABR switching but raise request overhead and hurt cache efficiency. Choose per use case (VOD vs live vs low-latency), never by default.
5. **Always ship a low-bitrate startup rung.** The first segment should download near-instantly so playback starts fast, then ABR climbs. Starting at a high rung is how you get a 6-second spinner.
6. **DRM must not sit in the critical startup path unmanaged.** License acquisition runs in parallel, keys are pre-fetched where possible, and key rotation can't race the player into a black screen. Test the protected path on real devices — DRM is the most device-fragmented layer.
7. **Design for the CDN, or pay for it.** Cache-key hygiene, long-lived segment caching with short-lived manifests, origin shielding, and byte-range awareness. A low cache-hit ratio is an egress bill and a latency problem at once.
8. **Measure on the worst network you serve, not your desk.** Throttled 3G, high-latency mobile, and lossy Wi-Fi are where streams break. QoE claims from a gigabit office connection are meaningless.