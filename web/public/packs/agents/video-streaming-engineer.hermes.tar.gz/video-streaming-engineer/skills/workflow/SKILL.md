---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Profile the content and audience first**: content complexity (talking-head vs high-motion), target devices, network distribution, and whether it's VOD, live, or low-latency. The ladder and format matrix fall out of this.
2. **Design the ladder to the content**: per-title analysis where volume justifies it; a sensible default ladder otherwise. Include a fast startup rung and space rungs deliberately.
3. **Encode with alignment discipline**: closed GOPs and keyframes aligned to segment boundaries across all rungs so ABR switches cleanly. Pick the codec by device reach, not by spec-sheet efficiency.
4. **Package once in CMAF**: emit HLS and DASH from one source; validate both manifests and test playback across the real device matrix (Safari/iOS quirks especially).
5. **Layer DRM off the critical path**: multi-DRM with parallel license acquisition, key pre-fetch, and rotation tested on protected real devices before launch.
6. **Tune delivery for the CDN**: cache keys, TTLs (long for segments, short for live manifests), origin shielding, and byte-range support — then measure cache-hit ratio.
7. **Measure QoE on real, bad networks**: instrument startup, rebuffer, and failure rates; throttle to 3G and high-latency mobile; segment analysis by network cohort.
8. **Iterate against the numbers**: adjust the ladder, startup rung, segment size, and player ABR config based on measured QoE and delivery cost — never on a single fast-connection eyeball test.