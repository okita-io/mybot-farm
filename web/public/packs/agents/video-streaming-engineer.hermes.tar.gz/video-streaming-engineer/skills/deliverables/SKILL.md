---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

ffmpeg Transcode Ladder → CMAF (package once)

```bash
# Encode a multi-rung ladder with aligned keyframes (GOP) so ABR can switch
# cleanly at segment boundaries. Keyframe interval = segment duration * fps.
ffmpeg -i source.mov \
  -filter_complex "[0:v]split=4[v1][v2][v3][v4]; \
    [v1]scale=w=640:h=360[v360]; [v2]scale=w=1280:h=720[v720]; \
    [v3]scale=w=1920:h=1080[v1080]; [v4]scale=w=2560:h=1440[v1440]" \
  -map "[v360]"  -c:v:0 libx264 -b:v:0 800k   -maxrate:0 856k   -bufsize:0 1200k \
  -map "[v720]"  -c:v:1 libx264 -b:v:1 2800k  -maxrate:1 2996k  -bufsize:1 4200k \
  -map "[v1080]" -c:v:2 libx264 -b:v:2 5000k  -maxrate:2 5350k  -bufsize:2 7500k \
  -map "[v1440]" -c:v:3 libx264 -b:v:3 8000k  -maxrate:3 8560k  -bufsize:3 12000k \
  -x264-params "keyint=48:min-keyint=48:scenecut=0" \  # closed GOP, 2s @ 24fps, aligned across rungs
  -map a:0 -c:a aac -b:a 128k \
  -f null -   # (real pipeline pipes to a CMAF packager; keyframe alignment is the point here)

# Package the encoded renditions ONCE into CMAF, emitting both HLS + DASH manifests:
packager \
  in=v360.mp4,stream=video,init_segment=v360/init.mp4,segment_template='v360/$Number$.m4s' \
  in=v720.mp4,stream=video,init_segment=v720/init.mp4,segment_template='v720/$Number$.m4s' \
  in=audio.mp4,stream=audio,init_segment=a/init.mp4,segment_template='a/$Number$.m4s' \
  --hls_master_playlist_output master.m3u8 \
  --mpd_output manifest.mpd \
  --segment_duration 2
```

### Bitrate Ladder Design (per-title beats one-size)

| Rung | Resolution | Bitrate | Role |
|------|-----------|---------|------|
| 1 | 640×360 | ~0.8 Mbps | Startup rung + congested-network floor (fast first frame) |
| 2 | 1280×720 | ~2.8 Mbps | The workhorse — most sessions live here on mobile/Wi-Fi |
| 3 | 1920×1080 | ~5.0 Mbps | Good broadband default |
| 4 | 2560×1440 | ~8.0 Mbps | Large screens on strong connections |

Rules: rungs spaced ~1.5–2× apart (too close wastes storage and confuses ABR; too far causes jarring quality jumps). Per-title analysis shifts these — a cartoon or slide deck needs far fewer bits than a snow-filled ski run for the same perceived quality. Add rungs only where the audience's devices and networks can use them.

### Latency Tier Decision Table

| Use case | Segment/chunk | Protocol | Target latency | Trade-off accepted |
|----------|--------------|----------|----------------|-------------------|
| VOD | 4–6s segments | HLS/DASH | Startup-optimized, latency irrelevant | Best cache efficiency, cheapest delivery |
| Standard live | 2–4s segments | HLS/DASH | 15–30s glass-to-glass | Simple, robust, cache-friendly |
| Low-latency live | CMAF chunks (~0.2–0.5s) in 2s segments | LL-HLS / LL-DASH | 2–6s | More requests, tighter tuning, higher cost |
| Real-time/interactive | sub-second | WebRTC | < 1s | Different stack entirely; ABR + scale are harder |

### QoE Metrics That Actually Matter

```text
Track per session, segment by segment — these predict engagement, not resolution:
  · Time-to-first-frame (startup delay)   → target < 1s; this is churn-at-the-door
  · Rebuffer ratio (stall time / watch time) → target < 0.5%; the #1 abandonment driver
  · Play-failure rate (never started)     → often DRM, manifest, or codec-support bugs
  · Average bitrate delivered + switch freq → quality without excessive oscillation
  · Exit-before-video-start rate          → the startup path is too slow or broken
Alert on the worst-network cohort, not the average — the average hides the users you're losing.
```