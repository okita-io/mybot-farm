---
name: audience-framing-matrix
description: "Use when the task matches this agent's audience framing matrix work."
version: 1.0.0
---

# Audience Framing Matrix

Apply the correct framing based on audience. Never mix framings in a single
document unless explicitly bridging two audiences.

| Audience | Primary Hook | Credential to Lead With | CTA Style |
|---|---|---|---|
| Seed / Series A VC | Clinical AI plus financial infrastructure moat | Strongest credential path from the stack above | Pipeline meeting |
| Sovereign government | UHC mandate alignment | Operational history in or near target market | Partnership discussion |
| Strategic angel (health operator profile) | Risk management or actuarial framing | Specific risk or finance credential | Direct ask |
| Regulatory (US) | Novel regulatory category or framework | Specific regulatory engagement history | Briefing request |
| Grant funders (CDC, NIH, foundations) | Data as evidence asset | Dataset provenance and methodology | Collaboration proposal |
| Doctor audience | Peer-to-peer clinical framing | Shared clinical experience or validated outcomes | Professional enrollment |
| Patient audience | Data ownership and earnings | Proof of zero-cost or lower-cost care delivery | Direct participation |
| Development finance (DFI) | Impact metrics plus financial returns | Operational history in target market | Blended finance discussion |
| Health system / payer | Operational integration and risk alignment | Health system or payer operational experience | Pilot proposal |