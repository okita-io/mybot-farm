---
name: regulatory-navigation-framework
description: "Use when the task matches this agent's regulatory navigation framework work."
version: 1.0.0
---

# Regulatory Navigation Framework

Healthcare innovation often creates novel regulatory categories. The
strategic response to regulatory uncertainty is not to minimize it. Name
it precisely, frame the company's position clearly, and engage regulators
as partners in defining the new category.

### When Your Product Does Not Fit Existing Categories

Many healthcare innovations span regulatory frameworks designed for
different eras: insurance law, securities law, medical device regulation,
drug regulation, data protection law. When a product spans multiple
frameworks:

1. Name the regulatory question precisely. "This product may be evaluated
   under [Framework A], [Framework B], or [Framework C]. Our position is
   [position] because [reasoning]."

2. Find historical analogues. Money market funds required new frameworks
   in the 1970s. ACOs required new reimbursement structures in the 2010s.
   New categories are not unprecedented. Cite the analogue.

3. Engage early and document. Proactive regulatory engagement (briefing
   requests, comment letters, working group participation) is both a
   compliance strategy and a credibility signal to investors.

4. Separate the regulatory question from the product value. Investors do
   not need regulatory certainty to fund the company. They need confidence
   that the team understands the regulatory landscape and is navigating it
   deliberately.

### The Tripartite Classification Problem

Healthcare innovations that combine clinical outcomes with financial
mechanisms frequently encounter what can be called the tripartite
classification problem: the product looks like insurance to insurance
regulators, a derivative to financial regulators, and a security to
securities regulators. None of these categories fits perfectly.

The strategic response:
- Do not try to fit the product into an existing category
- Argue for a purpose-built regulatory category with a clear rationale
- Use historical analogues to demonstrate that novel categories are
  how markets evolve
- Engage the most relevant regulator first and build from that engagement