---
name: narrative-architecture-framework
description: "Use when the task matches this agent's narrative architecture framework work."
version: 1.0.0
---

# Narrative Architecture Framework

The Integrated Thesis

Every healthcare innovation company needs one thesis that works across
all audiences. The thesis is not a tagline. It is the answer to:
"Why does this exist, why now, and why can this team deliver it?"

A strong integrated thesis has three components:

**The Problem (clinical and financial simultaneously)**
State the problem in a way that is specific enough to be credible and
broad enough to be important. Avoid generic problem statements. Use
specific evidence: a cost figure, an outcome gap, a structural
misalignment. The best problem statements come from direct experience,
whether clinical, operational, or financial.

**The Mechanism (why the solution works)**
Explain the mechanism of action, not just the output. Investors and
regulators who understand healthcare will ask "why does this work?" before
they ask "what does this do?" The mechanism should connect to the founding
team's specific experience directly.

**The Evidence (validated, not projected)**
Lead with what has been validated, not what is projected. A small, specific,
validated proof point is worth more than a large projected TAM. If you have
operational data, use it. If you have clinical outcomes, cite them with
methodology. If you have financial validation, show the unit economics.
Reserve projections for a clearly labeled forward-looking section.

### The Multi-Market Framing

Healthcare innovation increasingly requires simultaneous framing for
multiple market contexts: regulated markets (US, EU, UK), sovereign health
mandate markets (emerging economies with UHC obligations), and institutional
markets (health systems, payers, academic medical centers). These are
different audiences with different decision criteria, but they reinforce
each other:

- Regulated market validation strengthens credibility in sovereign markets
- Sovereign market scale strengthens the growth narrative in regulated markets
- Institutional market adoption provides clinical validation for both

The multi-market framing works when the underlying product genuinely serves
multiple contexts. It fails when it is forced. If your product only works
in one market, say so and make the case for why that market is sufficient.

Never optimize the narrative for one market at the expense of another when
both are genuine target markets.

### The Credential Anchor Protocol

Every investor memo, regulatory brief, or partner proposal should anchor
to a specific credential in the first paragraph. Not a biography. A single
specific fact that establishes why this team can solve this problem.

Good credential anchors:
- "I spent [X] years managing [specific patient population] with [specific
  clinical challenge]: that is where I first saw this gap."
- "Our team managed [specific dollar amount] in [specific risk program]:
  that actuarial experience is the foundation of how we designed the
  financial model."
- "We have operated a [clinic / telemedicine program / community health
  network] in [specific market] since [year]: that is where we first
  validated this approach."
- "Our dataset of [N] real-world encounters, validated by licensed
  physicians and published in [journal], is the evidence base for
  every outcomes claim we make."

Bad credential anchors:
- "With decades of experience in healthcare..." (too vague)
- "Our team has a passion for improving patient outcomes..." (no credential)
- "We saw an opportunity in the [X] billion dollar healthcare market..." (no credibility)