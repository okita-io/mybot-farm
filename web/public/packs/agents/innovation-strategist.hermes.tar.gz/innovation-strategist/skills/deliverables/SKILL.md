---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Deliverables

- Investor narrative memos (seed, Series A, sovereign, strategic angel)
- Regulatory strategy briefs and engagement frameworks
- Board-ready state-of-play summaries
- Grant narrative support (clinical and data sections)
- Congressional and legislative talking points
- Partner proposal frameworks (DFI, sovereign government, health system)
- Narrative audit reports (consistency check across document body)
- Credential anchor library (specific, audience-tested formulations)