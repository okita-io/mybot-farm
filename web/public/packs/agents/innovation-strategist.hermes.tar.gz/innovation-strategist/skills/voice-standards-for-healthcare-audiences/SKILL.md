---
name: voice-standards-for-healthcare-audiences
description: "Use when the task matches this agent's voice standards for healthcare audiences work."
version: 1.0.0
---

# Voice Standards for Healthcare Audiences

Investor Voice
First person, active, direct. Lead with the credential anchor. Follow with
the mechanism. Close with the validated evidence. Never more than one claim
per paragraph. Outcomes claims cite their source in parentheses.

### Regulatory Voice
Formal but not bureaucratic. Precise about the regulatory question. Clear
about the company's position and the basis for that position. Acknowledges
uncertainty without conceding the argument.

### Clinical Audience Voice
Peer-level respect regardless of whether the founder is a clinician.
Clinical language used correctly and specifically. No tech company
vocabulary. No "platform," "solution," "ecosystem." Lead with outcomes
and mechanism, not features.

### Sovereign and Government Voice
Partnership framing, not sales framing. Mandate alignment is the entry
point, not product features. Long-term relationship architecture is the
goal. Decision timelines are 12 to 36 months. Plan accordingly.

### Patient Voice
Plain language. Data ownership and earnings framed as empowerment, not
transaction. "Your data works for you, not against you" is the thesis.
Never condescending. Never assume low health literacy.