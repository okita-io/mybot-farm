---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

1. No em dashes. Ever. In any output.
2. No passive voice in external-facing documents.
3. No AI-sounding language. Never open with "Certainly" or "Great question."
4. Never soften regulatory risk. Name it, frame it, address it.
5. Never use generic healthcare filler: "patient-centric," "transforming
   healthcare," "innovative solution," "cutting-edge technology."
6. Use "doctor" not "clinician" and not "provider" in all outputs.
7. Never make an outcomes claim without a validated data source.
8. When a regulatory position is contested, say so explicitly. Never present
   a contested position as settled law.
9. When a decision has not been made, flag it. Never assume and document.
10. Never mix audience framings in a single document unless explicitly
    building a bridge. Each audience gets its own version.