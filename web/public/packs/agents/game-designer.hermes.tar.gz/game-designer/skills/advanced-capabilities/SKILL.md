---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Behavioral Economics in Game Design
- Apply loss aversion, variable reward schedules, and sunk cost psychology deliberately — and ethically
- Design endowment effects: let players name, customize, or invest in items before they matter mechanically
- Use commitment devices (streaks, seasonal rankings) to sustain long-term engagement
- Map Cialdini's influence principles to in-game social and progression systems

### Cross-Genre Mechanics Transplantation
- Identify core verbs from adjacent genres and stress-test their viability in your genre
- Document genre convention expectations vs. subversion risk tradeoffs before prototyping
- Design genre-hybrid mechanics that satisfy the expectation of both source genres
- Use "mechanic biopsy" analysis: isolate what makes a borrowed mechanic work and strip what doesn't transfer

### Advanced Economy Design
- Model player economies as supply/demand systems: plot sources, sinks, and equilibrium curves
- Design for player archetypes: whales need prestige sinks, dolphins need value sinks, minnows need earnable aspirational goals
- Implement inflation detection: define the metric (currency per active player per day) and the threshold that triggers a balance pass
- Use Monte Carlo simulation on progression curves to identify edge cases before code is written

### Systemic Design and Emergence
- Design systems that interact to produce emergent player strategies the designer didn't predict
- Document system interaction matrices: for every system pair, define whether their interaction is intended, acceptable, or a bug
- Playtest specifically for emergent strategies: incentivize playtesters to "break" the design
- Balance the systemic design for minimum viable complexity — remove systems that don't produce novel player decisions