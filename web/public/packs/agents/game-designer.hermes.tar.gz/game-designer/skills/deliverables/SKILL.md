---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Core Gameplay Loop Document
```markdown
# Core Loop: [Game Title]

## Moment-to-Moment (0–30 seconds)
- **Action**: Player performs [X]
- **Feedback**: Immediate [visual/audio/haptic] response
- **Reward**: [Resource/progression/intrinsic satisfaction]

## Session Loop (5–30 minutes)
- **Goal**: Complete [objective] to unlock [reward]
- **Tension**: [Risk or resource pressure]
- **Resolution**: [Win/fail state and consequence]

## Long-Term Loop (hours–weeks)
- **Progression**: [Unlock tree / meta-progression]
- **Retention Hook**: [Daily reward / seasonal content / social loop]
```

### Economy Balance Spreadsheet Template
```
Variable          | Base Value | Min | Max | Tuning Notes
------------------|------------|-----|-----|-------------------
Player HP         | 100        | 50  | 200 | Scales with level
Enemy Damage      | 15         | 5   | 40  | [PLACEHOLDER] - test at level 5
Resource Drop %   | 0.25       | 0.1 | 0.6 | Adjust per difficulty
Ability Cooldown  | 8s         | 3s  | 15s | Feel test: does 8s feel punishing?
```

### Player Onboarding Flow
```markdown
## Onboarding Checklist
- [ ] Core verb introduced within 30 seconds of first control
- [ ] First success guaranteed — no failure possible in tutorial beat 1
- [ ] Each new mechanic introduced in a safe, low-stakes context
- [ ] Player discovers at least one mechanic through exploration (not text)
- [ ] First session ends on a hook — cliff-hanger, unlock, or "one more" trigger
```

### Mechanic Specification
```markdown
## Mechanic: [Name]

**Purpose**: Why this mechanic exists in the game
**Player Fantasy**: What power/emotion this delivers
**Input**: [Button / trigger / timer / event]
**Output**: [State change / resource change / world change]
**Success Condition**: [What "working correctly" looks like]
**Failure State**: [What happens when it goes wrong]
**Edge Cases**:
  - What if [X] happens simultaneously?
  - What if the player has [max/min] resource?
**Tuning Levers**: [List of variables that control feel/balance]
**Dependencies**: [Other systems this touches]
```