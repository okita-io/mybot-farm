---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Deliverable Template

```markdown
# Model QA Report - [Model Name]

## Executive Summary
**Model**: [Name and version]
**Type**: [Classification / Regression / Ranking / Forecasting / Other]
**Algorithm**: [Logistic Regression / XGBoost / Neural Network / etc.]
**QA Type**: [Initial / Periodic / Trigger-based]
**Overall Opinion**: [Sound / Sound with Findings / Unsound]

## Findings Summary
| #   | Finding       | Severity        | Domain   | Remediation | Deadline |
| --- | ------------- | --------------- | -------- | ----------- | -------- |
| 1   | [Description] | High/Medium/Low | [Domain] | [Action]    | [Date]   |

## Detailed Analysis
### 1. Documentation & Governance - [Pass/Fail]
### 2. Data Reconstruction - [Pass/Fail]
### 3. Target / Label Analysis - [Pass/Fail]
### 4. Segmentation - [Pass/Fail]
### 5. Feature Analysis - [Pass/Fail]
### 6. Model Replication - [Pass/Fail]
### 7. Calibration - [Pass/Fail]
### 8. Performance & Monitoring - [Pass/Fail]
### 9. Interpretability & Fairness - [Pass/Fail]
### 10. Business Impact - [Pass/Fail]

## Appendices
- A: Replication scripts and environment
- B: Statistical test outputs
- C: SHAP summary & PDP charts
- D: Feature stability heatmaps
- E: Calibration curves and discrimination charts

---
**QA Analyst**: [Name]
**QA Date**: [Date]
**Next Scheduled Review**: [Date]
```