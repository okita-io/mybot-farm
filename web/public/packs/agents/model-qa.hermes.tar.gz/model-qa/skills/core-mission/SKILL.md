---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

1. Documentation & Governance Review
- Verify existence and sufficiency of methodology documentation for full model replication
- Validate data pipeline documentation and confirm consistency with methodology
- Assess approval/modification controls and alignment with governance requirements
- Verify monitoring framework existence and adequacy
- Confirm model inventory, classification, and lifecycle tracking

### 2. Data Reconstruction & Quality
- Reconstruct and replicate the modeling population: volume trends, coverage, and exclusions
- Evaluate filtered/excluded records and their stability
- Analyze business exceptions and overrides: existence, volume, and stability
- Validate data extraction and transformation logic against documentation

### 3. Target / Label Analysis
- Analyze label distribution and validate definition components
- Assess label stability across time windows and cohorts
- Evaluate labeling quality for supervised models (noise, leakage, consistency)
- Validate observation and outcome windows (where applicable)

### 4. Segmentation & Cohort Assessment
- Verify segment materiality and inter-segment heterogeneity
- Analyze coherence of model combinations across subpopulations
- Test segment boundary stability over time

### 5. Feature Analysis & Engineering
- Replicate feature selection and transformation procedures
- Analyze feature distributions, monthly stability, and missing value patterns
- Compute Population Stability Index (PSI) per feature
- Perform bivariate and multivariate selection analysis
- Validate feature transformations, encoding, and binning logic
- **Interpretability deep-dive**: SHAP value analysis and Partial Dependence Plots for feature behavior

### 6. Model Replication & Construction
- Replicate train/validation/test sample selection and validate partitioning logic
- Reproduce model training pipeline from documented specifications
- Compare replicated outputs vs. original (parameter deltas, score distributions)
- Propose challenger models as independent benchmarks
- **Default requirement**: Every replication must produce a reproducible script and a delta report against the original

### 7. Calibration Testing
- Validate probability calibration with statistical tests (Hosmer-Lemeshow, Brier, reliability diagrams)
- Assess calibration stability across subpopulations and time windows
- Evaluate calibration under distribution shift and stress scenarios

### 8. Performance & Monitoring
- Analyze model performance across subpopulations and business drivers
- Track discrimination metrics (Gini, KS, AUC, F1, RMSE - as appropriate) across all data splits
- Evaluate model parsimony, feature importance stability, and granularity
- Perform ongoing monitoring on holdout and production populations
- Benchmark proposed model vs. incumbent production model
- Assess decision threshold: precision, recall, specificity, and downstream impact

### 9. Interpretability & Fairness
- Global interpretability: SHAP summary plots, Partial Dependence Plots, feature importance rankings
- Local interpretability: SHAP waterfall / force plots for individual predictions
- Fairness audit across protected characteristics (demographic parity, equalized odds)
- Interaction detection: SHAP interaction values for feature dependency analysis

### 10. Business Impact & Communication
- Verify all model uses are documented and change impacts are reported
- Quantify economic impact of model changes
- Produce audit report with severity-rated findings
- Verify evidence of result communication to stakeholders and governance bodies