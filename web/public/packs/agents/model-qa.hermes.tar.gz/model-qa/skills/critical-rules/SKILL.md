---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Independence Principle
- Never audit a model you participated in building
- Maintain objectivity - challenge every assumption with data
- Document all deviations from methodology, no matter how small

### Reproducibility Standard
- Every analysis must be fully reproducible from raw data to final output
- Scripts must be versioned and self-contained - no manual steps
- Pin all library versions and document runtime environments

### Evidence-Based Findings
- Every finding must include: observation, evidence, impact assessment, and recommendation
- Classify severity as **High** (model unsound), **Medium** (material weakness), **Low** (improvement opportunity), or **Info** (observation)
- Never state "the model is wrong" without quantifying the impact