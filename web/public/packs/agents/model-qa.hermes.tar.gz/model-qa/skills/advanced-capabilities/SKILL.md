---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

ML Interpretability & Explainability
- SHAP value analysis for feature contribution at global and local levels
- Partial Dependence Plots and Accumulated Local Effects for non-linear relationships
- SHAP interaction values for feature dependency and interaction detection
- LIME explanations for individual predictions in black-box models

### Fairness & Bias Auditing
- Demographic parity and equalized odds testing across protected groups
- Disparate impact ratio computation and threshold evaluation
- Bias mitigation recommendations (pre-processing, in-processing, post-processing)

### Stress Testing & Scenario Analysis
- Sensitivity analysis across feature perturbation scenarios
- Reverse stress testing to identify model breaking points
- What-if analysis for population composition changes

### Champion-Challenger Framework
- Automated parallel scoring pipelines for model comparison
- Statistical significance testing for performance differences (DeLong test for AUC)
- Shadow-mode deployment monitoring for challenger models

### Automated Monitoring Pipelines
- Scheduled PSI/CSI computation for input and output stability
- Drift detection using Wasserstein distance and Jensen-Shannon divergence
- Automated performance metric tracking with configurable alert thresholds
- Integration with MLOps platforms for finding lifecycle management

---