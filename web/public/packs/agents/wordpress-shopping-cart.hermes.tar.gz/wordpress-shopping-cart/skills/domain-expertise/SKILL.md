---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

WooCommerce Architecture

- **Core Data Model**: products (`WC_Product` types), `WC_Cart`, `WC_Order`, `WC_Customer`, and High-Performance Order Storage (HPOS / custom order tables)
- **Hook System**: the action/filter model, key hooks across cart/checkout/order, and `template_redirect`/`woocommerce_*` lifecycle hooks
- **Payment Gateway API**: extending `WC_Payment_Gateway`, `process_payment()`, `process_refund()`, and the `WC_Payment_Tokens` API for saved cards/SCA
- **Checkout Blocks & Store API**: the block-based checkout, Store API endpoints, and the supported extensibility points (vs. legacy shortcode checkout)
- **Tax Engine**: tax classes, `WC_Tax`, rate tables, and inclusive/exclusive calculation
- **Coupon Engine**: `WC_Coupon`, discount types, validation hooks, and restriction logic
- **Stock Management**: `wc_update_product_stock()`, stock status, holds, and oversell prevention

### Platform & Stack

- **WordPress**: hooks, the plugin/child-theme model, `wp-config.php`, WP-CLI, the REST API, and the block editor
- **PHP**: modern PHP practices, WooCommerce/WordPress coding standards, and writing update-safe plugins
- **Build & Deploy**: child themes, custom plugins, Composer where used, and staging→production workflows
- **Hosting**: WP Engine, Kinsta, Pressable, Cloudways — and object/page caching, CDN, and cache-exclusion rules for commerce pages
- **Performance**: Core Web Vitals, query optimization, autoload bloat, and caching that respects dynamic cart state

### Payment Gateways

- **WooPayments / Stripe**: hosted Payment Element, SCA/3DS, webhooks, saved cards, and instant payouts
- **PayPal**: PayPal Payments (Checkout), IPN/webhooks, and reference transactions
- **Square, Authorize.Net, Braintree**: official and contrib gateway plugins and their capture/refund/void semantics
- **PCI Scope**: hosted fields/redirect (SAQ A) vs. direct card fields (SAQ A-EP) and the compliance trade-off

### Standards & Operations

- **PCI-DSS**: minimizing scope, never storing card numbers, and tokenization
- **Order Reconciliation**: matching WooCommerce orders to gateway payout/settlement reports
- **Accessibility**: WCAG-compliant checkout forms, labels, and error messaging
- **Conversion Rate Optimization**: checkout friction reduction, trust signals, and mobile-first funnels

---