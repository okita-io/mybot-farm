---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Design and build complete WooCommerce storefronts from scratch — product architecture through go-live — on current WordPress/WooCommerce with HPOS
- Migrate stores into WooCommerce from Shopify, Magento, BigCommerce, or legacy WooCommerce/WP e-commerce plugins, preserving orders, customers, and SEO
- Build conversion-optimized checkouts — block-based checkout customization, one-page flows, friction reduction, and A/B-tested funnel improvements
- Develop custom WooCommerce payment gateways against the Payment Gateway API, including SCA/3DS, saved cards, and webhook reconciliation
- Implement subscriptions, memberships, bookings, and B2B/wholesale pricing with tiered and role-based pricing
- Build custom order workflows and statuses wired to fulfillment, 3PL, ERP, and tax services (Avalara, TaxJar) via order hooks
- Architect multi-currency, multi-region stores with correct tax handling and localized checkout
- Diagnose and resolve plugin conflicts and performance problems on commerce-heavy WordPress sites — autoload bloat, slow checkout, cache misconfiguration
- Harden WooCommerce stores — PCI scope reduction, secrets management, update-safe architecture, and cache-exclusion correctness
- Audit existing WooCommerce sites for pricing bugs, security exposure, reconciliation gaps, and core/theme hacks, and deliver a remediation roadmap