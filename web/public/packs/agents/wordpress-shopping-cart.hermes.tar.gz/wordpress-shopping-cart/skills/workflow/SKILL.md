---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Discovery & Product Modeling

1. **Pick the right product type per item** — simple vs. variable vs. subscription; don't overcomplicate
2. **Define attributes before generating variations** — they drive the variation matrix and SKUs
3. **Decide stock management early** — managed vs. unmanaged, and when stock reduces
4. **Set tax mode up front** — inclusive vs. exclusive pricing changes every displayed price
5. **Audit the plugin stack** — know what already touches cart, checkout, and payment

### Step 2: Cart & Checkout Construction

1. **Default to block checkout** — use Store API extensibility, not DOM hacks
2. **Add custom fields the documented way** — saved to order meta, shown in admin + emails
3. **Validate server-side and fail gracefully** — never let a custom field silently block checkout
4. **Test on real devices** — mobile Safari, slow networks, autofill, back button
5. **Reduce friction** — fewer fields, fast load, clear errors; instrument the funnel

### Step 3: Payment Integration

1. **Start in sandbox with the real gateway** — never mock payment away entirely
2. **Implement the full operation set** — authorize, capture, void, refund (partial too)
3. **Make webhooks first-class** — verified, idempotent, logged via WC_Logger
4. **Reconcile against payout reports** — prove WooCommerce matches the gateway
5. **Run the go-live checklist** — keys, mode, webhook, receipt, test+refund

### Step 4: Tax, Coupons & Orders

1. **Configure tax in WooCommerce settings, never hard-code rates**
2. **Build coupons with explicit, documented stacking rules**
3. **Define order statuses to match real fulfillment** — including failure states
4. **Wire order hooks** — emails, fulfillment, ERP/3PL, analytics events
5. **Test edge cases** — partial refunds, cancelled orders, expired/over-limit coupons

### Step 5: Performance, Hardening & Deployment

1. **Exclude cart/checkout/account from full-page cache** — and verify on the live CDN
2. **Optimize for conversion** — Core Web Vitals, image sizes, minimal checkout friction
3. **Secure the store** — keys out of the DB, plugins/core current, gateway mode verified
4. **Stage and test the full purchase path** — then deploy with a tested rollback
5. **Reconcile post-launch** — first live orders matched to gateway payouts

---