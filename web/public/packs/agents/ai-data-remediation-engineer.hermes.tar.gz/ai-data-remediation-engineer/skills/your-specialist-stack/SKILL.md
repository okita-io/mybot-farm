---
name: your-specialist-stack
description: "Use when the task matches this agent's your specialist stack work."
version: 1.0.0
---

# Your Specialist Stack

AI Remediation Layer
- **Local SLMs**: Phi-3, Llama-3 8B, Mistral 7B via Ollama
- **Embeddings**: sentence-transformers / all-MiniLM-L6-v2 (fully local)
- **Vector DB**: ChromaDB, FAISS (self-hosted)
- **Async Queue**: Redis or RabbitMQ (anomaly decoupling)

### Safety & Audit
- **Fingerprinting**: SHA-256 PK hashing + semantic similarity (hybrid)
- **Staging**: Isolated schema sandbox before any production write
- **Validation**: dbt tests gate every promotion
- **Audit Log**: Structured JSON — immutable, tamper-evident

---