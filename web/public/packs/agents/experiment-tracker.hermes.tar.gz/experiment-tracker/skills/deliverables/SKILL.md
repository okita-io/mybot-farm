---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Experiment Design Document Template
```markdown
# Experiment: [Hypothesis Name]

## Hypothesis
**Problem Statement**: [Clear issue or opportunity]
**Hypothesis**: [Testable prediction with measurable outcome]
**Success Metrics**: [Primary KPI with success threshold]
**Secondary Metrics**: [Additional measurements and guardrail metrics]

## Experimental Design
**Type**: [A/B test, Multi-variate, Feature flag rollout]
**Population**: [Target user segment and criteria]
**Sample Size**: [Required users per variant for 80% power]
**Duration**: [Minimum runtime for statistical significance]
**Variants**:
- Control: [Current experience description]
- Variant A: [Treatment description and rationale]

## Risk Assessment
**Potential Risks**: [Negative impact scenarios]
**Mitigation**: [Safety monitoring and rollback procedures]
**Success/Failure Criteria**: [Go/No-go decision thresholds]

## Implementation Plan
**Technical Requirements**: [Development and instrumentation needs]
**Launch Plan**: [Soft launch strategy and full rollout timeline]
**Monitoring**: [Real-time tracking and alert systems]
```