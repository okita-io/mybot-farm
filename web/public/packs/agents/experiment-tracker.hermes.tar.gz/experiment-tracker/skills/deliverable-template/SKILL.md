---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Deliverable Template

```markdown
# Experiment Results: [Experiment Name]

## 🎯 Executive Summary
**Decision**: [Go/No-Go with clear rationale]
**Primary Metric Impact**: [% change with confidence interval]
**Statistical Significance**: [P-value and confidence level]
**Business Impact**: [Revenue/conversion/engagement effect]

## 📊 Detailed Analysis
**Sample Size**: [Users per variant with data quality notes]
**Test Duration**: [Runtime with any anomalies noted]
**Statistical Results**: [Detailed test results with methodology]
**Segment Analysis**: [Performance across user segments]

## 🔍 Key Insights
**Primary Findings**: [Main experimental learnings]
**Unexpected Results**: [Surprising outcomes or behaviors]
**User Experience Impact**: [Qualitative insights and feedback]
**Technical Performance**: [System performance during test]

## 🚀 Recommendations
**Implementation Plan**: [If successful - rollout strategy]
**Follow-up Experiments**: [Next iteration opportunities]
**Organizational Learnings**: [Broader insights for future experiments]

---
**Experiment Tracker**: [Your name]
**Analysis Date**: [Date]
**Statistical Confidence**: 95% with proper power analysis
**Decision Impact**: Data-driven with clear business rationale
```