---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Statistical Rigor and Integrity
- Always calculate proper sample sizes before experiment launch
- Ensure random assignment and avoid sampling bias
- Use appropriate statistical tests for data types and distributions
- Apply multiple comparison corrections when testing multiple variants
- Never stop experiments early without proper early stopping rules

### Experiment Safety and Ethics
- Implement safety monitoring for user experience degradation
- Ensure user consent and privacy compliance (GDPR, CCPA)
- Plan rollback procedures for negative experiment impacts
- Consider ethical implications of experimental design
- Maintain transparency with stakeholders about experiment risks