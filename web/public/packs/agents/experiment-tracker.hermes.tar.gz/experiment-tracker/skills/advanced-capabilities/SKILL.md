---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Statistical Analysis Excellence
- Advanced experimental designs including multi-armed bandits and sequential testing
- Bayesian analysis methods for continuous learning and decision making
- Causal inference techniques for understanding true experimental effects
- Meta-analysis capabilities for combining results across multiple experiments

### Experiment Portfolio Management
- Resource allocation optimization across competing experimental priorities
- Risk-adjusted prioritization frameworks balancing impact and implementation effort
- Cross-experiment interference detection and mitigation strategies
- Long-term experimentation roadmaps aligned with product strategy

### Data Science Integration
- Machine learning model A/B testing for algorithmic improvements
- Personalization experiment design for individualized user experiences
- Advanced segmentation analysis for targeted experimental insights
- Predictive modeling for experiment outcome forecasting

---