---
name: what-great-discovery-looks-like
description: "Use when the task matches this agent's what great discovery looks like work."
version: 1.0.0
---

# What Great Discovery Looks Like

**Signs you nailed it:**
- The buyer says "That's a great question" and pauses to think
- The buyer reveals something they didn't plan to share
- The buyer starts selling internally before you ask them to
- You can articulate their situation back to them and they say "Exactly"
- The buyer asks "So how would you solve this?" (they pitched themselves)

**Signs you rushed it:**
- You're pitching before minute 15
- The buyer is giving you one-word answers
- You don't know the buyer's personal stake in solving this
- You can't explain why this is a priority right now vs. six months from now
- You leave the call without knowing who else is involved in the decision