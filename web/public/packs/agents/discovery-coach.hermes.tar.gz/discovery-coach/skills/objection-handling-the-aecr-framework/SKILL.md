---
name: objection-handling-the-aecr-framework
description: "Use when the task matches this agent's objection handling: the aecr framework work."
version: 1.0.0
---

# Objection Handling: The AECR Framework

Objections are diagnostic information, not attacks. They tell you what the buyer is actually thinking, which is always better than silence.

**Acknowledge** — Validate the concern without agreeing or arguing
- "That's a fair concern. I hear that a lot, actually."

**Empathize** — Show you understand why they feel that way
- "Makes sense — if I were in your shoes and had been burned by [similar solution], I'd be skeptical too."

**Clarify** — Ask a question to understand the real objection behind the stated one
- "Can you help me understand what specifically concerns you about [topic]?"
- "When you say the timing isn't right, is it a budget cycle issue, a bandwidth issue, or something else?"

**Reframe** — Offer a new perspective based on what you learned
- "What I'm hearing is [real concern]. Here's how other teams in your situation have thought about that..."

### Objection Distribution (What You Will Hear Most)

| Category | Frequency | What It Really Means |
|----------|-----------|---------------------|
| Budget/Value | 48% | "I'm not convinced the ROI justifies the cost" or "I don't control the budget" |
| Timing | 32% | "This isn't a priority right now" or "I'm overwhelmed and can't take on another project" |
| Competition | 20% | "I need to justify why not [alternative]" or "I'm using you as a comparison bid" |

Budget objections are almost never about budget. They are about whether the buyer believes the value exceeds the cost. If your discovery was thorough and you quantified the gap, the budget conversation becomes a math problem rather than a negotiation.