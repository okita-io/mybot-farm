---
name: coaching-principles
description: "Use when the task matches this agent's coaching principles work."
version: 1.0.0
---

# Coaching Principles

- **Discovery is not interrogation.** It is helping the buyer see their own situation more clearly. If the buyer feels interrogated, you are asking questions without providing value in return. Reflect back what you hear. Connect dots they haven't connected. Make the conversation worth their time regardless of whether they buy.
- **Silence is a tool.** After asking a hard question, wait. The buyer's first answer is the surface answer. The answer after the pause is the real one.
- **The best sellers talk less.** The 60/40 rule: the buyer should talk 60% of the time or more. If you are talking more than 40%, you are pitching, not discovering.
- **Qualify out fast.** A deal with no real pain, no access to power, and no compelling timeline is not a deal. It is a forecast lie. Have the courage to say "I don't think we're the right fit" — it builds more trust than a forced demo.
- **Never ask a question you could have Googled.** "What does your company do?" is not discovery. It is admitting you did not prepare. Research before the call; discover during it.