---
name: elite-discovery-call-structure
description: "Use when the task matches this agent's elite discovery call structure work."
version: 1.0.0
---

# Elite Discovery Call Structure

The 30-minute discovery call, architected for maximum insight:

### Opening (2 minutes): Set the Upfront Contract

The upfront contract is the single highest-leverage technique in modern selling. It eliminates ambiguity, builds trust, and gives you permission to ask hard questions.

```
"Thanks for making time. Here's what I was thinking for our 30 minutes:

 I'd love to ask some questions to understand what's going on in
 your world and whether there's a fit. You should ask me anything
 you want — I'll be direct.

 At the end, one of three things will happen: we'll both see a fit
 and schedule a next step, we'll realize this isn't the right
 solution and I'll tell you that honestly, or we'll need more
 information before we can decide. Any of those outcomes is fine.

 Does that work for you? Anything you'd add to the agenda?"
```

This accomplishes four things: sets the agenda, gets time agreement, establishes permission to ask tough questions, and normalizes a "no" outcome (which paradoxically makes "yes" more likely).

### Discovery Phase (18 minutes): 60-70% on Current State and Pain

**Spend the majority here.** The most common mistake in discovery is rushing past pain to get to the pitch. You are not ready to pitch until you can articulate the buyer's situation back to them better than they described it.

**Opening territory question:**
- "What prompted you to take this call?" (for inbound)
- "When I reached out, I mentioned [signal]. Can you tell me what's happening on your end with [topic]?" (for outbound)

**Then follow the signal.** Use SPIN, Gap, or Sandler depending on what emerges. Your job is to understand:

1. **What is broken?** (Problem) — stated in their words
2. **Why is it broken?** (Root cause) — the real reason, not the symptom
3. **What does it cost?** (Impact) — in dollars, time, risk, or people
4. **Who else cares?** (Stakeholder map) — who else feels this pain
5. **Why now?** (Trigger) — what changed that makes this a priority today
6. **What happens if they do nothing?** (Cost of inaction) — the status quo has a price

### Tailored Pitch (6 minutes): Only What Is Relevant

After — and only after — you understand the buyer's situation, present your solution mapped directly to their stated problems. Not a product tour. Not your standard deck. A targeted response to what they just told you.

```
"Based on what you described — [restate their problem in their words] —
here's specifically how we address that..."
```

Limit to 2-3 capabilities that directly map to their pain. Resist the urge to show everything your product can do. Relevance beats comprehensiveness.

### Next Steps (4 minutes): Be Explicit

- Define exactly what happens next (who does what, by when)
- Identify who else needs to be involved and why
- Set the next meeting before ending this one
- Agree on what a "no" looks like so neither side wastes time