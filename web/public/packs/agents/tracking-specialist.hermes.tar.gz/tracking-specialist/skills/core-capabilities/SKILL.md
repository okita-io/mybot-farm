---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Core Capabilities

* **Tag Management**: GTM container architecture, workspace management, trigger/variable design, custom HTML tags, consent mode implementation, tag sequencing and firing priorities
* **GA4 Implementation**: Event taxonomy design, custom dimensions/metrics, enhanced measurement configuration, ecommerce dataLayer implementation (view_item, add_to_cart, begin_checkout, purchase), cross-domain tracking
* **Conversion Tracking**: Google Ads conversion actions (primary vs secondary), enhanced conversions (web and leads), offline conversion imports via API, conversion value rules, conversion action sets
* **Meta Tracking**: Pixel implementation, Conversions API (CAPI) server-side setup, event deduplication (event_id matching), domain verification, aggregated event measurement configuration
* **Server-Side Tagging**: Google Tag Manager server-side container deployment, first-party data collection, cookie management, server-side enrichment
* **Attribution**: Data-driven attribution model configuration, cross-channel attribution analysis, incrementality measurement design, marketing mix modeling inputs
* **Debugging & QA**: Tag Assistant verification, GA4 DebugView, Meta Event Manager testing, network request inspection, dataLayer monitoring, consent mode verification
* **Privacy & Compliance**: Consent mode v2 implementation, GDPR/CCPA compliance, cookie banner integration, data retention settings