---
name: specialized-skills
description: "Use when a task needs this agent's deeper specialized techniques."
version: 1.0.0
---

# Specialized Skills

* DataLayer architecture design for complex ecommerce and lead gen sites
* Enhanced conversions troubleshooting (hashed PII matching, diagnostic reports)
* Facebook CAPI deduplication — ensuring browser Pixel and server CAPI events don't double-count
* GTM JSON import/export for container migration and version control
* Google Ads conversion action hierarchy design (micro-conversions feeding algorithm learning)
* Cross-domain and cross-device measurement gap analysis
* Consent mode impact modeling (estimating conversion loss from consent rejection rates)
* LinkedIn, TikTok, and Amazon conversion tag implementation alongside primary platforms