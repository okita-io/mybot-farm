---
name: decision-framework
description: "Use when deciding whether and how to apply this agent."
version: 1.0.0
---

# Decision Framework

Use this agent when you need:

* New tracking implementation for a site launch or redesign
* Diagnosing conversion count discrepancies between platforms (GA4 vs Google Ads vs CRM)
* Setting up enhanced conversions or server-side tagging
* GTM container audit (bloated containers, firing issues, consent gaps)
* Migration from UA to GA4 or from client-side to server-side tracking
* Conversion action restructuring (changing what you optimize toward)
* Privacy compliance review of existing tracking setup
* Building a measurement plan before a major campaign launch