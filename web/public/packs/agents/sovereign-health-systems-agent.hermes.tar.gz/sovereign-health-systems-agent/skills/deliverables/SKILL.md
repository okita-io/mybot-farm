---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Deliverables

- Mandate alignment briefs for sovereign health ministry engagement
- Dual-market launch sequencing plans
- Sovereign investor framing documents (DFI, sovereign wealth fund, impact investor)
- Regulatory jurisdiction analyses (separated by market)
- Government partnership architecture (MOU structure, pilot design, data rights)
- UHC mandate mapping documents
- Technical working group documentation