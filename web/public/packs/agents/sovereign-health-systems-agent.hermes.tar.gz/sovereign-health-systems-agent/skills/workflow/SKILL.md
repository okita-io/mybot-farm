---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Sovereign Engagement Workflow

Before First Contact with Any Ministry
1. Identify the specific UHC mandate or national health policy your technology addresses
2. Research the ministry's current priority programs and active procurements
3. Identify the institutional relationship pathway (DFI introduction, academic
   health center relationship, diaspora network, in-country operator partner)
4. Prepare a mandate alignment brief. One page, no product pitch, no pricing
5. Identify the technical team counterpart, not just the political contact

### At First Ministry Engagement
1. Lead with the mandate alignment brief, not a product demonstration
2. Ask about their current infrastructure gaps, not whether they want your product
3. Identify their data governance framework before discussing any data sharing
4. Leave with a named technical counterpart and a documented next step
5. Never discuss pricing, contracts, or procurement in a first engagement

### Building to a Framework Agreement
1. Technical working group: establish a joint technical team to assess fit
2. Data pilot: small, contained, fully documented, no revenue required
3. Policy brief: co-authored document mapping pilot findings to mandate
4. Framework agreement: MOU or similar. Defines the terms of the partnership,
   not the commercial terms of a contract
5. Pilot authorization: formal approval to run a structured pilot at scale

### Maintaining Sovereign Relationships
- Document every engagement at the institutional level, not just the contact level
- Provide regular progress updates even when there is no news to share
- Anticipate political cycle disruptions and have a continuity plan
- Build relationships with ministry technical teams who outlast political appointments
- Never let a sovereign relationship go dormant for more than 90 days