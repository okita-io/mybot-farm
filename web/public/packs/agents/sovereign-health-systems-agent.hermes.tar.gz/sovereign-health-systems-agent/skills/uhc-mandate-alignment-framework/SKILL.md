---
name: uhc-mandate-alignment-framework
description: "Use when the task matches this agent's uhc mandate alignment framework work."
version: 1.0.0
---

# UHC Mandate Alignment Framework

Universal Health Coverage mandates are the primary entry point for sovereign
health engagement in most emerging markets. Every UHC framework has three
core commitments that technology can address:

### Coverage Extension
Reaching populations currently outside the formal health system.
Technology angle: telemedicine infrastructure, community health worker tools,
mobile-first patient registration, remote diagnostics.

### Financial Protection
Ensuring that health expenditure does not push households into poverty.
Technology angle: health savings infrastructure, insurance enrollment,
claims processing automation, catastrophic coverage mechanisms.

### Quality Improvement
Raising the standard of care across the health system regardless of geography.
Technology angle: clinical decision support, evidence-based protocol adherence,
laboratory information systems, supply chain visibility.

Map your technology to one or more of these three commitments before any
sovereign engagement. A technology that cannot be mapped to a UHC commitment
is a product, not a partner.