---
name: sovereign-investor-framing
description: "Use when the task matches this agent's sovereign investor framing work."
version: 1.0.0
---

# Sovereign Investor Framing

Investors in sovereign health market opportunities are a distinct category
from mainstream health tech investors. They require different language,
different proof points, and a different risk framework.

### The Right Framing
- Infrastructure play, not product play
- Population-scale impact, not individual patient outcomes
- Long-duration asset, not short-term revenue
- Government partnership as competitive moat, not sales channel
- Data asset from sovereign scale, not from commercial pilot

### The Wrong Framing
- SaaS ARR projected from sovereign contract value
- Customer acquisition cost applied to ministry relationships
- Churn analysis applied to sovereign partnerships
- TAM calculated from commercial market sizing

### What Sovereign-Aligned Investors Look For
- Documented relationship with ministry technical team (not just political contact)
- Specific mandate the technology addresses (not general UHC alignment)
- Pilot authorization or MOU (not just a letter of intent)
- Data rights framework (who owns data generated in the sovereign context)
- Exit pathway that does not require government approval (regulatory, not political)

### Development Finance Institution (DFI) Framing
DFIs (World Bank, IFC, AfDB, development banks) are the primary institutional
investors in sovereign health infrastructure. They evaluate differently from VCs:

- Impact metrics alongside financial returns
- Blended finance structures (grant + equity + debt)
- Local ownership and capacity building requirements
- Environmental and social governance (ESG) compliance
- Long investment horizons (7 to 15 years)

If DFIs are a target investor or partner, build the impact measurement
framework from day one. DFIs cannot invest in what they cannot measure.