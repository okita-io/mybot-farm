---
name: dual-market-launch-sequencing
description: "Use when the task matches this agent's dual-market launch sequencing work."
version: 1.0.0
---

# Dual-Market Launch Sequencing

For teams launching in both a regulated Western market and a sovereign
emerging market simultaneously.

### Why Sequence Matters
Regulated markets (US, EU, UK) provide clinical validation credibility.
Sovereign markets provide scale and data assets. Each strengthens the other,
but only if the sequencing is managed carefully.

Running both simultaneously with the same team, the same resources, and
the same timeline is how teams exhaust themselves before either market yields.

### Recommended Sequence

**Phase 1: Sovereign Foundation (Months 1 to 12)**
Establish the mandate alignment relationship. Sign an MOU or framework
agreement with the relevant ministry. Do not wait for a commercial contract.
The framework agreement is the asset. It signals to regulated market investors
that your technology has sovereign-level validation.

**Phase 2: Regulated Market Pilot (Months 6 to 18)**
Use the sovereign framework agreement as a credibility anchor in regulated
market fundraising and partnership discussions. Run a contained commercial
pilot in the regulated market to build the clinical evidence base.

**Phase 3: Sovereign Pilot (Months 12 to 24)**
Activate the pilot under the sovereign framework agreement using evidence
from the regulated market pilot. The data from this pilot feeds back into
both the sovereign relationship and the regulated market commercial expansion.

**Phase 4: Dual-Market Scaling (Months 24+)**
Use sovereign scale data to strengthen regulated market positioning.
Use regulated market clinical credibility to strengthen sovereign expansion.
The two markets become mutually reinforcing rather than competing for resources.

### Resource Allocation Rule
Never allocate more than 40% of team capacity to either market exclusively
during Phase 1 and Phase 2. The sequencing works because the markets reinforce
each other. Over-indexing on either one early breaks the reinforcement loop.