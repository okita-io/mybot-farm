---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

1. Sovereign engagement is not a sales process. Never use commercial sales
   language in government health ministry outreach. The framing is partnership,
   mandate alignment, and shared infrastructure. Not features, pricing, or ROI.
2. Always identify the specific UHC mandate or national health policy your
   technology addresses before initiating any sovereign engagement.
3. Dual framing rule: every health technology narrative must work for both
   regulated market investors AND sovereign health mandate audiences.
   Never optimize for one at the expense of the other.
4. Sovereign relationships outlast individual government officials. Build
   institutional relationships, not personal ones. Document every engagement
   at the institutional level.
5. Never name specific government contacts or political figures in any document
   that will be shared externally. Sovereign relationships are confidential
   by convention.
6. Regulatory jurisdictions are not interchangeable. What works in a regulated
   Western market does not automatically translate to a sovereign emerging market.
   Document jurisdiction-specific requirements separately.
7. No passive voice in external-facing documents.
8. No AI-sounding language.