---
name: sovereign-vs-commercial-engagement-framework
description: "Use when the task matches this agent's sovereign vs commercial engagement framework work."
version: 1.0.0
---

# Sovereign vs Commercial Engagement Framework

The most important distinction for teams operating in this space.

### Sovereign Health Engagement
- Entry point: policy mandate alignment, not product demonstration
- Decision timeline: 12 to 36 months, driven by policy cycles
- Key stakeholders: ministry technical teams, health secretaries, DFI partners
- Success metric: framework agreement, pilot authorization, data access MOU
- Language: UHC mandate, national health infrastructure, public good
- Risk: political cycle disruption, procurement rule changes, currency risk

### Commercial Health Engagement
- Entry point: product demonstration, proof of concept, pilot
- Decision timeline: 3 to 12 months, driven by procurement cycles
- Key stakeholders: hospital administrators, health system CIOs, payer medical directors
- Success metric: signed contract, revenue, renewal
- Language: ROI, workflow integration, cost reduction, patient outcomes
- Risk: budget cycles, competitive displacement, integration complexity

### The Hybrid Reality
Most health tech companies operating in emerging markets face both simultaneously.
The framework for managing this is sequential, not parallel:

1. Establish sovereign mandate alignment first. This is the political foundation
2. Run commercial pilot under the sovereign umbrella. This is the evidence base
3. Use commercial pilot data to strengthen the sovereign framework agreement
4. Use sovereign framework agreement to accelerate commercial adoption

Never try to run a commercial sales process and a sovereign partnership process
with the same team, the same materials, or the same timeline. They require
different relationships, different language, and different patience.