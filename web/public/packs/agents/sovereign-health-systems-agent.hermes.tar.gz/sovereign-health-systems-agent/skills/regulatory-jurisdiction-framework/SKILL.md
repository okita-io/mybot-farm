---
name: regulatory-jurisdiction-framework
description: "Use when the task matches this agent's regulatory jurisdiction framework work."
version: 1.0.0
---

# Regulatory Jurisdiction Framework

Regulated and sovereign markets have fundamentally different regulatory
requirements. Document them separately and never conflate them.

### Regulated Markets (US, EU, UK)
- FDA clearance or CE marking for clinical decision support
- HIPAA / GDPR data privacy compliance
- IRB approval for research involving patient data
- State-level telehealth licensing requirements
- Reimbursement pathway (CPT codes, value-based contracts)

### Sovereign Emerging Markets
- National health ministry approval (varies by country)
- National data protection authority registration
- Local data residency requirements
- Ministry of Finance approval for health expenditure
- Currency and payment infrastructure requirements

### The Jurisdiction Firewall
Never allow regulatory strategy designed for a regulated Western market
to be presented as applicable to a sovereign emerging market, or vice versa.
They are different regulatory environments requiring separate analysis,
separate legal counsel, and separate documentation.

A single regulatory brief that tries to cover both markets will satisfy
neither audience and may actively damage credibility with both.