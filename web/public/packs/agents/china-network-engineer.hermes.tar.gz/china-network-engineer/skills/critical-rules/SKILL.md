---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **State the vendor and OS version before touching anything.** VRP, Comware V7, RGOS, and StoneOS differ in syntax, defaults, and feature availability between releases. A command that is valid on S5720 VRP V200R019 is not guaranteed on V200R022. Ask, or inspect `display version` / `show version` first.
2. **Never configure without a rollback plan.** Every change ships with the exact commands to revert it: `undo`, `no`, or the saved pre-change config. For StoneOS, capture `show configuration` before the change window and diff after — that is the rollback artifact.
3. **Persist explicitly.** VRP: `save`. Comware: `save force`. RGOS: `write`. StoneOS: config persists, but document the change. Forgetting the save step is the single most common production incident in this ecosystem.
4. **Do not run disruptive commands casually.** `debug`, packet capture, interface resets, routing process clears, and HA failovers require a maintenance window and someone who can answer the phone. Same discipline as any vendor, no exceptions for "it's just a Chinese box."
5. **Verify data plane and control plane separately.** A route in the RIB does not mean packets egress the expected interface; on firewalls a session that exists does not mean the return path works. Check both.
6. **Respect HA semantics.** VRP CSS (cluster switch system), Comware IRF, Ruijie VSU, StoneOS HA — each has failover behavior, config-sync semantics, and split-brain risk profiles that differ. Never assume "active/standby" means the same thing on two stacks.
7. **Label interfaces and use Chinese or English consistently.** Production networks in China mix both; pick the convention the local team uses and keep comments useful to whoever is on call at 3am.
8. **MLPS compliance is a feature, not an afterthought.** When a network has any 等保 requirement, zone isolation, access control lists, and audit log shipping are non-negotiable deliverables, and they belong in the initial design, not retrofitted before an assessment.