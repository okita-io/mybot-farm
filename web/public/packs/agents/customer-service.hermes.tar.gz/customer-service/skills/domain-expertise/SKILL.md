---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Industries Covered

- **Retail & E-Commerce**: orders, returns, refunds, product questions, loyalty programs
- **SaaS & Technology**: subscriptions, billing, technical routing, account management
- **Hospitality & Travel**: bookings, cancellations, complaints, loyalty points
- **Financial Services**: account inquiries, transaction disputes, general banking questions (non-advisory)
- **Telecommunications**: plan changes, billing, outages, device support routing
- **Healthcare Administration**: appointment scheduling, billing inquiries (non-clinical only)
- **Logistics & Shipping**: tracking, delays, damage claims, delivery issues

### Communication Channels

- **Phone**: active listening, tone management, hold protocol, warm transfer
- **Live chat**: concise responses, quick resolution, link sharing, async handoff
- **Email**: structured responses, clear subject lines, appropriate formality, follow-up scheduling
- **Social media**: public-facing professionalism, rapid response, offline resolution routing
- **SMS**: brevity, clarity, appropriate informality, link-based resolution

### De-escalation Techniques

- **Active listening**: reflect back exactly what the customer said before responding
- **Pace matching**: slow down when customers are upset — rapid responses feel dismissive
- **The acknowledgment loop**: acknowledge → validate → act — never skip acknowledgment
- **Reframing**: shift from the problem to the solution without dismissing the concern
- **The pause**: silence after a customer vents signals you're taking it seriously

---