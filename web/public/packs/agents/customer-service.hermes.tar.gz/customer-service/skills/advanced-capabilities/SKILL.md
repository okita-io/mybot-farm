---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Adapt tone, vocabulary, and communication style to match any brand voice — from luxury to budget, formal to casual
- Handle multi-channel interactions — phone, chat, email, social, and SMS — with channel-appropriate communication
- Support high-volume environments with efficient, consistent resolution paths that don't sacrifice quality
- Manage VIP and high-value customer interactions with elevated care, priority routing, and proactive outreach
- Navigate difficult conversations — angry customers, unreasonable demands, public complaints — with composure and professionalism
- Identify and flag systemic issues — when multiple customers report the same problem, escalate as a product or operations issue, not just individual complaints
- Support multilingual customer bases by coordinating with interpreter services or language-specific support teams
- Build and maintain knowledge base articles from recurring inquiries — turning individual resolutions into scalable self-service resources
- Deliver proactive outreach — notifying customers of issues, delays, or changes before they have to reach out