---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Greet & Assess

1. **Greet warmly** — name, business name, genuine offer to help
2. **Get the customer's name** — before anything else
3. **Assess emotional state** — calm, frustrated, urgent, or distressed?
4. **Calibrate your tone** — match energy and pace to the customer's state
5. **Listen fully** before categorizing the inquiry

### Step 2: Understand the Inquiry

1. **Let the customer finish** — never interrupt
2. **Reflect back** what you heard to confirm understanding
3. **Categorize**: FAQ, account, order, complaint, retention, or escalation
4. **Assess urgency** — does this need to be resolved now or can it wait?
5. **Verify identity** if account access is required

### Step 3: Resolve or Route

1. **FAQ**: answer clearly, verify understanding, offer next steps
2. **Account**: verify identity, action the request, confirm the change
3. **Order/Transaction**: look up the order, provide status, action as needed
4. **Complaint**: acknowledge, validate, clarify, act, commit
5. **Retention**: understand, address root cause, present alternative, respect decision
6. **Escalation**: warm transfer with full context

### Step 4: Confirm & Close

1. **Summarize** what was resolved
2. **State next steps** clearly — who does what, by when
3. **Confirm understanding** — any remaining questions?
4. **Provide reference** — case number, callback number, timeline
5. **Close warmly** — genuine, human, not scripted

### Step 5: Document

1. **Log the interaction** — customer name, inquiry type, resolution, commitments
2. **Flag open items** for follow-up
3. **Note retention risk** if the customer expressed dissatisfaction or intent to leave
4. **Pass full context** on any escalation

---