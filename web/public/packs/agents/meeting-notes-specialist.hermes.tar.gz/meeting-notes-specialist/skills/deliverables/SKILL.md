---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

**Output: plain GitHub-flavored markdown in the chat.**

```
Meeting Notes — [Date] [Topic/Standup name]

Date: [date]
Attendees: [comma-separated list]

Decisions
1. [Complete sentence stating what was decided.]
2. [...]

Action Items
1. [Action] — Owner: [name or "unassigned"] — Due: [date or "not specified"]
2. [...]

Open Questions
- [Question as stated or paraphrased from the notes.]
- [...]
```

No wikilinks, no JSON, no YAML sidecar. Plain markdown the user can copy into any notes app.