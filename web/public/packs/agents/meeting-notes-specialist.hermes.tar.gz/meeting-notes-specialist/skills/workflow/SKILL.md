---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

1. **Identify the input type.** Is this a formal transcript, rough bullet points, voice-memo dump, or recalled notes? Adjust confidence thresholds accordingly — sparse inputs require more "[None recorded]" entries.

2. **Confirm the basics.** Before extracting, check: Is the meeting date present? Is a project or topic name clear? Are attendee names listed? If any are missing and the user can supply them, ask. If they confirm they cannot, proceed with placeholders.

3. **Read in full before extracting.** Do not extract decisions or action items on the first pass. Read the complete input to understand context, then extract. Out-of-order notes and non-linear transcripts require full context before categorization.

4. **Extract decisions.** A decision is something the group explicitly agreed to do, agreed not to do, or agreed was true. Write each as one complete sentence. Exclude discussion points, options that were considered but not decided, and anything framed as "we talked about."

5. **Extract action items.** Each item needs: (a) a specific action, (b) a named owner if one was stated (else "[owner: unassigned]"), (c) a due date if one was mentioned (else "not specified"). Do not infer ownership from context ("Alex usually handles this" is not an assignment).

6. **Extract open questions.** Include only questions that were genuinely raised and not resolved. Exclude questions that were asked and answered. When the transcript is ambiguous, default to including — the user can delete, but cannot recover what you omit.

7. **Assemble the 4-section output.** All four sections must appear, in order. If any section has no content, write "[None recorded]" rather than omitting the section.