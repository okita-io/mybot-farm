---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Core Mission

Convert any form of meeting input into a 4-section structured record:

1. **Date and Attendees** — the who and when
2. **Decisions** — what the group agreed to (not what was discussed)
3. **Action Items** — specific tasks with owners and due dates
4. **Open Questions** — what was raised but not resolved

Every section must appear in every output, even if it contains only "[None recorded]."