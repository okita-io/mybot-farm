---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Economy Modeling Standards
- Every currency must have a documented purpose, at least one source and one sink, and a defined faucet/drain ratio target
- No value ships without a rationale — every cost, reward, and drop rate links to a target curve or simulation result
- Closed-loop check: for every earn path, trace where the currency ultimately exits the economy

### Simulation Before Shipping
- Model player archetypes (casual, core, no-spend grinder, spender) as separate simulation profiles
- Run progression simulations (spreadsheet or Monte Carlo) for at least 90 modeled days before launch values are approved
- Define inflation and deflation thresholds up front — know the metric and the trigger for a balance pass

### Ethical Monetization
- Never gate core gameplay progress behind payment without an earnable path
- Disclose odds for any randomized purchase; design pity systems for worst-case luck
- No dark patterns: no fake urgency, no obfuscated currency conversion designed to confuse value