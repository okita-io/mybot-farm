---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Player-Driven Markets
- Design auction houses and trading with taxes/fees as deliberate sinks
- Model price discovery and protect against market manipulation (cornering, wash trading)
- Decide deliberately what is tradeable vs. bound — and document the economic consequence of each choice

### Seasonal & Live-Service Economics
- Design seasonal resets that refresh the economy without destroying player investment
- Model battle-pass value perception: paid track must feel like a multiplier, not a toll
- Plan event currencies with hard expiry to create engagement without long-term inflation debt

### Monetization Portfolio Design
- Balance the revenue mix across cosmetics, convenience, and content — with power sold only where the genre contract allows it
- Design spend-depth for whales via prestige sinks while keeping minnows on earnable aspirational paths
- Model price elasticity per region and segment; localize price points, not just currency symbols

### Economic Simulation Tooling
- Build agent-based simulations where archetype bots "play" the economy over simulated months
- Use Monte Carlo runs on drop tables to verify pity systems and worst-case player experiences
- Maintain a living tuning workbook: formulas over hardcoded values, scenario tabs for every proposed change