---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Currency Specification
```markdown
## Currency: [Name]

**Purpose**: What player decisions this currency creates
**Type**: [Soft / hard / premium / event / social]
**Sources**: [List every faucet with rate per hour/session]
**Sinks**: [List every drain with cost and frequency]
**Faucet/Drain Target Ratio**: [e.g., 1.05 early game, 0.95 endgame]
**Cap / Storage Limit**: [Value and rationale]
**Conversion Paths**: [What it exchanges to/from, and at what rate]
**Exploit Surface**: [Duping, botting, trading risks and mitigations]
```

### Economy Flow Map
```
[Gameplay] --earn--> [Soft Currency] --spend--> [Upgrades] --enable--> [Harder Content]
[IAP] --buy--> [Hard Currency] --convert--> [Soft Currency | Cosmetics | Time-skips]
Sinks: upgrade costs, repair fees, crafting, cosmetics, taxes on player trades
Rule: every loop must terminate in a sink or a cap
```

### Balance Simulation Sheet
```
Archetype   | Sessions/day | Earn/day | Spend/day | Net flow | Day-30 balance | Day-90 balance
------------|--------------|----------|-----------|----------|----------------|---------------
Casual      | 1            | 500      | 450       | +50      | 1,500          | 4,500
Core        | 3            | 1,800    | 1,700     | +100     | 3,000          | 9,000 [!] needs sink
Grinder     | 6            | 4,000    | 3,200     | +800     | 24,000 [!!]    | inflation risk
Spender     | 2            | 1,200+$  | 2,500     | varies   | model IAP mix  | check P2W gap
```

### Economy Health Dashboard Spec
```markdown
## Telemetry Requirements
- [ ] Currency earned/spent per player per day, segmented by source/sink
- [ ] Median and P90 wallet balance by player tenure cohort
- [ ] Faucet/drain ratio trend (7-day rolling)
- [ ] Sink participation rate (what % of players use each sink)
- [ ] Conversion rate and ARPPU without P2W-gap regression
- [ ] Alert thresholds: faucet/drain > [X] for [Y] days triggers balance review
```