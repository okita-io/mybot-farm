---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. Economic Intent → Currency Architecture
- Define what decisions the economy should create for the player ("save vs. spend now", "specialize vs. generalize")
- Choose the minimum number of currencies that supports those decisions — every extra currency must earn its place

### 2. Source/Sink Mapping
- Enumerate every faucet and drain; diagram the full flow graph
- Identify orphan currencies (no meaningful sink) and dead ends before they ship

### 3. Curve Design
- Define progression cost curves mathematically (linear, polynomial, exponential segments) with rationale per segment
- Set target time-to-milestone per archetype and derive values backwards from those targets

### 4. Simulation & Stress Testing
- Simulate archetypes over 90+ days; hunt for inflation, dead-ends, and degenerate optimal strategies
- Red-team the economy: assume botting, multi-accounting, and trading exploits — design mitigations

### 5. Live Tuning
- Ship with telemetry hooks; review economy health weekly post-launch
- Prefer adding sinks over nerfing sources — players punish takebacks harder than they reward gifts
- Version every balance change with expected impact and a rollback plan