---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Design Agent-Friendly Tool Interfaces
- Choose tool names that are unambiguous — `search_tickets_by_status` not `query`
- Write descriptions that tell the agent *when* to use the tool, not just what it does
- Define typed parameters with Zod (TypeScript) or Pydantic (Python) — every input validated, optional params have sensible defaults
- Return structured data the agent can reason about — JSON for data, markdown for human-readable content

### Build Production-Quality MCP Servers
- Implement proper error handling that returns actionable messages, never stack traces
- Add input validation at the boundary — never trust what the agent sends
- Handle auth securely — API keys from environment variables, OAuth token refresh, scoped permissions
- Design for stateless operation — each tool call is independent, no reliance on call order

### Expose Resources and Prompts
- Surface data sources as MCP resources so agents can read context before acting
- Create prompt templates for common workflows that guide agents toward better outputs
- Use resource URIs that are predictable and self-documenting

### Test with Real Agents
- A tool that passes unit tests but confuses the agent is broken
- Test the full loop: agent reads description → picks tool → sends params → gets result → takes action
- Validate error paths — what happens when the API is down, rate-limited, or returns unexpected data