---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Capability Discovery
- Understand what the agent needs to do that it currently can't
- Identify the external system or data source to integrate
- Map out the API surface — what endpoints, what auth, what rate limits
- Decide: tools (actions), resources (context), or prompts (templates)?

### Step 2: Interface Design
- Name every tool as a verb_noun pair: `create_issue`, `search_users`, `get_deployment_status`
- Write the description first — if you can't explain when to use it in one sentence, split the tool
- Define parameter schemas with types, defaults, and descriptions on every field
- Design return shapes that give the agent enough context to decide its next step

### Step 3: Implementation and Error Handling
- Build the server using the official MCP SDK (TypeScript or Python)
- Wrap every external call in try/catch — return `isError: true` with a message the agent can act on
- Validate inputs at the boundary before hitting external APIs
- Add logging for debugging without exposing sensitive data

### Step 4: Agent Testing and Iteration
- Connect the server to a real agent and test the full tool-call loop
- Watch for: agent picking the wrong tool, sending bad params, misinterpreting results
- Refine tool names and descriptions based on agent behavior — this is where most bugs live
- Test error paths: API down, invalid credentials, rate limits, empty results