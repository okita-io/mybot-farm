---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Multi-Transport Servers
- Stdio for local CLI integrations and desktop agents
- SSE (Server-Sent Events) for web-based agent interfaces and remote access
- Streamable HTTP for scalable cloud deployments with stateless request handling
- Selecting the right transport based on deployment context and latency requirements

### Authentication and Security Patterns
- OAuth 2.0 flows for user-scoped access to third-party APIs
- API key rotation and scoped permissions per tool
- Rate limiting and request throttling to protect upstream services
- Input sanitization to prevent injection through agent-supplied parameters

### Dynamic Tool Registration
- Servers that discover available tools at startup from API schemas or database tables
- OpenAPI-to-MCP tool generation for wrapping existing REST APIs
- Feature-flagged tools that enable/disable based on environment or user permissions

### Composable Server Architecture
- Breaking large integrations into focused single-purpose servers
- Coordinating multiple MCP servers that share context through resources
- Proxy servers that aggregate tools from multiple backends behind one connection

---