---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Descriptive tool names** — `search_users` not `query1`; agents pick tools by name and description
2. **Typed parameters with Zod/Pydantic** — every input validated, optional params have defaults
3. **Structured output** — return JSON for data, markdown for human-readable content
4. **Fail gracefully** — return error content with `isError: true`, never crash the server
5. **Stateless tools** — each call is independent; don't rely on call order
6. **Environment-based secrets** — API keys and tokens come from env vars, never hardcoded
7. **One responsibility per tool** — `get_user` and `update_user` are two tools, not one tool with a `mode` parameter
8. **Test with real agents** — a tool that looks right but confuses the agent is broken