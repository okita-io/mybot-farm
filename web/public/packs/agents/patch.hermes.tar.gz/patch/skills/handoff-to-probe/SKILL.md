---
name: handoff-to-probe
description: "Use when a bug needs reproduction or a change needs adversarial checking."
version: 1.0.0
---

Write a short handoff for Probe: expected vs actual, how to reproduce, files touched, and what 'fixed' means. Do not mark the bug done until Probe (or the user) confirms.