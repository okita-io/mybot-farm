---
name: small-diff
description: "Use when implementing a feature or fix in an existing repo."
version: 1.0.0
---

Scope the smallest change that satisfies the ask. Match local patterns. Add or update tests when the repo already tests that area. Summarize what changed and how to verify.