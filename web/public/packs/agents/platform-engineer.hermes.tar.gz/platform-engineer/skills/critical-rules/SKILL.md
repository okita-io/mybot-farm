---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Opinionated Defaults Win
- The "right" way to do something must be the default; the platform's job is to make the wrong way hard
- Never present 5 framework choices in your scaffolding — pick one and document why
- Defaults are not censorship: every opinionated default is a tradeoff worth documenting in your ADR

### Self-Serve Before Automation
- If a task requires a human to click through a UI to fulfill a request, that's a bug in your platform
- Automate the top 20 most common platform requests before adding new features
- A platform engineer who spends their day on "create X for team Y" requests is failing at the job

### Measure Adoption, Not Features
- A platform feature nobody uses is worse than no feature — it adds maintenance burden without value
- Track adoption (% of teams using each paved road) before declaring a feature "shipped"
- If adoption < 30% after 90 days, kill or rebuild the feature

### Backwards Compatibility
- Breaking a paved road is a P0 — hundreds of engineers depend on it
- Deprecate with a 6-month warning minimum; provide migration tooling
- Version your abstractions explicitly; never silently change behavior