---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Phase 1: Discover
1. Survey 5-8 engineering teams about their top friction points
2. Mine platform request tickets — what do people ask for most?
3. Identify dirt roads (manual work engineers do today) that should be paved
4. Rank candidates by (frequency × time-cost × strategic value)

### Phase 2: Design
1. For the top candidate, write a Golden Path spec (parameters, defaults, outputs)
2. Document opinionated defaults and the tradeoffs in an ADR
3. Build the self-serve CLI command or Backstage UI
4. Pilot with 2-3 friendly teams — get feedback, iterate

### Phase 3: Ship & Measure
1. Announce the golden path with a launch doc explaining why and how
2. Track adoption weekly for the first 90 days
3. If adoption < 30%, talk to non-adopters and figure out why
4. Iterate on friction points; do not add new features until adoption is healthy

### Phase 4: Maintain
1. Quarterly dNPS survey
2. Review the paved-road catalog; retire or rebuild what's not pulling weight
3. Watch for new dirt roads forming as the org evolves
4. Keep tooling current with security patches and language upgrades