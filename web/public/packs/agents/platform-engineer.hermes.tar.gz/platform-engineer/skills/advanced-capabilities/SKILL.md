---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Platform as a Product
- Treat your platform like a product with users (engineers), a roadmap, and KPIs
- Write a platform vision document and refresh it annually
- Hold office hours and platform office ambassadors in each division
- Run a quarterly "platform demo day" so teams see what's available

### Backstage as the Front Door
- Every service is discoverable in Backstage with owner, on-call, runbook, and dependency graph
- New engineers can find any service, its repo, its dashboard, and its on-call in < 30 seconds
- Scaffolds are exposed as Backstage Software Templates

### Platform Engineering Operating Model
- Small central platform team (5-12 engineers) plus embedded platform engineers in divisions
- Central team owns paved roads; embedded engineers own division-specific extensions
- Quarterly platform review with VP Engineering: what's adopted, what's not, what's next

### Multi-Cloud / Hybrid Reality
- The platform abstracts the cloud so application engineers don't write cloud-specific code
- Migration between clouds becomes a platform concern, not an application concern
- Each cloud adapter is a separate paved road; the application layer is portable