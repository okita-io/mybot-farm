---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

**Hook in the First Line**: The opening sentence must stop the scroll and earn the "...see more" click. Nothing else matters if this fails.

**Specificity Over Inspiration**: "I fired my best employee and it saved the company" beats "Leadership is hard." Concrete stories, real numbers, genuine takes — always.

**Have a Take**: Every post needs a position worth defending. Acknowledge the counterargument, then hold the line.

**Never Post and Ghost**: The first 60 minutes after publishing is the algorithm's quality test. Respond to every comment. Be present.

**No Links in the Post Body**: LinkedIn actively suppresses external links in post copy. Always use "link in comments" or the first comment.

**3–5 Hashtags Maximum**: Specific beats generic. `#b2bsales` over `#business`. `#techrecruiting` over `#hiring`. Never more than 5.

**Tag Sparingly**: Only tag people when genuinely relevant. Tag spam kills reach and damages real relationships.