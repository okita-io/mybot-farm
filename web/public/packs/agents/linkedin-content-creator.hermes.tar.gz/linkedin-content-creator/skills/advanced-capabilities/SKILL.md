---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

**Hook Engineering by Audience**
```
For job seekers:
"I applied to 94 jobs. 3 responded. Here's what changed everything."

For founders:
"We almost ran out of runway. This LinkedIn post saved us."

For developers:
"I posted one thread about system design. 3 recruiters DMed me that week."

For B2B sellers:
"I deleted my cold outreach sequence. Replaced it with this. Pipeline doubled."
```

**Audience-Specific Playbooks**

*Founders*: Build in public — specific numbers, real decisions, honest mistakes. Customer story arcs where the customer is always the hero. Expertise-to-pipeline funnel: free value → deeper insight → soft CTA → direct offer. Never skip steps.

*Job Seekers*: Show skills through story, never lists. Let the narrative do the resume work. Warm up the network through content engagement before you need anything. Post your target role context so recruiters find you.

*Developers & Technical Professionals*: Teach one specific concept publicly to demonstrate mastery. Translate deep expertise into accessible insight without dumbing it down. "Here's how I think about [hard thing]" is your highest-leverage format.

*Career Changers*: Reframe past experience as transferable advantage before the pivot, not after. Build new niche authority in parallel. Let the content do the repositioning work — the audience that follows you through the change becomes the strongest social proof.

*B2B Marketers & Consultants*: Warm DMs from content engagement close faster than cold outreach at any volume. Comment threads with ideal clients are the new pipeline. Expertise posts attract the buyer; story posts build the trust that closes them.

**LinkedIn Algorithm Levers**
- **Dwell time**: Long reads and carousel swipes are quality signals — structure content to reward completion
- **Save rate**: Practical, reference-worthy content gets saved — saves outweigh likes in feed scoring
- **Early velocity**: First-hour engagement determines distribution — respond fast, respond substantively
- **Native content**: Carousels uploaded as PDFs, native video, and native articles get 3–5x more reach than posts with external links

**Carousel Deep Architecture**
- Lead slide must function as a standalone post — if they never swipe, they should still get value and feel the pull to swipe
- Each interior slide: one idea, one visual metaphor or data point, max 15 words of body copy
- The reveal slide (second to last): the payoff — the insight the whole carousel was building toward
- Final slide: specific CTA tied to the carousel topic + follow prompt + "save for later" if reference-worthy

**Comment-to-Pipeline System**
- Target 5 accounts per day (ideal employers, ideal clients, industry voices) with substantive comments — not "great post!" but a genuine extension of their idea
- This primes the algorithm AND builds real relationship before you ever need anything
- DM only after establishing comment presence — reference the specific exchange, add one new thing
- Never pitch in the DM until you've earned the right with genuine engagement