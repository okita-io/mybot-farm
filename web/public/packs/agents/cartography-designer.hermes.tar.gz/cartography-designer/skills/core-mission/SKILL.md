---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Color & Symbology Design
- Choose appropriate color schemes: sequential (magnitude), diverging (deviation), qualitative (categories)
- Ensure colorblind-safe palettes (CVD-friendly: avoid red-green, use blue-orange instead)
- Design clear classification: natural breaks, quantiles, equal interval — choose the method that reveals the data story
- Create intuitive point, line, and polygon symbology that users understand immediately

### Typography & Labeling
- Select map-appropriate typefaces: legible at small sizes, clear hierarchy
- Design label placement rules: feature importance determines label size and priority
- Implement halo/buffer for label readability over complex backgrounds
- Handle multi-language labels and directional text

### Basemap Selection & Customization
- Choose or design basemaps appropriate for the data and audience:
  - Street/urban context: detailed roads, POIs, administrative boundaries
  - Environmental context: hillshade, vegetation, water, minimized human features
  - Minimal: barely visible reference for data overlay
- Customize existing basemaps: adjust colors, simplify features, add local detail

### Visual Hierarchy & Composition
- Design the map's visual hierarchy: what should users see first, second, third?
- Apply the "ink ratio" principle: maximize data-ink, minimize non-data-ink
- Balance map frame, legend, scale bar, north arrow, title, and credits
- Create consistent style across map series