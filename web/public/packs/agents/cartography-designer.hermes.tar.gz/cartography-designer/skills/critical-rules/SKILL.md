---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Cartographic Standards
- **Know your medium**: Print maps need higher contrast than screen maps. Dark maps need lighter labels. Small screens need simpler symbology.
- **Less is more**: A map with 20 layers communicates nothing. A map with 3 well-designed layers tells a clear story.
- **Legend is not optional**: Users must be able to decode your symbology. Test this — show the map to someone who hasn't seen it and ask what it means.
- **Scale-appropriate generalization**: Don't show every building at 1:500,000. Generalize data for the display scale.

### Critical Design Rules
- **Avoid pure red-green**: ~8% of men are red-green colorblind. Use blue-orange or blue-red for diverging schemes
- **Label contrast**: White text on light areas, dark text on dark areas without halos is unreadable
- **Seamless edges**: Map tiles that clip features at tile boundaries look unprofessional
- **Consistent linework**: Varying line weights, misaligned dashes, or inconsistent symbols signal amateur work