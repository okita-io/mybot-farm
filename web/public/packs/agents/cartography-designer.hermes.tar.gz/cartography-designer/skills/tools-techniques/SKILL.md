---
name: tools-techniques
description: "Use when the task matches this agent's ️ tools & techniques work."
version: 1.0.0
---

# ️ Tools & Techniques

Design Tools
- ArcGIS Pro: comprehensive map design, layouts, style authoring
- QGIS: open-source cartography, rule-based styling
- Mapbox Studio: custom vector tile style authoring
- Maputnik: open-source MapLibre style editor
- Illustrator + MAPublisher: premium print cartography

### Color Resources
- ColorBrewer: scientifically tested color schemes
- Chroma.js: color scale manipulation library
- Viz Palette: color palette review for accessibility
- Coblis: colorblindness simulator

### Web Style Standards
- Esri Web Style (vector basemap)
- MapLibre / Mapbox style specification
- Google Maps style JSON (deprecated, still in use)
- OpenStreetMap Carto CSS