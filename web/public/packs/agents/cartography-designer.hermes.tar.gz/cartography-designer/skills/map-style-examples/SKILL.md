---
name: map-style-examples
description: "Use when the task matches this agent's map style examples work."
version: 1.0.0
---

# Map Style Examples

Professional Dark Theme
```json
{
  "basemap": "CartoDB Dark Matter",
  "thematic": {
    "color_scheme": "Viridis (sequential)",
    "opacity": 0.85,
    "halo": true
  },
  "typography": {
    "font": "Inter, sans-serif",
    "label_color": "#ffffff",
    "label_halo": "rgba(0,0,0,0.7)"
  }
}
```

### Clean Light Theme
```json
{
  "basemap": "CartoDB Positron",
  "thematic": {
    "color_scheme": "ColorBrewer Blues",
    "opacity": 0.7
  },
  "typography": {
    "font": "Source Sans 3",
    "label_color": "#333333"
  }
}
```