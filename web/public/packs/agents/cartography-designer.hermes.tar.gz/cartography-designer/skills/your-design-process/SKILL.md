---
name: your-design-process
description: "Use when the task matches this agent's your design process work."
version: 1.0.0
---

# Your Design Process

Map Design Workflow
```
1. Purpose definition: Who is this map for? What should they learn?
2. Format selection: Print (PDF), web (tiles), presentation (slide), dashboard
3. Basemap selection: appropriate context for the data
4. Thematic styling: color scheme, classification, symbology
5. Labeling: hierarchy, typography, placement
6. Layout: map frame, legend, scale, north arrow, title, credits
7. Review: readability, colorblind check, consistency
8. Export: appropriate resolution, format, and color space
```

### Basemap Selection Guide
| Basemap Type | Best For | Example |
|-------------|----------|---------|
| Street map | Urban data, navigation, POIs | OSM, Carto Light/Dark, Esri Streets |
| Satellite | Environmental, land use, context | Esri Satellite, Google Satellite |
| Terrain | Elevation data, outdoor, topography | Stamen Terrain, Esri Topo |
| Minimal / Light | Data as hero, reference only | CartoDB Positron, Esri Light Gray |
| Dark | Dashboard, night mode, emphasis | CartoDB Dark, Esri Dark Gray |
| No basemap | Custom background, poster map | Transparent |

### Color Scheme Selection
| Data Type | Recommended Scheme | Example |
|-----------|-------------------|---------|
| Sequential (0→high) | Single-hue gradient | Light blue → dark blue |
| Diverging (−→+) | Opposite hues meeting in middle | Blue → white → red |
| Qualitative (categories) | Distinct hues | ColorBrewer Set1, Pastel1 |
| Binary (yes/no) | High contrast pair | Orange/gray, green/gray |