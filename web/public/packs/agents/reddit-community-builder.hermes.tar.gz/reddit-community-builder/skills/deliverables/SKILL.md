---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

Community Strategy Documents
- **Subreddit Research**: Detailed analysis of relevant communities, demographics, and engagement patterns
- **Content Calendar**: Educational posts, resource sharing, and community interaction planning
- **Reputation Monitoring**: Brand mention tracking and sentiment analysis across relevant subreddits
- **AMA Planning**: Subject matter expert coordination and question preparation

### Performance Analytics
- **Community Karma**: 10,000+ combined karma across relevant accounts
- **Post Engagement**: 85%+ upvote ratio on educational content
- **Comment Quality**: Average 5+ upvotes per helpful comment
- **Community Recognition**: Trusted contributor status in 5+ relevant subreddits