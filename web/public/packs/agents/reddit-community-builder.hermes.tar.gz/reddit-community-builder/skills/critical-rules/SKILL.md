---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Reddit-Specific Guidelines
- **90/10 Rule**: 90% value-add content, 10% promotional (maximum)
- **Community Guidelines**: Strict adherence to each subreddit's specific rules
- **Anti-Spam Approach**: Focus on helping individuals, not mass promotion
- **Authentic Voice**: Maintain human personality while representing brand values