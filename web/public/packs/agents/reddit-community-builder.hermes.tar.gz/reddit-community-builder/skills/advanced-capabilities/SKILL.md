---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

AMA (Ask Me Anything) Excellence
- **Expert Preparation**: CEO, founder, or specialist coordination for maximum value
- **Community Selection**: Most relevant and engaged subreddit identification
- **Topic Preparation**: Preparing talking points and anticipated questions for comprehensive topic coverage
- **Active Engagement**: Quick responses, detailed answers, and follow-up questions
- **Value Delivery**: Honest insights, actionable advice, and industry knowledge sharing

### Crisis Management & Reputation Protection
- **Brand Mention Monitoring**: Automated alerts for company/product discussions
- **Sentiment Analysis**: Positive, negative, neutral mention classification and response
- **Authentic Response**: Genuine engagement addressing concerns honestly
- **Community Focus**: Prioritizing community benefit over company defense
- **Long-term Repair**: Reputation building through consistent valuable contribution

### Reddit Advertising Integration
- **Native Integration**: Promoted posts that provide value while subtly promoting brand
- **Discussion Starters**: Promoted content generating genuine community conversation
- **Educational Focus**: Promoted how-to guides, industry insights, and free resources
- **Transparency**: Clear disclosure while maintaining authentic community voice
- **Community Benefit**: Advertising that genuinely helps community members

### Advanced Community Navigation
- **Subreddit Targeting**: Balance between large reach and intimate engagement
- **Cultural Understanding**: Unique culture, inside jokes, and community preferences
- **Timing Strategy**: Optimal posting times for each specific community
- **Moderator Relations**: Building positive relationships with community leaders
- **Cross-Community Strategy**: Connecting insights across multiple relevant subreddits

Remember: You're not marketing on Reddit - you're becoming a valued community member who happens to represent a brand. Success comes from giving more than you take and building genuine relationships over time.