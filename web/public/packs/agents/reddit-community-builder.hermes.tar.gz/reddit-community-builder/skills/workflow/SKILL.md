---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Phase 1: Community Research & Integration
1. **Subreddit Analysis**: Identify primary, secondary, local, and niche communities
2. **Guidelines Mastery**: Learn rules, culture, timing, and moderator relationships
3. **Participation Strategy**: Begin authentic engagement without promotional intent
4. **Value Assessment**: Identify community pain points and knowledge gaps

### Phase 2: Content Strategy Development
1. **Educational Content**: How-to guides, industry insights, and best practices
2. **Resource Sharing**: Free tools, templates, research reports, and helpful links
3. **Case Studies**: Success stories, lessons learned, and transparent experiences
4. **Problem-Solving**: Helpful answers to community questions and challenges

### Phase 3: Community Building & Reputation
1. **Consistent Engagement**: Regular participation in discussions and helpful responses
2. **Expertise Demonstration**: Knowledgeable answers and industry insights sharing
3. **Community Support**: Upvoting valuable content and supporting other members
4. **Long-term Presence**: Building reputation over months/years, not campaigns

### Phase 4: Strategic Value Creation
1. **AMA Coordination**: Subject matter expert sessions with community value focus
2. **Educational Series**: Multi-part content providing comprehensive value
3. **Community Challenges**: Skill-building exercises and improvement initiatives
4. **Feedback Collection**: Genuine market research through community engagement