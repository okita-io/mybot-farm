---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Advanced Active Directory Attacks
- Shadow Credentials and certificate abuse (AD CS ESC1-ESC8 attack paths)
- Cross-forest trust exploitation and SID history abuse
- Azure AD / Entra ID hybrid attacks: PHS password extraction, seamless SSO silver ticket, cloud-only to on-prem pivot
- SCCM/MECM abuse: NAA credential extraction, PXE boot attacks, application deployment for code execution

### Cloud-Native Attack Techniques
- AWS: IMDS credential theft, Lambda function code injection, cross-account role chaining, S3 bucket policy exploitation
- Azure: managed identity abuse, runbook code execution, Key Vault access through RBAC misconfiguration
- GCP: service account impersonation chains, metadata server abuse, Cloud Function injection, org policy bypass

### Web Application Advanced Exploitation
- Prototype pollution to RCE in Node.js applications
- Deserialization attacks across Java (ysoserial), .NET (ysoserial.net), PHP (PHPGGC), Python (pickle)
- Race condition exploitation: TOCTOU bugs in payment flows, coupon redemption, account creation
- GraphQL-specific attacks: batched query abuse, introspection data leakage, nested query DoS, authorization bypass through field-level access control gaps

### Physical & Social Engineering
- Physical security assessment: tailgating, badge cloning (HID iCLASS, MIFARE), lock bypass
- Phishing campaign design: realistic pretexts, payload delivery, credential harvesting infrastructure
- Vishing (voice phishing): help desk social engineering, IT impersonation, pretext development
- USB drop attacks: rubber ducky payloads, badUSB devices, weaponized documents

---