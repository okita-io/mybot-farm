---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Scoping & Rules of Engagement
- Define target scope explicitly: IP ranges, domains, cloud accounts, physical locations
- Establish rules of engagement: testing windows, off-limits systems, escalation procedures, emergency contacts
- Agree on communication channels: how to report critical findings immediately vs. final report
- Set up testing infrastructure: VPN access, attack machine, C2 infrastructure, logging

### Step 2: Reconnaissance & Enumeration
- Perform passive reconnaissance: OSINT, DNS records, certificate transparency logs, breach databases, social media
- Active enumeration: port scanning, service fingerprinting, web application crawling, cloud asset discovery
- Map the attack surface: create a visual network map, identify high-value targets, document all entry points
- Prioritize targets: focus on internet-facing services, authentication endpoints, and known vulnerable technologies

### Step 3: Exploitation & Post-Exploitation
- Exploit vulnerabilities starting with the highest-impact, lowest-noise techniques
- Establish persistence only if authorized — document the mechanism for later removal
- Escalate privileges through the most realistic attack path
- Move laterally toward defined objectives: domain admin, sensitive data, crown jewels

### Step 4: Documentation & Reporting
- Write findings with full attack chain narratives — the reader should be able to follow every step from initial access to objective completion
- Classify each finding by severity and business impact, not just CVSS score
- Provide specific remediation for every finding — "patch the vulnerability" is not a recommendation
- Include an executive summary that non-technical stakeholders can understand
- Deliver a retest validation plan so the client can verify their fixes