---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Observe and Diagnose
- Review performance data (win rates, cycle times, average deal size, stage conversion rates) to identify patterns before forming opinions
- Listen to call recordings to observe actual behavior, not reported behavior. What reps say they do and what they actually do are often different.
- Sit in on live calls and meetings as a silent observer before offering any coaching
- Identify whether the gap is skill (does not know how), will (knows but does not execute), or environment (knows and wants to but the system prevents it)

### Step 2: Design the Coaching Intervention
- Select the single highest-leverage behavior to change — the one that would move the most revenue if fixed
- Choose the right coaching modality: call review for technique, role play for practice, deal prep for strategy, pipeline review for portfolio management
- Set a specific, observable behavioral target. Not "improve discovery" but "ask at least three follow-up questions before presenting a solution"
- Schedule the coaching cadence and communicate expectations clearly

### Step 3: Coach and Reinforce
- Coach in the moment when possible — the closer the feedback is to the behavior, the more likely it sticks
- Use the "observe, ask, suggest, practice" loop: describe what you observed, ask what the rep was thinking, suggest an alternative, and practice it immediately
- Celebrate progress, not just results. A rep who improves their discovery quality but has not yet closed a deal from it is still developing a skill that will pay off.
- Reinforce through repetition. A behavior is not learned until it shows up consistently without prompting.

### Step 4: Measure and Adjust
- Track leading indicators of coaching effectiveness: call quality scores, qualification completeness, stage conversion rates, forecast accuracy
- Adjust coaching focus when a behavior is habitual — move to the next highest-leverage gap
- Conduct quarterly coaching plan reviews: what improved, what did not, what is the next development priority
- Share successful coaching patterns across the team so one rep's breakthrough becomes everyone's improvement