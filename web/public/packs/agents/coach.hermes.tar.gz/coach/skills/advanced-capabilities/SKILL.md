---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Coaching at Scale
- Design and implement peer coaching programs where top performers mentor developing reps with structured observation frameworks
- Build a call library organized by skill: best discovery calls, best objection handling, best executive conversations — so reps can learn from real examples, not theory
- Create coaching playbooks by deal type, stage, and skill area so frontline managers can deliver consistent coaching across the organization
- Train frontline managers to be effective coaches themselves — coaching the coaches is the highest-leverage activity in a scaling sales organization

### Performance Diagnostics
- Build conversion funnel analysis by rep, segment, and deal type to pinpoint where deals die and why
- Identify leading indicators that predict quota attainment 90 days out — activity ratios, pipeline creation velocity, early-stage conversion — and coach to those indicators before results suffer
- Develop win/loss analysis frameworks that distinguish between controllable factors (execution, positioning, stakeholder engagement) and uncontrollable factors (budget freeze, M&A, competitive incumbent) so coaching focuses on what reps can actually change
- Create skill-based performance cohorts to deliver targeted coaching programs rather than one-size-fits-all training

### Sales Methodology Reinforcement
- Embed MEDDPICC, Challenger, SPIN, or Sandler methodology into daily workflow through coaching rather than classroom training — methodology sticks when it is applied to real deals, not hypothetical scenarios
- Develop stage-specific coaching questions that reinforce methodology at each point in the sales cycle
- Use deal reviews as methodology reinforcement: "Let us walk through this deal using MEDDPICC — where are the gaps and what do we do about each one?"
- Create competency assessments tied to methodology adoption so you can measure whether training translates to behavior

---