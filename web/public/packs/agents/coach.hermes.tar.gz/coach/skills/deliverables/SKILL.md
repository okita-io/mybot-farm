---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Rep Coaching Plan
```markdown
# Coaching Plan: [Rep Name]

## Current Performance
- **Quota Attainment (YTD)**: [%]
- **Win Rate**: [%]
- **Average Deal Size**: [$]
- **Sales Cycle Length**: [days]
- **Pipeline Coverage**: [Ratio]

## Skill Assessment
| Competency | Current Level | Target Level | Gap |
|-----------|--------------|-------------|-----|
| Discovery quality | [1-5] | [1-5] | [Notes on specific gap] |
| Qualification rigor | [1-5] | [1-5] | [Notes on specific gap] |
| Objection handling | [1-5] | [1-5] | [Notes on specific gap] |
| Executive presence | [1-5] | [1-5] | [Notes on specific gap] |
| Closing / next-step commitment | [1-5] | [1-5] | [Notes on specific gap] |
| Forecast accuracy | [1-5] | [1-5] | [Notes on specific gap] |

## Focus Areas (Max 3)
### Focus 1: [Skill]
- **Current behavior**: [What the rep does now — specific, observed]
- **Target behavior**: [What "good" looks like — specific, behavioral]
- **Coaching actions**: [How you will develop this — call reviews, role plays, shadowing]
- **Milestone**: [How you will know it is working — observable indicator]
- **Target date**: [When you expect the behavior to be habitual]

## Coaching Cadence
- **Weekly 1:1**: [Day/time, focus areas, standing agenda]
- **Call reviews**: [Frequency, selection criteria — random vs. targeted]
- **Deal prep sessions**: [For which deal types or stages]
- **Debrief sessions**: [Post-loss, post-win, post-important-meeting]
```

### Pipeline Review Framework
```markdown
# Pipeline Review: [Rep Name] — [Date]

## Portfolio Health
- **Total Pipeline**: [$] across [#] deals
- **Weighted Pipeline**: [$]
- **Pipeline-to-Quota Ratio**: [X:1] (target 3:1+)
- **Average Age by Stage**: [Days — flag deals that are stale]
- **Stage Distribution**: [Is pipeline front-loaded (risk) or well-distributed?]

## Deal Inspection (Top 5 by Value)
| Deal | Value | Stage | Age | Key Question | Risk |
|------|-------|-------|-----|-------------|------|
| [Deal] | [$] | [Stage] | [Days] | "What do we not know?" | [Red/Yellow/Green] |

## For Each Deal Under Review
1. **What changed since last review?** — progress, not just activity
2. **Who are we talking to?** — are we multi-threaded or single-threaded?
3. **What is the business case?** — can you articulate why the buyer would spend this money?
4. **What is the decision process?** — steps, people, criteria, timeline
5. **What is the biggest risk?** — and what is the plan to mitigate it?
6. **What is the specific next step?** — with a date, an owner, and a purpose

## Pattern Observations
- **Stalled deals**: [Which deals have not progressed? Why?]
- **Qualification gaps**: [Recurring missing information across deals]
- **Stage accuracy**: [Are deals in the right stage based on evidence?]
- **Coaching moment**: [One portfolio-level observation to discuss in the 1:1]
```

### Call Coaching Debrief
```markdown
# Call Coaching: [Rep Name] — [Date]

## Call Details
- **Account**: [Name]
- **Call Type**: [Discovery / Demo / Negotiation / Executive]
- **Buyer Attendees**: [Names and roles]
- **Duration**: [Minutes]
- **Recording Link**: [URL]

## What Went Well
- [Specific moment and why it was effective]
- [Specific moment and why it was effective]

## Coaching Opportunity
- **Moment**: [Timestamp] — [What the buyer said or did]
- **What happened**: [How the rep responded]
- **What to try instead**: [Specific alternative — exact words or approach]
- **Why it matters**: [What this would have unlocked in the deal]

## Skill Connection
- **This connects to**: [Which focus area in the coaching plan]
- **Practice assignment**: [What the rep should try in their next call]
- **Follow-up**: [When you will review the next attempt]
```

### New Rep Ramp Plan
```markdown
# Ramp Plan: [Rep Name] — Start Date: [Date]

## 30-Day Milestones (Learn)
- [ ] Complete product certification with passing score
- [ ] Shadow [#] discovery calls and [#] demos with top performers
- [ ] Deliver practice pitch to manager and receive feedback
- [ ] Articulate the top 3 customer pain points and how the product addresses each
- [ ] Complete CRM and tool stack onboarding
- **Competency gate**: Can the rep describe the product's value proposition in the customer's language?

## 60-Day Milestones (Execute with Support)
- [ ] Run [#] discovery calls with manager observing and debriefing
- [ ] Build [#] qualified pipeline (measured by MEDDPICC completeness, not dollar value)…