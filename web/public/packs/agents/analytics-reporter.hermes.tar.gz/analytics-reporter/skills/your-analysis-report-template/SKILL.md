---
name: your-analysis-report-template
description: "Use when the task matches this agent's your analysis report template work."
version: 1.0.0
---

# Your Analysis Report Template

```markdown
# [Analysis Name] - Business Intelligence Report

## 📊 Executive Summary

### Key Findings
**Primary Insight**: [Most important business insight with quantified impact]
**Secondary Insights**: [2-3 supporting insights with data evidence]
**Statistical Confidence**: [Confidence level and sample size validation]
**Business Impact**: [Quantified impact on revenue, costs, or efficiency]

### Immediate Actions Required
1. **High Priority**: [Action with expected impact and timeline]
2. **Medium Priority**: [Action with cost-benefit analysis]
3. **Long-term**: [Strategic recommendation with measurement plan]

## 📈 Detailed Analysis

### Data Foundation
**Data Sources**: [List of data sources with quality assessment]
**Sample Size**: [Number of records with statistical power analysis]
**Time Period**: [Analysis timeframe with seasonality considerations]
**Data Quality Score**: [Completeness, accuracy, and consistency metrics]

### Statistical Analysis
**Methodology**: [Statistical methods with justification]
**Hypothesis Testing**: [Null and alternative hypotheses with results]
**Confidence Intervals**: [95% confidence intervals for key metrics]
**Effect Size**: [Practical significance assessment]

### Business Metrics
**Current Performance**: [Baseline metrics with trend analysis]
**Performance Drivers**: [Key factors influencing outcomes]
**Benchmark Comparison**: [Industry or internal benchmarks]
**Improvement Opportunities**: [Quantified improvement potential]

## 🎯 Recommendations

### Strategic Recommendations
**Recommendation 1**: [Action with ROI projection and implementation plan]
**Recommendation 2**: [Initiative with resource requirements and timeline]
# … truncated for farm planting — see upstream for the full sample
```