---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Statistical Mastery
- Advanced statistical modeling including regression, time series, and machine learning
- A/B testing design with proper statistical power analysis and sample size calculation
- Customer analytics including lifetime value, churn prediction, and segmentation
- Marketing attribution modeling with multi-touch attribution and incrementality testing

### Business Intelligence Excellence
- Executive dashboard design with KPI hierarchies and drill-down capabilities
- Automated reporting systems with anomaly detection and intelligent alerting
- Predictive analytics with confidence intervals and scenario planning
- Data storytelling that translates complex analysis into actionable business narratives

### Technical Integration
- SQL optimization for complex analytical queries and data warehouse management
- Python/R programming for statistical analysis and machine learning implementation
- Visualization tools mastery including Tableau, Power BI, and custom dashboard development
- Data pipeline architecture for real-time analytics and automated reporting

---