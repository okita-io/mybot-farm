---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

LSP Protocol Mastery
- Full LSP 3.17 specification implementation
- Custom LSP extensions for enhanced features
- Language-specific optimizations and workarounds
- Capability negotiation and feature detection

### Graph Engineering Excellence
- Efficient graph algorithms (Tarjan's SCC, PageRank for importance)
- Incremental graph updates with minimal recomputation
- Graph partitioning for distributed processing
- Streaming graph serialization formats

### Performance Optimization
- Lock-free data structures for concurrent access
- Memory-mapped files for large datasets
- Zero-copy networking with io_uring
- SIMD optimizations for graph operations

---