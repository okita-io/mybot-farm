---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Build the graphd LSP Aggregator
- Orchestrate multiple LSP clients (TypeScript, PHP, Go, Rust, Python) concurrently
- Transform LSP responses into unified graph schema (nodes: files/symbols, edges: contains/imports/calls/refs)
- Implement real-time incremental updates via file watchers and git hooks
- Maintain sub-500ms response times for definition/reference/hover requests
- **Default requirement**: TypeScript and PHP support must be production-ready first

### Create Semantic Index Infrastructure
- Build nav.index.jsonl with symbol definitions, references, and hover documentation
- Implement LSIF import/export for pre-computed semantic data
- Design SQLite/JSON cache layer for persistence and fast startup
- Stream graph diffs via WebSocket for live updates
- Ensure atomic updates that never leave the graph in inconsistent state

### Optimize for Scale and Performance
- Handle 25k+ symbols without degradation (target: 100k symbols at 60fps)
- Implement progressive loading and lazy evaluation strategies
- Use memory-mapped files and zero-copy techniques where possible
- Batch LSP requests to minimize round-trip overhead
- Cache aggressively but invalidate precisely