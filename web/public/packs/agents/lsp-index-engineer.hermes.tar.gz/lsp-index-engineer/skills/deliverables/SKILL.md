---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

graphd Core Architecture
```typescript
// Example graphd server structure
interface GraphDaemon {
  // LSP Client Management
  lspClients: Map<string, LanguageClient>;

  // Graph State
  graph: {
    nodes: Map<NodeId, GraphNode>;
    edges: Map<EdgeId, GraphEdge>;
    index: SymbolIndex;
  };

  // API Endpoints
  httpServer: {
    '/graph': () => GraphResponse;
    '/nav/:symId': (symId: string) => NavigationResponse;
    '/stats': () => SystemStats;
  };

  // WebSocket Events
  wsServer: {
    onConnection: (client: WSClient) => void;
    emitDiff: (diff: GraphDiff) => void;
  };

  // File Watching
  watcher: {
    onFileChange: (path: string) => void;
    onGitCommit: (hash: string) => void;
  };
}

// Graph Schema Types
interface GraphNode {
  id: string;        // "file:src/foo.ts" or "sym:foo#method"
  kind: 'file' | 'module' | 'class' | 'function' | 'variable' | 'type';
  file?: string;     // Parent file path
  range?: Range;     // LSP Range for symbol location
  detail?: string;   // Type signature or brief description
}
# … truncated for farm planting — see upstream for the full sample
```

### LSP Client Orchestration
```typescript
// Multi-language LSP orchestration
class LSPOrchestrator {
  private clients = new Map<string, LanguageClient>();
  private capabilities = new Map<string, ServerCapabilities>();

  async initialize(projectRoot: string) {
    // TypeScript LSP
    const tsClient = new LanguageClient('typescript', {
      command: 'typescript-language-server',
      args: ['--stdio'],
      rootPath: projectRoot
    });

    // PHP LSP (Intelephense or similar)
    const phpClient = new LanguageClient('php', {
      command: 'intelephense',
      args: ['--stdio'],
      rootPath: projectRoot
    });

    // Initialize all clients in parallel
    await Promise.all([
      this.initializeClient('typescript', tsClient),
      this.initializeClient('php', phpClient)
    ]);
  }

  async getDefinition(uri: string, position: Position): Promise<Location[]> {
    const lang = this.detectLanguage(uri);
    const client = this.clients.get(lang);

    if (!client || !this.capabilities.get(lang)?.definitionProvider) {
      return [];
    }

    return client.sendRequest('textDocument/definition', {
      textDocument: { uri },
      position
    });
  }
# … truncated for farm planting — see upstream for the full sample
```

### Graph Construction Pipeline
```typescript
// ETL pipeline from LSP to graph
class GraphBuilder {
  async buildFromProject(root: string): Promise<Graph> {
    const graph = new Graph();

    // Phase 1: Collect all files
    const files = await glob('**/*.{ts,tsx,js,jsx,php}', { cwd: root });

    // Phase 2: Create file nodes
    for (const file of files) {
      graph.addNode({
        id: `file:${file}`,
        kind: 'file',
        path: file
      });
    }

    // Phase 3: Extract symbols via LSP
    const symbolPromises = files.map(file =>
      this.extractSymbols(file).then(symbols => {
        for (const sym of symbols) {
          graph.addNode({
            id: `sym:${sym.name}`,
            kind: sym.kind,
            file: file,
            range: sym.range
          });

          // Add contains edge
          graph.addEdge({
            source: `file:${file}`,
            target: `sym:${sym.name}`,
            type: 'contains'
          });
        }
      })
    );

    await Promise.all(symbolPromises);

# … truncated for farm planting — see upstream for the full sample
```

### Navigation Index Format
```jsonl
{"symId":"sym:AppController","def":{"uri":"file:///src/controllers/app.php","l":10,"c":6}}
{"symId":"sym:AppController","refs":[
  {"uri":"file:///src/routes.php","l":5,"c":10},
  {"uri":"file:///tests/app.test.php","l":15,"c":20}
]}
{"symId":"sym:AppController","hover":{"contents":{"kind":"markdown","value":"```php\nclass AppController extends BaseController\n```\nMain application controller"}}}
{"symId":"sym:useState","def":{"uri":"file:///node_modules/react/index.d.ts","l":1234,"c":17}}
{"symId":"sym:useState","refs":[
  {"uri":"file:///src/App.tsx","l":3,"c":10},
  {"uri":"file:///src/components/Header.tsx","l":2,"c":10}
]}
```