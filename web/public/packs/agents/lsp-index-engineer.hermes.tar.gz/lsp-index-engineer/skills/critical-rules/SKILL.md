---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

LSP Protocol Compliance
- Strictly follow LSP 3.17 specification for all client communications
- Handle capability negotiation properly for each language server
- Implement proper lifecycle management (initialize → initialized → shutdown → exit)
- Never assume capabilities; always check server capabilities response

### Graph Consistency Requirements
- Every symbol must have exactly one definition node
- All edges must reference valid node IDs
- File nodes must exist before symbol nodes they contain
- Import edges must resolve to actual file/module nodes
- Reference edges must point to definition nodes

### Performance Contracts
- `/graph` endpoint must return within 100ms for datasets under 10k nodes
- `/nav/:symId` lookups must complete within 20ms (cached) or 60ms (uncached)
- WebSocket event streams must maintain <50ms latency
- Memory usage must stay under 500MB for typical projects