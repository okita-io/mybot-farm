---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Buyer Needs Assessment

```
BUYER CONSULTATION GUIDE
───────────────────────────────────────
Buyer:              [Name(s)]
Date:               [Date]
Agent:              [Name]
Pre-approval:       [ ] Yes — Amount: $_______ Lender: _______
                    [ ] No — Refer to preferred lender

PROPERTY CRITERIA
───────────────────────────────────────
Price Range:        $_______ to $_______
Property Types:     [ ] Single family  [ ] Condo  [ ] Townhome
                    [ ] Multi-family  [ ] Land  [ ] Other
Bedrooms:           Minimum ___  Preferred ___
Bathrooms:          Minimum ___  Preferred ___
Square Footage:     Minimum ___  Preferred ___
Garage:             [ ] Required  [ ] Preferred  [ ] Not needed
Lot Size:           [ ] Doesn't matter  [ ] Minimum: ___

LOCATION CRITERIA
───────────────────────────────────────
Target Areas:       [Neighborhoods / cities / zip codes]
School District:    [ ] Critical  [ ] Preferred district: _______
Commute:            Work location: _______  Max commute: ___ minutes
Deal-breaker areas: [Any areas to exclude]

MUST-HAVES (Non-negotiable):
  1. _______________
  2. _______________
  3. _______________

NICE-TO-HAVES (Would love but not required):
  1. _______________
  2. _______________
  3. _______________

DEAL-BREAKERS (Automatic disqualifiers):
  1. _______________
  2. _______________
  3. _______________
# … truncated for farm planting — see upstream for the full sample
```

### Comparative Market Analysis (CMA) Template

```
COMPARATIVE MARKET ANALYSIS
───────────────────────────────────────
Property:       [Address]
Prepared for:   [Client Name]
Prepared by:    [Agent Name]
Date:           [Date]
Purpose:        [ ] Listing price recommendation
                [ ] Offer price guidance
                [ ] Annual market update

SUBJECT PROPERTY
───────────────────────────────────────
Address:        [Full address]
Style:          [Ranch / Two-story / Split / Condo / etc.]
Year Built:     ___  Beds: ___  Baths: ___  Sq Ft: ___
Lot Size:       ___  Garage: ___  Basement: [ ] Yes [ ] No
Updates:        [Key renovations or updates]
Condition:      [ ] Excellent  [ ] Good  [ ] Average  [ ] Fair

ACTIVE COMPETITION (Current listings)
───────────────────────────────────────
Address         | LP      | Beds | Bath | SqFt | $/SqFt | DOM
----------------|---------|------|------|------|--------|----
[Comp 1]        | $       |      |      |      | $      |
[Comp 2]        | $       |      |      |      | $      |
[Comp 3]        | $       |      |      |      | $      |
Active Average: | $       |      |      |      | $      |

PENDING SALES (Under contract — strongest market signal)
───────────────────────────────────────
Address         | LP      | SP Est | Beds | Bath | SqFt | DOM
----------------|---------|--------|------|------|------|----
[Comp 1]        | $       | $      |      |      |      |
[Comp 2]        | $       | $      |      |      |      |
Pending Average:| $       | $      |      |      |      |

SOLD COMPARABLES (Last 90 days preferred)
───────────────────────────────────────
Address         | LP      | SP      | SP/LP% | SqFt | $/SqFt | DOM
----------------|---------|---------|--------|------|--------|----
# … truncated for farm planting — see upstream for the full sample
```

### Offer Preparation & Negotiation Guide

```
OFFER STRATEGY FRAMEWORK
───────────────────────────────────────
Property:       [Address]
List Price:     $___________
Offer Date:     ___________
Offer Deadline: ___________ (if applicable)

MARKET CONTEXT
───────────────────────────────────────
Days on Market:         ___
Price Reductions:       [ ] Yes — reduced from $_______ on _______
                        [ ] No
Competing Offers:       [ ] Confirmed  [ ] Rumored  [ ] None known
Seller Motivation:      [Any known factors — relocation, divorce, estate, etc.]

OFFER COMPONENTS
───────────────────────────────────────
Purchase Price:         $___________
  vs. List Price:       [+/-] $_______ ([+/-]__%)
  vs. CMA Value:        [+/-] $_______

Earnest Money:          $___________  ([  ]% of purchase price)
  Delivered within:     ___ days of acceptance
  Escrow held by:       _______________

Financing:              [ ] Conventional  [ ] FHA  [ ] VA  [ ] Cash
  Down Payment:         ____%
  Pre-approval:         [ ] Included  [ ] Not included
  Lender:               _______________

CONTINGENCIES
───────────────────────────────────────…