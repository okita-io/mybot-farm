---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Client Consultation & Goal Setting

1. **Conduct buyer or seller consultation** — understand goals, timeline, and motivation
2. **For buyers**: collect needs assessment, confirm pre-approval, set up MLS search
3. **For sellers**: complete CMA, agree on pricing strategy, sign listing agreement
4. **Set communication expectations** — preferred method, frequency, and response time
5. **Explain the process** — walk client through every step from today to closing

### Step 2: Active Search or Listing Phase

**For Buyers:**
1. **Set up automated MLS alerts** — matching client criteria, immediate notification
2. **Preview listings** — filter results and recommend best matches
3. **Schedule showings** — coordinate with listing agents and client availability
4. **Capture showing notes** — document client reactions and feedback after each showing
5. **Refine search** — adjust criteria based on feedback from showings

**For Sellers:**
1. **Execute marketing plan** — photos, MLS, syndication, social media, open house
2. **Manage showings** — confirm appointments, provide access, collect feedback
3. **Communicate weekly** — market activity report, showing feedback, competitive update
4. **Monitor market** — watch for new competition, price reductions, and sold comps
5. **Recommend price adjustments** — based on feedback and market data, when appropriate

### Step 3: Offer & Negotiation

**For Buyers:**
1. **Analyze the property** — CMA, condition assessment, red flags
2. **Develop offer strategy** — price, terms, contingencies based on market and motivation
3. **Prepare and submit offer** — complete contract with all required disclosures
4. **Present offer** — communicate to listing agent with supporting rationale
5. **Negotiate response** — counteroffer strategy, escalation clause, terms negotiation

**For Sellers:**
1. **Present all offers** — every offer must be presented, regardless of amount
2. **Analyze each offer** — net proceeds, terms strength, buyer qualification
3. **Advise on response** — accept, counter, or reject with strategic rationale
4. **Manage multiple offer situations** — highest and best process, escalation clauses
5. **Negotiate to mutual agreement** — terms, closing date, contingencies, concessions

### Step 4: Transaction Management

1. **Open escrow/title** — confirm earnest money delivered and deposited
2. **Schedule inspection** — coordinate access and attend with client
3. **Negotiate inspection resolution** — repairs, credits, or acceptance
4. **Monitor financing** — track lender milestones and appraisal
5. **Clear all contingencies** — document each contingency removal in writing
6. **Coordinate vendors** — inspectors, lenders, title, attorneys, movers

### Step 5: Closing & Post-Close

1. **Conduct final walkthrough** — verify property condition and agreed repairs
2. **Confirm closing logistics** — time, location, funds required, documents to bring
3. **Attend closing** — support client through signing process
4. **Deliver keys / transfer possession** — per contract terms
5. **Post-closing follow-up** — thank you, referral request, stay-in-touch plan

---