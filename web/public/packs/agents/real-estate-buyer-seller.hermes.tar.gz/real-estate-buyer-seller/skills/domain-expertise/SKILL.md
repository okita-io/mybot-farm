---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Market Knowledge

- **Comparative Market Analysis**: sold comps, active competition, pending sales, absorption rate
- **Neighborhood Analysis**: school districts, walkability, amenities, development trends
- **Investment Analysis**: cap rate, GRM, cash-on-cash return, appreciation potential
- **Market Timing**: seasonal patterns, interest rate impact, inventory trends
- **Property Valuation**: cost approach, sales comparison, income approach

### Contract Expertise

- **Purchase agreements**: all standard and addendum forms by state
- **Contingencies**: inspection, financing, appraisal, home sale, kick-out clauses
- **Disclosures**: seller disclosures, lead paint, HOA, natural hazard, agency disclosure
- **Amendments**: modification of terms, deadline extensions, repair agreements
- **Closing documents**: HUD-1/ALTA settlement statement, deed, title insurance

### Negotiation Strategies

- **Multiple offer situations**: escalation clauses, highest and best, offer presentation strategy
- **Inspection negotiations**: repair requests, credits, price reductions, as-is acceptance
- **Appraisal gap strategies**: gap coverage clauses, price reductions, FHA/VA appraisal challenges
- **Seller concession strategy**: closing cost assistance, rate buydowns, repair credits
- **Creative terms**: leaseback agreements, flexible possession, personal property inclusion

### Wire Fraud Prevention

```
WIRE FRAUD WARNING — SEND TO EVERY BUYER BEFORE CLOSING
───────────────────────────────────────
⚠️ IMPORTANT: Wire Fraud Alert

Real estate wire fraud is one of the fastest-growing crimes in
the United States. Criminals intercept email communications and
send fraudulent wiring instructions that appear to come from your
real estate agent, lender, or title company.

BEFORE WIRING ANY FUNDS:
1. Call your title company directly using a phone number you
   independently verified — NOT a number from an email
2. Verbally confirm the exact wire amount and account number
3. Never wire funds based solely on email instructions
4. If anything seems different or unusual — STOP and call us

If you believe you have been a victim of wire fraud, immediately:
- Contact your bank to request a wire recall
- Call the FBI's Internet Crime Complaint Center at ic3.gov
- Contact local law enforcement

Your closing funds are protected when you verify before you wire.
```

---