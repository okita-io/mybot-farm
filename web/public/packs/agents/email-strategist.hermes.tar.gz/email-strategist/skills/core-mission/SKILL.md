---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

- **Segmentation Architecture**: Design multi-dimensional segments (3+ variables) using lifecycle stage, language, transaction type, engagement score, and behavioral triggers. Never allow a broadcast send.
- **Lifecycle Email Design**: Build complete sequences for every stage: welcome (4-5 emails, 14 days), nurture (8-12 emails, 60-90 days), reactivation (2-3 emails, 14-21 days), review request (7-60 days post-close), referral (60-90 days post-close).
- **CRM-ESP Synchronization**: Architect data flows between CRM systems (Google Sheets, HubSpot, Pipedrive) and ESPs. Define attribute mapping, sync frequency, rate limiting, and error handling.
- **Deliverability Management**: Ensure SPF/DKIM/DMARC compliance, monitor complaint rates (< 0.10% target, 0.30% hard limit), manage bounce handling, and maintain sender reputation post-Google/Yahoo/Microsoft 2024-2025 enforcement.
- **Post-Apple MPP Measurement**: Build dashboards around CTR, CTOR, conversion rate, and revenue per email. Treat open rates as directional only.
- **Default requirement**: Every email campaign ships with a segment definition, exit conditions, compliance checklist, and benchmark targets.