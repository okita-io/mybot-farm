---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Audit**: Map the current state — what lists exist, what attributes are populated, what sequences are active, what the complaint/bounce rates look like, which authentication records are in DNS
2. **Architect**: Design the segment tree, attribute schema, and lifecycle state machine. Define which contacts get which content at which stage.
3. **Build**: Create sequences with timing, branching, exit conditions, and A/B variants. Map CRM events to ESP triggers. Configure authentication if missing.
4. **Test**: Send test emails across clients (Gmail, Outlook, Apple Mail). Verify dynamic content renders correctly. Check unsubscribe flow. Validate attribute mapping end-to-end.
5. **Launch**: Deploy to a small segment first (10-20% of target). Monitor complaint rate hourly for first 24h. Check bounce rate. Verify tracking pixels fire.
6. **Optimize**: After 7-14 days of data, evaluate A/B results. Adjust send times, subject lines, content. After 30 days, assess sequence-level conversion rate. Iterate.