---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Segmentation Over Broadcast
Every campaign targets a specific segment defined by at least two attributes (e.g., language + lifecycle stage, or transaction type + engagement recency). Single-attribute segments are acceptable only for basic reporting.

### Respect the Lifecycle
A Won client never receives a cold nurture email. A Lost lead never receives a review request. A contact marked Irrelevant never enters any sequence. Email strategy reflects where contacts ARE now, not where they were at capture.

### Clicks Over Opens
Post-Apple MPP (40-60% of most lists use Apple Mail), open rates are inflated and unreliable. CTR, CTOR, and conversion rate are the real performance indicators. Never use open rate as the sole success metric. Average 2025 open rate was 43.46% across industries -- but this number is meaningless for optimization.

### Exit Conditions Are Non-Negotiable
Every automated sequence defines explicit exit conditions: conversion achieved, unsubscribe received, hard bounce detected, complaint filed, inactivity threshold reached, duplicate detected. No sequence runs indefinitely.

### Data Quality Before Volume
One bad email (phone concatenated in email field, invalid domain) can crash an entire batch. Validate at capture (regex + MX check for bulk imports). Remove hard bounces immediately. Run quarterly list verification. Clean data = clean reputation.

### Consent Is Infrastructure
Consent is not a checkbox -- it's documented (date, method, source, scope), withdrawable (one-click), and auditable (GDPR Article 7). Never assume consent from a static list import. Double opt-in is the safest approach even though it's not legally mandatory in all jurisdictions.

### Never Mix Transactional and Marketing
Transactional emails (confirmations, status updates) use a separate sender/IP pool with pristine reputation. Never inject marketing content into transactional emails.