---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

AI-Powered Optimization (2025-2026 Production-Ready)

**Send-Time Optimization (STO)**: AI predicts each contact's optimal engagement window based on historical click patterns. Measured lift: 15-23% higher open rates. Critical: modern STO must analyze clicks and conversions, not opens (Apple MPP spoofs opens). Requires 30+ days of engagement data per contact. Available natively in Brevo from Standard plan.

**Subject Line AI**: Generate 3-5 variants, A/B test on 10-20% sample, auto-deploy winner. eBay case study: 15.8% open rate lift, 31% increase in clicks. 64% of email marketers now use AI in their programs; AI personalization drives 41% average revenue increase.

**Brevo Aura AI** (launched May 2025): Chat-style assistant in dashboard and email editor. Generates subject lines, body copy, CTAs, tone adjustments, multilingual translations. Available on free plan.

**Generative Review Suggestions**: Use LLMs (Claude Haiku) to generate personalized Google Review suggestions based on transaction type, language, and client name. Inject via template params ({{ params.SUGGESTED_REVIEW }}). Include in review request emails as copy-paste inspiration.

### Behavioral Trigger Architecture
```
[Property page viewed, no inquiry] → 24h delay → Abandoned browse email
[Form partially filled] → 4h delay → "Finish your inquiry" reminder
[CRM status → Won] → 7-day delay → Review request sequence
[CRM status → Lost, 90+ days] → Reactivation sequence
[Email clicked, no conversion] → 48h delay → Related content follow-up
[3+ property views same city] → Immediate → City-specific property digest
[Client anniversary] → Annual → "Thank you" + referral ask
```

### Multi-Language Campaign Architecture
For multilingual markets (e.g., BG/EN/FR):
- Separate templates per language (not dynamic content blocks — translation quality matters)
- Language attribute as category type (numeric IDs: EN=1, BG=2, FR=3)
- Router node in automation: IF Language=BG → BG template, ELSE → EN template
- Correction flow: contact initially captured in wrong language can be recategorized by agent, next upsert updates ESP attribute

### Real Estate Vertical Playbook
- **Property storytelling** in emails: narrative descriptions that help buyers envision their life there (highest engagement, most underutilized)
- **Market data emails**: price trends by neighborhood, homes sold this week, timing insights (establishes authority)
- **Optimal email length**: 200-300 words for real estate (tested). Shorter = higher CTR. Longer = perceived as newsletter.
- **Best days**: Tuesday and Friday (highest open + CTR across real estate studies)
- **Review request timing**: agent calls client within 7 days of closing. Email follows only after the personal touch. Include direct Google Review link + AI-generated suggested review text.
- **Referral program**: 60-90 days post-closing. Reward structure (cash, service credit, or recognition). Unique tracking per client. Quarterly "thinking of you" to keep referral pipeline warm.

### Post-February 2024 Deliverability Landscape
- **Google** (Feb 2024 + Nov 2025 escalation): SPF + DKIM + DMARC required. One-click unsubscribe required for bulk (5K+/day). Complaint rate < 0.30%. Non-compliant emails now face permanent rejections, not just spam folder.
- **Yahoo**: Aligned with Google requirements (Feb 2024).
- **Microsoft** (May 2025): Enforcing similar standards for Outlook/Hotmail.
- **BIMI**: Display your logo in inbox. Requires DMARC p=quarantine or p=reject + VMC certificate. Worth implementing for brand recognition in competitive verticals.

### GDPR & ePrivacy Compliance (2026 State)
- ePrivacy Regulation withdrawn by European Commission (Feb 2025). Original ePrivacy Directive still applies with member-state variations.
- CNIL draft (June 2025): tracking pixel deployment may require separate consent from marketing email consent. Monitor enforcement.
- GDPR fines increasing: CNIL fined Google 325M EUR (Sept 2025).
- Consent records: store date, time, method, source URL, IP, scope. Not just a checkbox.
- Data retention: document policy. Delete/anonymize after 12-24 months of zero engagement.