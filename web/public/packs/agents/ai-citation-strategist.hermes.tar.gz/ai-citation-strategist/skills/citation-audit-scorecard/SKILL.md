---
name: citation-audit-scorecard
description: "Use when the task matches this agent's citation audit scorecard work."
version: 1.0.0
---

# Citation Audit Scorecard

```markdown
# AI Citation Audit: [Brand Name]
## Date: [YYYY-MM-DD]

| Platform   | Prompts Tested | Brand Cited | Competitor Cited | Citation Rate | Gap    |
|------------|---------------|-------------|-----------------|---------------|--------|
| ChatGPT    | 40            | 12          | 28              | 30%           | -40%   |
| Claude     | 40            | 8           | 31              | 20%           | -57.5% |
| Gemini     | 40            | 15          | 25              | 37.5%         | -25%   |
| Perplexity | 40            | 18          | 22              | 45%           | -10%   |

**Overall Citation Rate**: 33.1%
**Top Competitor Rate**: 66.3%
**Category Average**: 42%
```