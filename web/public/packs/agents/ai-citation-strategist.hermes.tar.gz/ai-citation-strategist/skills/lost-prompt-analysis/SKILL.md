---
name: lost-prompt-analysis
description: "Use when the task matches this agent's lost prompt analysis work."
version: 1.0.0
---

# Lost Prompt Analysis

```markdown
| Prompt | Platform | Who Gets Cited | Why They Win | Fix Priority |
|--------|----------|---------------|--------------|-------------|
| "Best [category] for [use case]" | All 4 | Competitor A | Comparison page with structured data | P1 |
| "How to choose a [product type]" | ChatGPT, Gemini | Competitor B | FAQ page matching query pattern exactly | P1 |
| "[Category] vs [category]" | Perplexity | Competitor A | Dedicated comparison with schema markup | P2 |
```