---
name: fix-pack-template
description: "Use when the task matches this agent's fix pack template work."
version: 1.0.0
---

# Fix Pack Template

```markdown
# Fix Pack: [Brand Name]
## Priority 1 (Implement within 7 days)

### Fix 1: Add FAQ Schema to [Page]
- **Target prompts**: 8 lost prompts related to [topic]
- **Expected impact**: +15-20% citation rate on FAQ-style queries
- **Implementation**:
  - Add FAQPage schema markup
  - Structure Q&A pairs to match exact prompt patterns
  - Include entity references (brand name, product names, category terms)

### Fix 2: Create Comparison Content
- **Target prompts**: 6 lost prompts where competitors win with comparison pages
- **Expected impact**: +10-15% citation rate on comparison queries
- **Implementation**:
  - Create "[Brand] vs [Competitor]" pages
  - Use structured data (Product schema with reviews)
  - Include objective feature-by-feature tables
```