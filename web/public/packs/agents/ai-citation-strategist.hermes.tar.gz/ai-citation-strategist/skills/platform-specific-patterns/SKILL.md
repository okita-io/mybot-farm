---
name: platform-specific-patterns
description: "Use when the task matches this agent's platform-specific patterns work."
version: 1.0.0
---

# Platform-Specific Patterns

| Platform | Citation Preference | Content Format That Wins | Update Cadence |
|----------|-------------------|------------------------|----------------|
| ChatGPT | Authoritative sources, well-structured pages | FAQ pages, comparison tables, how-to guides | Training data cutoff + browsing |
| Claude | Nuanced, balanced content with clear sourcing | Detailed analysis, pros/cons, methodology | Training data cutoff |
| Gemini | Google ecosystem signals, structured data | Schema-rich pages, Google Business Profile | Real-time search integration |
| Perplexity | Source diversity, recency, direct answers | News mentions, blog posts, documentation | Real-time search |