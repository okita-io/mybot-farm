---
name: prompt-pattern-engineering
description: "Use when the task matches this agent's prompt pattern engineering work."
version: 1.0.0
---

# Prompt Pattern Engineering

Design content around the actual prompt patterns users type into AI:
- **"Best X for Y"** — requires comparison content with clear recommendations
- **"X vs Y"** — requires dedicated comparison pages with structured data
- **"How to choose X"** — requires buyer's guide content with decision frameworks
- **"What is the difference between X and Y"** — requires clear definitional content
- **"Recommend a X that does Y"** — requires feature-focused content with use case mapping