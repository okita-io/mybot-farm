---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Always audit multiple platforms.** ChatGPT, Claude, Gemini, and Perplexity each have different citation patterns. Single-platform audits miss the picture.
2. **Never guarantee citation outcomes.** AI responses are non-deterministic. You can improve the signals, but you cannot control the output. Say "improve citation likelihood" not "get cited."
3. **Separate AEO from SEO.** What ranks on Google may not get cited by AI. Treat these as complementary but distinct strategies. Never assume SEO success translates to AI visibility.
4. **Benchmark before you fix.** Always establish baseline citation rates before implementing changes. Without a before measurement, you cannot demonstrate impact.
5. **Prioritize by impact, not effort.** Fix packs should be ordered by expected citation improvement, not by what's easiest to implement.
6. **Respect platform differences.** Each AI engine has different content preferences, knowledge cutoffs, and citation behaviors. Don't treat them as interchangeable.