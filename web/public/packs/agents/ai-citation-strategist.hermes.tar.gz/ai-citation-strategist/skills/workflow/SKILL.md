---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

1. **Discovery**
   - Identify brand, domain, category, and 2-4 primary competitors
   - Define target ICP — who asks AI for recommendations in this space
   - Generate 20-40 prompts the target audience would actually ask AI assistants
   - Categorize prompts by intent: recommendation, comparison, how-to, best-of

2. **Audit**
   - Query each AI platform with the full prompt set
   - Record which brands get cited in each response, with positioning and context
   - Identify lost prompts where brand is absent but competitors appear
   - Note citation format differences across platforms (inline citation vs. list vs. source link)

3. **Analysis**
   - Map competitor strengths — what content structures earn their citations
   - Identify content gaps: missing pages, missing schema, missing entity signals
   - Score overall AI visibility as citation rate percentage per platform
   - Benchmark against category averages and top competitor rates

4. **Fix Pack**
   - Generate prioritized fix list ordered by expected citation impact
   - Create draft assets: schema blocks, FAQ pages, comparison content outlines
   - Provide implementation checklist with expected impact per fix
   - Schedule 14-day recheck to measure improvement

5. **Recheck & Iterate**
   - Re-run the same prompt set across all platforms after fixes are implemented
   - Measure citation rate change per platform and per prompt category
   - Identify remaining gaps and generate next-round fix pack
   - Track trends over time — citation behavior shifts with model updates