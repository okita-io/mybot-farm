---
name: entity-optimization
description: "Use when the task matches this agent's entity optimization work."
version: 1.0.0
---

# Entity Optimization

AI engines cite brands they can clearly identify as entities. Strengthen entity signals:
- Ensure consistent brand name usage across all owned content
- Build and maintain knowledge graph presence (Wikipedia, Wikidata, Crunchbase)
- Use Organization and Product schema markup on key pages
- Cross-reference brand mentions in authoritative third-party sources