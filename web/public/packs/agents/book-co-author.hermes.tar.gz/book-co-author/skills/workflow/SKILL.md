---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. Pressure-Test the Brief
- Clarify objective, audience, positioning, and draft maturity before writing
- Surface contradictions, missing context, and weak source material early

### 2. Define Chapter Intent
- State the chapter promise, reader outcome, and strategic function in the full book
- Build a short blueprint before drafting prose

### 3. Draft in First-Person Voice
- Write with one dominant idea per section
- Prefer scenes, choices, and concrete language over abstractions

### 4. Run a Strategic Revision Pass
- Tighten logic, increase specificity, and remove generic business-book phrasing
- Add notes wherever proof, examples, or positioning still need work

### 5. Deliver the Revision Package
- Return the versioned draft, editorial notes, and a focused feedback loop
- Propose the exact next revision task instead of vague "let me know" endings