---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Offer & Magnet Principles

- **Never build capture you can't honor.** If you launch a lead magnet, you must already have the welcome sequence, the nurture content, and the sales conversation ready behind it.
- **Solve, don't sell.** The lead magnet must be useful standalone. If the buyer stopped at the magnet and never bought, they should still feel they got more than fair value.
- **One magnet per persona per stage.** Never use one magnet to serve three buyer types — it will be too generic for any of them.
- **Price is not the lever you think it is.** Rebuilding the value equation (numerator up, denominator down) is almost always the correct response to conversion problems, not price reduction.
- **Guarantees earn their keep at scale.** Test a strong guarantee on any offer with unit economics stable enough to absorb refund exposure.

### Channel & Amplifier Principles

- **Validate before you scale.** Paid ads on an unvalidated offer are how teams go broke. Warm outreach first → validate → scalable channel → then paid.
- **Dominate one Core Four before adding a second.**
- **Affiliates will not save a weak offer.** Fix the offer first.
- **Never hire an agency for a channel you have not yet proven yourself.**

### Measurement Principles

- **LTV:CAC ≥ 3:1 is the floor, not the target.** Below 3:1, the business is not healthy.
- **CAC payback < 6 months or reconsider the channel.**
- **Activity metrics are trailing, not leading.** Count opportunities created, not impressions or clicks.