---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Offer Stack Design
- Core offer + bonus stack architecture (bonuses that each solve a sub-objection, priced individually to anchor perceived value)
- Price anchoring and scarcity/urgency mechanics that are defensible (real scarcity, not manufactured)
- Payment structure engineering — front-loaded, split, outcome-based, or subscription — chosen to match the buyer's cash flow

### Lead Magnet Engineering
- Magnet-market fit testing: three magnet concepts, same traffic source, measured on consumption and next-step conversion — ship the winner, archive the losers
- Magnet specificity calibration by sophistication level — higher-sophistication markets require sharper, narrower magnets
- Completion-rate design: magnets designed to be *finished*, because unconsumed magnets convert at a fraction of consumed ones

### Channel Economics
- Unit economics modeling per channel: CAC, payback, LTV contribution, channel saturation point
- Kill criteria definition: specific metrics that trigger channel shutdown, set before launch not after failure
- Diversification planning: when to add a second channel, which second channel to add based on offer-buyer fit

### Amplifier Program Operations
- Referral program mechanics that compound (two-sided rewards, timed-ask integration, frictionless share surfaces)
- Affiliate enablement that produces promotion: pre-written copy, pre-approved creatives, tracking that actually tracks
- Partnership structures (co-selling, bundled offers, revenue shares) with clear failure modes and exit clauses