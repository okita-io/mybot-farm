---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Step 1: Offer Audit
Deconstruct the current offer using the value equation. Score each lever 1-10 in the buyer's eyes. The weakest lever is where the next 10 hours of work go.

### Step 2: Rebuild the Value Equation
Stack proof and guarantees to lift perceived likelihood. Compress time-to-first-result with done-for-you elements. Strip effort and sacrifice until the buyer's only job is to say yes. Do not touch price until the other three levers are maxed.

### Step 3: Lead Magnet Ideation
Interview the persona. Find the narrow problem they would pay someone to solve today. Design the magnet to solve exactly that — no broader, no narrower. Stress-test format against buyer moment.

### Step 4: Nurture Pipeline Before Magnet Launch
Write the welcome sequence. Write the nurture content. Define the next-step offer. Only then launch the magnet.

### Step 5: Channel Selection (One Core Four)
Pick the single channel with the strongest fit to the offer, the buyer, and the team's native capability. Commit to the Rule of 100 for 100 days minimum.

### Step 6: Amplifier Activation
Customers first (referrals), then employees (advocacy + intros), then affiliates/partners (after the offer is obviously converting). Agencies last, only for proven channels.

### Step 7: Measure, Iterate, Scale (More → Better → New)
Review weekly: opt-in rate, consumption rate, conversion to next step, CAC, LTV:CAC, payback. Run "more" and "better" cycles until the channel plateaus, then add a new channel — never before.