---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Core Mission

The Grand Slam Offer — Value Equation First

An offer is the goods and services you promise in exchange for money. A **grand-slam offer** is an offer so good prospects feel stupid saying no. The math behind it:

```
               Dream Outcome  ×  Perceived Likelihood of Achievement
Value = ──────────────────────────────────────────────────────────────
                   Time Delay  ×  Effort & Sacrifice
```

Every offer design choice either increases the numerator or decreases the denominator. That is the entire job.

**Numerator levers:**
- **Dream outcome**: paint the result in the buyer's own language — the transformation they are actually buying, not the deliverable they nominally pay for
- **Perceived likelihood**: stack guarantees, proof, reversals, and risk-inverters so the buyer believes *this one will work*

**Denominator levers:**
- **Time delay**: compress the gap between purchase and result — done-for-you beats done-with-you beats DIY
- **Effort & sacrifice**: remove every step the buyer has to take, every decision they have to make, every habit they have to build

**Guarantees are a core offer element, not an afterthought.** The right guarantee shifts risk from buyer to seller and often doubles conversion without touching price. Use them deliberately: unconditional (money-back), conditional (outcome-based), anti-guarantee (explicit no-refund with a reason), or implied (we deliver before you pay).

### Lead Magnets: The Three Types

A **lead magnet** is a complete solution to a narrow problem, given in exchange for contact information. The magnet must deliver real value standalone — if a buyer could stop there and feel served, they are far more likely to trust the paid offer behind it.

| Type | What It Does | When to Use |
|------|--------------|-------------|
| **Solve a problem** | Gives the buyer a concrete result they can use immediately — a calculator, a ready-made plan, a diagnostic | You sell a how-to product and want to demonstrate mastery by giving a small, usable win |
| **Educate** | Reframes the buyer's understanding so they recognize they have a bigger problem than they thought | You sell a high-ticket solution and the buyer doesn't yet understand the full cost of inaction |
| **Sample** | Gives the buyer a literal piece of the paid product — a chapter, a session, a trial | You sell an experience-based product where tasting is the fastest path to belief |

**The magnet picks the buyer.** Sophisticated magnets attract sophisticated buyers. Match the magnet's intellectual altitude to your target.

### Getting Leads: The Core Four

Every lead-generation activity falls into exactly four categories. There is no fifth. Pick one to dominate before adding another.

| Channel | Audience Relationship | Cost Profile | Best For |
|---------|----------------------|--------------|----------|
| **Warm outreach** | People who know you | Free, high-effort, non-scalable | Early-stage, first 100 customers |
| **Post free content** | Strangers becoming a warm audience | Free, high-effort, compounding | Building durable attention and authority |
| **Cold outreach** | Strangers who don't know you | Free/cheap, scalable with systems | Direct sales motion, B2B, niche audiences |
| **Paid ads** | Strangers you rent attention from | Cash, scalable, instantly dial-up-able | Proven offers with known unit economics |

**The sequencing rule.** Start with warm outreach to validate the offer. Move to one of cold outreach or posted content to build a repeatable engine. Only add paid ads once you have evidence the offer converts at a CAC your LTV can pay for.

**One Core Four before two.** Most teams fail by spreading thin across all four from day one. Dominate one channel first — then layer the next.

### Lead Getters: Amplifying Reach

Four categories of people who get leads *for* you:

- **Customers — Referrals.** Build the ask into the fulfillment moment, make the referral mechanic effortless, reward both sides.
- **Employees — Internal lead machine.** Train them to post and introduce. Compensate referrals.
- **Agencies — Rented expertise.** Useful when you have a validated offer. Rule: never hire an agency for a channel you have not yet proven yourself.
- **Affiliates & partners — Performance amplifiers.** Formal affiliates (track-and-pay), strategic partners (bundled offers), and content amplifiers (creators whose audience overlaps yours). Commission typically 20-50% of front-end.

### The Rule of 100…