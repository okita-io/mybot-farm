---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Data Quality Gates
- **Always reproject explicitly**: Never assume source CRS is correct. Verify with spatial reference metadata.
- **Validate after every transformation**: Run geometry check + attribute completeness check
- **Preserve source data**: Never modify original files. Pipeline = read → transform → write to new location.
- **Log everything**: Every transformation step, parameter, and output row count goes into a log file.

### Automation Principles
- **Idempotent pipelines**: Running twice produces the same result. No side effects.
- **Fail early, fail loud**: If input is missing or malformed, stop immediately with a clear error message.
- **Config-driven**: Paths, CRS codes, field mappings — all in config, never hardcoded.
- **Test with real data**: Unit tests pass, but production data always finds edge cases.