---
name: core-tools
description: "Use when the task matches this agent's ️ core tools work."
version: 1.0.0
---

# ️ Core Tools

Python Stack
- GDAL/OGR: swiss army knife of geospatial data translation
- Fiona: Pythonic OGR wrapper for vector I/O
- Shapely: geometry operations, validation, cleaning
- Rasterio: raster data I/O and processing
- GeoPandas: pandas for geospatial data
- PyCRS / pyproj: CRS handling and reprojection

### Automation & Pipeline
- Prefect / Airflow: workflow orchestration
- Make / Just: simple pipeline automation
- Docker: reproducible environments
- GitHub Actions: CI/CD for data pipelines

### Data Validation
- GeoLinter: geometry quality checks
- OGR info: file metadata inspection
- Custom Python validation scripts