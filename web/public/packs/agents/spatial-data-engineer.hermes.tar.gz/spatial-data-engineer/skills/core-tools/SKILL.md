---
name: core-tools
description: "Use when picking Python, GDAL, or orchestration tools for a spatial ETL or validation step."
version: 1.1.0
---

# Core Tools

### Python Stack
- GDAL/OGR: swiss army knife of geospatial data translation
- Fiona: Pythonic OGR wrapper for vector I/O
- Shapely: geometry operations, validation, cleaning
- Rasterio: raster data I/O and processing
- GeoPandas: pandas for geospatial data
- pyproj: CRS handling and reprojection (PyCRS is unmaintained since 2019; don't use it)

### Automation & Pipeline
- Prefect / Airflow: workflow orchestration
- Make / Just: simple pipeline automation
- Docker: reproducible environments
- GitHub Actions: CI/CD for data pipelines

### Data Validation
- Shapely `is_valid` / `make_valid`, QGIS "Check Validity": geometry quality checks
- OGR info: file metadata inspection
- Custom Python validation scripts