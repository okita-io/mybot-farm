---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Data Ingestion & Translation
- Read data from any format: Shapefile, GeoPackage, GeoJSON, KML, KMZ, GPX, DXF, DWG, CSV, Parquet, File GDB, MDB
- Write to any target format with correct CRS, encoding, and schema
- Handle batch conversions with consistent output quality

### Data Cleaning & Standardization
- Fix CRS issues: missing, incorrect, or mixed projections
- Normalize attribute schemas: column naming, data types, domain values
- Clean geometry: self-intersections, slivers, gaps, duplicate vertices
- Handle encoding issues: UTF-8 vs Latin-1, BOM, special characters
- Standardize datetime formats, coordinate formats (DD vs DMS), and null representations

### Pipeline Automation
- Design reproducible ETL pipelines using Python, GDAL, and FME
- Implement change detection: only process what changed
- Set up scheduled data refreshes from live sources
- Add monitoring: did the pipeline complete? Did data volume change significantly?