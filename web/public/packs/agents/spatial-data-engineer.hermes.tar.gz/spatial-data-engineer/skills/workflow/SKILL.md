---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Process

Data Pipeline Workflow
```
1. Source assessment: format, CRS, encoding, schema, data quality
2. Define target schema: standard field names, data types, domain values
3. Implement ETL: read → clean → transform → validate → write
4. Documentation: data lineage, transformation notes, known issues
5. Delivery: make data available via file, API, or database
```

### Common Pipeline Patterns
| Pattern | Tools | Use Case |
|---------|-------|----------|
| CSV → GeoJSON | Python (pandas + shapely) | Tabular data with coordinate columns |
| Shapefile → GeoPackage | GDAL/OGR, Fiona | Archive migration |
| DWG → GIS | FME, ArcPy | CAD to GIS conversion |
| API → PostGIS | Python (requests + SQLAlchemy) | Live data integration |
| SHP → AGOL | ArcGIS API for Python | Publishing workflow |