---
name: inventory-management-strategies
description: "Use when the task matches this agent's inventory management strategies work."
version: 1.0.0
---

# Inventory Management Strategies

Inventory Model Selection

```python
import numpy as np
from dataclasses import dataclass
from typing import Optional

@dataclass
class InventoryParameters:
    annual_demand: float       # Annual demand quantity
    order_cost: float          # Cost per order
    holding_cost_rate: float   # Inventory holding cost rate (percentage of unit price)
    unit_price: float          # Unit price
    lead_time_days: int        # Procurement lead time (days)
    demand_std_dev: float      # Demand standard deviation
    service_level: float       # Service level (e.g., 0.95 for 95%)

class InventoryManager:
    def __init__(self, params: InventoryParameters):
        self.params = params

    def calculate_eoq(self) -> float:
        """
        Calculate Economic Order Quantity (EOQ)
        EOQ = sqrt(2 * D * S / H)
        """
        d = self.params.annual_demand
        s = self.params.order_cost
        h = self.params.unit_price * self.params.holding_cost_rate
        eoq = np.sqrt(2 * d * s / h)
        return round(eoq)

    def calculate_safety_stock(self) -> float:
        """
        Calculate safety stock
        SS = Z * sigma_dLT
        Z: Z-value corresponding to the service level
        sigma_dLT: Standard deviation of demand during lead time
        """
        from scipy.stats import norm
        z = norm.ppf(self.params.service_level)
        lead_time_factor = np.sqrt(self.params.lead_time_days / 365)
        sigma_dlt = self.params.demand_std_dev * lead_time_factor
# … truncated for farm planting — see upstream for the full sample
```

### Inventory Management Model Comparison

- **JIT (Just-In-Time)**: Best for stable demand with nearby suppliers — reduces holding costs but requires extremely reliable supply chains
- **VMI (Vendor-Managed Inventory)**: Supplier handles replenishment — suitable for standard parts and bulk materials, reducing the buyer's inventory burden
- **Consignment**: Pay after consumption, not on receipt — suitable for new product trials or high-value materials
- **Safety Stock + ROP**: The most universal model, suitable for most companies — the key is setting parameters correctly