---
name: risk-management-framework
description: "Use when the task matches this agent's risk management framework work."
version: 1.0.0
---

# Risk Management Framework

Supply Chain Risk Assessment

```python
class SupplyChainRiskManager:
    """
    Supply chain risk identification, assessment, and response
    """

    RISK_CATEGORIES = {
        'supply_disruption_risk': {
            'indicators': ['Supplier concentration', 'Single-source material ratio', 'Supplier financial health'],
            'mitigation': ['Multi-source procurement strategy', 'Safety stock reserves', 'Alternative supplier development']
        },
        'quality_risk': {
            'indicators': ['Incoming defect rate trend', 'Customer complaint rate', 'Quality system certification status'],
            'mitigation': ['Strengthen incoming inspection', 'Supplier quality improvement plan', 'Quality traceability system']
        },
        'price_volatility_risk': {
            'indicators': ['Commodity price index', 'Currency fluctuation range', 'Supplier price increase warnings'],
            'mitigation': ['Long-term price-lock contracts', 'Futures/options hedging', 'Alternative material reserves']
        },
        'geopolitical_risk': {
            'indicators': ['Trade policy changes', 'Tariff adjustments', 'Export control lists'],
            'mitigation': ['Supply chain diversification', 'Nearshoring/friendshoring', 'Domestic substitution plans (国产替代)']
        },
        'logistics_risk': {
            'indicators': ['Capacity tightness index', 'Port congestion level', 'Extreme weather warnings'],
            'mitigation': ['Multimodal transport solutions', 'Advance stocking', 'Regional warehousing strategy']
        }
    }

    def risk_assessment(self, supplier_data: dict) -> dict:
        """
        Comprehensive supplier risk assessment
        """
        risk_scores = {}

        # Supply concentration risk
        if supplier_data.get('spend_share', 0) > 0.3:
            risk_scores['concentration_risk'] = 'High'
        elif supplier_data.get('spend_share', 0) > 0.15:
            risk_scores['concentration_risk'] = 'Medium'
        else:
# … truncated for farm planting — see upstream for the full sample
```

### Multi-Source Procurement Strategy

- **Core principle**: Critical materials require at least 2 qualified suppliers; strategic materials require at least 3
- **Volume allocation**: Primary supplier 60-70%, backup supplier 20-30%, development supplier 5-10%
- **Dynamic adjustment**: Adjust allocations based on quarterly performance reviews — reward top performers, reduce allocations for underperformers
- **Domestic substitution** (国产替代): Proactively develop domestic alternatives for imported materials affected by export controls or geopolitical risks