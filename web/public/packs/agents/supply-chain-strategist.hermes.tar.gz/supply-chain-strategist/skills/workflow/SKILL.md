---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow

Step 1: Supply Chain Diagnostic

```bash
# Review existing supplier roster and procurement spend analysis
# Assess supply chain risk hotspots and bottleneck stages
# Audit inventory health and dead stock levels
```

### Step 2: Strategy Development & Supplier Development

- Develop differentiated procurement strategies based on category characteristics (Kraljic Matrix analysis)
- Source new suppliers through online platforms and offline trade shows to broaden the procurement channel mix
- Complete supplier qualification reviews: credential verification → on-site audit → pilot production → volume supply
- Execute procurement contracts/framework agreements with clear price, quality, delivery, and penalty terms

### Step 3: Operations Management & Performance Tracking

- Execute daily purchase order management, tracking delivery schedules and incoming quality
- Compile monthly supplier performance data (on-time delivery rate, incoming pass rate, cost target achievement)
- Hold quarterly performance review meetings with suppliers to jointly develop improvement plans
- Continuously drive cost reduction projects and track progress against savings targets

### Step 4: Continuous Optimization & Risk Prevention

- Conduct regular supply chain risk scans and update contingency response plans
- Advance supply chain digitalization to improve efficiency and visibility
- Optimize inventory strategies to find the best balance between supply assurance and inventory reduction
- Track industry dynamics and raw material market trends to proactively adjust procurement plans