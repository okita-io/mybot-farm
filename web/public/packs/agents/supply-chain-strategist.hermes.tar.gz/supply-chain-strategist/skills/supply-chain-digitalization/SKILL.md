---
name: supply-chain-digitalization
description: "Use when the task matches this agent's supply chain digitalization work."
version: 1.0.0
---

# Supply Chain Digitalization

ERP & Procurement Systems

```python
class SupplyChainDigitalization:
    """
    Supply chain digital maturity assessment and roadmap planning
    """

    # Comparison of major ERP systems in China
    ERP_SYSTEMS = {
        'SAP': {
            'target': 'Large conglomerates / foreign-invested enterprises',
            'modules': ['MM (Materials Management)', 'PP (Production Planning)', 'SD (Sales & Distribution)', 'WM (Warehouse Management)'],
            'cost': 'Starting from millions of RMB',
            'implementation': '6-18 months',
            'strength': 'Comprehensive functionality, rich industry best practices',
            'weakness': 'High implementation cost, complex customization'
        },
        'Yonyou U8+ / YonBIP': {
            'target': 'Mid-to-large private enterprises',
            'modules': ['Procurement Management', 'Inventory Management', 'Supply Chain Collaboration', 'Smart Manufacturing'],
            'cost': 'Hundreds of thousands to millions of RMB',
            'implementation': '3-9 months',
            'strength': 'Strong localization, excellent tax system integration',
            'weakness': 'Less experience with large-scale projects'
        },
        'Kingdee Cloud Galaxy / Cosmic': {
            'target': 'Mid-size growth companies',
            'modules': ['Procurement Management', 'Warehousing & Logistics', 'Supply Chain Collaboration', 'Quality Management'],
            'cost': 'Hundreds of thousands to millions of RMB',
            'implementation': '2-6 months',
            'strength': 'Fast SaaS deployment, excellent mobile experience',
            'weakness': 'Limited deep customization capability'
        }
    }

    # SRM procurement management systems
    SRM_PLATFORMS = {
        'ZhenYun (甄云科技)': 'Full-process digital procurement, ideal for manufacturing',
        'QiQiTong (企企通)': 'Supplier collaboration platform, focused on SMEs',
        'ZhuJiCai (筑集采)': 'Specialized procurement platform for the construction industry',
        'Yonyou Procurement Cloud (用友采购云)': 'Deep integration with Yonyou ERP',
        'SAP Ariba': 'Global procurement network, ideal for multinational enterprises'
# … truncated for farm planting — see upstream for the full sample
```