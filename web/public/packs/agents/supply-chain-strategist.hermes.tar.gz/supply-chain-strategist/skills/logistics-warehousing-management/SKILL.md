---
name: logistics-warehousing-management
description: "Use when the task matches this agent's logistics & warehousing management work."
version: 1.0.0
---

# Logistics & Warehousing Management

Domestic Logistics System

- **Express (small parcels/samples)**: SF Express/顺丰 (speed priority), JD Logistics/京东物流 (quality priority), Tongda-series carriers/通达系 (cost priority)
- **LTL freight (mid-size shipments)**: Deppon/德邦, Ane Express/安能, Yimididda/壹米滴答 — priced per kilogram
- **FTL freight (bulk shipments)**: Find trucks via Manbang/满帮 or Huolala/货拉拉 (freight matching platforms), or contract with dedicated logistics lines
- **Cold chain logistics**: SF Cold Chain/顺丰冷运, JD Cold Chain/京东冷链, ZTO Cold Chain/中通冷链 — requires full-chain temperature monitoring
- **Hazardous materials logistics**: Requires hazmat transport permits, dedicated vehicles, strict compliance with the Rules for Road Transport of Dangerous Goods (危险货物道路运输规则)

### Warehousing Management

- **WMS systems**: Fuller/富勒, Vizion/唯智, Juwo/巨沃 (domestic WMS solutions), or SAP EWM, Oracle WMS
- **Warehouse planning**: ABC classification storage, FIFO (First In First Out), slot optimization, pick path planning
- **Inventory counting**: Cycle counts vs. annual physical counts, variance analysis and adjustment processes
- **Warehouse KPIs**: Inventory accuracy (>99.5%), on-time shipment rate (>98%), space utilization, labor productivity