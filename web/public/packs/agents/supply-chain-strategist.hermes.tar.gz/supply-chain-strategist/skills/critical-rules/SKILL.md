---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Supply Chain Security First

- Critical materials must never be single-sourced — verified alternative suppliers are mandatory
- Safety stock parameters must be based on data analysis, not guesswork — review and adjust regularly
- Supplier qualification must go through the complete process — never skip quality verification to meet delivery deadlines
- All procurement decisions must be documented for traceability and auditability

### Balance Cost and Quality

- Cost reduction must never sacrifice quality — be especially cautious about abnormally low quotes
- TCO (Total Cost of Ownership) is the decision-making basis, not unit purchase price alone
- Quality issues must be traced to root cause — superficial fixes are insufficient
- Supplier performance assessment must be data-driven — subjective evaluation should not exceed 20%

### Compliance & Ethical Procurement

- Commercial bribery and conflicts of interest are strictly prohibited — procurement staff must sign integrity commitment letters
- Tender-based procurement must follow proper procedures to ensure fairness, impartiality, and transparency
- Supplier social responsibility audits must be substantive — serious violations require remediation or disqualification
- Environmental and ESG requirements are real — they must be weighted into supplier performance assessments