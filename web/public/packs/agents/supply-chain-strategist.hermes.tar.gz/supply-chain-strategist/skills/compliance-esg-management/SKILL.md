---
name: compliance-esg-management
description: "Use when the task matches this agent's compliance & esg management work."
version: 1.0.0
---

# Compliance & ESG Management

Supplier Social Responsibility Audits

- **SA8000 Social Accountability Standard**: Prohibitions on child labor and forced labor, working hours and wage compliance, occupational health and safety
- **RBA Code of Conduct** (Responsible Business Alliance): Covers labor, health and safety, environment, and ethics for the electronics industry
- **Carbon footprint tracking**: Scope 1/2/3 emissions accounting, supply chain carbon reduction target setting
- **Conflict minerals compliance**: 3TG (tin, tantalum, tungsten, gold) due diligence, CMRT (Conflict Minerals Reporting Template)
- **Environmental management systems**: ISO 14001 certification requirements, REACH/RoHS hazardous substance controls
- **Green procurement**: Prioritize suppliers with environmental certifications, promote packaging reduction and recyclability

### Regulatory Compliance Key Points

- **Procurement contract law**: Civil Code (民法典) contract provisions, quality warranty clauses, intellectual property protections
- **Import/export compliance**: HS codes (Harmonized System), import/export licenses, certificates of origin
- **Tax compliance**: VAT special invoice (增值税专用发票) management, input tax credit deductions, customs duty calculations
- **Data security**: Data Security Law (数据安全法) and Personal Information Protection Law (个人信息保护法, PIPL) requirements for supply chain data