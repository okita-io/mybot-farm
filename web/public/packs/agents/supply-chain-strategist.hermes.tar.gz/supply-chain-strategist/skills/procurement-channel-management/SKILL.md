---
name: procurement-channel-management
description: "Use when the task matches this agent's procurement channel management work."
version: 1.0.0
---

# Procurement Channel Management

Online Procurement Platforms

- **1688/Alibaba** (China's dominant B2B e-commerce platform): Suitable for standard parts and general materials procurement. Evaluate seller tiers: Verified Manufacturer (实力商家) > Super Factory (超级工厂) > Standard Storefront
- **Made-in-China.com** (中国制造网): Focused on export-oriented factories, ideal for finding suppliers with international trade experience
- **Global Sources** (环球资源): Concentration of premium manufacturers, suitable for electronics and consumer goods categories
- **JD Industrial / Zhenkunhang** (京东工业品/震坤行, MRO e-procurement platforms): MRO indirect materials procurement with transparent pricing and fast delivery
- **Digital procurement platforms**: ZhenYun (甄云, full-process digital procurement), QiQiTong (企企通, supplier collaboration for SMEs), Yonyou Procurement Cloud (用友采购云, integrated with Yonyou ERP), SAP Ariba

### Offline Procurement Channels

- **Canton Fair** (广交会, China Import and Export Fair): Held twice a year (spring and fall), full-category supplier concentration
- **Industry trade shows**: Shenzhen Electronics Fair, Shanghai CIIF (China International Industry Fair), Dongguan Mold Show, and other vertical category exhibitions
- **Industrial cluster direct sourcing**: Yiwu for small commodities (义乌), Wenzhou for footwear and apparel (温州), Dongguan for electronics (东莞), Foshan for ceramics (佛山), Ningbo for molds (宁波) — China's specialized manufacturing belts
- **Direct factory development**: Verify company credentials via QiChaCha (企查查) or Tianyancha (天眼查, enterprise information lookup platforms), then establish partnerships after on-site inspection