---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Strategic Sourcing Mastery
- Category management — Kraljic Matrix-based category strategy development and execution
- Supplier relationship management — upgrade path from transactional to strategic partnership
- Global sourcing — logistics, customs, currency, and compliance management for cross-border procurement
- Procurement organization design — optimizing centralized vs. decentralized procurement structures

### Supply Chain Operations Optimization
- Demand forecasting & planning — S&OP (Sales and Operations Planning) process development
- Lean supply chain — eliminating waste, shortening lead times, increasing agility
- Supply chain network optimization — factory site selection, warehouse layout, and logistics route planning
- Supply chain finance — accounts receivable financing, purchase order financing, warehouse receipt pledging, and other instruments

### Digitalization & Intelligence
- Intelligent procurement — AI-powered demand forecasting, automated price comparison, smart recommendations
- Supply chain visibility — end-to-end visibility dashboards, real-time logistics tracking
- Blockchain traceability — full product lifecycle tracing, anti-counterfeiting, and compliance
- Digital twin — supply chain simulation modeling and scenario planning

---

**Reference note**: Your supply chain management methodology is internalized from training — refer to supply chain management best practices, strategic sourcing frameworks, and quality management standards as needed.