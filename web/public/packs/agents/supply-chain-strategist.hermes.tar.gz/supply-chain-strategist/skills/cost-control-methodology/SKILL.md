---
name: cost-control-methodology
description: "Use when the task matches this agent's cost control methodology work."
version: 1.0.0
---

# Cost Control Methodology

TCO (Total Cost of Ownership) Analysis

- **Direct costs**: Unit purchase price, tooling/mold fees, packaging costs, freight
- **Indirect costs**: Inspection costs, incoming defect losses, inventory holding costs, administrative costs
- **Hidden costs**: Supplier switching costs, quality risk costs, delivery delay losses, coordination overhead
- **Full lifecycle costs**: Usage and maintenance costs, disposal and recycling costs, environmental compliance costs

### Cost Reduction Strategy Framework

```markdown
## Cost Reduction Strategy Matrix

### Short-Term Savings (0-3 months to realize)
- **Commercial negotiation**: Leverage competitive quotes for price reduction, negotiate payment term improvements (e.g., Net 30 → Net 60)
- **Consolidated purchasing**: Aggregate similar requirements to leverage volume discounts (typically 5-15% savings)
- **Payment term optimization**: Early payment discounts (2/10 net 30), or extended terms to improve cash flow

### Mid-Term Savings (3-12 months to realize)
- **VA/VE (Value Analysis / Value Engineering)**: Analyze product function vs. cost, optimize design without compromising functionality
- **Material substitution**: Find lower-cost alternative materials with equivalent performance (e.g., engineering plastics replacing metal parts)
- **Process optimization**: Jointly improve manufacturing processes with suppliers to increase yield and reduce processing costs
- **Supplier consolidation**: Reduce supplier count, concentrate volume with top suppliers in exchange for better pricing

### Long-Term Savings (12+ months to realize)
- **Vertical integration**: Make-or-buy decisions for critical components
- **Supply chain restructuring**: Shift production to lower-cost regions, optimize logistics networks
- **Joint development**: Co-develop new products/processes with suppliers, sharing cost reduction benefits
- **Digital procurement**: Reduce transaction costs and manual overhead through electronic procurement processes
```