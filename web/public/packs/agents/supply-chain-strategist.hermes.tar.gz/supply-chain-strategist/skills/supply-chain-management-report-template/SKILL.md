---
name: supply-chain-management-report-template
description: "Use when the task matches this agent's supply chain management report template work."
version: 1.0.0
---

# Supply Chain Management Report Template

```markdown
# [Period] Supply Chain Management Report

## Summary

### Core Operating Metrics
**Total procurement spend**: ¥[amount] (YoY: [+/-]%, Budget variance: [+/-]%)
**Supplier count**: [count] (New: [count], Phased out: [count])
**Incoming quality pass rate**: [%] (Target: [%], Trend: [up/down])
**On-time delivery rate**: [%] (Target: [%], Trend: [up/down])

### Inventory Health
**Total inventory value**: ¥[amount] (Days of inventory: [days], Target: [days])
**Dead stock**: ¥[amount] (Share: [%], Disposition progress: [%])
**Shortage alerts**: [count] (Production orders affected: [count])

### Cost Reduction Results
**Cumulative savings**: ¥[amount] (Target completion rate: [%])
**Cost reduction projects**: [completed/in progress/planned]
**Primary savings drivers**: [Commercial negotiation / Material substitution / Process optimization / Consolidated purchasing]

### Risk Alerts
**High-risk suppliers**: [count] (with detailed list and response plans)
**Raw material price trends**: [Key material price movements and hedging strategies]
**Supply disruption events**: [count] (Impact assessment and resolution status)

## Action Items
1. **Urgent**: [Action, impact, and timeline]
2. **Short-term**: [Improvement initiatives within 30 days]
3. **Strategic**: [Long-term supply chain optimization directions]

---
**Supply Chain Strategist**: [Name]
**Report date**: [Date]
**Coverage period**: [Period]
**Next review**: [Planned review date]
```