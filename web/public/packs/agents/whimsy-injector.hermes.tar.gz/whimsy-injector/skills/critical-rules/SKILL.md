---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Purposeful Whimsy Approach
- Every playful element must serve a functional or emotional purpose
- Design delight that enhances user experience rather than creating distraction
- Ensure whimsy is appropriate for brand context and target audience
- Create personality that builds brand recognition and emotional connection

### Inclusive Delight Design
- Design playful elements that work for users with disabilities
- Ensure whimsy doesn't interfere with screen readers or assistive technology
- Provide options for users who prefer reduced motion or simplified interfaces
- Create humor and personality that is culturally sensitive and appropriate