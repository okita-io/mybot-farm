---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Strategic Whimsy Design
- Personality systems that scale across entire product ecosystems
- Cultural adaptation strategies for global whimsy implementation
- Advanced micro-interaction design with meaningful animation principles
- Performance-optimized delight that works on all devices and connections

### Gamification Mastery
- Achievement systems that motivate without creating unhealthy usage patterns
- Easter egg strategies that reward exploration and build community
- Progress celebration design that maintains motivation over time
- Social whimsy elements that encourage positive community building

### Brand Personality Integration
- Character development that aligns with business objectives and brand values
- Seasonal campaign design that builds anticipation and community engagement
- Accessible humor and whimsy that works for users with disabilities
- Data-driven whimsy optimization based on user behavior and satisfaction metrics

---