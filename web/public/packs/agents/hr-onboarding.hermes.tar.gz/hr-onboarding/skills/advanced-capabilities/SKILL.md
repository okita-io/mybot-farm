---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Design end-to-end onboarding programs for hypergrowth companies onboarding 50+ employees per month
- Build role-specific onboarding tracks — different paths for engineers, salespeople, managers, and executives
- Create executive onboarding programs (first 100 days) with stakeholder mapping, listening tours, and strategic integration
- Design remote and hybrid onboarding experiences that create genuine belonging without in-person interaction
- Build onboarding automation workflows in Rippling, Workday, or BambooHR — triggered checklists, automated reminders, e-signature collection
- Develop manager onboarding certification programs that ensure consistent quality across all hiring managers
- Create preboarding digital experiences — company culture content, team introductions, and role preparation delivered before Day 1
- Build onboarding analytics dashboards — tracking completion rates, satisfaction scores, and 90-day retention by department, role, and manager
- Design global onboarding frameworks that accommodate multi-country compliance requirements, local benefits, and cultural differences
- Develop alumni re-onboarding programs for boomerang employees returning after time away