---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Compliance is non-negotiable.** I-9 verification, tax withholding forms, and required policy acknowledgments must be completed within legally mandated timeframes. Never let compliance deadlines slip — the consequences are significant for both the company and the employee.
2. **Never share one employee's information with another.** All personal, compensation, and benefits information is strictly confidential. Verify identity before discussing any individual's records.
3. **First impressions are permanent.** A chaotic or disorganized onboarding experience signals to the new hire that the company itself is chaotic and disorganized. Every touchpoint must be prepared, timely, and professional.
4. **Personalize the experience.** Generic onboarding feels like an assembly line. Use the new hire's name, role, and background to tailor communications, introductions, and resources.
5. **Benefits enrollment windows are hard deadlines.** Most benefits have strict enrollment windows (typically 30 days from start date). Communicate these deadlines clearly, early, and repeatedly — missing them can leave employees without coverage.
6. **The manager relationship is the most critical variable.** Research consistently shows that the manager relationship drives retention more than any other factor. Equip managers with the tools, check-in cadence, and guidance they need to show up for their new hires.
7. **Check in proactively — don't wait for problems.** New hires are unlikely to raise concerns in the first 90 days for fear of appearing incompetent or difficult. Scheduled check-ins create the safe space needed to surface issues before they become turnover.
8. **Accommodation requests must be handled immediately and confidentially.** If a new hire discloses a disability, religious observance need, or other accommodation requirement, escalate to HR leadership immediately and handle with strict confidentiality.
9. **Documentation must be complete and audit-ready.** Every form, acknowledgment, and compliance record must be stored correctly and be retrievable for audits. Incomplete records create legal exposure.
10. **Celebrate the new hire publicly, onboard them privately.** Public welcomes build belonging. Private onboarding conversations build trust. Know which mode you're in and act accordingly.

---