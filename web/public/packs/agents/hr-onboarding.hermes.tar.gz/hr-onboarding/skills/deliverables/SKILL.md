---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Pre-Boarding Checklist

```
PRE-BOARDING CHECKLIST (Before Day 1)
───────────────────────────────────────
2 Weeks Before Start:
  □ Offer letter signed and filed
  □ Background check initiated and cleared
  □ IT equipment ordered (laptop, phone, peripherals)
  □ System access requests submitted (email, Slack, HRIS, role-specific tools)
  □ Workspace prepared (desk, badge, parking if applicable)
  □ Welcome email sent to new hire with Day 1 logistics
  □ Buddy/mentor assigned and briefed
  □ Manager onboarding guide sent to hiring manager
  □ Team notified of new hire's start date and role

1 Week Before Start:
  □ IT equipment confirmed delivered or ready for pickup
  □ All system access confirmed active
  □ Day 1 schedule prepared and sent to new hire
  □ Welcome package prepared (swag, handbook, resources)
  □ First week meetings scheduled (1:1 with manager, team intro, HR orientation)
  □ Payroll setup initiated (direct deposit form sent)
  □ Benefits enrollment portal access confirmed

Day Before Start:
  □ Confirm new hire is still starting (send a warm reminder)
  □ Confirm manager is available and prepared for Day 1
  □ Confirm IT equipment is functional and credentials are ready
  □ Confirm workspace is set up and stocked
```

### Day One Orientation Schedule

```
DAY ONE SCHEDULE TEMPLATE
───────────────────────────────────────
9:00 AM — Welcome & Introduction
  Host: HR / People Ops
  Content:
    - Warm welcome and company overview
    - Mission, vision, and values (story-based, not slide-based)
    - Who's who: leadership team and key contacts
    - Office/remote environment tour

10:00 AM — Administrative & Compliance
  Host: HR
  Content:
    - I-9 verification (must be completed Day 1)
    - W-4 and state tax forms
    - Direct deposit setup
    - Policy acknowledgments (handbook, code of conduct, acceptable use)
    - Benefits overview and enrollment timeline

11:30 AM — IT & Systems Setup
  Host: IT / Manager
  Content:
    - Laptop setup and credential verification
    - Email, Slack, and communication tools
    - Role-specific software and access confirmation
    - Security training overview and password policy

12:30 PM — Welcome Lunch
  Host: Manager + immediate team
  Content: Informal, relationship-building — no work agenda

2:00 PM — Role & Team Orientation
  Host: Hiring Manager
  Content:
    - Team structure and how the team operates
    - Role expectations and initial priorities
    - 30-60-90 day plan introduction
    - Communication norms and meeting cadence

3:30 PM — Buddy Introduction
# … truncated for farm planting — see upstream for the full sample
```

### 30-60-90 Day Onboarding Plan

```
30-60-90 DAY PLAN TEMPLATE
───────────────────────────────────────
DAYS 1-30: LEARN
  Focus: Orientation, relationships, and context
  Goals:
    □ Complete all compliance and benefits enrollment
    □ Meet all immediate team members and key stakeholders
    □ Understand the company's products, customers, and competitive landscape
    □ Learn the tools, systems, and processes used day-to-day
    □ Shadow experienced team members in key workflows
    □ Complete all required compliance training
  Manager check-ins: Weekly 1:1s (minimum 30 minutes)
  HR check-in: End of week 2 and end of month 1
  Success marker: "I understand what this company does, how my team operates,
                   and what success looks like in my role."

DAYS 31-60: CONTRIBUTE
  Focus: Taking ownership of initial responsibilities
  Goals:
    □ Complete role-specific training and certifications
    □ Take ownership of at least one defined project or responsibility
    □ Build relationships beyond immediate team
    □ Identify one area for improvement or opportunity
    □ Give and receive first formal feedback with manager
  Manager check-ins: Bi-weekly 1:1s
  HR check-in: Mid-point of day 60
  Success marker: "I am contributing independently and have built key
                   relationships across the organization."

DAYS 61-90: ACCELERATE
  Focus: Demonstrating impact and full integration
  Goals:
    □ Deliver measurable results in at least one area
    □ Propose one initiative or improvement based on fresh-eyes perspective
    □ Complete 90-day formal review with manager
    □ Establish ongoing development goals for the next 6 months
    □ Transition from "new hire" to "fully integrated team member"
  Manager check-ins: Bi-weekly 1:1s
  HR check-in: 90-day formal check-in and survey…