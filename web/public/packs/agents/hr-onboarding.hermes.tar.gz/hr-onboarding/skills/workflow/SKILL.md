---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Pre-Boarding Setup

1. **Confirm start date and role details** with hiring manager and HR
2. **Initiate background check** and confirm clearance before start date
3. **Submit IT and system access requests** — allow minimum 5 business days
4. **Assign buddy/mentor** and brief them on their role
5. **Send welcome email** to new hire with Day 1 logistics, parking, dress code, and who to ask for
6. **Send manager onboarding guide** and confirm Day 1 readiness
7. **Prepare compliance documentation** — have all forms ready before Day 1

### Step 2: Day One Execution

1. **Greet the new hire personally** — never let a new hire arrive to an empty desk or a confused receptionist
2. **Complete I-9 verification** — legally required on Day 1
3. **Walk through Day One schedule** — no surprises, no rushing
4. **Complete all compliance forms** before end of Day 1
5. **Confirm IT and system access is working** — test everything before the new hire needs it
6. **Facilitate the buddy introduction** — warm, informal, no agenda
7. **End Day 1 with an HR check-in** — first impressions feedback and open questions

### Step 3: First Week Integration

1. **Confirm benefits enrollment is initiated** and deadline is understood
2. **Facilitate team introductions** — structured enough to be useful, informal enough to be human
3. **Deliver role-specific orientation** — tools, processes, and initial responsibilities
4. **Set up recurring 1:1 cadence** between new hire and manager
5. **Introduce the 30-60-90 day plan** and confirm mutual understanding
6. **Complete end-of-week check-in** — surface any early friction before it compounds

### Step 4: 30-60-90 Day Milestones

1. **Day 14 HR check-in**: How is the transition going? Any concerns?
2. **Day 30 milestone review**: Learning goals met? Compliance complete? Benefits enrolled?
3. **Day 60 mid-point check-in**: Contributing independently? Feedback received?
4. **Day 90 formal review**: Results delivered? Fully integrated? Development goals set?
5. **Flag retention risks immediately** — if a new hire shows signs of disengagement in the first 90 days, escalate to HR leadership and the manager without delay

### Step 5: Transition to Steady State

1. **Confirm all compliance training is complete** and documented
2. **Confirm benefits enrollment is finalized** and confirmed in the system
3. **Transition from onboarding cadence to standard HR support**
4. **Conduct onboarding experience survey** — capture feedback to improve the process
5. **Archive onboarding records** in HRIS — audit-ready and complete

---