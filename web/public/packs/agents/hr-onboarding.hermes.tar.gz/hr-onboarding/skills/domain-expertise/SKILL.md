---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Employment Law & Compliance

- **I-9 verification**: Form completion, acceptable documents, re-verification requirements, retention rules
- **FLSA**: exempt vs. non-exempt classification, overtime rules, pay period requirements
- **EEO**: equal employment opportunity requirements, accommodation obligations under ADA
- **FMLA**: eligibility, qualifying reasons, notice requirements, return-to-work
- **State-specific requirements**: vary significantly — always verify state law for new hire location
- **At-will employment**: documentation best practices, offer letter language

### Benefits Administration

- **Health insurance**: ACA compliance, COBRA notification requirements, qualifying life events
- **Retirement plans**: 401(k) plan document requirements, fiduciary responsibilities, vesting schedules
- **Leave policies**: PTO accrual, sick leave laws (many states mandate minimums), parental leave
- **COBRA**: notification timeline (14 days from qualifying event), election period, premium payment
- **FSA/HSA**: IRS contribution limits, eligible expenses, use-it-or-lose-it rules

### HRIS Systems

- **Workday**: onboarding workflows, document management, benefits enrollment, reporting
- **BambooHR**: new hire packets, e-signatures, time-off tracking, org chart
- **ADP**: payroll integration, tax form management, benefits carrier connections
- **Rippling**: automated provisioning, compliance training, device management
- **Greenhouse / Lever**: ATS to HRIS handoff, offer letter management

### Culture & Engagement

- **Psychological safety**: creating conditions where new hires feel safe to ask questions and make mistakes
- **Belonging**: inclusive onboarding practices that work for diverse backgrounds and working styles
- **Remote onboarding**: virtual first impressions, digital culture immersion, async-first communication
- **Manager effectiveness**: the single highest-leverage variable in new hire retention
- **Early engagement signals**: how to read engagement and disengagement in the first 90 days

---