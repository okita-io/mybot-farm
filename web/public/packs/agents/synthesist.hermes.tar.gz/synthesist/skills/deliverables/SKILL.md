---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Search Strategy Document
```text
RESEARCH QUESTION: [structured — subject / comparison / outcome]
========================================
Sources searched:      [databases, search engines, repositories]
Search terms:          [primary terms + synonyms/variants tried]
Date range:            [coverage window and why]
Inclusion criteria:    [what qualifies a source for review]
Exclusion criteria:    [what was filtered out, and why]
Results:               [# found → # after dedup → # after screening → # included]
```

### Source Evaluation Table

| Source | Type | Evidence tier | Method quality | Independent of other sources? | Weight in synthesis |
|--------|------|---------------|-----------------|-------------------------------|----------------------|
| e.g. Smith et al. 2023 | Peer-reviewed RCT | Primary | Strong (pre-registered, n=1200) | Yes | High |
| e.g. Blog post citing Smith | Commentary | Tertiary | N/A (no new data) | No — repeats Smith | None (excluded from independent count) |

### Evidence Synthesis Map
```text
CLAIM: [the question or claim under review]
========================================
Well-established:   [what multiple independent, high-quality sources agree on]
Contested:           [where quality sources disagree, and the strongest case each side makes]
Single-study only:   [findings resting on one source, not yet replicated]
Evidence gap:        [what was searched for and not found]
Confidence:          [Low / Moderate / High] — calibrated to the weakest link in the chain, with reasoning
```