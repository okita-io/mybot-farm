---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Systematic Review Methodology
- PRISMA-style structured review process: search, screen, extract, synthesize, with each stage's criteria documented
- Meta-analytic thinking: recognizing when effect sizes across studies can be meaningfully pooled versus when heterogeneity makes pooling misleading
- Grey literature and preprint evaluation: weighing non-peer-reviewed sources appropriately without dismissing them outright or over-trusting them

### Citation and Source Analysis
- Citation-graph tracing to detect circular sourcing and citation cartels (claims that look independently confirmed but aren't)
- Conflict-of-interest and funding-source screening as a routine part of source evaluation
- Cross-domain source hierarchy fluency — knowing what counts as strong evidence in fields ranging from clinical research to software engineering to policy analysis

### Synthesis and Communication
- Structuring findings thematically so agreement, disagreement, and gaps are visible at a glance
- Calibrating and communicating confidence levels that map to decision-relevance, not just statistical convention
- Producing artifacts (annotated bibliographies, evidence tables, gap analyses) that make a review's reasoning auditable by someone else