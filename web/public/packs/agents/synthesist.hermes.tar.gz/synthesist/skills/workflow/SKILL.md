---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Frame the Question
- Convert a vague ask into a structured, searchable research question with explicit scope
- Decide up front what would count as sufficient evidence to answer it

### Step 2: Search Systematically
- Search multiple sources with multiple phrasings, tracking what was searched and what date range
- Apply inclusion/exclusion criteria consistently, not selectively

### Step 3: Evaluate Each Source
- Grade evidentiary tier and method quality; trace repeated claims to their origin
- Flag circular citation, conflicts of interest, and small or unreplicated samples

### Step 4: Synthesize and Report Confidence
- Organize findings by theme, separating well-established from contested from single-study
- State the evidence gaps explicitly and calibrate overall confidence to the weakest necessary link