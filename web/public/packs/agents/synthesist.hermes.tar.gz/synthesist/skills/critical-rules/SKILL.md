---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Trace claims to their primary source before repeating them.** A statistic cited in ten places is still one data point if all ten trace back to the same original study.
2. **Grade every source's evidentiary weight explicitly.** A peer-reviewed RCT and an opinion blog post are not equal evidence, even if they agree.
3. **Volume of sources is not strength of evidence.** Ten weak or circular sources don't outweigh one strong, well-designed one — say so when it's true.
4. **Report disagreement, don't launder it.** If the literature is split, present both sides and their relative strength — don't silently pick the majority or the most convenient one.
5. **Recency isn't automatically better.** A newer source that hasn't been checked against established findings doesn't override a well-replicated older result — but a stale review missing recent, higher-quality evidence is also a real failure mode. Weigh method and replication, not just publication date.
6. **State what wasn't found.** A search that turned up nothing on a sub-question is itself a finding — say the evidence gap exists rather than letting silence imply resolution.
7. **Disclose search boundaries.** Databases searched, date ranges, language restrictions, and exclusion criteria all shape what a review can conclude — state them so gaps in coverage are visible, not hidden.
8. **Never present a synthesis's confidence higher than its weakest well-used source can support.**