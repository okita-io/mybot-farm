---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Custom EditorWindow — Asset Auditor
```csharp
public class AssetAuditWindow : EditorWindow
{
    [MenuItem("Tools/Asset Auditor")]
    public static void ShowWindow() => GetWindow<AssetAuditWindow>("Asset Auditor");

    private Vector2 _scrollPos;
    private List<string> _oversizedTextures = new();
    private bool _hasRun = false;

    private void OnGUI()
    {
        GUILayout.Label("Texture Budget Auditor", EditorStyles.boldLabel);

        if (GUILayout.Button("Scan Project Textures"))
        {
            _oversizedTextures.Clear();
            ScanTextures();
            _hasRun = true;
        }

        if (_hasRun)
        {
            EditorGUILayout.HelpBox($"{_oversizedTextures.Count} textures exceed budget.", MessageWarningType());
            _scrollPos = EditorGUILayout.BeginScrollView(_scrollPos);
            foreach (var path in _oversizedTextures)
            {
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField(path, EditorStyles.miniLabel);
                if (GUILayout.Button("Select", GUILayout.Width(55)))
                    Selection.activeObject = AssetDatabase.LoadAssetAtPath<Texture>(path);
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndScrollView();
        }
    }

    private void ScanTextures()
    {
        var guids = AssetDatabase.FindAssets("t:Texture2D");
        int processed = 0;
# … truncated for farm planting — see upstream for the full sample
```

### AssetPostprocessor — Texture Import Enforcer
```csharp
public class TextureImportEnforcer : AssetPostprocessor
{
    private const int MAX_RESOLUTION = 2048;
    private const string NORMAL_SUFFIX = "_N";
    private const string UI_PATH = "Assets/UI/";

    void OnPreprocessTexture()
    {
        var importer = (TextureImporter)assetImporter;
        string path = assetPath;

        // Enforce normal map type by naming convention
        if (System.IO.Path.GetFileNameWithoutExtension(path).EndsWith(NORMAL_SUFFIX))
        {
            if (importer.textureType != TextureImporterType.NormalMap)
            {
                importer.textureType = TextureImporterType.NormalMap;
                Debug.LogWarning($"[TextureImporter] Set '{path}' to Normal Map based on '_N' suffix.");
            }
        }

        // Enforce max resolution budget
        if (importer.maxTextureSize > MAX_RESOLUTION)
        {
            importer.maxTextureSize = MAX_RESOLUTION;
            Debug.LogWarning($"[TextureImporter] Clamped '{path}' to {MAX_RESOLUTION}px max.");
        }

        // UI textures: disable mipmaps and set point filter
        if (path.StartsWith(UI_PATH))
        {
            importer.mipmapEnabled = false;
            importer.filterMode = FilterMode.Point;
        }

        // Set platform-specific compression
        var androidSettings = importer.GetPlatformTextureSettings("Android");
        androidSettings.overridden = true;
        androidSettings.format = importer.textureType == TextureImporterType.NormalMap
            ? TextureImporterFormat.ASTC_4x4
# … truncated for farm planting — see upstream for the full sample
```

### Custom PropertyDrawer — MinMax Range Slider
```csharp
[System.Serializable]
public struct FloatRange { public float Min; public float Max; }

[CustomPropertyDrawer(typeof(FloatRange))]
public class FloatRangeDrawer : PropertyDrawer
{
    private const float FIELD_WIDTH = 50f;
    private const float PADDING = 5f;

    public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
    {
        EditorGUI.BeginProperty(position, label, property);

        position = EditorGUI.PrefixLabel(position, label);

        var minProp = property.FindPropertyRelative("Min");
        var maxProp = property.FindPropertyRelative("Max");

        float min = minProp.floatValue;
        float max = maxProp.floatValue;

        // Min field
        var minRect  = new Rect(position.x, position.y, FIELD_WIDTH, position.height);
        // Slider
        var sliderRect = new Rect(position.x + FIELD_WIDTH + PADDING, position.y,
            position.width - (FIELD_WIDTH * 2) - (PADDING * 2), position.height);
        // Max field
        var maxRect  = new Rect(position.xMax - FIELD_WIDTH, position.y, FIELD_WIDTH, position.height);

        EditorGUI.BeginChangeCheck();
        min = EditorGUI.FloatField(minRect, min);…