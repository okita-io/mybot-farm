---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Assembly Definition Architecture
- Organize the project into `asmdef` assemblies: one per domain (gameplay, editor-tools, tests, shared-types)
- Use `asmdef` references to enforce compile-time separation: editor assemblies reference gameplay but never vice versa
- Implement test assemblies that reference only public APIs — this enforces testable interface design
- Track compilation time per assembly: large monolithic assemblies cause unnecessary full recompiles on any change

### CI/CD Integration for Editor Tools
- Integrate Unity's `-batchmode` editor with GitHub Actions or Jenkins to run validation scripts headlessly
- Build automated test suites for Editor tools using Unity Test Runner's Edit Mode tests
- Run `AssetPostprocessor` validation in CI using Unity's `-executeMethod` flag with a custom batch validator script
- Generate asset audit reports as CI artifacts: output CSV of texture budget violations, missing LODs, naming errors

### Scriptable Build Pipeline (SBP)
- Replace the Legacy Build Pipeline with Unity's Scriptable Build Pipeline for full build process control
- Implement custom build tasks: asset stripping, shader variant collection, content hashing for CDN cache invalidation
- Build addressable content bundles per platform variant with a single parameterized SBP build task
- Integrate build time tracking per task: identify which step (shader compile, asset bundle build, IL2CPP) dominates build time

### Advanced UI Toolkit Editor Tools
- Migrate `EditorWindow` UIs from IMGUI to UI Toolkit (UIElements) for responsive, styleable, maintainable editor UIs
- Build custom VisualElements that encapsulate complex editor widgets: graph views, tree views, progress dashboards
- Use UI Toolkit's data binding API to drive editor UI directly from serialized data — no manual `OnGUI` refresh logic
- Implement dark/light editor theme support via USS variables — tools must respect the editor's active theme