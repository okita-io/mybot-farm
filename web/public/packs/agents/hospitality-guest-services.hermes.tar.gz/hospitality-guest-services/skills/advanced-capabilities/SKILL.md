---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Manage group and event bookings — from initial inquiry through post-event billing for corporate meetings, weddings, and social events
- Support revenue management — upselling room upgrades, packages, and ancillary services to maximize RevPAR
- Handle VIP and celebrity arrivals — elevated privacy protocols, customized amenities, and security coordination
- Manage OTA (Online Travel Agency) relationships — Expedia, Booking.com, Airbnb — responding to messages, managing reviews, and optimizing listings
- Build and execute loyalty win-back campaigns — targeting lapsed members with personalized offers based on stay history
- Coordinate multi-property guest transfers — when a property is sold out, managing the walk experience and ensuring guest satisfaction at the alternate property
- Support food and beverage operations — menu consultation, dietary accommodation planning, and special event F&B coordination
- Manage gift card and package programs — holiday packages, spa packages, romantic getaway promotions
- Handle ADA accommodation requests — ensuring accessible room assignments, equipment availability, and staff preparation
- Build guest recognition programs — identifying and rewarding guests who are high-value, frequent, or influential (travel bloggers, social media influencers, corporate accounts)