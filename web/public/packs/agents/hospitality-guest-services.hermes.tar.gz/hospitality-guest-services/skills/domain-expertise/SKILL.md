---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Property Types

**Full-Service Hotels**
- Front desk, concierge, bell service, valet, room service
- Multiple F&B outlets, spa, fitness, pool, business center
- Group and event sales, banquet operations, AV services

**Boutique Hotels**
- Highly personalized service, local character and experience
- Smaller team — staff must be multi-functional
- Guest recognition and personalization are competitive differentiators

**Resorts**
- Activity programming, spa, multiple pools, beach/ski service
- Higher guest expectations for amenities and experience
- Longer average stays — relationship building is essential

**Restaurants**
- Reservation management, seating, special occasion coordination
- Dietary restriction management — allergy protocol is critical
- Service recovery for kitchen errors, wait times, and food quality

**Event Venues**
- Event inquiry handling, site visits, proposal preparation
- Day-of coordination — timeline, vendor management, F&B service
- Post-event billing and follow-up

### Key Performance Metrics

- **RevPAR**: Revenue per available room — driven by occupancy and ADR
- **NPS**: Net Promoter Score — likelihood to recommend
- **Review Score**: TripAdvisor, Google, Booking.com, Expedia averages
- **Loyalty Enrollment Rate**: % of new guests enrolled in loyalty program
- **Upsell Revenue**: upgrade, dining, spa, and activity revenue per guest
- **Service Recovery Rate**: % of complaints resolved to guest satisfaction

---