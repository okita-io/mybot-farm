---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Reservation Management

```
RESERVATION CONFIRMATION TEMPLATE
───────────────────────────────────────
Dear [Guest Name],

Thank you for choosing [Property Name]. We look forward to
welcoming you!

YOUR RESERVATION DETAILS
───────────────────────────────────────
Confirmation #:     [Number]
Check-in:           [Date] after [Time]
Check-out:          [Date] by [Time]
Room Type:          [Room description]
Guests:             [Number of adults / children]
Rate:               $[Amount] per night + taxes and fees
Total Estimated:    $[Amount]

SPECIAL REQUESTS CONFIRMED
───────────────────────────────────────
[ ] [Special request 1]
[ ] [Special request 2]
Note: Special requests are subject to availability and cannot
be guaranteed. We will do our best to accommodate your needs.

YOUR STAY INCLUDES
───────────────────────────────────────
[ ] Complimentary breakfast
[ ] Parking (self / valet): $[Amount] per night
[ ] WiFi: Complimentary / $[Amount] per day
[ ] [Other inclusions]

CANCELLATION POLICY
───────────────────────────────────────
[Policy description — free cancellation until X / non-refundable]

ARRIVAL INFORMATION
───────────────────────────────────────
Address:    [Property address]
Parking:    [Instructions]
Check-in:   [Location / process]
# … truncated for farm planting — see upstream for the full sample
```

### Pre-Arrival Communication

```
PRE-ARRIVAL TOUCHPOINT — 48 HOURS BEFORE CHECK-IN
───────────────────────────────────────
Subject: "We're getting ready for your arrival, [First Name]!"

Dear [Guest Name],

We're looking forward to welcoming you to [Property Name]
in just [X] days!

YOUR ARRIVAL DETAILS
───────────────────────────────────────
Check-in:   [Date] | Earliest check-in: [Time]
Room:       [Room type]
Confirmation: [Number]

BEFORE YOU ARRIVE
───────────────────────────────────────
[ ] Online check-in available: [Link] (saves time at the desk)
[ ] Digital key available: Download [App name] before arrival
[ ] Parking: [Instructions and rate]
[ ] Early check-in: Available from [Time] — $[Amount] / complimentary
    for [Loyalty tier] members

PERSONALIZED FOR YOUR STAY
───────────────────────────────────────
[If special occasion flagged:]
We noticed you're celebrating [anniversary/birthday]!
We have a small surprise waiting for you. 🎉

[If loyalty member:]
Welcome back, [Loyalty Tier] member! As our thanks for
your loyalty, we've arranged [upgrade / amenity / benefit].

[If dining reservation:]
Your dinner reservation at [Restaurant] is confirmed for
[Date] at [Time]. We'll see you there!

ANYTHING WE CAN DO BEFORE YOU ARRIVE?
───────────────────────────────────────
Reply to this message or call [Phone] — we'd love to make
# … truncated for farm planting — see upstream for the full sample
```

### Check-In Excellence Guide

```
CHECK-IN PROTOCOL
───────────────────────────────────────
BEFORE THE GUEST ARRIVES
  [ ] Pull reservation and review notes
  [ ] Check loyalty status and stay history
  [ ] Confirm special requests with housekeeping
  [ ] Pre-assign room based on preferences and availability
  [ ] Flag any special occasions — birthday, anniversary, honeymoon
  [ ] Prepare upgrade if available and appropriate
  [ ] Review any prior complaints or service notes

GREETING (within 30 seconds of approach)
  "Welcome to [Property Name]! [For returns: Welcome back!]
  How are you doing today? May I get your name to pull up
  your reservation?"

  Body language: Eye contact, genuine smile, stand up/step forward
  Never: Look down at computer before acknowledging the guest

LOYALTY RECOGNITION (always, every time)
  "[Loyalty tier] member — thank you so much for your loyalty
  to [Brand]. It's always a pleasure to have you with us."

  If top tier: "As a [Elite tier] member, we've arranged
  [specific benefit] for you during your stay."

ROOM ASSIGNMENT & UPGRADE
  Standard: "[Room type] on the [floor] floor — it has
  [notable feature]."

  Upgrade: "I'm pleased to offer you a complimentary upgrade
  to our [room type] — it features [specific highlights].
  I think you'll really enjoy it."

  Never: Describe a room as "standard" or "basic"
  Always: Name a specific, appealing feature of the room

SPECIAL REQUEST CONFIRMATION
  "I have noted [special request] for your stay. [Status:
  confirmed / we'll do our best / ready in your room]."
# … truncated for farm planting — see upstream for the full sample
```

### Complaint Resolution Framework

```
SERVICE RECOVERY PROTOCOL…