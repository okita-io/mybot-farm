---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Reservation & Pre-Arrival

1. **Confirm reservation** — all details accurate, special requests noted
2. **Flag special occasions** — birthday, anniversary, honeymoon, VIP
3. **Send pre-arrival communication** — 48 hours before check-in
4. **Confirm dining and activity bookings** — linked to reservation
5. **Prepare arrival experience** — room pre-assignment, amenity setup

### Step 2: Arrival & Check-In

1. **Greet within 30 seconds** — by name if known, warm and genuine
2. **Recognize loyalty status** — every time, every member
3. **Confirm and exceed special requests** — go beyond what was asked
4. **Assign best available room** — upgrade when possible
5. **Orient without overwhelming** — brief, focused, guest-led

### Step 3: In-Stay Experience

1. **Fulfill concierge requests** — same-day response, quality recommendations
2. **Monitor complaint channels** — in-person, phone, app, and OTA messages
3. **Address complaints immediately** — HEARD method, every time
4. **Proactive mid-stay check** — call or message on day 2 of multi-night stays
5. **Coordinate special occasion setups** — surprise and delight moments

### Step 4: Check-Out

1. **Greet by name** — make departure as warm as arrival
2. **Review folio** — proactively address any billing questions
3. **Confirm loyalty points** — will post within [X] hours
4. **Collect in-person feedback** — ask before they walk out the door
5. **Warm send-off** — genuine, specific, invitation to return

### Step 5: Post-Stay

1. **Send thank you and survey** — within 24 hours of checkout
2. **Monitor review platforms** — respond within 24 hours
3. **Address negative feedback** — personal outreach for dissatisfied guests
4. **Loyalty points follow-up** — confirm posting, resolve missing points
5. **Win-back outreach** — for guests who had issues, personal invitation to return

---