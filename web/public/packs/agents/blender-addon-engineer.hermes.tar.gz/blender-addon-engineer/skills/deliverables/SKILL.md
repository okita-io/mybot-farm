---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Asset Validator Operator
```python
import bpy

class PIPELINE_OT_validate_assets(bpy.types.Operator):
    bl_idname = "pipeline.validate_assets"
    bl_label = "Validate Assets"
    bl_description = "Check naming, transforms, and material slots before export"

    def execute(self, context):
        issues = []
        for obj in context.selected_objects:
            if obj.type != "MESH":
                continue

            if obj.name != obj.name.strip():
                issues.append(f"{obj.name}: leading/trailing whitespace in object name")

            if any(abs(s - 1.0) > 0.0001 for s in obj.scale):
                issues.append(f"{obj.name}: unapplied scale")

            if len(obj.material_slots) == 0:
                issues.append(f"{obj.name}: missing material slot")

        if issues:
            self.report({'WARNING'}, f"Validation found {len(issues)} issue(s). See system console.")
            for issue in issues:
                print("[VALIDATION]", issue)
            return {'CANCELLED'}

        self.report({'INFO'}, "Validation passed")
        return {'FINISHED'}
```

### Export Preset Panel
```python
class PIPELINE_PT_export_panel(bpy.types.Panel):
    bl_label = "Pipeline Export"
    bl_idname = "PIPELINE_PT_export_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Pipeline"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.prop(scene, "pipeline_export_path")
        layout.prop(scene, "pipeline_target", text="Target")
        layout.operator("pipeline.validate_assets", icon="CHECKMARK")
        layout.operator("pipeline.export_selected", icon="EXPORT")


class PIPELINE_OT_export_selected(bpy.types.Operator):
    bl_idname = "pipeline.export_selected"
    bl_label = "Export Selected"

    def execute(self, context):
        export_path = context.scene.pipeline_export_path
        bpy.ops.export_scene.gltf(
            filepath=export_path,
            use_selection=True,
            export_apply=True,
            export_texcoords=True,
            export_normals=True,
        )
        self.report({'INFO'}, f"Exported selection to {export_path}")
        return {'FINISHED'}
```

### Naming Audit Report
```python
def build_naming_report(objects):
    report = {"ok": [], "problems": []}
    for obj in objects:
        if "." in obj.name and obj.name[-3:].isdigit():
            report["problems"].append(f"{obj.name}: Blender duplicate suffix detected")
        elif " " in obj.name:
            report["problems"].append(f"{obj.name}: spaces in name")
        else:
            report["ok"].append(obj.name)
    return report
```

### Deliverable Examples
- Blender add-on scaffold with `AddonPreferences`, custom operators, panels, and property groups
- asset validation checklist for naming, transforms, origins, material slots, and collection placement
- engine handoff exporter for FBX, glTF, or USD with repeatable preset rules

### Validation Report Template
```markdown
# Asset Validation Report — [Scene or Collection Name]

## Summary
- Objects scanned: 24
- Passed: 18
- Warnings: 4
- Errors: 2

## Errors
| Object | Rule | Details | Suggested Fix |
|---|---|---|---|
| SM_Crate_A | Transform | Unapplied scale on X axis | Review scale, then apply intentionally |
| SM_Door Frame | Materials | No material assigned | Assign default material or correct slot mapping |

## Warnings
| Object | Rule | Details | Suggested Fix |
|---|---|---|---|
| SM_Wall Panel | Naming | Contains spaces | Replace spaces with underscores |
| SM_Pipe.001 | Naming | Blender duplicate suffix detected | Rename to deterministic production name |
```