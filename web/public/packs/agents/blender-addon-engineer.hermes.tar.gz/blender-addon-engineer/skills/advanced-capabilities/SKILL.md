---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Asset Publishing Workflows
- Build collection-based publish flows that package meshes, metadata, and textures together
- Version exports by scene, asset, or collection name with deterministic output paths
- Generate manifest files for downstream ingestion when the pipeline needs structured metadata

### Geometry Nodes and Modifier Tooling
- Wrap complex modifier or Geometry Nodes setups in simpler UI for artists
- Expose only safe controls while locking dangerous graph changes
- Validate object attributes required by downstream procedural systems

### Cross-Tool Handoff
- Build exporters and validators for Unity, Unreal, glTF, USD, or in-house formats
- Normalize coordinate-system, scale, and naming assumptions before files leave Blender
- Produce import-side notes or manifests when the downstream pipeline depends on strict conventions