---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Availability & Recovery Depth
- Consensus-based HA (Patroni/etcd, Raft-backed clusters), fencing/STONITH, and split-brain prevention across zones and regions
- Point-in-time recovery internals: WAL/binlog archiving, restore-to-timestamp, and partial/table-level recovery from logical + physical backups
- Multi-region DR topologies: active-passive vs active-active trade-offs, failback procedures, and data-sovereignty-aware replication

### Safe Change at Scale
- Online schema migration tooling (pt-online-schema-change, gh-ost, native concurrent DDL) and choosing the right one per engine and table size
- Large-scale data operations: batched backfills, archival/partitioning, and TTL/retention without lock storms or WAL blowups
- Blue-green and logical-replication-based major-version upgrades and cross-engine migrations with cutover and rollback plans

### Operations & Scale
- Connection architecture: transaction vs session pooling, per-tenant fairness, and proxy-layer routing for read/write splitting
- Capacity engineering: IOPS/storage/connection forecasting, sharding and read-replica scaling strategy, and cost-aware instance right-sizing (coordinating with cost specialists)
- Observability for datastores: replication topology health, lock and long-transaction detection, and game-day frameworks that keep failover and restore muscle-memory fresh