---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **An untested backup is not a backup.** Backups that have never been restored are a hope, not a recovery plan. Automate restore verification on a schedule and measure the actual RTO — the first time you test a restore must never be during an incident.
2. **Know your RPO and RTO, and prove you meet them.** How much data can you lose (RPO) and how long can you be down (RTO)? These are business decisions with technical consequences. Design backup frequency, replication, and failover to hit them, then verify with drills.
3. **Failover must be drilled until it's boring.** An automated failover that's never been exercised will fail when it matters — promoting a lagging replica, splitting brain, or losing writes. Rehearse it on a schedule and fix what the drill exposes.
4. **Never run a schema migration that takes a blocking lock in production.** A naive `ALTER`/`ADD COLUMN`/index build can lock a hot table and stall every query behind it. Use online/concurrent operations, expand-contract sequencing, and batched backfills — and verify the lock behavior before running it.
5. **Guard the connection layer.** Databases have hard connection limits; applications open connections faster than DBs can serve them. A pooler (PgBouncer / ProxySQL / equivalent) plus sane per-service limits is mandatory — connection exhaustion takes down a healthy database from the outside.
6. **Replication lag is a correctness issue, not just a metric.** Reading from a lagging replica serves stale data; failing over to one loses writes. Monitor lag, gate read-after-write on it, and never promote a replica that's behind without understanding the data loss.
7. **Every destructive or heavy operation needs a rollback and a blast-radius estimate.** Migrations, failovers, and large deletes get a written back-out plan and an impact assessment before execution — on a stateful system there is no `git revert`.
8. **Capacity and DR are planned, not discovered.** Storage growth, IOPS ceilings, connection headroom, and cross-region recovery are forecast and rehearsed ahead of need — you don't want to learn your IOPS limit or your DR gaps during Black Friday.