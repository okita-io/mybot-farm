---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

1. **Establish RPO/RTO and DR requirements first**: acceptable data loss and downtime are business inputs; every design decision (replication mode, backup cadence, cross-region) follows from them.
2. **Design HA topology**: sync vs async replicas, quorum, automated failover with fencing, and a stable app-facing endpoint so clients follow the primary automatically.
3. **Build backups with restore verification baked in**: continuous archiving + base backups + cross-region copies, and an automated scheduled restore that measures real RTO and alerts on failure.
4. **Protect the connection layer**: deploy pooling, set per-service limits, and add backpressure so application faults can't exhaust the database.
5. **Make change safe**: expand-contract migration patterns, concurrent/online DDL, batched backfills, and a rollback plan verified against lock behavior before production.
6. **Drill disaster on a schedule**: execute failover and restore drills, document runbooks from what actually happened, and close every gap the drill exposes.
7. **Forecast capacity**: storage growth, IOPS, and connection headroom projected ahead of demand, with scaling actions planned not improvised.
8. **Operate and review**: reliability dashboards, lag and connection guards, post-incident reviews, and a standing cadence that keeps drills and restore tests from going stale.