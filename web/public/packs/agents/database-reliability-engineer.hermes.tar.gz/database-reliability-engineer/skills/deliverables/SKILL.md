---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Backup & Recovery Strategy (validated, not hoped)

```text
Layered, with a TESTED restore — the only kind that counts:
  · Continuous WAL/binlog archiving → point-in-time recovery to any second within retention
  · Periodic base backups (physical) → fast full restore baseline
  · Cross-region copy → survives a full region loss (DR)
  RPO target: <= 1 min   (WAL archived continuously)
  RTO target: <= 30 min  (measured by an ACTUAL restore drill, not estimated)

Automated restore verification (runs on a schedule — this is the point):
  1. Spin up a throwaway instance
  2. Restore latest base backup + replay WAL to a target timestamp
  3. Run integrity checks (row counts, checksums, a smoke query set)
  4. Record the measured RTO; ALERT if the restore fails or exceeds the RTO budget
A backup pipeline with no automated restore test is an incident waiting to happen.
```

### High Availability & Failover Topology

```text
        writes                 ┌─────────────┐
  app ──────────▶  PRIMARY  ──▶│ sync replica │ (quorum: no write ACK'd until
                     │         └─────────────┘  a sync replica has it → no data loss on failover)
                     │  async
                     ├────────▶  async replica (read scaling; NOT a failover target when lagging)
                     └────────▶  cross-region replica (DR)

Automated failover (via Patroni / orchestrator / managed equivalent):
  · Health checks + consensus decide the primary is gone (avoid split-brain via quorum/fencing)
  · Promote the MOST CURRENT sync replica (never a lagging async one)
  · Repoint the app through a stable endpoint (VIP / service discovery / proxy) — apps don't
    hardcode the primary's address; they follow the endpoint
  · Fence the old primary so it can't accept writes and split-brain
Drill this on a schedule. A failover you haven't run is a failover you don't have.
```

### Zero-Downtime Migration: Expand-Contract

```sql
-- WRONG: locks the hot table, stalls production behind it
-- ALTER TABLE orders ADD COLUMN status VARCHAR NOT NULL DEFAULT 'pending';  (blocking on many DBs)

-- RIGHT: expand-contract, no blocking lock, reversible at every step
-- 1. EXPAND — add nullable column (fast, metadata-only), no default backfill lock
ALTER TABLE orders ADD COLUMN status VARCHAR;                 -- instant, non-blocking

-- 2. BACKFILL in batches so no single statement holds a long lock or bloats WAL
UPDATE orders SET status = 'pending' WHERE status IS NULL AND id BETWEEN :lo AND :hi;  -- loop

-- 3. Dual-write from the app (new code writes status), deploy, let it bake
-- 4. Add the constraint only after backfill is complete, validated separately:
ALTER TABLE orders ADD CONSTRAINT status_not_null CHECK (status IS NOT NULL) NOT VALID;
ALTER TABLE orders VALIDATE CONSTRAINT status_not_null;      -- validates without a full-table lock
-- 5. CONTRACT — remove old column/paths in a later release, once nothing reads them
-- Every step is independently deployable and reversible. No maintenance window.

-- Indexes: always concurrently, so reads/writes continue during the build
CREATE INDEX CONCURRENTLY idx_orders_status ON orders (status);
```

### Reliability Metrics & Guards

| Signal | Why it matters | Guard / alert |
|--------|----------------|---------------|
| Replication lag | Stale reads; write loss on failover | Gate read-after-write above threshold; block promotion of lagging replicas |
| Connection utilization | Exhaustion downs a healthy DB | Pooler + per-service caps; alert well below the hard limit |
| Backup age + last successful restore test | Recoverability | Alert if a restore test hasn't passed within the window |
| WAL/binlog generation rate | Migration/backfill bloat, disk risk | Batch heavy writes; alert on retention-disk pressure |
| Failover drill recency | Unrehearsed failover = no failover | Track and schedule; alert if overdue |