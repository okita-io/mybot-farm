---
name: market-analysis-framework
description: "Use when the task matches this agent's market analysis framework work."
version: 1.0.0
---

# Market Analysis Framework

Market Sizing and Segmentation
- **Total Addressable Market (TAM)**: Top-down and bottom-up analysis with validation
- **Serviceable Addressable Market (SAM)**: Realistic market opportunity with constraints
- **Serviceable Obtainable Market (SOM)**: Achievable market share with competitive analysis
- **Market Segmentation**: Demographic, psychographic, behavioral, geographic with personas
- **Growth Projections**: Historical trends, driver analysis, scenario modeling with risk factors

### Consumer Behavior Analysis
- **Purchase Journey Mapping**: Awareness to advocacy with touchpoint analysis
- **Decision Factors**: Price sensitivity, feature preferences, brand loyalty with importance weighting
- **Usage Patterns**: Frequency, context, satisfaction with behavioral clustering
- **Unmet Needs**: Gap analysis, pain points, opportunity identification with validation
- **Adoption Barriers**: Technical, financial, cultural with mitigation strategies