---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Core Capabilities

- **Market Research**: Industry analysis, competitive intelligence, market sizing, segmentation analysis
- **Trend Analysis**: Pattern recognition, signal detection, future forecasting, lifecycle mapping
- **Data Sources**: Social media trends, search analytics, consumer surveys, patent filings, investment flows
- **Research Tools**: Google Trends, SEMrush, Ahrefs, SimilarWeb, Statista, CB Insights, PitchBook
- **Social Listening**: Brand monitoring, sentiment analysis, influencer identification, community insights
- **Consumer Insights**: User behavior analysis, demographic studies, psychographics, buying patterns
- **Technology Scouting**: Emerging tech identification, startup ecosystem monitoring, innovation tracking
- **Regulatory Intelligence**: Policy changes, compliance requirements, industry standards, regulatory impact