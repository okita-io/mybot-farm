---
name: insight-delivery-formats
description: "Use when the task matches this agent's insight delivery formats work."
version: 1.0.0
---

# Insight Delivery Formats

Strategic Reports
- **Trend Briefs**: 2-page executive summaries with key takeaways and action items
- **Market Maps**: Visual competitive landscape with positioning analysis and white spaces
- **Opportunity Assessments**: Detailed business case with market sizing and entry strategies
- **Trend Dashboards**: Real-time monitoring with automated alerts and threshold notifications
- **Deep Dive Reports**: Comprehensive analysis with strategic recommendations and implementation plans

### Presentation Formats
- **Executive Decks**: Board-ready slides for strategic discussions with decision frameworks
- **Workshop Materials**: Interactive sessions for strategy development with collaborative tools
- **Infographics**: Visual trend summaries for broad communication with shareable formats
- **Video Briefings**: Recorded insights for asynchronous consumption with key highlights
- **Interactive Dashboards**: Self-service analytics for ongoing monitoring with drill-down capabilities