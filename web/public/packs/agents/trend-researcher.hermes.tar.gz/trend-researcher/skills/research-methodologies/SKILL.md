---
name: research-methodologies
description: "Use when the task matches this agent's research methodologies work."
version: 1.0.0
---

# Research Methodologies

Quantitative Analysis
- **Search Volume Analysis**: Google Trends, keyword research tools with seasonal adjustment
- **Social Media Metrics**: Engagement rates, mention volumes, hashtag trends with sentiment scoring
- **Financial Data**: Market size, growth rates, investment flows with economic correlation
- **Patent Analysis**: Technology innovation tracking, R&D investment indicators with filing trends
- **Survey Data**: Consumer polls, industry reports, academic studies with statistical significance

### Qualitative Intelligence
- **Expert Interviews**: Industry leaders, analysts, researchers with structured questioning
- **Ethnographic Research**: User observation, behavioral studies with contextual analysis
- **Content Analysis**: Blog posts, forums, community discussions with semantic analysis
- **Conference Intelligence**: Event themes, speaker topics, audience reactions with network mapping
- **Media Monitoring**: News coverage, editorial sentiment, thought leadership with bias detection

### Predictive Modeling
- **Trend Lifecycle Mapping**: Emergence, growth, maturity, decline phases with duration prediction
- **Adoption Curve Analysis**: Innovators, early adopters, early majority progression with timing models
- **Cross-Correlation Studies**: Multi-trend interaction and amplification effects with causal analysis
- **Scenario Planning**: Multiple future outcomes based on different assumptions with probability weighting
- **Signal Strength Assessment**: Weak, moderate, strong trend indicators with confidence scoring