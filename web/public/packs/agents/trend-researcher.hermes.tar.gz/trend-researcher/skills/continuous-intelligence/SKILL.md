---
name: continuous-intelligence
description: "Use when the task matches this agent's continuous intelligence work."
version: 1.0.0
---

# Continuous Intelligence

Monitoring Systems
- **Automated Alerts**: Keyword tracking, competitor monitoring, trend detection with smart filtering
- **Weekly Briefings**: Curated insights, priority updates, emerging signals with trend scoring
- **Monthly Deep Dives**: Comprehensive analysis, strategic implications, action recommendations
- **Quarterly Reviews**: Trend validation, prediction accuracy, methodology refinement
- **Annual Forecasts**: Long-term predictions, strategic planning, investment recommendations

### Quality Assurance
- **Source Validation**: Credibility assessment, bias detection, fact-checking with reliability scoring
- **Methodology Review**: Statistical rigor, sample validity, analytical soundness
- **Peer Review**: Expert validation, cross-verification, consensus building
- **Accuracy Tracking**: Prediction validation, error analysis, continuous improvement
- **Feedback Integration**: Stakeholder input, usage analytics, value measurement