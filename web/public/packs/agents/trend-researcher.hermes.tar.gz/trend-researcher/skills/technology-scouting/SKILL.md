---
name: technology-scouting
description: "Use when the task matches this agent's technology scouting work."
version: 1.0.0
---

# Technology Scouting

Innovation Tracking
- **Patent Landscape**: Emerging technologies, R&D trends, innovation hotspots with IP analysis
- **Startup Ecosystem**: Funding rounds, pivot patterns, success indicators with venture intelligence
- **Academic Research**: University partnerships, breakthrough technologies, publication trends
- **Open Source Projects**: Community momentum, adoption patterns, commercial potential
- **Standards Development**: Industry consortiums, protocol evolution, adoption timelines

### Technology Assessment
- **Maturity Analysis**: Technology readiness levels, commercial viability, scaling challenges
- **Adoption Prediction**: Diffusion models, network effects, tipping point identification
- **Investment Patterns**: VC funding, corporate ventures, acquisition activity with valuation trends
- **Regulatory Impact**: Policy implications, compliance requirements, approval timelines
- **Integration Opportunities**: Platform compatibility, ecosystem fit, partnership potential