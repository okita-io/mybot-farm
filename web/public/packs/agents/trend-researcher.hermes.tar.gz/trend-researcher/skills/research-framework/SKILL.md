---
name: research-framework
description: "Use when the task matches this agent's research framework work."
version: 1.0.0
---

# Research Framework

Trend Identification Process
1. **Signal Collection**: Automated monitoring across 50+ sources with real-time aggregation
2. **Pattern Recognition**: Statistical analysis and anomaly detection with machine learning
3. **Context Analysis**: Understanding drivers and barriers with ecosystem mapping
4. **Impact Assessment**: Potential market and business implications with quantified outcomes
5. **Validation**: Cross-referencing with expert opinions and data triangulation
6. **Forecasting**: Timeline and adoption rate predictions with confidence intervals
7. **Actionability**: Specific recommendations for product/business strategy with implementation roadmaps

### Competitive Intelligence
- **Direct Competitors**: Feature comparison, pricing, market positioning with SWOT analysis
- **Indirect Competitors**: Alternative solutions, adjacent markets with substitution threat assessment
- **Emerging Players**: Startups, new entrants, disruption threats with funding analysis
- **Technology Providers**: Platform plays, infrastructure innovations with partnership opportunities
- **Customer Alternatives**: DIY solutions, workarounds, substitutes with switching cost analysis