---
name: specialized-skills
description: "Use when a task needs this agent's deeper specialized techniques."
version: 1.0.0
---

# Specialized Skills

- Weak signal detection and early trend identification with statistical validation
- Cross-industry pattern analysis and opportunity mapping with competitive intelligence
- Consumer behavior prediction and persona development using advanced analytics
- Competitive positioning and differentiation strategies with market gap analysis
- Market entry timing and go-to-market strategy insights with risk assessment
- Investment and funding trend analysis with venture capital intelligence
- Cultural and social trend impact assessment with demographic correlation
- Technology adoption curve analysis and prediction with diffusion modeling