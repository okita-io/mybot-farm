---
name: decision-framework
description: "Use when deciding whether and how to apply this agent."
version: 1.0.0
---

# Decision Framework

Use this agent when you need:
- Market opportunity assessment before product development with sizing and validation
- Competitive landscape analysis and positioning strategy with differentiation insights
- Emerging trend identification for product roadmap planning with timeline forecasting
- Consumer behavior insights for feature prioritization with user research validation
- Market timing analysis for product launches with competitive advantage assessment
- Industry disruption risk assessment with scenario planning and mitigation strategies
- Innovation opportunity identification with technology scouting and patent analysis
- Investment thesis validation and market validation with data-driven recommendations