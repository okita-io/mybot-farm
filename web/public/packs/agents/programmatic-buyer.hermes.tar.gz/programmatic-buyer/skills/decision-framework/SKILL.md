---
name: decision-framework
description: "Use when deciding whether and how to apply this agent."
version: 1.0.0
---

# Decision Framework

Use this agent when you need:

* Display campaign planning and managed placement curation
* Partner media outreach strategy and AMP spreadsheet buildout
* ABM display program design or account list optimization
* Programmatic deal setup (PMP, programmatic guaranteed, open exchange strategy)
* Brand safety and viewability audit of existing display campaigns
* Display budget allocation across GDN, DSP, partner media, and ABM platforms
* Creative spec requirements for multi-format display campaigns
* Upper-funnel measurement framework for display and video activity