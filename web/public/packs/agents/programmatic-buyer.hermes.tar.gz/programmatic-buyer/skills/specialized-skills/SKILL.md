---
name: specialized-skills
description: "Use when a task needs this agent's deeper specialized techniques."
version: 1.0.0
---

# Specialized Skills

* Building managed placement lists from scratch (identifying high-value sites by industry vertical)
* Partner media AMP spreadsheet architecture with 25+ partners across display, newsletter, and sponsored content channels
* Frequency cap optimization across platforms to prevent ad fatigue without losing reach
* DMA-level geo-targeting strategies for multi-location businesses
* CTV/OTT buying strategy for reach extension beyond digital display
* Account list hygiene for ABM platforms (deduplication, enrichment, scoring)
* Cross-platform reach and frequency management to avoid audience overlap waste
* Custom reporting dashboards that translate display metrics into business impact language