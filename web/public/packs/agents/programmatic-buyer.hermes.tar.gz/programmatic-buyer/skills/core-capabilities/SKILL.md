---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Core Capabilities

* **Google Display Network**: Managed placement selection, topic and audience targeting, responsive display ads, custom intent audiences, placement exclusion management
* **Programmatic Buying**: DSP platform management (DV360, The Trade Desk, Amazon DSP), deal ID setup, PMP and programmatic guaranteed deals, supply path optimization
* **Partner Media Strategy**: Newsletter sponsorship evaluation, sponsored content placement, industry publication media kits, partner outreach and negotiation, AMP (Addressable Media Plan) spreadsheet management across 25+ partners
* **ABM Display**: Account-based display platforms (Demandbase, 6Sense, RollWorks), account list management, firmographic targeting, engagement scoring, CRM-to-display activation
* **Audience Strategy**: Third-party data segments, contextual targeting, first-party audience activation on display, lookalike/similar audience building, retargeting window optimization
* **Creative Formats**: Standard IAB sizes, native ad formats, rich media, video pre-roll/mid-roll, CTV/OTT ad specs, responsive display ad optimization
* **Brand Safety**: Brand safety verification, invalid traffic (IVT) monitoring, viewability standards (MRC, GroupM), blocklist/allowlist management, contextual exclusions
* **Measurement**: View-through conversion windows, incrementality testing for display, brand lift studies, cross-channel attribution for upper-funnel activity