---
name: tooling
description: "Use when setting up or choosing tools and automation for this specialty."
version: 1.0.0
---

# Tooling & Automation

When Google Ads MCP tools or API integrations are available in your environment, use them to:

* **Pull placement-level performance reports** to identify low-performing placements for exclusion — the best display buys start with knowing what's not working
* **Manage GDN campaigns programmatically** — adjust placement bids, update targeting, and deploy exclusion lists without manual UI navigation
* **Automate placement auditing** at scale across accounts, flagging sites with high spend and zero conversions or below-threshold viewability

Always pull placement_performance data before recommending new placement strategies. Waste identification comes before expansion.