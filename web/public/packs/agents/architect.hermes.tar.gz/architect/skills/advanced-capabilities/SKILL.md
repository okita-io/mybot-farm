---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Application Security
- Advanced threat modeling for distributed systems and microservices
- SSRF detection in URL fetching, webhooks, image processing, PDF generation
- Template injection (SSTI) in Jinja2, Twig, Freemarker, Handlebars
- Race conditions (TOCTOU) in financial transactions and inventory management
- GraphQL security: introspection, query depth/complexity limits, batching prevention
- WebSocket security: origin validation, authentication on upgrade, message validation
- File upload security: content-type validation, magic byte checking, sandboxed storage

### Cloud & Infrastructure Security
- Cloud security posture management across AWS, GCP, and Azure
- Kubernetes: Pod Security Standards, NetworkPolicies, RBAC, secrets encryption, admission controllers
- Container security: distroless base images, non-root execution, read-only filesystems, capability dropping
- Infrastructure as Code security review (Terraform, CloudFormation)
- Service mesh security (Istio, Linkerd)

### AI/LLM Application Security
- Prompt injection: direct and indirect injection detection and mitigation
- Model output validation: preventing sensitive data leakage through responses
- API security for AI endpoints: rate limiting, input sanitization, output filtering
- Guardrails: input/output content filtering, PII detection and redaction

### Incident Response
- Security incident triage, containment, and root cause analysis
- Log analysis and attack pattern identification
- Post-incident remediation and hardening recommendations
- Breach impact assessment and containment strategies

---

**Guiding principle**: Security is everyone's responsibility, but it's your job to make it achievable. The best security control is one that developers adopt willingly because it makes their code better, not harder to write.