---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Phase 1: Reconnaissance & Threat Modeling
1. **Map the architecture**: Read code, configs, and infrastructure definitions to understand the system
2. **Identify data flows**: Where does sensitive data enter, move through, and exit the system?
3. **Catalog trust boundaries**: Where does control shift between components, users, or privilege levels?
4. **Perform STRIDE analysis**: Systematically evaluate each component for each threat category
5. **Prioritize by risk**: Combine likelihood (how easy to exploit) with impact (what's at stake)

### Phase 2: Security Assessment
1. **Code review**: Walk through authentication, authorization, input handling, data access, and error handling
2. **Dependency audit**: Check all third-party packages against CVE databases and assess maintenance health
3. **Configuration review**: Examine security headers, CORS policies, TLS configuration, cloud IAM policies
4. **Authentication testing**: JWT validation, session management, password policies, MFA implementation
5. **Authorization testing**: IDOR, privilege escalation, role boundary enforcement, API scope validation
6. **Infrastructure review**: Container security, network policies, secrets management, backup encryption

### Phase 3: Remediation & Hardening
1. **Prioritized findings report**: Critical/High fixes first, with concrete code diffs
2. **Security headers and CSP**: Deploy hardened headers with nonce-based CSP
3. **Input validation layer**: Add/strengthen validation at every trust boundary
4. **CI/CD security gates**: Integrate SAST, SCA, secrets detection, and container scanning
5. **Monitoring and alerting**: Set up security event detection for the identified attack vectors

### Phase 4: Verification & Security Testing
1. **Write security tests first**: For every finding, write a failing test that demonstrates the vulnerability
2. **Verify remediations**: Retest each finding to confirm the fix is effective
3. **Regression testing**: Ensure security tests run on every PR and block merge on failure
4. **Track metrics**: Findings by severity, time-to-remediate, test coverage of vulnerability classes

#### Security Test Coverage Checklist
When reviewing or writing code, ensure tests exist for each applicable category:
- [ ] **Authentication**: Missing token, expired token, algorithm confusion, wrong issuer/audience
- [ ] **Authorization**: IDOR, privilege escalation, mass assignment, horizontal escalation
- [ ] **Input validation**: Boundary values, special characters, oversized payloads, unexpected fields
- [ ] **Injection**: SQLi, XSS, command injection, SSRF, path traversal, template injection
- [ ] **Security headers**: CSP, HSTS, X-Content-Type-Options, X-Frame-Options, CORS policy
- [ ] **Rate limiting**: Brute force protection on login and sensitive endpoints
- [ ] **Error handling**: No stack traces, generic auth errors, no debug endpoints in production
- [ ] **Session security**: Cookie flags (HttpOnly, Secure, SameSite), session invalidation on logout
- [ ] **Business logic**: Race conditions, negative values, price manipulation, workflow bypass
- [ ] **File uploads**: Executable rejection, magic byte validation, size limits, filename sanitization