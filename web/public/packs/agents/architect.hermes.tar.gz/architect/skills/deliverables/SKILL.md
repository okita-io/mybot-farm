---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Threat Model Document
```markdown
# Threat Model: [Application Name]

**Date**: [YYYY-MM-DD] | **Version**: [1.0] | **Author**: Security Engineer

## System Overview
- **Architecture**: [Monolith / Microservices / Serverless / Hybrid]
- **Tech Stack**: [Languages, frameworks, databases, cloud provider]
- **Data Classification**: [PII, financial, health/PHI, credentials, public]
- **Deployment**: [Kubernetes / ECS / Lambda / VM-based]
- **External Integrations**: [Payment processors, OAuth providers, third-party APIs]

## Trust Boundaries
| Boundary | From | To | Controls |
|----------|------|----|----------|
| Internet → App | End user | API Gateway | TLS, WAF, rate limiting |
| API → Services | API Gateway | Microservices | mTLS, JWT validation |
| Service → DB | Application | Database | Parameterized queries, encrypted connection |
| Service → Service | Microservice A | Microservice B | mTLS, service mesh policy |

## STRIDE Analysis
| Threat | Component | Risk | Attack Scenario | Mitigation |
|--------|-----------|------|-----------------|------------|
| Spoofing | Auth endpoint | High | Credential stuffing, token theft | MFA, token binding, account lockout |
| Tampering | API requests | High | Parameter manipulation, request replay | HMAC signatures, input validation, idempotency keys |
| Repudiation | User actions | Med | Denying unauthorized transactions | Immutable audit logging with tamper-evident storage |
| Info Disclosure | Error responses | Med | Stack traces leak internal architecture | Generic error responses, structured logging |
| DoS | Public API | High | Resource exhaustion, algorithmic complexity | Rate limiting, WAF, circuit breakers, request size limits |
| Elevation of Privilege | Admin panel | Crit | IDOR to admin functions, JWT role manipulation | RBAC with server-side enforcement, session isolation |

## Attack Surface Inventory
- **External**: Public APIs, OAuth/OIDC flows, file uploads, WebSocket endpoints, GraphQL
- **Internal**: Service-to-service RPCs, message queues, shared caches, internal APIs
- **Data**: Database queries, cache layers, log storage, backup systems
- **Infrastructure**: Container orchestration, CI/CD pipelines, secrets management, DNS
- **Supply Chain**: Third-party dependencies, CDN-hosted scripts, external API integrations
```

### Secure Code Review Pattern
```python
# Example: Secure API endpoint with authentication, validation, and rate limiting

from fastapi import FastAPI, Depends, HTTPException, status, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field, field_validator
from slowapi import Limiter
from slowapi.util import get_remote_address
import re

app = FastAPI(docs_url=None, redoc_url=None)  # Disable docs in production
security = HTTPBearer()
limiter = Limiter(key_func=get_remote_address)

class UserInput(BaseModel):
    """Strict input validation — reject anything unexpected."""
    username: str = Field(..., min_length=3, max_length=30)
    email: str = Field(..., max_length=254)

    @field_validator("username")
    @classmethod
    def validate_username(cls, v: str) -> str:
        if not re.match(r"^[a-zA-Z0-9_-]+$", v):
            raise ValueError("Username contains invalid characters")
        return v

async def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Validate JWT — signature, expiry, issuer, audience. Never allow alg=none."""
    try:
        payload = jwt.decode(
            credentials.credentials,
            key=settings.JWT_PUBLIC_KEY,
            algorithms=["RS256"],
            audience=settings.JWT_AUDIENCE,
            issuer=settings.JWT_ISSUER,
        )
        return payload
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

@app.post("/api/users", status_code=status.HTTP_201_CREATED)
# … truncated for farm planting — see upstream for the full sample
```

### CI/CD Security Pipeline
```yaml
# GitHub Actions security scanning
name: Security Scan
on:
  pull_request:
    branches: [main]

jobs:
  sast:
    name: Static Analysis
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run Semgrep SAST
        uses: semgrep/semgrep-action@v1
        with:
          config: >-
            p/owasp-top-ten
            p/cwe-top-25

  dependency-scan:
    name: Dependency Audit
    runs-on: ubuntu-latest
    steps:…