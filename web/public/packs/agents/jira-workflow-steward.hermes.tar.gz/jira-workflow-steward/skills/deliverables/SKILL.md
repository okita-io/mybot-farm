---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Branch and Commit Decision Matrix
| Change Type | Branch Pattern | Commit Pattern | When to Use |
|-------------|----------------|----------------|-------------|
| Feature | `feature/JIRA-214-add-sso-login` | `✨ JIRA-214: add SSO login flow` | New product or platform capability |
| Bug Fix | `bugfix/JIRA-315-fix-token-refresh` | `🐛 JIRA-315: fix token refresh race` | Non-production-critical defect work |
| Hotfix | `hotfix/JIRA-411-patch-auth-bypass` | `🐛 JIRA-411: patch auth bypass check` | Production-critical fix from `main` |
| Refactor | `feature/JIRA-522-refactor-audit-service` | `♻️ JIRA-522: refactor audit service boundaries` | Structural cleanup tied to a tracked task |
| Docs | `feature/JIRA-623-document-api-errors` | `📚 JIRA-623: document API error catalog` | Documentation work with a Jira task |
| Tests | `bugfix/JIRA-724-cover-session-timeouts` | `🧪 JIRA-724: add session timeout regression tests` | Test-only change tied to a tracked defect or feature |
| Config | `feature/JIRA-811-add-ci-policy-check` | `🔧 JIRA-811: add branch policy validation` | Configuration or workflow policy changes |
| Dependencies | `bugfix/JIRA-902-upgrade-actions` | `📦 JIRA-902: upgrade GitHub Actions versions` | Dependency or platform upgrades |

If a higher-priority tool requires an outer prefix, keep the repository branch intact inside it, for example: `codex/feature/JIRA-214-add-sso-login`.

### Official Gitmoji References
- Primary reference: [gitmoji.dev](https://gitmoji.dev/) for the current emoji catalog and intended meanings
- Source of truth: [github.com/carloscuesta/gitmoji](https://github.com/carloscuesta/gitmoji) for the upstream project and usage model
- Repository-specific default: use `✨` when adding a brand-new agent because Gitmoji defines it for new features; use `📚` only when the change is limited to documentation updates around existing agents or contribution docs

### Commit and Branch Validation Hook
```bash
#!/usr/bin/env bash
set -euo pipefail

message_file="${1:?commit message file is required}"
branch="$(git rev-parse --abbrev-ref HEAD)"
subject="$(head -n 1 "$message_file")"

branch_regex='^(feature|bugfix|hotfix)/[A-Z]+-[0-9]+-[a-z0-9-]+$|^release/[0-9]+\.[0-9]+\.[0-9]+$'
commit_regex='^(🚀|✨|🐛|♻️|📚|🧪|💄|🔧|📦) [A-Z]+-[0-9]+: .+$'

if [[ ! "$branch" =~ $branch_regex ]]; then
  echo "Invalid branch name: $branch" >&2
  echo "Use feature/JIRA-ID-description, bugfix/JIRA-ID-description, hotfix/JIRA-ID-description, or release/version." >&2
  exit 1
fi

if [[ "$branch" != release/* && ! "$subject" =~ $commit_regex ]]; then
  echo "Invalid commit subject: $subject" >&2
  echo "Use: <gitmoji> JIRA-ID: short description" >&2
  exit 1
fi
```

### Pull Request Template
```markdown
## What does this PR do?
Implements **JIRA-214** by adding the SSO login flow and tightening token refresh handling.

## Jira Link
- Ticket: JIRA-214
- Branch: feature/JIRA-214-add-sso-login

## Change Summary
- Add SSO callback controller and provider wiring
- Add regression coverage for expired refresh tokens
- Document the new login setup path

## Risk and Security Review
- Auth flow touched: yes
- Secret handling changed: no
- Rollback plan: revert the branch and disable the provider flag

## Testing
- Unit tests: passed
- Integration tests: passed in staging
- Manual verification: login and logout flow verified in staging
```

### Delivery Planning Template
```markdown
# Jira Delivery Packet

## Ticket
- Jira: JIRA-315
- Outcome: Fix token refresh race without changing the public API

## Planned Branch
- bugfix/JIRA-315-fix-token-refresh

## Planned Commits
1. 🐛 JIRA-315: fix refresh token race in auth service
2. 🧪 JIRA-315: add concurrent refresh regression tests
3. 📚 JIRA-315: document token refresh failure modes

## Review Notes
- Risk area: authentication and session expiry
- Security check: confirm no sensitive tokens appear in logs
- Rollback: revert commit 1 and disable concurrent refresh path if needed
```