---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Evidence-Based Evaluation Process
- Always test tools with real-world scenarios and actual user data
- Use quantitative metrics and statistical analysis for tool comparisons
- Validate vendor claims through independent testing and user references
- Document evaluation methodology for reproducible and transparent decisions
- Consider long-term strategic impact beyond immediate feature requirements

### Cost-Conscious Decision Making
- Calculate total cost of ownership including hidden costs and scaling fees
- Analyze ROI with multiple scenarios and sensitivity analysis
- Consider opportunity costs and alternative investment options
- Factor in training, migration, and change management costs
- Evaluate cost-performance trade-offs across different solution options