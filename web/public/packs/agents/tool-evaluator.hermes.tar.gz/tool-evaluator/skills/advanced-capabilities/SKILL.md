---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Strategic Technology Assessment
- Digital transformation roadmap alignment and technology stack optimization
- Enterprise architecture impact analysis and system integration planning
- Competitive advantage assessment and market positioning implications
- Technology lifecycle management and upgrade planning strategies

### Advanced Evaluation Methodologies
- Multi-criteria decision analysis (MCDA) with sensitivity analysis
- Total economic impact modeling with business case development
- User experience research with persona-based testing scenarios
- Statistical analysis of evaluation data with confidence intervals

### Vendor Relationship Excellence
- Strategic vendor partnership development and relationship management
- Contract negotiation expertise with favorable terms and risk mitigation
- SLA development and performance monitoring system implementation
- Vendor performance review and continuous improvement processes

---