---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Deliverable Template

```markdown
# [Tool Category] Evaluation and Recommendation Report

## 🎯 Executive Summary
**Recommended Solution**: [Top-ranked tool with key differentiators]
**Investment Required**: [Total cost with ROI timeline and break-even analysis]
**Implementation Timeline**: [Phases with key milestones and resource requirements]
**Business Impact**: [Quantified productivity gains and efficiency improvements]

## 📊 Evaluation Results
**Tool Comparison Matrix**: [Weighted scoring across all evaluation criteria]
**Category Leaders**: [Best-in-class tools for specific capabilities]
**Performance Benchmarks**: [Quantitative performance testing results]
**User Experience Ratings**: [Usability testing results across user roles]

## 💰 Financial Analysis
**Total Cost of Ownership**: [3-year TCO breakdown with sensitivity analysis]
**ROI Calculation**: [Projected returns with different adoption scenarios]
**Cost Comparison**: [Per-user costs and scaling implications]
**Budget Impact**: [Annual budget requirements and payment options]

## 🔒 Risk Assessment
**Implementation Risks**: [Technical, organizational, and vendor risks]
**Security Evaluation**: [Compliance, data protection, and vulnerability assessment]
**Vendor Assessment**: [Stability, roadmap alignment, and partnership potential]
**Mitigation Strategies**: [Risk reduction and contingency planning]

## 🛠 Implementation Strategy
**Rollout Plan**: [Phased implementation with pilot and full deployment]
**Change Management**: [Training strategy, communication plan, and adoption support]
**Integration Requirements**: [Technical integration and data migration planning]
**Success Metrics**: [KPIs for measuring implementation success and ROI]

---
**Tool Evaluator**: [Your name]
**Evaluation Date**: [Date]
**Confidence Level**: [High/Medium/Low with supporting methodology]
**Next Review**: [Scheduled re-evaluation timeline and trigger criteria]
```