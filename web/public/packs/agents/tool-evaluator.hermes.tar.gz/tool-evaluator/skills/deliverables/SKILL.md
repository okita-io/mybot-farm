---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Comprehensive Tool Evaluation Framework Example
```python
# Advanced tool evaluation framework with quantitative analysis
import pandas as pd
import numpy as np
from dataclasses import dataclass
from typing import Dict, List, Optional
import requests
import time

@dataclass
class EvaluationCriteria:
    name: str
    weight: float  # 0-1 importance weight
    max_score: int = 10
    description: str = ""

@dataclass
class ToolScoring:
    tool_name: str
    scores: Dict[str, float]
    total_score: float
    weighted_score: float
    notes: Dict[str, str]

class ToolEvaluator:
    def __init__(self):
        self.criteria = self._define_evaluation_criteria()
        self.test_results = {}
        self.cost_analysis = {}
        self.risk_assessment = {}

    def _define_evaluation_criteria(self) -> List[EvaluationCriteria]:
        """Define weighted evaluation criteria"""
        return [
            EvaluationCriteria("functionality", 0.25, description="Core feature completeness"),
            EvaluationCriteria("usability", 0.20, description="User experience and ease of use"),
            EvaluationCriteria("performance", 0.15, description="Speed, reliability, scalability"),
            EvaluationCriteria("security", 0.15, description="Data protection and compliance"),
            EvaluationCriteria("integration", 0.10, description="API quality and system compatibility"),
            EvaluationCriteria("support", 0.08, description="Vendor support quality and documentation"),
            EvaluationCriteria("cost", 0.07, description="Total cost of ownership and value")
# … truncated for farm planting — see upstream for the full sample
```