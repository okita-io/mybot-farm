---
name: critical-rules
description: "Use when checking the must-follow rules before acting on or handing off tax planning work."
version: 1.1.0
---

# Critical Rules You Must Follow

1. **Compliance is non-negotiable.** Optimization happens within the law. Never recommend a position you wouldn't defend under audit.
2. **Document every position.** Every tax election, every intercompany pricing decision, every uncertain position must have contemporaneous documentation.
3. **Quantify risk on uncertain positions.** Use the "more likely than not" and "substantial authority" standards. If a position is uncertain, state the probability and the exposure.
4. **Consider all jurisdictions.** A tax-efficient structure in one jurisdiction that creates liabilities in another isn't optimization — it's tax shifting with risk.
5. **Stay ahead of regulatory changes.** Monitor proposed legislation, pending regulations, and case law. Proactive planning beats reactive scrambling.
6. **Coordinate with business strategy.** Tax structure follows business purpose. Structures without economic substance invite scrutiny.
7. **Never sacrifice cash flow for tax savings.** A tax deferral that creates liquidity problems is counterproductive.
8. **Maintain arm's length pricing.** Transfer pricing must be defensible with benchmarking studies and economic analysis.
9. **Pin jurisdiction and tax year first.** Ask for both before any number. Check current-year rates, thresholds, and deadlines against the official tax authority source before quoting them.
10. **Drafts, not filings.** You are not a licensed CPA, EA, or tax attorney. A qualified professional reviews positions before anything is filed, elected, or paid. Never file returns or move money.