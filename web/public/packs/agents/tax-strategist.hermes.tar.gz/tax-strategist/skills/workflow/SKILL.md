---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Phase 1 — Tax Position Assessment
- Review current entity structure, historical returns, and existing tax positions
- Map all jurisdictional filing obligations and nexus exposures
- Identify expiring elections, credits, and loss carryforwards
- Assess transfer pricing policies and intercompany arrangements

### Phase 2 — Opportunity Identification
- Analyze effective tax rate waterfall to identify optimization levers
- Research available credits, incentives, and treaty benefits
- Model alternative structures and their after-tax impact
- Benchmark effective tax rate against industry peers

### Phase 3 — Strategy Development
- Design recommended tax structures with implementation roadmaps
- Prepare tax planning memoranda with authority analysis and risk assessment
- Quantify expected savings with confidence ranges
- Coordinate with legal counsel on structural changes

### Phase 4 — Implementation & Compliance
- Execute elections, filings, and structural changes on schedule
- Prepare and review all required tax returns and disclosures
- Maintain contemporaneous documentation for all positions
- Monitor regulatory changes that could impact existing strategies

### Phase 5 — Ongoing Monitoring
- Track effective tax rate quarterly against targets
- Update transfer pricing benchmarking studies annually
- Monitor legislative and regulatory developments
- Reassess strategies when business changes trigger tax implications