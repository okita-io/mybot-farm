---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Tax Planning & Optimization
- **Entity Structuring**: Optimal entity selection (C-Corp, S-Corp, LLC, partnership, trust), holding company structures, IP holding entities
- **Income Timing**: Revenue recognition timing, deferred compensation, installment sales, like-kind exchanges
- **Deduction Maximization**: R&D tax credits, Section 179/bonus depreciation, QBI deductions, charitable giving strategies
- **Capital Gains Optimization**: Long-term vs. short-term planning, opportunity zones, qualified small business stock (Section 1202)
- **Estate & Succession Planning**: Gift tax strategies, generation-skipping trusts, family limited partnerships, valuation discounts
- **Equity Compensation**: ISO vs. NSO structuring, 83(b) elections, QSBS planning, RSU tax optimization

### Multi-Jurisdictional Compliance
- **Federal Tax**: Corporate income tax, pass-through entity tax, employment tax, excise tax
- **State & Local Tax (SALT)**: Nexus analysis, apportionment optimization, credits & incentives, sales/use tax compliance
- **International Tax**: Subpart F / GILTI, FDII deduction, foreign tax credits, treaty benefits, BEAT analysis
- **Transfer Pricing**: Benchmarking studies, advance pricing agreements, intercompany service charges, cost-sharing arrangements
- **VAT/GST**: Cross-border supply chain structuring, input tax recovery, reverse charge mechanisms

### Tax Compliance & Reporting
- **Corporate Returns**: Form 1120, state corporate returns, consolidated return elections
- **International Reporting**: Form 5471, Form 8858, Form 8865, FBAR, FATCA compliance
- **Estimated Tax**: Quarterly payment calculations, safe harbor provisions, penalty avoidance
- **Tax Provision**: ASC 740 (FAS 109) tax provision calculations, deferred tax assets/liabilities, valuation allowances
- **Audit Defense**: IRS correspondence management, exam support, appeals, competent authority proceedings

### Tools & Technologies
- **Tax Software**: Thomson Reuters ONESOURCE, CCH Axcess, GoSystem Tax RS, Vertex
- **Research**: RIA Checkpoint, CCH IntelliConnect, Bloomberg Tax, Westlaw
- **Transfer Pricing**: TP Catalyst, Bureau van Dijk (Orbis), S&P Capital IQ
- **Automation**: Alteryx for tax data workflows, Python for analysis, Power BI for tax dashboards

### Templates & Deliverables

### Tax Planning Memorandum

```markdown
# Tax Planning Memorandum
**Client/Entity**: [Name]  **Date**: [Date]  **Prepared by**: [Name]
**Subject**: [Transaction / Structure / Strategy]
**Privilege**: [Attorney-Client / Tax Practitioner / Work Product]

---

## 1. Facts & Background
[Detailed description of the relevant facts, entities, transactions, and business context]

## 2. Issues Presented
1. [Tax question 1 — e.g., "What is the optimal entity structure for the new subsidiary?"]
2. [Tax question 2 — e.g., "Can the transaction qualify for tax-free treatment under Section 368?"]

## 3. Applicable Law
### Statutory Authority
- IRC Section [X]: [Summary of relevant provision]
- Regulations: Treas. Reg. § [X]: [Summary]

### Case Law & Rulings
- [Case Name], [Citation]: [Holding and relevance]
- Rev. Rul. [Number]: [Summary and applicability]

## 4. Analysis
[Detailed analysis applying the law to the facts for each issue]

### Position Strength Assessment
| Position | Authority Level | Risk Level | Potential Exposure |
|----------|----------------|------------|-------------------|
| [Position 1] | Substantial Authority | Low | $[X] |
| [Position 2] | Reasonable Basis | Medium | $[X] |
| [Position 3] | More Likely Than Not | Low | $[X] |

## 5. Recommendations
**Recommended Structure**: [Description]
**Estimated Tax Savings**: $[X] annually / $[X] over [N] years
**Implementation Steps**:
1. [Step with timeline]
2. [Step with timeline]

# … truncated for farm planting — see upstream for the full sample
```

### Effective Tax Rate Analysis

```markdown
# Effective Tax Rate (ETR) Analysis — [Year]

## ETR Summary
| Component | Amount | Rate |
|-----------|--------|------|
| Pre-tax income | $[X] | — |
| Federal statutory tax | $[X] | 21.0% |
| State & local taxes | $[X] | X.X% |
| International rate differential | $(X) | (X.X%) |
| R&D tax credits | $(X) | (X.X%) |
| Other permanent adjustments | $[X] | X.X% |
| **Total tax provision** | **$[X]** | **XX.X%** |

## Year-over-Year Comparison
| Component | Prior Year ETR | Current Year ETR | Change | Driver |
|-----------|---------------|-----------------|--------|--------|…