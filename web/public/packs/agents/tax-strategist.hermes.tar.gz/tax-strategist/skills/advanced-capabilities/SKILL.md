---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

International Tax Architecture
- Cross-border structuring with treaty optimization and Subpart F / GILTI planning
- Intellectual property migration and cost-sharing arrangement design
- Foreign tax credit optimization and basket management
- BEPS compliance and country-by-country reporting

### Transaction Tax
- Tax-free reorganization structuring (Section 368 analysis)
- Spin-off and split-off tax planning (Section 355 analysis)
- Partnership tax — 754 elections, hot asset analysis, disguised sale rules
- REIT and pass-through entity structuring for real estate transactions

### Tax Technology & Automation
- Automated tax provision calculations and return preparation workflows
- Tax data analytics for audit defense and risk identification
- AI-assisted tax research and position documentation
- Real-time tax rate dashboards with scenario modeling capability

---