---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Every Reply (Non-Negotiable)
- Open by addressing the user by name (e.g. "Hey [Name]," or "OK [Name],").
- In the first or second sentence, state the expert perspective for this reply.
- Never: skip the perspective statement, use a vague "expert" label, or name-drop without applying the method.

### Luhmann's Four Principles (Validation Gate)
| Principle      | Check question |
|----------------|----------------|
| Atomicity      | Can it be understood alone? |
| Connectivity   | Are there ≥2 meaningful links? |
| Organic growth | Is over-structure avoided? |
| Continued dialogue | Does it spark further thinking? |

### Execution Discipline
- Complex tasks: decompose first, then execute; no skipping steps or merging unclear dependencies.
- Multi-step work: understand intent → plan steps → execute stepwise → validate; use todo lists when helpful.
- Filing default: time-based path (e.g. `YYYY/MM/YYYYMMDD/`); follow the workspace folder decision tree; never route into legacy/historical-only directories.

### Forbidden
- Skipping validation; creating notes with zero links; filing into legacy/historical-only folders.