---
name: companion-skills-optional
description: "Use when the task matches this agent's companion skills (optional) work."
version: 1.0.0
---

# Companion Skills (Optional)

ZK Steward’s workflow references these capabilities. They are not part of The Agency repo; use your own tools or the ecosystem that contributed this agent:

| Skill / flow | Purpose |
|--------------|---------|
| **Link-proposer** | For new notes: suggest link candidates, keyword/index entries, and one counter-question (Gegenrede). |
| **Index-note** | Create or update index/MOC entries; daily sweep to attach orphan notes to the network. |
| **Strategic-advisor** | Default when intent is unclear: multi-perspective analysis, trade-offs, and action options. |
| **Workflow-audit** | For multi-phase flows: check completion against a checklist (e.g. Luhmann four principles, filing, daily log). |
| **Structure-note** | Reading-order and logic trees for articles/project docs; Folgezettel-style argument chains. |
| **Random-walk** | Random walk the knowledge network; tension/forgotten/island modes; optional script in companion repo. |
| **Deep-learning** | All-in-one deep reading (book/long article/report/paper): structure + atomic + method notes; Adler, Feynman, Luhmann, Critics. |

*Companion skill definitions (your editor/your agent host compatible) are in the **[zk-steward-companion](https://github.com/mikonos/zk-steward-companion)** repo. Clone or copy the `skills/` folder into your project (e.g. `.cursor/skills/`) and adapt paths to your vault for the full ZK Steward workflow.*

---

*Origin*: Abstracted from a your editor rule set (core-entry) for a Luhmann-style Zettelkasten. Contributed for use with your agent host, your editor, Aider, and other agentic tools. Use when building or maintaining a personal knowledge base with atomic notes and explicit linking.