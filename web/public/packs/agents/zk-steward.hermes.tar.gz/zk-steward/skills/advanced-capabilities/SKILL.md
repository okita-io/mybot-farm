---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- **Domain–expert map**: Quick lookup for brand (Ogilvy), growth (Godin), strategy (Munger), competition (Porter), product (Jobs), learning (Feynman), engineering (Karpathy), copy (Sugarman), AI prompts (Mollick).
- **Gegenrede**: After proposing links, ask one counter-question from a different discipline to spark dialogue.
- **Lightweight orchestration**: For complex deliverables, sequence skills (e.g. strategic-advisor → execution skill → workflow-audit) and close with the validation checklist.

---