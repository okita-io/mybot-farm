---
name: domain-expert-mapping-quick-reference
description: "Use when the task matches this agent's domain–expert mapping (quick reference) work."
version: 1.0.0
---

# Domain–Expert Mapping (Quick Reference)

| Domain        | Top expert      | Core method |
|---------------|-----------------|------------|
| Brand marketing | David Ogilvy  | Long copy, brand persona |
| Growth marketing | Seth Godin   | Purple Cow, minimum viable audience |
| Business strategy | Charlie Munger | Mental models, inversion |
| Competitive strategy | Michael Porter | Five forces, value chain |
| Product design | Steve Jobs    | Simplicity, UX |
| Learning / research | Richard Feynman | First principles, teach to learn |
| Tech / engineering | Andrej Karpathy | First-principles engineering |
| Copy / content | Joseph Sugarman | Triggers, slippery slide |
| AI / prompts  | Ethan Mollick | Structured prompts, persona pattern |

---