---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Note and Task Closure Checklist
- Luhmann four-principle check (table or bullet list).
- Filing path and ≥2 link descriptions.
- Daily log entry (Intent / Changes / Open loops); optional Hub triplet (Top links / Tags / Open loops) at top.
- For new notes: link-proposer output (link candidates + keyword suggestions); shareability judgment and where to file it.

### File Naming
- `YYYYMMDD_short-description.md` (or your locale’s date format + slug).

### Deliverable Template (Task Close)
```markdown
## Validation
- [ ] Luhmann four principles (atomic / connected / organic / dialogue)
- [ ] Filing path + ≥2 links
- [ ] Daily log updated
- [ ] Open loops: promoted "easy to forget" items to open-loops file
- [ ] If new note: link candidates + keyword suggestions + shareability
```

### Daily Log Entry Example
```markdown
### [YYYYMMDD] Short task title

- **Intent**: What the user wanted to accomplish.
- **Changes**: What was done (files, links, decisions).
- **Open loops**: [ ] Unresolved item 1; [ ] Unresolved item 2 (or "None.")
```

### Deep-reading output example (structure note)

After a deep-learning run (e.g. book/long video), the structure note ties atomic notes into a navigable reading order and logic tree. Example from *Deep Dive into LLMs like ChatGPT* (Karpathy):

```markdown
---
type: Structure_Note
tags: [LLM, AI-infrastructure, deep-learning]
links: ["[[Index_LLM_Stack]]", "[[Index_AI_Observations]]"]
---

# [Title] Structure Note

> **Context**: When, why, and under what project this was created.
> **Default reader**: Yourself in six months—this structure is self-contained.

## Overview (5 Questions)
1. What problem does it solve?
2. What is the core mechanism?
3. Key concepts (3–5) → each linked to atomic notes [[YYYYMMDD_Atomic_Topic]]
4. How does it compare to known approaches?
5. One-sentence summary (Feynman test)

## Logic Tree
Proposition 1: …
├─ [[Atomic_Note_A]]
├─ [[Atomic_Note_B]]
└─ [[Atomic_Note_C]]
Proposition 2: …
└─ [[Atomic_Note_D]]

## Reading Sequence
1. **[[Atomic_Note_A]]** — Reason: …
2. **[[Atomic_Note_B]]** — Reason: …
```

Companion outputs: execution plan (`YYYYMMDD_01_[Book_Title]_Execution_Plan.md`), atomic/method notes, index note for the topic, workflow-audit report. See **deep-learning** in [zk-steward-companion](https://github.com/mikonos/zk-steward-companion).