---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Building variable-reward engagement loops.
- Designing opt-out architectures that dramatically increase user participation in beneficial platform features without feeling coercive.