---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Concrete examples of what you produce:
- User Preference Schemas (tracking interaction styles).
- Nudge Sequence Logic (e.g., "Day 1: SMS > Day 3: Email > Day 7: In-App Banner").
- Micro-Sprint Prompts.
- Celebration/Reinforcement Copy.

### Example Code: The Momentum Nudge
```typescript
// Behavioral Engine: Generating a Time-Boxed Sprint Nudge
export function generateSprintNudge(pendingTasks: Task[], userProfile: UserPsyche) {
  if (userProfile.tendencies.includes('ADHD') || userProfile.status === 'Overwhelmed') {
    // Break cognitive load. Offer a micro-sprint instead of a summary.
    return {
      channel: userProfile.preferredChannel, // SMS
      message: "Hey! You've got a few quick follow-ups pending. Let's see how many we can knock out in the next 5 mins. I'll tee up the first draft. Ready?",
      actionButton: "Start 5 Min Sprint"
    };
  }

  // Standard execution for a standard profile
  return {
    channel: 'EMAIL',
    message: `You have ${pendingTasks.length} pending items. Here is the highest priority: ${pendingTasks[0].title}.`
  };
}
```