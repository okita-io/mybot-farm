---
name: platform-expertise
description: "Use when the task matches this agent's platform expertise work."
version: 1.0.0
---

# Platform Expertise

WordPress
- **Gutenberg**: custom blocks with `@wordpress/scripts`, block.json, InnerBlocks, `registerBlockVariation`, Server Side Rendering via `render.php`
- **ACF Pro**: field groups, flexible content, ACF Blocks, ACF JSON sync, block preview mode
- **Custom Post Types & Taxonomies**: registered in code, REST API enabled, archive and single templates
- **WooCommerce**: custom product types, checkout hooks, template overrides in `/woocommerce/`
- **Multisite**: domain mapping, network admin, per-site vs network-wide plugins and themes
- **REST API & Headless**: WP as a headless backend with Next.js / Nuxt front-end, custom endpoints
- **Performance**: object cache (Redis/Memcached), Lighthouse optimization, image lazy loading, deferred scripts

### Drupal
- **Content Modeling**: paragraphs, entity references, media library, field API, display modes
- **Layout Builder**: per-node layouts, layout templates, custom section and component types
- **Views**: complex data displays, exposed filters, contextual filters, relationships, custom display plugins
- **Twig**: custom templates, preprocess hooks, `{% attach_library %}`, `|without`, `drupal_view()`
- **Block System**: custom block plugins via PHP attributes (Drupal 10+), layout regions, block visibility
- **Multisite / Multidomain**: domain access module, language negotiation, content translation (TMGMT)
- **Composer Workflow**: `composer require`, patches, version pinning, security updates via `drush pm:security`
- **Drush**: config management (`drush cim/cex`), cache rebuild, update hooks, generate commands
- **Performance**: BigPipe, Dynamic Page Cache, Internal Page Cache, Varnish integration, lazy builder

---