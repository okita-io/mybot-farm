---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

WordPress: Custom Theme Structure

```
my-theme/
├── style.css              # Theme header only — no styles here
├── functions.php          # Enqueue scripts, register features
├── index.php
├── header.php / footer.php
├── page.php / single.php / archive.php
├── template-parts/        # Reusable partials
│   ├── content-card.php
│   └── hero.php
├── inc/
│   ├── custom-post-types.php
│   ├── taxonomies.php
│   ├── acf-fields.php     # ACF field group registration (JSON sync)
│   └── enqueue.php
├── assets/
│   ├── css/
│   ├── js/
│   └── images/
└── acf-json/              # ACF field group sync directory
```

### WordPress: Custom Plugin Boilerplate

```php
<?php
/**
 * Plugin Name: My Agency Plugin
 * Description: Custom functionality for [Client].
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 8.1
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'MY_PLUGIN_VERSION', '1.0.0' );
define( 'MY_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

// Autoload classes
spl_autoload_register( function ( $class ) {
    $prefix = 'MyPlugin\\';
    $base_dir = MY_PLUGIN_PATH . 'src/';
    if ( strncmp( $prefix, $class, strlen( $prefix ) ) !== 0 ) return;
    $file = $base_dir . str_replace( '\\', '/', substr( $class, strlen( $prefix ) ) ) . '.php';
    if ( file_exists( $file ) ) require $file;
} );

add_action( 'plugins_loaded', [ new MyPlugin\Core\Bootstrap(), 'init' ] );
```

### WordPress: Register Custom Post Type (code, not UI)

```php
add_action( 'init', function () {
    register_post_type( 'case_study', [
        'labels'       => [
            'name'          => 'Case Studies',
            'singular_name' => 'Case Study',
        ],
        'public'        => true,
        'has_archive'   => true,
        'show_in_rest'  => true,   // Gutenberg + REST API support
        'menu_icon'     => 'dashicons-portfolio',
        'supports'      => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ],
        'rewrite'       => [ 'slug' => 'case-studies' ],
    ] );
} );
```

### Drupal: Custom Module Structure

```
my_module/
├── my_module.info.yml
├── my_module.module
├── my_module.routing.yml
├── my_module.services.yml
├── my_module.permissions.yml
├── my_module.links.menu.yml
├── config/
│   └── install/
│       └── my_module.settings.yml
└── src/
    ├── Controller/
    │   └── MyController.php
    ├── Form/
    │   └── SettingsForm.php
    ├── Plugin/
    │   └── Block/
    │       └── MyBlock.php
    └── EventSubscriber/
        └── MySubscriber.php
```

### Drupal: Module info.yml

```yaml
name: My Module
type: module
description: 'Custom functionality for [Client].'
core_version_requirement: ^10 || ^11
package: Custom
dependencies:
  - drupal:node
  - drupal:views
```

### Drupal: Implementing a Hook

```php
<?php
// my_module.module

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Implements hook_node_access().
 */
function my_module_node_access(EntityInterface $node, $op, AccountInterface $account) {
  if ($node->bundle() === 'case_study' && $op === 'view') {
    return $account->hasPermission('view case studies')
      ? AccessResult::allowed()->cachePerPermissions()
      : AccessResult::forbidden()->cachePerPermissions();
  }
  return AccessResult::neutral();
}
```

### Drupal: Custom Block Plugin

```php
<?php
namespace Drupal\my_module\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Block\Attribute\Block;
use Drupal\Core\StringTranslation\TranslatableMarkup;

#[Block(
  id: 'my_custom_block',
  admin_label: new TranslatableMarkup('My Custom Block'),
)]
class MyBlock extends BlockBase {

  public function build(): array {
    return [
      '#theme' => 'my_custom_block',
      '#attached' => ['library' => ['my_module/my-block']],
      '#cache' => ['max-age' => 3600],
    ];
  }

}
```

### WordPress: Gutenberg Custom Block (block.json + JS + PHP render)

**block.json**
```json
{
  "$schema": "https://schemas.wp.org/trunk/block.json",
  "apiVersion": 3,
  "name": "my-theme/case-study-card",
  "title": "Case Study Card",
  "category": "my-theme",
  "description": "Displays a case study teaser with image, title, and excerpt.",
  "supports": { "html": false, "align": ["wide", "full"] },
  "attributes": {
    "postId":   { "type": "number" },
    "showLogo": { "type": "boolean", "default": true }
  },
  "editorScript": "file:./index.js",
  "render": "file:./render.php"
}
```

**render.php**…