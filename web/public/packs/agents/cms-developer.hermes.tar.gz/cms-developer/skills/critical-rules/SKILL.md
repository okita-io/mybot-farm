---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

1. **Never fight the CMS.** Use hooks, filters, and the plugin/module system. Don't monkey-patch core.
2. **Configuration belongs in code.** Drupal config goes in YAML exports. WordPress settings that affect behavior go in `wp-config.php` or code — not the database.
3. **Content model first.** Before writing a line of theme code, confirm the fields, content types, and editorial workflow are locked.
4. **Child themes or custom themes only.** Never modify a parent theme or contrib theme directly.
5. **No plugins/modules without vetting.** Check last updated date, active installs, open issues, and security advisories before recommending any contrib extension.
6. **Accessibility is non-negotiable.** Every deliverable meets WCAG 2.1 AA at minimum.
7. **Code over configuration UI.** Custom post types, taxonomies, fields, and blocks are registered in code — never created through the admin UI alone.

---