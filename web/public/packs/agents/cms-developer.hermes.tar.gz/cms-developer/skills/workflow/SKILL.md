---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Step 1: Discover & Model (Before Any Code)

1. **Audit the brief**: content types, editorial roles, integrations (CRM, search, e-commerce), multilingual needs
2. **Choose CMS fit**: Drupal for complex content models / enterprise / multilingual; WordPress for editorial simplicity / WooCommerce / broad plugin ecosystem
3. **Define content model**: map every entity, field, relationship, and display variant — lock this before opening an editor
4. **Select contrib stack**: identify and vet all required plugins/modules upfront (security advisories, maintenance status, install count)
5. **Sketch component inventory**: list every template, block, and reusable partial the theme will need

### Step 2: Theme Scaffold & Design System

1. Scaffold theme (`wp scaffold child-theme` or `drupal generate:theme`)
2. Implement design tokens via CSS custom properties — one source of truth for color, spacing, type scale
3. Wire up asset pipeline: `@wordpress/scripts` (WP) or a Webpack/Vite setup attached via `.libraries.yml` (Drupal)
4. Build layout templates top-down: page layout → regions → blocks → components
5. Use ACF Blocks / Gutenberg (WP) or Paragraphs + Layout Builder (Drupal) for flexible editorial content

### Step 3: Custom Plugin / Module Development

1. Identify what contrib handles vs what needs custom code — don't build what already exists
2. Follow coding standards throughout: WordPress Coding Standards (PHPCS) or Drupal Coding Standards
3. Write custom post types, taxonomies, fields, and blocks **in code**, never via UI only
4. Hook into the CMS properly — never override core files, never use `eval()`, never suppress errors
5. Add PHPUnit tests for business logic; Cypress/Playwright for critical editorial flows
6. Document every public hook, filter, and service with docblocks

### Step 4: Accessibility & Performance Pass

1. **Accessibility**: run axe-core / WAVE; fix landmark regions, focus order, color contrast, ARIA labels
2. **Performance**: audit with Lighthouse; fix render-blocking resources, unoptimized images, layout shifts
3. **Editor UX**: walk through the editorial workflow as a non-technical user — if it's confusing, fix the CMS experience, not the docs

### Step 5: Pre-Launch Checklist

```
□ All content types, fields, and blocks registered in code (not UI-only)
□ Drupal config exported to YAML; WordPress options set in wp-config.php or code
□ No debug output, no TODO in production code paths
□ Error logging configured (not displayed to visitors)
□ Caching headers correct (CDN, object cache, page cache)
□ Security headers in place: CSP, HSTS, X-Frame-Options, Referrer-Policy
□ Robots.txt / sitemap.xml validated
□ Core Web Vitals: LCP < 2.5s, CLS < 0.1, INP < 200ms
□ Accessibility: axe-core zero critical errors; manual keyboard/screen reader test
□ All custom code passes PHPCS (WP) or Drupal Coding Standards
□ Update and maintenance plan handed off to client
```

---