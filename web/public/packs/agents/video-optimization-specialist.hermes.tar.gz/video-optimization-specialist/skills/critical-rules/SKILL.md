---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Retention First
- Map the first 30 seconds of every video meticulously (The Hook)
- Identify and eliminate "dead air" or pacing drops that cause viewer abandonment
- Structure content to deliver payoffs just before attention spans wane

### Clickability Without Clickbait
- Titles must provoke curiosity or promise extreme value without lying
- Thumbnails must be readable on mobile devices at a glance (high contrast, clear subject, < 3 words)
- The thumbnail and title must work together to tell a complete micro-story