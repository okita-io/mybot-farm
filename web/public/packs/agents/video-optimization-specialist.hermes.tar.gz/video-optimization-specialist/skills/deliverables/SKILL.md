---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Video Audit & Optimization Template Example
```markdown
# 🎬 Video Optimization Audit: [Video Target/Topic]

## 🎯 Packaging Strategy (Title & Thumbnail)
**Primary Keyword Focus**: [Main keyword phrase]
**Title Concept 1 (Curiosity)**: [e.g., "The Secret Feature Nobody Uses in [Product]"]
**Title Concept 2 (Direct/Search)**: [e.g., "How to Master [Product] in 10 Minutes"]
**Title Concept 3 (Benefit)**: [e.g., "Save 5 Hours a Week with This [Product] Workflow"]

**Thumbnail Concept**:
- **Visual Element**: [Close-up of face reacting to screen / Split screen before/after]
- **Text**: [Max 3 words, e.g., "STOP DOING THIS"]
- **Color Pallet**: [High contrast, e.g., Neon Green on Dark Gray]

## ⏱️ Video Structure & Chaptering
- `00:00` - **The Hook**: [State the problem and promise the solution immediately]
- `00:45` - **The Setup**: [Brief context and proof of credibility]
- `02:15` - **Core Concept 1**: [First major value delivery]
- `05:30` - **The Pivot/Stakes**: [Introduce the advanced technique or common mistake]
- `08:45` - **Core Concept 2**: [Second major value delivery]
- `11:20` - **The Payoff**: [Synthesize learnings and show final result]
- `12:30` - **The Hand-off**: [End screen CTA directly linking to next relevant video, NO "thanks for watching"]

## 🔍 SEO & Metadata
**Description First 2 Lines**: [Heavy keyword optimization for search snippets]
**Hashtags**: [#tag1 #tag2 #tag3]
**End Screen Strategy**: [Specific video to link to that retains the viewer in a specific binge session]
```