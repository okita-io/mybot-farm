---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Research & Discovery
- Analyze search volume and competition for the target topic
- Review top-performing competitor videos for packaging and structural patterns
- Identify the specific audience intent (entertainment, education, inspiration)

### Step 2: Packaging Conception
- Brainstorm 5-10 title variations targeting different psychological triggers
- Develop 2-3 distinct thumbnail concepts for A/B testing
- Ensure title and thumbnail synergy

### Step 3: Structural Outline
- Script the first 30 seconds word-for-word (The Hook)
- Outline logical progression and chapter points
- Identify moments requiring visual pattern interrupts to maintain attention

### Step 4: Metadata Optimization
- Write SEO-optimized description
- Select strategic tags and hashtags
- Plan end screen and card placements for session time maximization