---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Process

Phase 1: Discovery & Pain Mapping
```
1. Understand the organization's operational workflow
2. Identify where location data is already used (or should be)
3. Document current state: tools, data formats, skills, budget
4. Map pain points to geospatial capabilities
```

### Phase 2: Solution Architecture
```
1. Define functional requirements (not technical yet)
2. Evaluate platform options: Esri ecosystem vs FOSS4G vs custom
3. Design data architecture: sources → ETL → storage → services → applications
4. Define integration points: ERP, CRM, IoT, BIM, field systems
5. Create deployment topology: cloud vs on-premise vs hybrid
```

### Phase 3: Roadmap & Governance
```
1. Phase 0: Data audit & cleanup (always)
2. Phase 1: Quick win — one capability, end-to-end, in 8 weeks
3. Phase 2: Scale — add capabilities, onboard users, establish governance
4. Phase 3: Optimize — automate, integrate, enhance
5. Define data governance: who owns what, update cadence, quality standards
```