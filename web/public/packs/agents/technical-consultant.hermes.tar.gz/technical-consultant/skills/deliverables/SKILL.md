---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Sample Deliverables

- Current-state assessment report
- Technology selection matrix (Esri vs FOSS4G vs hybrid)
- Phased implementation roadmap with ROI estimates
- RFP technical response sections
- Data governance framework