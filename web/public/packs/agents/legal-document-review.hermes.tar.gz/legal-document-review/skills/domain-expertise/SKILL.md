---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Contract Types

**Commercial Contracts**
- Master Service Agreements (MSAs): scope, SLAs, payment, IP, indemnification
- Non-Disclosure Agreements (NDAs): scope, duration, permitted disclosure, remedies
- Vendor Agreements: deliverables, payment terms, warranties, termination
- Licensing Agreements: scope of license, royalties, IP ownership, sublicensing rights
- Employment Agreements: compensation, benefits, non-compete, IP assignment, termination

**Real Estate Documents**
- Purchase and Sale Agreements: price, contingencies, closing conditions, representations
- Commercial Leases: rent, CAM charges, use restrictions, improvement allowances, options
- Residential Leases: rent, security deposit, maintenance, termination, renewal
- Loan Agreements: interest rate, covenants, events of default, prepayment penalties
- Title Documents: easements, encumbrances, title exceptions, survey issues

**Corporate Documents**
- Operating Agreements: member rights, voting, distributions, transfer restrictions
- Shareholder Agreements: drag-along, tag-along, right of first refusal, anti-dilution
- Asset Purchase Agreements: assets included/excluded, representations, indemnification
- Stock Purchase Agreements: reps and warranties, closing conditions, escrow

### Litigation Documents

- **Complaints**: causes of action, damages alleged, jurisdiction, statute of limitations
- **Motions**: legal standard, argument structure, supporting authority, procedural compliance
- **Discovery Responses**: completeness, objection basis, privilege claims, responsiveness
- **Settlement Agreements**: release scope, payment terms, confidentiality, enforcement
- **Court Orders**: compliance requirements, deadlines, contempt exposure

### Compliance Frameworks

- **Employment Law**: FLSA, FMLA, ADA, Title VII, state wage and hour laws
- **Data Privacy**: GDPR, CCPA/CPRA, HIPAA, state privacy laws
- **Real Estate**: Fair Housing Act, RESPA, local zoning and disclosure requirements
- **Corporate**: Sarbanes-Oxley, securities regulations, state corporate law requirements
- **Industry-Specific**: financial services (Dodd-Frank), healthcare (HIPAA/HITECH), government contracting (FAR)

---