---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Document Summary Template

```
DOCUMENT SUMMARY
───────────────────────────────────────
Document Type:      [Contract / Motion / Lease / Settlement / etc.]
Parties:            [Party A] and [Party B]
Our Client:         [Which party we represent]
Date:               [Effective date or document date]
Jurisdiction:       [Governing law / jurisdiction]
Review Purpose:     [Initial review / negotiation / due diligence / litigation]

KEY TERMS AT A GLANCE
───────────────────────────────────────
Term/Duration:      [Length of agreement]
Payment/Value:      [Economic terms — fees, purchase price, rent, etc.]
Termination:        [How either party can exit]
Renewal:            [Auto-renewal terms, notice requirements]
Governing Law:      [Which state/jurisdiction governs]
Dispute Resolution: [Litigation / arbitration / mediation / venue]
Liability Cap:      [Maximum exposure]
Indemnification:    [Who indemnifies whom for what]
IP Ownership:       [Who owns work product / IP created]
Confidentiality:    [NDA provisions if any]

MISSING STANDARD TERMS ⚠️
───────────────────────────────────────
[ ] Limitation of liability clause
[ ] Indemnification provisions
[ ] Force majeure clause
[ ] Dispute resolution mechanism
[ ] IP ownership / work for hire clause
[ ] Data privacy / security provisions
[ ] Insurance requirements
[List any other missing terms flagged]

OVERALL RISK ASSESSMENT
───────────────────────────────────────
Risk Level:    🔴 HIGH / 🟡 MEDIUM / 🟢 LOW
Risk Summary:  [2-3 sentence overall risk assessment]
Priority Issues: [Number of high-priority issues flagged]
```

### Risk Clause Flagging Template

```
FLAGGED CLAUSES — RISK ANALYSIS
───────────────────────────────────────
🔴 HIGH RISK — Requires Immediate Attorney Attention

Issue #1: [Clause Title / Section Reference]
  Location:    Section [X], Page [Y]
  Language:    "[Exact clause language or summary]"
  Risk:        [What this clause does and why it's dangerous]
  Market Std:  [What market standard language looks like]
  Impact:      [Potential financial, legal, or operational impact]
  Recommended: [Suggested revision or negotiation position]

Issue #2: [Clause Title / Section Reference]
  [Same structure]

─────────────────────────────────────
🟡 MEDIUM RISK — Review and Consider Negotiating

Issue #3: [Clause Title / Section Reference]
  Location:    Section [X], Page [Y]
  Language:    "[Exact clause language or summary]"
  Risk:        [What this clause does and why it warrants attention]
  Market Std:  [What market standard looks like]
  Recommended: [Suggested revision or negotiation position]

─────────────────────────────────────
🟢 LOW RISK — Note for Attorney Awareness

Issue #4: [Clause Title / Section Reference]
  Location:    Section [X], Page [Y]
  Note:        [Why flagged — unusual but not necessarily dangerous]
  Recommended: [Monitor / accept / minor revision]

─────────────────────────────────────
RISK SUMMARY TABLE
  🔴 High Risk Issues:    [#]
  🟡 Medium Risk Issues:  [#]
  🟢 Low Risk Issues:     [#]
  ⚠️  Missing Terms:      [#]
  Total Issues Flagged:   [#]
```

### Contract Comparison Template

```
VERSION COMPARISON REPORT
───────────────────────────────────────
Document:       [Contract name]
Version A:      [Original / Prior version — date]
Version B:      [Revised / Current version — date]
Comparison By:  [Attorney name / matter reference]

CHANGE SUMMARY
───────────────────────────────────────
Total Changes Detected:  [#]
  Material Changes:      [#] — Changes that affect rights, obligations, or risk
  Administrative Changes:[#] — Formatting, defined terms, minor wording
  Additions:             [#] — New clauses or provisions added
  Deletions:             [#] — Clauses or provisions removed

MATERIAL CHANGES — DETAILED ANALYSIS
───────────────────────────────────────
Change #1: [Section / Clause Title]
  Version A:   "[Original language]"
  Version B:   "[Revised language]"
  Impact:      [What changed and why it matters]
  Favorable:   [Favorable to our client / Unfavorable / Neutral]
  Recommended: [Accept / Reject / Counter-propose]

Change #2: [Section / Clause Title]
  [Same structure]

ADDITIONS — NEW PROVISIONS
───────────────────────────────────────
[List all new clauses added in Version B with risk assessment]

DELETIONS — REMOVED PROVISIONS
───────────────────────────────────────
[List all clauses removed from Version A with impact assessment]

NEGOTIATION SCORECARD
───────────────────────────────────────…