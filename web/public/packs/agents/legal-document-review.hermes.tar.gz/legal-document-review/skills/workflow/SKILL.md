---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Document Intake & Classification

1. **Identify document type** — contract, motion, lease, settlement, discovery, etc.
2. **Identify the parties** — full legal names, roles, and which party is our client
3. **Identify the jurisdiction** — governing law and any multi-jurisdictional considerations
4. **Identify the review purpose** — initial review, due diligence, negotiation, litigation support
5. **Confirm attorney's priorities** — any specific clauses, risks, or issues to focus on
6. **Set risk tolerance** — conservative (flag everything) vs. standard (flag material issues)

### Step 2: Structural Analysis

1. **Map the document structure** — identify all sections, exhibits, schedules, and attachments
2. **Identify defined terms** — capture the defined terms dictionary and check for consistency
3. **Check for missing standard provisions** — identify what should be there but isn't
4. **Identify cross-references** — flag any internal cross-references that may be incorrect or ambiguous
5. **Check execution requirements** — signature blocks, notarization, witness requirements

### Step 3: Substantive Review

1. **Economic terms** — payment, pricing, fees, penalties, adjustments
2. **Term and termination** — duration, renewal, termination rights, notice requirements
3. **Risk allocation** — indemnification, limitation of liability, insurance, warranties
4. **Intellectual property** — ownership, licenses, work for hire, pre-existing IP
5. **Confidentiality** — scope, duration, exceptions, return/destruction obligations
6. **Dispute resolution** — governing law, venue, arbitration, mediation, jury waiver
7. **Compliance provisions** — regulatory requirements, audit rights, reporting obligations
8. **Special provisions** — any industry-specific or deal-specific terms requiring attention

### Step 4: Risk Assessment & Flagging

1. **Score each flagged clause** — High / Medium / Low risk
2. **Assess cumulative risk** — how do individual risks interact to create overall exposure?
3. **Prioritize negotiation targets** — which issues are must-fix vs. nice-to-fix
4. **Draft suggested revisions** — for high-risk items, provide suggested alternative language
5. **Note jurisdiction-specific concerns** — enforceability issues by state or country

### Step 5: Deliverable Preparation

1. **Executive summary** — one-page overview for partner or client briefing
2. **Detailed risk report** — full clause-by-clause analysis
3. **Negotiation priority list** — ranked list of issues to address in negotiation
4. **Suggested redlines** — recommended language changes for high-priority items
5. **Next steps** — clear, prioritized action items for the reviewing attorney

---