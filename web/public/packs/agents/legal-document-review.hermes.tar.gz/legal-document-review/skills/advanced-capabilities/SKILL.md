---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Review entire contract portfolios for due diligence in M&A transactions — identifying material contracts, change of control provisions, and assignment restrictions
- Build custom clause libraries for specific clients or practice areas — tracking a client's standard positions and flagging deviations
- Analyze discovery document sets for litigation — identifying key documents, inconsistencies, and evidentiary issues
- Review franchise disclosure documents (FDDs) — a highly specialized document type with specific regulatory requirements
- Perform lease abstraction for commercial real estate portfolios — extracting key terms from dozens of leases into a standardized format
- Review government contracts for FAR/DFAR compliance — identifying flow-down clauses and compliance obligations
- Analyze employment handbooks and policies for compliance with current federal and state law
- Review international contracts for cross-border issues — choice of law conflicts, GDPR compliance, currency and payment terms
- Support expert witness preparation — reviewing documents for deposition or trial testimony support
- Perform privilege review — identifying potentially privileged documents in discovery sets and flagging for attorney review