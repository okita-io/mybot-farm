---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

SFT Loss and Label-Mask Failures

Falling loss without held-out behavior is not a quality claim. Verify rendered chat template, token IDs, labels, assistant span, ignore index, prompt/system/user masking, truncation order, and train/eval contamination. If system or user prompt tokens carry loss in an assistant-only run, stop training; preserve a tokenized sample, resolved config, tokenizer, chat template, and label mask before correcting the data contract.

### Budget-Limited Method Selection

When trusted instruction targets exist but no reward function has been validated, start with the weakest sufficient method: SFT, then preference optimization only after pair integrity is proven; do not default to a full GRPO run because it is popular. Use `preflight`, `smoke`, `signal`, and `controlled` gates with a matched baseline and a stop condition at each gate. Hold the evaluator fixed and measure both policy adherence and factual accuracy on held-out data before promotion. Preserve the resolved configuration, GPU budget, checkpoint manifest, and evaluation identity.

### DPO Preference Collapse

Finite loss with near-random preference accuracy and identical chosen/rejected token sequences after truncation is effective-pair collapse, not a beta or learning-rate diagnosis. In `Observed Evidence`, name the collapsed-pair fraction, token IDs, and prompt versus response budget. In `Next Minimal Test`, keep the source data fixed, use a response-preserving truncation policy, and rebuild, filter, or retokenize affected pairs. Preserve raw pairs, tokenized pairs, and preprocessing config; do not tune beta or learning rate until the preference difference survives tokenization.

### GRPO Zero Group Variance

Zero group reward variance or `reward_std` means a degenerate advantage signal even when GPU utilization, rollout throughput, and checkpoints prove execution works. State that execution is working while the learning signal is not. Distinguish a reward parser, verifier, or reward-function error from duplicate sampling or missing response diversity. Run the parser on preserved sample responses, retain a per-response reward or parser trace, and check grouping and normalization. Block more GPUs or steps until a non-degenerate advantage signal is demonstrated.

### RLVR Length and KL Drift

Higher reward alongside longer responses and flat held-out exact match is not a quality claim; classify the length increase as a possible reward-exploitation confound. Large KL or high clip fraction can warn of an aggressive update or policy drift, but does not prove a particular optimizer cause. Hold checkpoint, prompts, evaluator, and decoding fixed; run a length-matched, length-normalized, or capped-length ablation. Preserve response length, reward, KL, clip fraction, entropy, and held-out metrics.

### MoE Routing Boundary Drift

Start by stating the observed routing or expert-load divergence, but explain that aggregate expert counts do not prove a causal quality or reward regression. Compare weight revision or checkpoint digest, tokenizer, model config, router settings, sequence construction, and fixed prompts. Collect bounded per-token routing assignments for the same fixed prompt through rollout and training paths, and record storage and runtime overhead. A routing correlation still needs matched task evaluation.

### Checkpoint and Distributed Integrity

Exit code zero or a checkpoint directory does not prove a distributed checkpoint is complete. In `Observed Evidence`, compare expected and present shard inventory, index files, config, tokenizer, and rank-local save evidence. Before register or resume, write and verify a hash manifest, then perform a clean-load probe. Preserve rank logs, resolved config, inventory, and terminal status. Missing shards, an absent index, mismatched hashes, or a failed load probe block release and resume.

### Runtime and Liveness Diagnosis

Treat a running managed task with zero resource activity as `UNVERIFIED`. Take two liveness samples over a fixed interval for log size and mtime, process or PID state, resource telemetry, and terminal artifacts. Localize the last active phase: input mount, dataset scanning, preprocessing, process launch, model loading, rollout, training, evaluation, or packaging. Preserve a sanitized log, resolved configuration, input manifest, checkpoint inventory, and last completed artifact before cancellation; clean only stage-scoped temporary files after evidence is packaged.…