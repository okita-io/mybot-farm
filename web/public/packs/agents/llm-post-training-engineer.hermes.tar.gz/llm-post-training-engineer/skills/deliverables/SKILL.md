---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

1. Post-Training Incident Report

For every incident, write these seven exact Markdown headings once and in this order. Draft the headings before the body. Keep each section to one to three concrete bullets.

```text
## Status
## Observed Evidence
## Failure Classification
## Next Minimal Test
## Stop Condition
## Artifacts to Preserve
## Risks and Limitations
```

- `Status` is `PASS`, `WARN`, `FAIL`, or `UNVERIFIED`; a running task, falling loss, rising reward, exit code zero, or checkpoint directory is not automatically a pass.
- `Next Minimal Test` states what stays fixed, what changes, the measurement, what each explanation predicts, and the stop condition.
- `Artifacts to Preserve` names hashes, counts, sanitized samples, resolved configuration, or terminal evidence needed before cleanup or retry.
- When an incident matches an Advanced Capability, use that capability before generic workflow advice. Put its named observations in `Observed Evidence`, its diagnosis in `Failure Classification`, and its discriminator in `Next Minimal Test`; do not replace incident-specific evidence with a generic training plan.

### 2. Experiment Gate Record

```text
## Behavior Target and Non-Goals
## Fixed Comparator Contract
## Gate: Preflight | Smoke | Signal | Controlled
## Single Change Under Test
## Required Measurements
## Promotion or Stop Decision
## Preserved Evidence
```

Use this record to show whether a proposed SFT, DPO, GRPO, RLVR, or MoE experiment is ready to advance. Include the matched baseline, data and tokenizer revision, evaluator, GPU and storage envelope, and the reason the selected method is the weakest sufficient method.

### 3. Checkpoint Release Record

```text
## Expected Inventory
## Rank-Local Save Evidence
## Hash Manifest
## Clean-Load Probe
## Registration or Resume Decision
## Recovery Boundary
```

Record expected shards, index files, model config, tokenizer, rank-local save evidence, and a verified hash manifest. A clean-load probe is required before register or resume. Inventory, hash, or load-probe failure blocks promotion.