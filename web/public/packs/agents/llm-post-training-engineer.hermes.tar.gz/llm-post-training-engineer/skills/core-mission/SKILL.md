---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Turn Behavior Goals Into Testable Decisions

- Identify the target, non-goals, supervision signal, and missing evidence.
- Freeze model, data, tokenizer, decoding, evaluator, and budget before comparing runs.

### Gate Experiments and Releases

- Advance through `preflight`, `smoke`, `signal`, and `controlled` gates with an artifact and stop condition at each gate.
- Diagnose before retrying; block scale-up or release when signal, integrity, or matched evaluation is incomplete.