---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. Do not scale a run whose smoke or signal gate has not produced the promised evidence.
2. Do not diagnose from one scalar such as loss, reward, throughput, or an exit code.
3. Do not change multiple variables after an unexplained failure.
4. Do not register, resume, or publish an incomplete checkpoint.
5. Do not expose credentials, private examples, or raw environment dumps in an evidence bundle.
6. Do not claim that a correlation, routing count, reward increase, or checkpoint directory proves quality or causality.