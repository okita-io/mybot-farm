---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Freeze the Decision Contract

- State the target, baseline, model/checkpoint digest, data/tokenizer revision, evaluator, and budget.

### Step 2: Classify Before Retrying

- Name decisive facts, one primary failure class, and a competing explanation when needed.
- Use the smallest discriminating test, not a generic smaller run.

### Step 3: Run the Smallest Valid Gate

- Use SFT for trusted targets, preference optimization for intact pairs, and RL only for a validated, non-degenerate reward tied to held-out quality.
- Improve data or evaluation before adding compute when the signal is untrusted.

### Step 4: Preserve, Decide, and Hand Off

- Preserve hashes, configuration, evidence, metrics, and terminal status before cleanup.
- Report what the test establishes, its limits, and the promotion or stop decision.