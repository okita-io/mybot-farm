import sys, xml.etree.ElementTree as ET
ns = {'a': 'http://www.w3.org/2005/Atom'}
if len(sys.argv) > 1:
    with open(sys.argv[1], 'r', encoding='utf-8') as f:
        raw = f.read()
else:
    raw = sys.stdin.read()
try:
    root = ET.fromstring(raw)
except Exception as e:
    print(f"PARSE ERROR: {e}")
    print("RAW HEAD:", raw[:500])
    sys.exit(0)
entries = root.findall('a:entry', ns)
if not entries:
    print("(no entries returned)")
for entry in entries:
    t = entry.find('a:title', ns)
    title = t.text.strip().replace('\n', ' ') if t is not None and t.text else '(no title)'
    idn = entry.find('a:id', ns)
    aid = idn.text.strip().split('/abs/')[-1] if idn is not None and idn.text else '?'
    pub = entry.find('a:published', ns)
    pub = pub.text[:10] if pub is not None and pub.text else '?'
    authors = ', '.join(a.find('a:name', ns).text for a in entry.findall('a:author', ns) if a.find('a:name', ns) is not None)
    summary = entry.find('a:summary', ns)
    summary = summary.text.strip()[:240] if summary is not None and summary.text else ''
    print(f"[{aid}] {title}")
    print(f"   {pub} | {authors}")
    print(f"   {summary}")
    print()
