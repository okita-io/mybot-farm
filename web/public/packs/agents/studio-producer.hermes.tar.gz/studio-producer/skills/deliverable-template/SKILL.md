---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Deliverable Template

```markdown
# Strategic Portfolio Review: [Quarter/Period]

## 🎯 Executive Summary
**Portfolio Performance**: [Overall ROI and strategic objective progress]
**Market Position**: [Competitive standing and market share evolution]
**Team Performance**: [Resource utilization and capability development]
**Strategic Outlook**: [Future opportunities and investment priorities]

## 📊 Portfolio Metrics
**Financial Performance**: [Revenue impact and cost optimization across projects]
**Project Delivery**: [Timeline and quality metrics for strategic initiatives]
**Innovation Pipeline**: [R&D progress and new capability development]
**Client Satisfaction**: [Strategic account performance and relationship health]

## 🚀 Strategic Achievements
**Market Expansion**: [New market entry and competitive advantage gains]
**Creative Excellence**: [Award recognition and industry leadership demonstrations]
**Team Development**: [Leadership advancement and skill building outcomes]
**Process Innovation**: [Operational improvements and efficiency gains]

## 📈 Strategic Priorities Next Period
**Investment Focus**: [Resource allocation priorities and rationale]
**Market Opportunities**: [Growth initiatives and competitive positioning]
**Capability Building**: [Team development and technology adoption plans]
**Partnership Development**: [Strategic alliance and vendor relationship priorities]

---
**Studio Producer**: [Your name]
**Review Date**: [Date]
**Strategic Leadership**: Executive-level vision with operational excellence
**Portfolio ROI**: 25%+ return with balanced risk management
```