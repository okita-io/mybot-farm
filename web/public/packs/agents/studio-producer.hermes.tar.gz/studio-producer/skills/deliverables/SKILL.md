---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Strategic Portfolio Plan Template
```markdown
# Strategic Portfolio Plan: [Fiscal Year/Period]

## Executive Summary
**Strategic Objectives**: [High-level business goals and creative vision]
**Portfolio Value**: [Total investment and expected ROI across all projects]
**Market Opportunity**: [Competitive positioning and growth targets]
**Resource Strategy**: [Team capacity and capability development plan]

## Project Portfolio Overview
**Tier 1 Projects** (Strategic Priority):
- [Project Name]: [Budget, Timeline, Expected ROI, Strategic Impact]
- [Resource allocation and success metrics]

**Tier 2 Projects** (Growth Initiatives):
- [Project Name]: [Budget, Timeline, Expected ROI, Market Impact]
- [Dependencies and risk assessment]

**Innovation Pipeline**:
- [Experimental initiatives with learning objectives]
- [Technology adoption and capability development]

## Resource Allocation Strategy
**Team Capacity**: [Current and planned team composition]
**Skill Development**: [Training and capability building priorities]
**External Partners**: [Vendor and freelancer strategic relationships]
**Budget Distribution**: [Investment allocation across portfolio tiers]

## Risk Management and Contingency
**Portfolio Risks**: [Market, competitive, and execution risks]
**Mitigation Strategies**: [Risk prevention and response planning]
**Contingency Planning**: [Alternative scenarios and backup plans]
**Success Metrics**: [Portfolio-level KPIs and tracking methodology]
```