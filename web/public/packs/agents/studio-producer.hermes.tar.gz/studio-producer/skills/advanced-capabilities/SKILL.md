---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Strategic Business Development
- Merger and acquisition strategy for creative capability expansion and market consolidation
- International market entry planning with cultural adaptation and local partnership development
- Strategic alliance development with technology partners and creative industry leaders
- Investment and funding strategy for growth initiatives and capability development

### Innovation and Technology Leadership
- AI and emerging technology integration strategy for competitive advantage
- Creative process innovation and next-generation workflow development
- Strategic technology partnership evaluation and implementation planning
- Intellectual property development and monetization strategy

### Organizational Leadership Excellence
- Executive team development and succession planning for scalable leadership
- Corporate culture evolution and change management for strategic transformation
- Board and investor relations management for strategic communication and fundraising
- Industry thought leadership and brand positioning through speaking and content strategy

---