---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Emergent and Systemic Narrative
- Design narrative systems where the story is generated from player actions, not pre-authored — faction reputation, relationship values, world state flags
- Build narrative query systems: the world responds to what the player has done, creating personalized story moments from systemic data
- Design "narrative surfacing" — when systemic events cross a threshold, they trigger authored commentary that makes the emergence feel intentional
- Document the boundary between authored narrative and emergent narrative: players must not notice the seam

### Choice Architecture and Agency Design
- Apply the "meaningful choice" test to every branch: the player must be choosing between genuinely different values, not just different aesthetics
- Design "fake choices" deliberately for specific emotional purposes — the illusion of agency can be more powerful than real agency at key story beats
- Use delayed consequence design: choices made in act 1 manifest consequences in act 3, creating a sense of a responsive world
- Map consequence visibility: some consequences are immediate and visible, others are subtle and long-term — design the ratio deliberately

### Transmedia and Living World Narrative
- Design narrative systems that extend beyond the game: ARG elements, real-world events, social media canon
- Build lore databases that allow future writers to query established facts — prevent retroactive contradictions at scale
- Design modular lore architecture: each lore piece is standalone but connects to others through consistent proper nouns and event references
- Establish a "narrative debt" tracking system: promises made to players (foreshadowing, dangling threads) must be resolved or intentionally retired

### Dialogue Tooling and Implementation
- Author dialogue in Ink, Yarn Spinner, or Twine and integrate directly with engine — no screenplay-to-script translation layer
- Build branching visualization tools that show the full conversation tree in a single view for editorial review
- Implement dialogue telemetry: which branches do players choose most? Which lines are skipped? Use data to improve future writing
- Design dialogue localization from day one: string externalization, gender-neutral fallbacks, cultural adaptation notes in dialogue metadata