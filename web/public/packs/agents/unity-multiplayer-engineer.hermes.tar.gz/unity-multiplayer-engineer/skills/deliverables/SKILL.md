---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Netcode Project Setup
```csharp
// NetworkManager configuration via code (supplement to Inspector setup)
public class NetworkSetup : MonoBehaviour
{
    [SerializeField] private NetworkManager _networkManager;

    public async void StartHost()
    {
        // Configure Unity Transport
        var transport = _networkManager.GetComponent<UnityTransport>();
        transport.SetConnectionData("0.0.0.0", 7777);

        _networkManager.StartHost();
    }

    public async void StartWithRelay(string joinCode = null)
    {
        await UnityServices.InitializeAsync();
        await AuthenticationService.Instance.SignInAnonymouslyAsync();

        if (joinCode == null)
        {
            // Host: create relay allocation
            var allocation = await RelayService.Instance.CreateAllocationAsync(maxConnections: 4);
            var hostJoinCode = await RelayService.Instance.GetJoinCodeAsync(allocation.AllocationId);

            var transport = _networkManager.GetComponent<UnityTransport>();
            transport.SetRelayServerData(AllocationUtils.ToRelayServerData(allocation, "dtls"));
            _networkManager.StartHost();

            Debug.Log($"Join Code: {hostJoinCode}");
        }
        else
        {
            // Client: join via relay join code
            var joinAllocation = await RelayService.Instance.JoinAllocationAsync(joinCode);
            var transport = _networkManager.GetComponent<UnityTransport>();
            transport.SetRelayServerData(AllocationUtils.ToRelayServerData(joinAllocation, "dtls"));
            _networkManager.StartClient();
        }
    }
# … truncated for farm planting — see upstream for the full sample
```

### Server-Authoritative Player Controller
```csharp
public class PlayerController : NetworkBehaviour
{
    [SerializeField] private float _moveSpeed = 5f;
    [SerializeField] private float _reconciliationThreshold = 0.5f;

    // Server-owned authoritative position
    private NetworkVariable<Vector3> _serverPosition = new NetworkVariable<Vector3>(
        readPerm: NetworkVariableReadPermission.Everyone,
        writePerm: NetworkVariableWritePermission.Server);

    private Queue<InputPayload> _inputQueue = new();
    private Vector3 _clientPredictedPosition;

    public override void OnNetworkSpawn()
    {
        if (!IsOwner) return;
        _clientPredictedPosition = transform.position;
    }

    private void Update()
    {
        if (!IsOwner) return;

        // Read input locally
        var input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")).normalized;

        // Client prediction: move immediately
        _clientPredictedPosition += new Vector3(input.x, 0, input.y) * _moveSpeed * Time.deltaTime;
        transform.position = _clientPredictedPosition;

        // Send input to server
        SendInputServerRpc(input, NetworkManager.LocalTime.Tick);
    }

    [ServerRpc]
    private void SendInputServerRpc(Vector2 input, int tick)
    {
        // Server simulates movement from this input
        Vector3 newPosition = _serverPosition.Value + new Vector3(input.x, 0, input.y) * _moveSpeed * Time.fixedDeltaTime;

# … truncated for farm planting — see upstream for the full sample
```

### Lobby + Matchmaking Integration
```csharp
public class LobbyManager : MonoBehaviour
{
    private Lobby _currentLobby;
    private const string KEY_MAP = "SelectedMap";
    private const string KEY_GAME_MODE = "GameMode";

    public async Task<Lobby> CreateLobby(string lobbyName, int maxPlayers, string mapName)
    {
        var options = new CreateLobbyOptions
        {
            IsPrivate = false,
            Data = new Dictionary<string, DataObject>
            {
                { KEY_MAP, new DataObject(DataObject.VisibilityOptions.Public, mapName) },
                { KEY_GAME_MODE, new DataObject(DataObject.VisibilityOptions.Public, "Deathmatch") }
            }
        };

        _currentLobby = await LobbyService.Instance.CreateLobbyAsync(lobbyName, maxPlayers, options);
        StartHeartbeat(); // Keep lobby alive
        return _currentLobby;
    }

    public async Task<List<Lobby>> QuickMatchLobbies()
    {
        var queryOptions = new QueryLobbiesOptions
        {
            Filters = new List<QueryFilter>
            {
                new QueryFilter(QueryFilter.FieldOptions.AvailableSlots, "1", QueryFilter.OpOptions.GE)
            },
            Order = new List<QueryOrder>
            {…