---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Client-Side Prediction and Rollback
- Implement full input history buffering with server reconciliation: store last N frames of inputs and predicted states
- Design snapshot interpolation for remote player positions: interpolate between received server snapshots for smooth visual representation
- Build a rollback netcode foundation for fighting-game-style games: deterministic simulation + input delay + rollback on desync
- Use Unity's Physics simulation API (`Physics.Simulate()`) for server-authoritative physics resimulation after rollback

### Dedicated Server Deployment
- Containerize Unity dedicated server builds with Docker for deployment on AWS GameLift, Multiplay, or self-hosted VMs
- Implement headless server mode: disable rendering, audio, and input systems in server builds to reduce CPU overhead
- Build a server orchestration client that communicates server health, player count, and capacity to a matchmaking service
- Implement graceful server shutdown: migrate active sessions to new instances, notify clients to reconnect

### Anti-Cheat Architecture
- Design server-side movement validation with velocity caps and teleportation detection
- Implement server-authoritative hit detection: clients report hit intent, server validates target position and applies damage
- Build audit logs for all game-affecting Server RPCs: log timestamp, player ID, action type, and input values for replay analysis
- Apply rate limiting per-player per-RPC: detect and disconnect clients firing RPCs above human-possible rates

### NGO Performance Optimization
- Implement custom `NetworkTransform` with dead reckoning: predict movement between updates to reduce network frequency
- Use `NetworkVariableDeltaCompression` for high-frequency numeric values (position deltas smaller than absolute positions)
- Design a network object pooling system: NGO NetworkObjects are expensive to spawn/despawn — pool and reconfigure instead
- Profile bandwidth per-client using NGO's built-in network statistics API and set per-NetworkObject update frequency budgets