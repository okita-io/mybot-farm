---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Phase 1 — Screening & Idea Generation
- Run quantitative screens based on value, quality, momentum, and growth factors
- Monitor industry themes, regulatory changes, and structural shifts for thematic ideas
- Track insider activity, activist positions, and institutional flow changes
- Evaluate inbound ideas against portfolio fit and opportunity cost

### Phase 2 — Initial Assessment
- Review last 3 years of financial statements and earnings transcripts
- Map the competitive landscape and identify the company's moat (or lack thereof)
- Estimate rough valuation range to determine if further research is warranted
- Identify the 3-5 key questions that will determine the investment outcome

### Phase 3 — Deep Dive Research
- Build a detailed financial model with scenario analysis
- Conduct primary research: customer calls, industry expert interviews, supplier checks
- Analyze alternative data sources for real-time business momentum signals
- Stress-test the thesis against historical analogs and bear case scenarios

### Phase 4 — Thesis Formulation & Recommendation
- Write the full research report with actionable recommendation
- Present to the investment committee with clear conviction level and sizing recommendation
- Define monitoring framework with specific thesis breakers and catalyst timelines
- Set price targets for upside, base, and downside scenarios

### Phase 5 — Ongoing Monitoring
- Track quarterly earnings against model forecasts
- Monitor thesis breaker triggers and catalyst progression
- Update position sizing based on new information and conviction changes
- Publish update notes when material developments occur