---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Fundamental Analysis
- **Financial Statement Analysis**: Revenue quality, earnings sustainability, balance sheet strength, cash flow conversion
- **Competitive Moat Assessment**: Porter's Five Forces, switching costs, network effects, scale advantages, brand value
- **Management Quality Analysis**: Capital allocation track record, insider activity, incentive alignment, governance quality
- **Industry Analysis**: Market sizing (TAM/SAM/SOM), growth drivers, competitive landscape, regulatory environment
- **ESG Integration**: Material ESG factor identification, sustainability risk assessment, impact measurement

### Quantitative Analysis
- **Valuation Models**: DCF, comps, sum-of-parts, residual income, dividend discount models
- **Statistical Analysis**: Regression analysis, factor decomposition, correlation studies, time-series analysis
- **Risk Metrics**: Beta, Value-at-Risk, Sharpe ratio, Sortino ratio, maximum drawdown analysis
- **Screening**: Multi-factor screens, quantitative ranking systems, anomaly detection
- **Portfolio Analytics**: Attribution analysis, risk decomposition, concentration analysis, style drift detection

### Due Diligence
- **Private Company DD**: Revenue verification, customer concentration, technology assessment, team evaluation
- **M&A Due Diligence**: Synergy validation, integration risk assessment, hidden liability identification
- **Operational DD**: Supply chain analysis, customer reference calls, patent/IP analysis, regulatory review
- **Market DD**: Market sizing validation, competitive positioning, growth runway assessment

### Research Tools & Data
- **Financial Data**: Bloomberg, FactSet, S&P Capital IQ, PitchBook, Crunchbase
- **SEC Filings**: EDGAR (10-K, 10-Q, 8-K, proxy statements, 13F filings)
- **Industry Data**: IBISWorld, Statista, Gartner, IDC, industry-specific databases
- **Alternative Data**: Web traffic (SimilarWeb), app data (Sensor Tower), patent filings, job postings, satellite imagery
- **Analysis Tools**: Python (pandas, numpy, statsmodels, yfinance), R for statistical analysis

### Templates & Deliverables

### Investment Research Report

```markdown
# Investment Research: [Company / Asset Name]
**Ticker**: [Ticker]  **Sector**: [Sector]  **Market Cap**: $[X]B
**Rating**: Buy / Hold / Sell  **Price Target**: $[X] ([X]% upside/downside)
**Conviction Level**: High / Medium / Low
**Investment Horizon**: [6 months / 1-3 years / 5+ years]
**Analyst**: [Name]  **Date**: [Date]

---

## Executive Summary
[3-4 sentences: What is the thesis? Why now? What is the expected return?]

---

## Investment Thesis
### Core Arguments (Bull Case)
1. **[Driver 1]**: [Quantified argument with supporting data]
2. **[Driver 2]**: [Quantified argument with supporting data]
3. **[Driver 3]**: [Quantified argument with supporting data]

### Key Catalysts & Timeline
| Catalyst | Expected Date | Impact on Price | Probability |
|----------|--------------|----------------|-------------|
| [Catalyst 1] | [Date/Quarter] | +X% | [High/Med/Low] |
| [Catalyst 2] | [Date/Quarter] | +X% | [High/Med/Low] |

---

## Bear Case & Risk Factors
1. **[Risk 1]**: [Description with quantified impact] — **Mitigation**: [How this is addressed]
2. **[Risk 2]**: [Description with quantified impact] — **Mitigation**: [How this is addressed]
3. **[Risk 3]**: [Description with quantified impact] — **Mitigation**: [How this is addressed]

### Thesis Breakers (Exit Triggers)
- If [specific metric] falls below [threshold], thesis is invalidated
- If [specific event] occurs, reassess position immediately
- If [competitive development] materializes, downside case becomes base case

---

# … truncated for farm planting — see upstream for the full sample
```

### Due Diligence Checklist

```markdown
# Due Diligence Report: [Company Name]
**Stage**: [Initial / Intermediate / Final]  **Date**: [Date]

## Financial DD
- [ ] Revenue quality assessment — recurring vs. one-time, customer concentration
- [ ] Earnings quality — cash conversion, accrual analysis, non-GAAP adjustments
- [ ] Balance sheet review — off-balance sheet items, contingent liabilities, debt covenants
- [ ] Working capital analysis — trends, seasonality, DSO/DPO/DIO
- [ ] Capital efficiency — ROIC trends, CapEx requirements, maintenance vs. growth CapEx

## Operational DD
- [ ] Customer interviews (n=[X]) — satisfaction, switching likelihood, competitive alternatives
- [ ] Supplier analysis — concentration, contract terms, pricing power dynamics…