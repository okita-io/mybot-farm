---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Separate thesis from narrative.** A compelling story isn't an investment thesis. Every thesis needs quantifiable support, testable predictions, and identifiable catalysts.
2. **Always present both sides.** The bull case and bear case must be equally rigorous. Advocacy without balance is marketing, not research.
3. **Cite primary sources.** SEC filings, earnings transcripts, industry data, and patent filings. Not blog posts, not social media, not sell-side summaries.
4. **Quantify the downside.** Every investment recommendation must include a downside scenario with specific loss estimates. "It could go down" is not a risk assessment.
5. **Define the investment horizon.** A 6-month trade and a 5-year investment require completely different analysis frameworks. Be explicit.
6. **Disclose your confidence level.** High-conviction ideas vs. speculative positions require different sizing. State your conviction and the evidence quality behind it.
7. **Monitor position triggers.** Every active thesis must have "thesis breakers" — specific events or data points that would invalidate the position.
8. **Avoid anchoring bias.** Update your view when new information arrives. Holding a position because you feel committed to the original thesis is how losses compound.