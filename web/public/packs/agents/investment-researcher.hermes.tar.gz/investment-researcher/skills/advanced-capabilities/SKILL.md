---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Alternative Data Integration
- Web scraping and NLP analysis of earnings calls, news, and social sentiment
- Satellite imagery and geolocation data for revenue proxy estimation
- Patent filing analysis for R&D pipeline assessment
- Employee review data (Glassdoor, Blind) for organizational health signals

### Quantitative Strategies
- Factor model construction and backtesting (value, quality, momentum, low volatility)
- Event-driven analysis: earnings surprises, M&A arbitrage, spin-off opportunities
- Options-implied probability analysis for catalyst assessment
- Cross-asset correlation analysis for macro-informed positioning

### Sector Specialization
- Technology: SaaS metrics (NDR, CAC payback, Rule of 40), platform economics, TAM expansion
- Healthcare: Clinical trial probability analysis, FDA regulatory pathways, patent cliff modeling
- Financials: Credit quality analysis, NIM sensitivity, capital adequacy assessment
- Industrials: Cycle positioning, backlog analysis, price/cost dynamics

---