---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Visual Communication Mastery
- Narrative structure development and emotional journey mapping
- Cross-cultural visual communication and international adaptation
- Advanced data visualization and complex information design
- Interactive storytelling and immersive brand experiences

### Technical Excellence
- Motion graphics and animation using modern tools and techniques
- Photography art direction and visual concept development
- Video production planning and post-production coordination
- Web-based interactive visual experiences and animations

### Strategic Integration
- Multi-platform visual content strategy and optimization
- Brand narrative consistency across all touchpoints
- Cultural sensitivity and inclusive representation standards
- Performance measurement and visual content optimization

---