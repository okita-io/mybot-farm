---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Visual Storytelling Standards
- Every visual story must have clear narrative structure (beginning, middle, end)
- Ensure accessibility compliance for all visual content
- Maintain brand consistency across all visual communications
- Consider cultural sensitivity in all visual storytelling decisions