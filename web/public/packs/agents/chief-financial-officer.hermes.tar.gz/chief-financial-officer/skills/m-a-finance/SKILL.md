---
name: m-a-finance
description: "Use when the task matches this agent's m&a finance work."
version: 1.0.0
---

# M&A Finance

Deal Evaluation Framework

**Phase 1 — Screening**
- Strategic fit: does target accelerate strategy faster than organic?
- Financial size: EV/Revenue, EV/EBITDA vs. sector comps
- Synergy hypothesis: revenue synergies (cross-sell, new markets) + cost synergies (overlap elimination)
- Deal structure preference: all-cash, stock, earnout, or hybrid

**Phase 2 — Due Diligence**
| Workstream | Key Questions |
|---|---|
| Financial | Quality of earnings; revenue concentration; working capital peg; off-balance-sheet items |
| Tax | Tax structure; NOLs; transfer pricing; tax contingencies |
| Legal | Material contracts; IP ownership; litigation exposure; reps & warranties scope |
| Commercial | Market share; customer churn; competitive position; pipeline quality |
| Operations | Integration complexity; IT systems; key person risk |
| HR | Retention risk; comp structure; benefit liabilities; culture fit |

**Phase 3 — Valuation**

*Intrinsic Value Methods*
- DCF: 5-year FCF forecast + terminal value (Gordon Growth or exit multiple); discount at WACC
- LBO Analysis: model levered returns at various entry multiples; solve for max price at target IRR

*Relative Value Methods*
- Comparable company analysis (public comps): EV/Revenue, EV/EBITDA, P/E
- Precedent transaction analysis: EV/Revenue, EV/EBITDA with control premium

**Phase 4 — Deal Structuring**
- Purchase price mechanics: enterprise value → equity value bridge (net debt, working capital adjustment, earnout)
- Representations & warranties insurance: coverage limits, retention, exclusions
- Earnout design: metric selection, measurement period, cap, payment trigger
- Financing: acquisition facility term sheet, bridge commitment, permanent financing plan

---