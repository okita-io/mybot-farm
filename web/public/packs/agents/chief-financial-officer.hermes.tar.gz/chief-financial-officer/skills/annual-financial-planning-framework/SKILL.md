---
name: annual-financial-planning-framework
description: "Use when the task matches this agent's annual financial planning framework work."
version: 1.0.0
---

# Annual Financial Planning Framework

Planning Calendar

| Month | Activity | Owner | Output |
|---|---|---|---|
| Aug–Sep | Strategic plan refresh | CEO + CFO | 3-year strategic direction |
| Sep | Top-down financial targets | CFO | Revenue, EBITDA, capex envelopes |
| Oct | Bottom-up budget submission | Business unit leaders | Department P&Ls |
| Oct–Nov | Budget consolidation & challenge | FP&A | Consolidated draft budget |
| Nov | Executive budget review | ExCo | Revised budget |
| Dec | Board budget approval | Board | Approved operating plan |
| Jan | Budget lock; system load | FP&A / Finance systems | Budget live in ERP |
| Monthly | Actuals vs. budget variance review | CFO + BU leads | Management accounts |
| Quarterly | Rolling forecast update | FP&A | Revised full-year outlook |

### Budget Architecture

**P&L Structure**
```
Revenue
  - Gross Revenue
  - Returns, Allowances, Discounts
= Net Revenue

Cost of Goods Sold / Cost of Revenue
= Gross Profit (Gross Margin %)

Operating Expenses
  - Sales & Marketing
  - Research & Development
  - General & Administrative
= EBITDA (EBITDA Margin %)

  - Depreciation & Amortization
= EBIT / Operating Income

  - Interest Expense (net)
  - Other Income / Expense
= Pre-Tax Income (EBT)

  - Income Tax Expense
= Net Income (Net Margin %)
```

**Key Planning Metrics by Stage**

| Stage | Primary Metric | Secondary Metrics |
|---|---|---|
| Early-stage / Pre-revenue | Runway (months) | Burn rate, ARR growth |
| Growth | Revenue growth rate | Gross margin, CAC payback |
| Scaling | EBITDA margin expansion | Rule of 40, NRR |
| Mature | ROIC, EPS growth | FCF conversion, dividend coverage |

---