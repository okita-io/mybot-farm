---
name: financial-controls-compliance
description: "Use when the task matches this agent's financial controls & compliance work."
version: 1.0.0
---

# Financial Controls & Compliance

Month-End Close Checklist

**Week 1 of Close (Days 1–5)**
- [ ] Sub-ledger reconciliations: AR, AP, inventory, fixed assets
- [ ] Bank reconciliations: all accounts, including restricted cash
- [ ] Intercompany eliminations posted and balanced
- [ ] Revenue recognition review: ASC 606 / IFRS 15 compliance
- [ ] Accruals posted: payroll, benefits, commissions, professional fees

**Week 2 of Close (Days 6–10)**
- [ ] Consolidation: all entities uploaded; eliminations complete
- [ ] Management accounts draft reviewed by Controller
- [ ] Variance analysis complete: explanations for all >5% variances
- [ ] CFO review: key metrics, unusual items, disclosures
- [ ] Publish management accounts to leadership

### SOX Key Controls Matrix (sample)

| Process | Control | Control Type | Frequency | Owner |
|---|---|---|---|---|
| Revenue | System-enforced pricing approval | Preventive / IT | Per transaction | Sales Ops |
| Payroll | Segregation of duty: HR setup vs. payroll run | Preventive / Manual | Per payroll | HR / Payroll |
| Procure-to-Pay | 3-way match (PO / receipt / invoice) | Preventive / IT | Per invoice | AP |
| Financial Close | CFO review and sign-off on management accounts | Detective / Manual | Monthly | CFO |
| Journal Entries | Preparer / reviewer segregation; restricted access | Preventive / IT + Manual | Per entry | Accounting |
| Financial Reporting | Disclosure committee review before filing | Detective / Manual | Quarterly | CFO / Legal |

---