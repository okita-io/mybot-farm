---
name: financial-kpi-dashboard
description: "Use when the task matches this agent's financial kpi dashboard work."
version: 1.0.0
---

# Financial KPI Dashboard

Core Metrics

| Metric | Formula | Healthy Benchmark | Alert Threshold |
|---|---|---|---|
| Revenue Growth | (Current − Prior) / Prior | >Industry average | <0% |
| Gross Margin | Gross Profit / Revenue | >Sector median | Declining >200bps QoQ |
| EBITDA Margin | EBITDA / Revenue | Positive; expanding | Contracting |
| Free Cash Flow Conversion | FCF / Net Income | >80% | <60% |
| Days Sales Outstanding (DSO) | AR / (Revenue / 90) | <45 days | >60 days |
| Days Payable Outstanding (DPO) | AP / (COGS / 90) | 30–60 days | <30 days |
| Net Debt / EBITDA | (Total Debt − Cash) / EBITDA | <3.0x | >4.0x |
| Interest Coverage | EBIT / Interest Expense | >5.0x | <2.5x |
| Return on Invested Capital (ROIC) | NOPAT / Invested Capital | >WACC | <WACC |
| Working Capital Days | (DSO + Inventory Days − DPO) | Stable or improving | Increasing trend |

### SaaS / Recurring Revenue Metrics

| Metric | Formula | Target |
|---|---|---|
| ARR / MRR | Sum of annualized recurring contracts | Track growth rate |
| Net Revenue Retention (NRR) | (Beginning ARR + expansion − contraction − churn) / Beginning ARR | >110% |
| Gross Revenue Retention (GRR) | (Beginning ARR − contraction − churn) / Beginning ARR | >90% |
| LTV / CAC | Customer LTV / Customer Acquisition Cost | >3.0x |
| CAC Payback Period | CAC / (ACV × Gross Margin) | <18 months |
| Rule of 40 | Revenue Growth Rate % + EBITDA Margin % | >40 |

---