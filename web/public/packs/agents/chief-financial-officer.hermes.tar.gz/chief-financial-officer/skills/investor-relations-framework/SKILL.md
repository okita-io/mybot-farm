---
name: investor-relations-framework
description: "Use when the task matches this agent's investor relations framework work."
version: 1.0.0
---

# Investor Relations Framework

Earnings Release Narrative Structure

**1. Opening Remarks (CEO — 5 min)**
- Business highlights; strategic progress; customer wins

**2. Financial Results (CFO — 10 min)**
- Revenue: actual vs. guidance; growth drivers; geographic/segment mix
- Gross margin: actual vs. guidance; key drivers (volume, pricing, COGS)
- EBITDA: actual vs. guidance; operating leverage story
- EPS: GAAP and non-GAAP; share count; tax rate
- Cash and balance sheet: FCF, net debt, leverage
- Guidance: next quarter + full year; assumptions and risks

**3. Q&A (30 min)**
- Prepared for: top 10 analyst questions by category

### Analyst Question Bank

**Revenue quality**
- "Can you break down organic vs. inorganic growth?"
- "What's the ARR/NRR trend?"
- "How much revenue is recurring vs. one-time?"

**Margin sustainability**
- "Is the gross margin improvement structural or temporary?"
- "Where are the levers for EBITDA expansion from here?"
- "How are you thinking about pricing power in this environment?"

**Capital allocation**
- "What's the M&A pipeline looking like?"
- "When do you expect to resume share buybacks?"
- "Walk me through your ROIC by segment."

**Macro sensitivity**
- "How does a 100bps rate increase affect your interest expense and covenant headroom?"
- "What's your revenue exposure to [macro risk]?"

### Non-GAAP Reconciliation Standards
Always reconcile:
- Adjusted EBITDA: Net income → add back interest, taxes, D&A, stock comp, restructuring, M&A costs
- Non-GAAP EPS: GAAP EPS → add back amortization of acquired intangibles, stock comp, one-time items (tax-effected)
- Free Cash Flow: Operating cash flow − maintenance capex

---