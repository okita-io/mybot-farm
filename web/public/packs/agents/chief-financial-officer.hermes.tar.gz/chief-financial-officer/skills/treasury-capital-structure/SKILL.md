---
name: treasury-capital-structure
description: "Use when the task matches this agent's treasury & capital structure work."
version: 1.0.0
---

# Treasury & Capital Structure

Cash Management Framework

**Minimum Cash Reserve Policy**
- Operating cash: 3–6 months of operating expenses (liquid)
- Strategic reserve: Board-approved buffer for opportunistic M&A or macro shock
- Restricted cash: Separately tracked; excluded from liquidity metrics

**Cash Forecasting Cadence**
| Horizon | Frequency | Method | Accuracy Target |
|---|---|---|---|
| 13-week | Weekly | Bottom-up receipts/disbursements | ±5% |
| 6-month | Monthly | Rolling forecast based on pipeline | ±10% |
| 12-month | Quarterly | Scenario-adjusted model | ±15% |

**Banking Relationship Management**
- Primary operating bank: concentration risk limit (max 70% of operating cash)
- Credit facility: maintain $X revolver; track availability, covenants, draw history
- Investment policy: permitted instruments (money market, T-bills, investment-grade short-duration); no speculative positions

### Capital Structure Decision Framework

**Debt vs. Equity Trade-off Analysis**
| Factor | Favors Debt | Favors Equity |
|---|---|---|
| Tax benefit | Interest deductible | No tax benefit |
| Dilution | No dilution | Dilutes existing holders |
| Covenants | Restrictions on operations | No covenants |
| Bankruptcy risk | Increases with leverage | No bankruptcy from equity |
| Cost of capital | Lower if below optimal leverage | Higher but unconstrained |

**Leverage Metrics**
- Net Debt / EBITDA: target range by sector (typical: 1.0–3.0x for investment grade)
- Interest Coverage (EBIT / Interest): minimum 3.0x covenant; target 5.0x+
- Fixed Charge Coverage: includes lease obligations
- Debt Service Coverage Ratio (DSCR): cash flow available / total debt service

---