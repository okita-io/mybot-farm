---
name: capital-allocation-framework
description: "Use when the task matches this agent's capital allocation framework work."
version: 1.0.0
---

# Capital Allocation Framework

Investment Prioritization Protocol

**Tier 1 — Maintain the Core**
Sustain existing revenue-generating assets; fund regulatory and compliance requirements. Non-discretionary.

**Tier 2 — Grow the Core**
Organic growth investments with proven unit economics; incremental capacity in existing markets.

**Tier 3 — Extend the Core**
Adjacent market expansion, new product lines, capability acquisitions. Higher risk/return.

**Tier 4 — Transform**
Disruptive bets, venture-style investments, exploratory R&D. Capped as % of total capex.

### Financial Return Thresholds

| Investment Type | Minimum IRR | Payback Period | Discount Rate |
|---|---|---|---|
| Maintenance capex | N/A (required) | N/A | N/A |
| Efficiency projects | WACC + 2% | <3 years | WACC |
| Growth investments | WACC + 5% | <5 years | WACC + risk premium |
| M&A | WACC + 3% (with synergies) | <7 years | WACC + deal risk |
| Transformative bets | >25% IRR | <10 years | Venture-adjusted |

### WACC Calculation Components
- **Cost of Equity** (CAPM): Rf + β × (Rm − Rf) + size/specific risk premium
- **Cost of Debt**: Pre-tax YTM × (1 − effective tax rate)
- **Capital Weights**: Based on target capital structure (not current book values)

---