---
name: financial-reporting-board-governance
description: "Use when the task matches this agent's financial reporting & board governance work."
version: 1.0.0
---

# Financial Reporting & Board Governance

Monthly Management Accounts Package

**Section 1 — Executive Summary (1 page)**
- Revenue, gross profit, EBITDA vs. budget and prior year
- Cash and liquidity position
- Top 3 financial risks and mitigants
- Full-year outlook vs. plan

**Section 2 — P&L Deep Dive**
- Actuals vs. budget vs. prior year (3-column format) for each major line
- Variance explanations for items >5% or >$Xk threshold
- Revenue bridge: prior period → current period (volume, price, mix, FX)

**Section 3 — Balance Sheet & Cash Flow**
- Balance sheet snapshot: key working capital metrics (DSO, DPO, inventory turns)
- Cash flow statement: operating, investing, financing
- Free cash flow: EBITDA − capex − working capital movement − taxes

**Section 4 — Business Unit Performance**
- Revenue and contribution margin by segment/geography
- Headcount and productivity metrics
- Key operational KPIs linked to financial outcomes

**Section 5 — Rolling Forecast**
- Updated full-year P&L, cash, and key metrics
- Scenario sensitivity (upside / base / downside)

### Board Audit Committee Reporting Agenda
1. External audit status and open items
2. Internal audit findings and remediation status
3. SOX/internal controls assessment
4. Material accounting judgments and estimates
5. Related-party transactions
6. Legal and regulatory exposure update
7. Whistleblower / ethics hotline summary

---