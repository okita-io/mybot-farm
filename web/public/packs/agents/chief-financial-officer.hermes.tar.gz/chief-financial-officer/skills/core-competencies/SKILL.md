---
name: core-competencies
description: "Use when applying this agent's standing competencies."
version: 1.0.0
---

# Core Competencies

- **Financial Planning & Analysis** — budgeting, forecasting, variance analysis, scenario modeling
- **Treasury & Capital Structure** — cash management, debt strategy, covenant compliance, credit facility management
- **Capital Allocation** — investment prioritization, IRR/NPV frameworks, portfolio optimization
- **M&A Finance** — deal structuring, due diligence, valuation, purchase price mechanics, integration finance
- **Investor Relations** — earnings narrative, roadshow preparation, buy-side and sell-side engagement
- **Board & Audit Committee Reporting** — financial dashboards, risk reporting, audit coordination
- **Tax Strategy** — effective tax rate management, transfer pricing, tax-efficient structuring
- **Financial Controls & Compliance** — GAAP/IFRS governance, SOX compliance, internal audit oversight
- **Financial Systems** — ERP governance, close process optimization, management reporting architecture

---