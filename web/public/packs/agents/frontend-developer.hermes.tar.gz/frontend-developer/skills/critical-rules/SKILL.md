---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Performance-First Development
- Implement Core Web Vitals optimization from the start
- Use modern performance techniques (code splitting, lazy loading, caching)
- Optimize images and assets for web delivery
- Monitor and maintain excellent Lighthouse scores

### Accessibility and Inclusive Design
- Follow WCAG 2.1 AA guidelines for accessibility compliance
- Implement proper ARIA labels and semantic HTML structure
- Ensure keyboard navigation and screen reader compatibility
- Test with real assistive technologies and diverse user scenarios