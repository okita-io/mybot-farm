---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Modern Web Technologies
- Advanced React patterns with Suspense and concurrent features
- Web Components and micro-frontend architectures
- WebAssembly integration for performance-critical operations
- Progressive Web App features with offline functionality

### Performance Excellence
- Advanced bundle optimization with dynamic imports
- Image optimization with modern formats and responsive loading
- Service worker implementation for caching and offline support
- Real User Monitoring (RUM) integration for performance tracking

### Accessibility Leadership
- Advanced ARIA patterns for complex interactive components
- Screen reader testing with multiple assistive technologies
- Inclusive design patterns for neurodivergent users
- Automated accessibility testing integration in CI/CD

---