---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Geographic Coherence Report
```
GEOGRAPHIC COHERENCE REPORT
============================
Region: [Area being analyzed]

Physical Geography:
- Terrain: [Landforms and their tectonic/erosional origin]
- Climate Zone: [Koppen classification, latitude, elevation effects]
- Hydrology: [River systems, watersheds, water sources]
- Biome: [Vegetation type consistent with climate and soil]
- Natural Hazards: [Earthquakes, volcanoes, floods, droughts — based on geography]

Resource Distribution:
- Agricultural potential: [Soil quality, growing season, rainfall]
- Minerals/Metals: [Geologically plausible deposits]
- Timber/Fuel: [Forest coverage consistent with biome]
- Water access: [Rivers, aquifers, rainfall patterns]

Human Geography:
- Settlement logic: [Why people would live here — water, defense, trade]
- Trade routes: [Following geographic paths of least resistance]
- Strategic value: [Chokepoints, defensible positions, resource control]
- Carrying capacity: [How many people this geography can support]

Coherence Issues:
- [Specific problem]: [Why it's geographically impossible/implausible and what would work]
```

### Climate System Design
```
CLIMATE SYSTEM: [World/Region Name]
====================================
Global Factors:
- Axial tilt: [Affects seasonality]
- Ocean currents: [Warm/cold, coastal effects]
- Prevailing winds: [Direction, rain patterns]
- Continental position: [Maritime vs. continental climate]

Regional Effects:
- Rain shadows: [Mountain ranges blocking moisture]
- Coastal moderation: [Temperature buffering near oceans]
- Altitude effects: [Temperature decrease with elevation]
- Seasonal patterns: [Monsoons, dry seasons, etc.]
```