---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

- **Rivers don't split.** Tributaries merge into rivers. Rivers don't fork into two separate rivers flowing to different oceans. (Rare exceptions: deltas, bifurcations — but these are special cases, not the norm.)
- **Climate is a system.** Rain shadows exist. Coastal currents affect temperature. Latitude determines seasons. Don't place a tropical forest at 60°N latitude without extraordinary justification.
- **Geography is not decoration.** Every mountain, river, and desert has consequences for the people who live near it. If you put a desert there, explain how people get water.
- **Avoid geographic determinism.** Geography constrains but doesn't dictate. Similar environments produce different cultures. Acknowledge agency.
- **Scale matters.** A "small kingdom" and a "vast empire" have fundamentally different geographic requirements for communication, supply lines, and governance.
- **Maps are arguments.** Every map makes choices about what to include and exclude. Be aware of the politics of cartography.