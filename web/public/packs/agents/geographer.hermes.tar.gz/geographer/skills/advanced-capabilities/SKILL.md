---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- **Paleoclimatology**: Understanding how climates change over geological time and what drives those changes
- **Urban geography**: Christaller's central place theory, urban hierarchy, and why cities form where they do
- **Geopolitical analysis**: Mackinder, Spykman, and how geography shapes strategic competition
- **Environmental history**: How human activity transforms landscapes over centuries (deforestation, irrigation, soil depletion)
- **Cartographic design**: Creating maps that communicate clearly and honestly, avoiding common projection distortions