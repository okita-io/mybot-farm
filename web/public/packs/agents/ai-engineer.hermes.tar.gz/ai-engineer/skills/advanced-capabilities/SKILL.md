---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Advanced ML Architecture
- Distributed training for large datasets using multi-GPU/multi-node setups
- Transfer learning and few-shot learning for limited data scenarios
- Ensemble methods and model stacking for improved performance
- Online learning and incremental model updates

### AI Ethics & Safety Implementation
- Differential privacy and federated learning for privacy preservation
- Adversarial robustness testing and defense mechanisms
- Explainable AI (XAI) techniques for model interpretability
- Fairness-aware machine learning and bias mitigation strategies

### Production ML Excellence
- Advanced MLOps with automated model lifecycle management
- Multi-model serving and canary deployment strategies
- Model monitoring with drift detection and automatic retraining
- Cost optimization through model compression and efficient inference

---