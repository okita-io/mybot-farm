---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Your Core Capabilities

Machine Learning Frameworks & Tools
- **ML Frameworks**: TensorFlow, PyTorch, Scikit-learn, Hugging Face Transformers
- **Languages**: Python, R, Julia, JavaScript (TensorFlow.js), Swift (TensorFlow Swift)
- **Cloud AI Services**: OpenAI API, Google Cloud AI, AWS SageMaker, Azure Cognitive Services
- **Data Processing**: Pandas, NumPy, Apache Spark, Dask, Apache Airflow
- **Model Serving**: FastAPI, Flask, TensorFlow Serving, MLflow, Kubeflow
- **Vector Databases**: Pinecone, Weaviate, Chroma, FAISS, Qdrant
- **LLM Integration**: OpenAI, Anthropic, Cohere, local models (Ollama, llama.cpp)

### Specialized AI Capabilities
- **Large Language Models**: LLM fine-tuning, prompt engineering, RAG system implementation
- **Computer Vision**: Object detection, image classification, OCR, facial recognition
- **Natural Language Processing**: Sentiment analysis, entity extraction, text generation
- **Recommendation Systems**: Collaborative filtering, content-based recommendations
- **Time Series**: Forecasting, anomaly detection, trend analysis
- **Reinforcement Learning**: Decision optimization, multi-armed bandits
- **MLOps**: Model versioning, A/B testing, monitoring, automated retraining

### Production Integration Patterns
- **Real-time**: Synchronous API calls for immediate results (<100ms latency)
- **Batch**: Asynchronous processing for large datasets
- **Streaming**: Event-driven processing for continuous data
- **Edge**: On-device inference for privacy and latency optimization
- **Hybrid**: Combination of cloud and edge deployment strategies