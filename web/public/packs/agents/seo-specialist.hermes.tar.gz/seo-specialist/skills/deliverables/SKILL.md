---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

Technical SEO Audit Template
```markdown
# Technical SEO Audit Report

## Crawlability & Indexation
### Robots.txt Analysis
- Allowed paths: [list critical paths]
- Blocked paths: [list and verify intentional blocks]
- Sitemap reference: [verify sitemap URL is declared]

### XML Sitemap Health
- Total URLs in sitemap: X
- Indexed URLs (via Search Console): Y
- Index coverage ratio: Y/X = Z%
- Issues: [orphaned pages, 404s in sitemap, non-canonical URLs]

### Crawl Budget Optimization
- Total pages: X
- Pages crawled/day (avg): Y
- Crawl waste: [parameter URLs, faceted navigation, thin content pages]
- Recommendations: [noindex/canonical/robots directives]

## Site Architecture & Internal Linking
### URL Structure
- Hierarchy depth: Max X clicks from homepage
- URL pattern: [domain.com/category/subcategory/page]
- Issues: [deep pages, orphaned content, redirect chains]

### Internal Link Distribution
- Top linked pages: [list top 10]
- Orphaned pages (0 internal links): [count and list]
- Link equity distribution score: X/10

## Core Web Vitals (Field Data)
| Metric | Mobile | Desktop | Target | Status |
|--------|--------|---------|--------|--------|
| LCP    | X.Xs   | X.Xs    | <2.5s  | ✅/❌  |
| INP    | Xms    | Xms     | <200ms | ✅/❌  |
| CLS    | X.XX   | X.XX    | <0.1   | ✅/❌  |

## Structured Data Implementation
- Schema types present: [Article, Product, FAQ, HowTo, Organization]
# … truncated for farm planting — see upstream for the full sample
```

### Keyword Research Framework
```markdown
# Keyword Strategy Document

## Topic Cluster: [Primary Topic]

### Pillar Page Target
- **Keyword**: [head term]
- **Monthly Search Volume**: X,XXX
- **Keyword Difficulty**: XX/100
- **Current Position**: XX (or not ranking)
- **Search Intent**: [Informational/Commercial/Transactional/Navigational]
- **SERP Features**: [Featured Snippet, PAA, Video, Images]
- **Target URL**: /pillar-page-slug

### Supporting Content Cluster
| Keyword | Volume | KD | Intent | Target URL | Priority |
|---------|--------|----|--------|------------|----------|
| [long-tail 1] | X,XXX | XX | Info | /blog/subtopic-1 | High |
| [long-tail 2] | X,XXX | XX | Commercial | /guide/subtopic-2 | Medium |
| [long-tail 3] | XXX | XX | Transactional | /product/landing | High |

### Content Gap Analysis
- **Competitors ranking, we're not**: [keyword list with volumes]
- **Low-hanging fruit (positions 4-20)**: [keyword list with current positions]
- **Featured snippet opportunities**: [keywords where competitor snippets are weak]

### Search Intent Mapping
- **Informational** (top-of-funnel): [keywords] → Blog posts, guides, how-tos
- **Commercial Investigation** (mid-funnel): [keywords] → Comparisons, reviews, case studies
- **Transactional** (bottom-funnel): [keywords] → Landing pages, product pages
```

### Cannibalization Audit Template
```markdown
# Cannibalization Audit: [Target Keyword Cluster]

## Step 1: Cross-Page Query Map
Query GSC with dimensions=[page, query] for all pages matching the target topic.

| Query | Page A (URL) | Page A Pos | Page A Clicks | Page B (URL) | Page B Pos | Page B Clicks | Conflict? |
|-------|-------------|------------|---------------|-------------|------------|---------------|-----------|
| [kw1] | /page-a     | X.X        | XX            | /page-b     | X.X        | XX            | YES/NO    |

## Step 2: Ownership Assignment
For each conflicting query, assign ONE owner page based on:
- Which page has the most clicks/impressions on that query
- Which page's topic is the closest semantic match
- Which page is the designated satellite/pillar for that topic

| Query | Current Winner | Designated Owner | Action Required |
|-------|---------------|-----------------|-----------------|
| [kw1] | /page-a       | /page-b          | [consolidate/redirect/rewrite] |

## Step 3: Resolution Plan
For each conflict:
- [ ] Remove/reduce competing content from non-owner pages
- [ ] Add internal links FROM non-owner TO owner page for the conflicting query
- [ ] Ensure title tags and H1s do not overlap on primary keywords
- [ ] Verify canonical tags are self-referencing (no cross-canonicals unless merging)
```

### Cannibalization Audit Without GSC (Pre-Access Fallback)
The template above assumes Search Console access. When it isn't available yet — new site, client
hasn't granted access, or you're auditing a competitor — use this sitemap + query-intent method…