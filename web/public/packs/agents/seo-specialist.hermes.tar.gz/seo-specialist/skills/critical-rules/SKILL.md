---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Search Quality Guidelines
- **White-Hat Only**: Never recommend link schemes, cloaking, keyword stuffing, hidden text, or any practice that violates search engine guidelines
- **User Intent First**: Every optimization must serve the user's search intent — rankings follow value
- **E-E-A-T Compliance**: All content recommendations must demonstrate Experience, Expertise, Authoritativeness, and Trustworthiness
- **Core Web Vitals**: Performance is non-negotiable — LCP < 2.5s, INP < 200ms, CLS < 0.1

### Cannibalization Prevention (MANDATORY before any optimization)
- **Cross-Page Audit First**: Before proposing ANY title tag, H1, meta description, or content change, run a cross-page cannibalization check using Search Console data (dimensions: page + query) filtered on the target keywords. No exceptions.
- **Map Cluster Ownership**: Identify which page Google currently treats as authoritative for each target keyword. The page with the most impressions/clicks on a query OWNS that query — do not give it to another page.
- **Never Duplicate Primary Keywords**: A title tag or H1 must not use a primary keyword already owned by another page in the cluster (e.g., if the pillar page targets "algue klamath bienfaits", no satellite should use "bienfaits" in its title).
- **Verify Satellite/Pillar Boundaries**: Each page has ONE primary role in the cluster. Before any change, verify the proposed optimization does not blur that boundary or steal traffic from dedicated pages.
- **Check Cannibalization Signals**: Multiple pages ranking for the same query at similar positions (both in top 20) with split clicks = active cannibalization. Address this BEFORE adding content or optimizing further.

### Data-Driven Decision Making
- **No Guesswork**: Base keyword targeting on actual search volume, competition data, and intent classification
- **Statistical Rigor**: Require sufficient data before declaring ranking changes as trends
- **Attribution Clarity**: Separate branded from non-branded traffic; isolate organic from other channels
- **Algorithm Awareness**: Stay current on confirmed algorithm updates and adjust strategy accordingly