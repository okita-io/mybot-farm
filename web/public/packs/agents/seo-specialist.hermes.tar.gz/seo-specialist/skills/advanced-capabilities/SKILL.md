---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

International SEO
- Hreflang implementation strategy for multi-language and multi-region sites
- Country-specific keyword research accounting for cultural search behavior differences
- International site architecture decisions: ccTLDs vs. subdirectories vs. subdomains
- Geotargeting configuration and Search Console international targeting setup

**Hreflang Implementation Template** (validated on a mixed CN/EN game-guide site):
```html
<!-- On EVERY language-variant URL, declare the full set RECIPROCALLY -->
<link rel="alternate" hreflang="en" href="https://site.com/guides/zhongli-build-en" />
<link rel="alternate" hreflang="zh" href="https://site.com/guides/zhongli-build-zh" />
<link rel="alternate" hreflang="x-default" href="https://site.com/guides/zhongli-build-en" />
```
- **Reciprocity is mandatory**: every `hreflang` URL must link back to all others, or Google ignores the entire set.
- **`lang` attribute is separate**: set `<html lang="en">` on the English page even when hreflang is present — crawlers use it as an independent signal.
- **Pitfall — mixed-language single page**: a URL containing both CN and EN copy with no `lang`/hreflang is treated as ONE ambiguous document. Google won't serve it cleanly to either-language searcher, and it dilutes topical authority for both. Split into per-language URLs, or at minimum tag language blocks — never leave a bilingual page untagged.

### Programmatic SEO
- Template-based page generation for scalable long-tail keyword targeting
- Dynamic content optimization for large-scale e-commerce and marketplace sites
- Automated internal linking systems for sites with thousands of pages
- Index management strategies for large inventories (faceted navigation, pagination)

### Algorithm Recovery
- Penalty identification through traffic pattern analysis and manual action review
- Content quality remediation for Helpful Content and Core Update recovery
- Link profile cleanup and disavow file management for link-related penalties
- E-E-A-T improvement programs: author bios, editorial policies, source citations

### Search Console & Analytics Mastery
- Advanced Search Console API queries for large-scale performance analysis
- Custom regex filters for precise keyword and page segmentation
- Looker Studio / dashboard creation for automated SEO reporting
- Search Analytics data reconciliation with GA4 for full-funnel attribution

### AI Search & SGE Adaptation
- Content optimization for AI-generated search overviews and citations
- Structured data strategies that improve visibility in AI-powered search features
- Authority building tactics that position content as trustworthy AI training sources
- Monitoring and adapting to evolving search interfaces beyond traditional blue links