---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Phase 1: Discovery & Technical Foundation
1. **Technical Audit**: Crawl the site (Screaming Frog / Sitebulb equivalent analysis), identify crawlability, indexation, and performance issues
2. **Search Console Analysis**: Review index coverage, manual actions, Core Web Vitals, and search performance data
3. **Competitive Landscape**: Identify top 5 organic competitors, their content strategies, and link profiles
4. **Baseline Metrics**: Document current organic traffic, keyword positions, domain authority, and conversion rates

### Phase 2: Keyword Strategy & Content Planning
1. **Keyword Research**: Build comprehensive keyword universe grouped by topic cluster and search intent
2. **Content Audit**: Map existing content to target keywords, identify gaps and cannibalization
3. **Topic Cluster Architecture**: Design pillar pages and supporting content with internal linking strategy
4. **Content Calendar**: Prioritize content creation/optimization by impact potential (volume × achievability)

### Phase 2.5: Cannibalization Audit (BLOCKER — must complete before Phase 3)
1. **Cross-Page Query Map**: For every keyword targeted in Phase 2, query GSC (dimensions: page+query) to identify ALL pages currently ranking for it
2. **Conflict Resolution**: For each case where 2+ pages rank for the same query, assign a single owner and plan de-optimization of competing pages
3. **Title/H1 Deconfliction**: Verify no two pages in the cluster share the same primary keyword in their title tag or H1
4. **Sign-Off**: Get explicit confirmation that the cannibalization map is clean before proceeding to content changes

### Phase 3: On-Page & Technical Execution
1. **Technical Fixes**: Resolve critical crawl issues, implement structured data, optimize Core Web Vitals
2. **Content Optimization**: Update existing pages with improved targeting, structure, and depth
3. **New Content Creation**: Produce high-quality content targeting identified gaps and opportunities
4. **Internal Linking**: Build contextual internal link architecture connecting clusters to pillars

### Phase 4: Authority Building & Off-Page
1. **Link Profile Analysis**: Assess current backlink health and identify growth opportunities
2. **Digital PR Campaigns**: Create linkable assets and execute journalist/blogger outreach
3. **Brand Mention Monitoring**: Convert unlinked mentions and manage online reputation
4. **Competitor Link Gap**: Identify and pursue link sources that competitors have but we don't

### Phase 5: Measurement & Iteration
1. **Ranking Tracking**: Monitor keyword positions weekly, analyze movement patterns
2. **Traffic Analysis**: Segment organic traffic by landing page, intent type, and conversion path
3. **ROI Reporting**: Calculate organic search revenue attribution and cost-per-acquisition
4. **Strategy Refinement**: Adjust priorities based on algorithm updates, performance data, and competitive shifts