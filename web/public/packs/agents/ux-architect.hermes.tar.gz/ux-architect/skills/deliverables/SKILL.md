---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

CSS Design System Foundation
```css
/* Example of your CSS architecture output */
:root {
  /* Light Theme Colors - Use actual colors from project spec */
  --bg-primary: [spec-light-bg];
  --bg-secondary: [spec-light-secondary];
  --text-primary: [spec-light-text];
  --text-secondary: [spec-light-text-muted];
  --border-color: [spec-light-border];

  /* Brand Colors - From project specification */
  --primary-color: [spec-primary];
  --secondary-color: [spec-secondary];
  --accent-color: [spec-accent];

  /* Typography Scale */
  --text-xs: 0.75rem;    /* 12px */
  --text-sm: 0.875rem;   /* 14px */
  --text-base: 1rem;     /* 16px */
  --text-lg: 1.125rem;   /* 18px */
  --text-xl: 1.25rem;    /* 20px */
  --text-2xl: 1.5rem;    /* 24px */
  --text-3xl: 1.875rem;  /* 30px */

  /* Spacing System */
  --space-1: 0.25rem;    /* 4px */
  --space-2: 0.5rem;     /* 8px */
  --space-4: 1rem;       /* 16px */
  --space-6: 1.5rem;     /* 24px */
  --space-8: 2rem;       /* 32px */
  --space-12: 3rem;      /* 48px */
  --space-16: 4rem;      /* 64px */

  /* Layout System */
  --container-sm: 640px;
  --container-md: 768px;
  --container-lg: 1024px;
  --container-xl: 1280px;
}

/* Dark Theme - Use dark colors from project spec */
# … truncated for farm planting — see upstream for the full sample
```

### Layout Framework Specifications
```markdown
## Layout Architecture

### Container System
- **Mobile**: Full width with 16px padding
- **Tablet**: 768px max-width, centered
- **Desktop**: 1024px max-width, centered
- **Large**: 1280px max-width, centered

### Grid Patterns
- **Hero Section**: Full viewport height, centered content
- **Content Grid**: 2-column on desktop, 1-column on mobile
- **Card Layout**: CSS Grid with auto-fit, minimum 300px cards
- **Sidebar Layout**: 2fr main, 1fr sidebar with gap

### Component Hierarchy
1. **Layout Components**: containers, grids, sections
2. **Content Components**: cards, articles, media
3. **Interactive Components**: buttons, forms, navigation
4. **Utility Components**: spacing, typography, colors
```

### Theme Toggle JavaScript Specification
```javascript
// Theme Management System
class ThemeManager {
  constructor() {
    this.currentTheme = this.getStoredTheme() || this.getSystemTheme();
    this.applyTheme(this.currentTheme);
    this.initializeToggle();
  }

  getSystemTheme() {
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  getStoredTheme() {
    return localStorage.getItem('theme');
  }

  applyTheme(theme) {
    if (theme === 'system') {
      document.documentElement.removeAttribute('data-theme');
      localStorage.removeItem('theme');
    } else {
      document.documentElement.setAttribute('data-theme', theme);
      localStorage.setItem('theme', theme);
    }
    this.currentTheme = theme;
    this.updateToggleUI();
  }

  initializeToggle() {
    const toggle = document.querySelector('.theme-toggle');
    if (toggle) {
      toggle.addEventListener('click', (e) => {
        if (e.target.matches('.theme-toggle-option')) {
          const newTheme = e.target.dataset.theme;
          this.applyTheme(newTheme);
        }
      });
    }
  }

# … truncated for farm planting — see upstream for the full sample
```

### UX Structure Specifications
```markdown
## Information Architecture

### Page Hierarchy
1. **Primary Navigation**: 5-7 main sections maximum
2. **Theme Toggle**: Always accessible in header/navigation
3. **Content Sections**: Clear visual separation, logical flow
4. **Call-to-Action Placement**: Above fold, section ends, footer
5. **Supporting Content**: Testimonials, features, contact info

### Visual Weight System
- **H1**: Primary page title, largest text, highest contrast
- **H2**: Section headings, secondary importance
- **H3**: Subsection headings, tertiary importance
- **Body**: Readable size, sufficient contrast, comfortable line-height
- **CTAs**: High contrast, sufficient size, clear labels
- **Theme Toggle**: Subtle but accessible, consistent placement

### Interaction Patterns
- **Navigation**: Smooth scroll to sections, active state indicators
- **Theme Switching**: Instant visual feedback, preserves user preference
- **Forms**: Clear labels, validation feedback, progress indicators
- **Buttons**: Hover states, focus indicators, loading states
- **Cards**: Subtle hover effects, clear clickable areas
```