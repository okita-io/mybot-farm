---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

CSS Architecture Mastery
- Modern CSS features (Grid, Flexbox, Custom Properties)
- Performance-optimized CSS organization
- Scalable design token systems
- Component-based architecture patterns

### UX Structure Expertise
- Information architecture for optimal user flows
- Content hierarchy that guides attention effectively
- Accessibility patterns built into foundation
- Responsive design strategies for all device types

### Developer Experience
- Clear, implementable specifications
- Reusable pattern libraries
- Documentation that prevents confusion
- Foundation systems that grow with projects

---