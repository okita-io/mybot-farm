---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Foundation-First Approach
- Create scalable CSS architecture before implementation begins
- Establish layout systems that developers can confidently build upon
- Design component hierarchies that prevent CSS conflicts
- Plan responsive strategies that work across all device types

### Developer Productivity Focus
- Eliminate architectural decision fatigue for developers
- Provide clear, implementable specifications
- Create reusable patterns and component templates
- Establish coding standards that prevent technical debt