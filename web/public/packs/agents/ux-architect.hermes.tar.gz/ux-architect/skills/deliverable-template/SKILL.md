---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Deliverable Template

```markdown
# [Project Name] Technical Architecture & UX Foundation

## 🏗️ CSS Architecture

### Design System Variables
**File**: `css/design-system.css`
- Color palette with semantic naming
- Typography scale with consistent ratios
- Spacing system based on 4px grid
- Component tokens for reusability

### Layout Framework
**File**: `css/layout.css`
- Container system for responsive design
- Grid patterns for common layouts
- Flexbox utilities for alignment
- Responsive utilities and breakpoints

## 🎨 UX Structure

### Information Architecture
**Page Flow**: [Logical content progression]
**Navigation Strategy**: [Menu structure and user paths]
**Content Hierarchy**: [H1 > H2 > H3 structure with visual weight]

### Responsive Strategy
**Mobile First**: [320px+ base design]
**Tablet**: [768px+ enhancements]
**Desktop**: [1024px+ full features]
**Large**: [1280px+ optimizations]

### Accessibility Foundation
**Keyboard Navigation**: [Tab order and focus management]
**Screen Reader Support**: [Semantic HTML and ARIA labels]
**Color Contrast**: [WCAG 2.1 AA compliance minimum]

## 💻 Developer Implementation Guide

### Priority Order
1. **Foundation Setup**: Implement design system variables
# … truncated for farm planting — see upstream for the full sample
```html
<!-- Theme Toggle Component (place in header/navigation) -->
<div class="theme-toggle" role="radiogroup" aria-label="Theme selection">
  <button class="theme-toggle-option" data-theme="light" role="radio" aria-checked="false">
    <span aria-hidden="true">☀️</span> Light
  </button>
  <button class="theme-toggle-option" data-theme="dark" role="radio" aria-checked="false">
    <span aria-hidden="true">🌙</span> Dark
  </button>
  <button class="theme-toggle-option" data-theme="system" role="radio" aria-checked="true">
    <span aria-hidden="true">💻</span> System
  </button>
</div>
```

### File Structure
```
css/
├── design-system.css    # Variables and tokens (includes theme system)
├── layout.css          # Grid and container system
├── components.css      # Reusable component styles (includes theme toggle)
├── utilities.css       # Helper classes and utilities
└── main.css            # Project-specific overrides
js/
├── theme-manager.js     # Theme switching functionality
└── main.js             # Project-specific JavaScript
```

### Implementation Notes
**CSS Methodology**: [BEM, utility-first, or component-based approach]
**Browser Support**: [Modern browsers with graceful degradation]
**Performance**: [Critical CSS inlining, lazy loading considerations]

---
**ArchitectUX Agent**: [Your name]
**Foundation Date**: [Date]
**Developer Handoff**: Ready for LuxuryDeveloper implementation
**Next Steps**: Implement foundation, then add premium polish
```