---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Scope, Standards & Baseline

1. **Confirm the conformance target and which legal driver applies** — Section 508 (WCAG 2.0 AA legal baseline) for federal; ADA Title II (WCAG 2.1 AA) for state/local government; WCAG 2.1/2.2 AA as best practice — plus any agency-specific standard
2. **Define the test matrix** — representative pages, critical task flows, document types, and the AT/browser pairs
3. **Run automated scans for a first pass** — axe/WAVE/Lighthouse to catch the low-hanging, detectable failures
4. **Establish the baseline** — catalog detectable issues; flag that manual testing is still required
5. **Record everything** — automated findings are the start, never the conclusion

### Step 2: Manual Keyboard & Assistive-Technology Testing

1. **Unplug the mouse** — tab through every flow; verify order, visible focus, no traps, operable controls
2. **Drive it with screen readers** — JAWS+Chrome, NVDA+Firefox, VoiceOver+Safari on the real flows
3. **Test the hard parts** — custom widgets, modals, dynamic updates, error handling, and live regions
4. **Check perceivability** — contrast, 200% zoom/400% reflow, text spacing, and color-only signals
5. **Capture the real barrier** — what the AT user actually experiences, mapped to the specific success criterion

### Step 3: Remediate at the Source

1. **Fix semantics first** — replace `div` soup with native elements; correct heading/landmark structure
2. **Apply ARIA only where needed, per the APG** — correct roles, synced states, full keyboard contracts
3. **Fix forms and errors** — programmatic labels, linked instructions, announced validation
4. **Fix media and documents** — captions, transcripts, alt text, tagged/ordered PDFs
5. **Never reach for an overlay** — every fix changes the source HTML/CSS/ARIA

### Step 4: Verify & Re-test

1. **Rescan automated** — confirm the detectable issues are gone (necessary, not sufficient)
2. **Re-run keyboard-only** — the whole flow, end to end
3. **Re-run all three screen readers** — confirm roles, names, states, and announcements are correct
4. **Confirm perceivability fixes** — contrast and reflow re-measured
5. **Prove the task is completable by an AT user** — not just that the scan is green

### Step 5: Document, Report & Sustain

1. **Author or update the VPAT/ACR honestly** — conformance levels backed by what was actually tested
2. **Deliver the prioritized remediation plan** — P0–P3 with root causes and source-level fixes
3. **Set up regression prevention** — CI accessibility checks (axe), component-library patterns, and PR gates
4. **Train the team** — accessible patterns, the don't-use-overlays rule, and how to test with AT
5. **Schedule re-evaluation** — accessibility decays; bake it into the release process

---