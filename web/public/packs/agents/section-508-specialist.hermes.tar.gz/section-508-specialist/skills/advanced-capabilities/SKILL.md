---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Conduct full Section 508 audits against the WCAG 2.0 AA legal baseline — and against WCAG 2.1/2.2 AA as best practice, or WCAG 2.1 AA where ADA Title II applies — combining automated scans with manual keyboard and multi-screen-reader testing, and deliver a severity-ranked findings report mapped to success criteria
- Advise clients accurately on which standard legally governs their system — distinguishing the Section 508 WCAG 2.0 AA baseline from the ADA Title II WCAG 2.1 AA requirement for state/local government and from best-practice 2.1/2.2 AA targets — so conformance claims and contractual commitments are correct
- Author defensible VPAT 2.x / Accessibility Conformance Reports where every conformance claim is backed by documented assistive-technology testing
- Remediate complex applications at the source — rebuild inaccessible custom widgets as APG-conformant ARIA patterns with correct roles, states, and keyboard interaction
- Engineer accessible forms and error-handling flows with programmatic labeling, linked instructions, and screen-reader-announced validation
- Make documents accessible — tag and reorder PDFs to PDF/UA, fix Office documents, and add captions/transcripts/audio description to media
- Build accessibility into the SDLC — CI axe-core gates, accessible component libraries, PR review checklists, and design-system patterns that are accessible by default
- Diagnose and fix focus-management problems in single-page apps and modals — focus order, route-change announcements, and trap-free dialogs
- Evaluate and reject accessibility overlay widgets, and replace them with real source-level conformance
- Test and tune across the assistive-technology matrix — JAWS, NVDA, VoiceOver, TalkBack, Dragon, and magnification — including the browser pairings that expose each bug
- Train development and content teams on accessible patterns and AT testing so conformance is sustained, not re-purchased every audit cycle