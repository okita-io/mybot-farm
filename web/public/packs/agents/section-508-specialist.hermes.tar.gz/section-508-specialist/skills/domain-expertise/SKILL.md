---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Standards & Law

- **Section 508**: the 2018 Refresh, incorporation of **WCAG 2.0 Level AA** by reference (still 2.0 as of 2026 — not updated to 2.1/2.2), and the Revised 508 chapters (Functional Performance Criteria, Software, Support Docs)
- **WCAG 2.1 / 2.2**: the POUR principles, Levels A/AA/AAA, the success criteria, the new 2.1 criteria (reflow, text spacing, non-text contrast) and 2.2 criteria (focus appearance, dragging, target size) — the recommended best-practice target above the 508 legal floor
- **ADA**: Title II requiring **WCAG 2.1 AA** for state/local government (the DOJ web rule, deadline April 24, 2026 for larger entities), Title III applicability, and the litigation landscape — a driver separate from Section 508
- **VPAT/ACR**: the ITI VPAT 2.x editions (508, WCAG, EU, INT) and writing defensible conformance claims

### Assistive Technology & Testing

- **Screen Readers**: JAWS, NVDA, VoiceOver (macOS/iOS), TalkBack, Narrator — and the recommended browser pairings
- **Other AT**: Dragon NaturallySpeaking (voice control), ZoomText/screen magnifiers, switch access, and braille displays
- **Manual Methods**: keyboard-only evaluation, the WCAG-EM methodology, and AT-user task testing
- **Automated Tooling**: axe-core/axe DevTools, WAVE, Lighthouse, ANDI, Pa11y, and CI integration — and their detection limits

### Implementation

- **Semantic HTML**: landmarks, heading hierarchy, lists, tables with headers, and native form controls
- **ARIA & the APG**: roles/states/properties, the Authoring Practices patterns, live regions, and accessible names/descriptions
- **Keyboard & Focus**: focus order, focus management in SPAs/modals, skip links, and visible focus indicators
- **Visual Design**: contrast ratios, reflow/resize, text spacing, motion/animation preferences, and target size

### Documents & Media

- **PDF Accessibility**: PDF/UA, tagging, reading order, alt text, table headers, form fields, and Acrobat's checker
- **Office Documents**: accessible Word/PowerPoint/Excel authoring and the built-in accessibility checker
- **Media**: captions (and the difference from subtitles), transcripts, and audio description

---