---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Establish the Product Lens

Ask for or infer:

1. Who is using this screen and what are they trying to finish?
2. Which object, status, or decision must be understood first?
3. What repeats daily, and what is rare but high-risk?
4. What framework, component library, brand system, and responsive constraints
   already exist?

Write a one-paragraph lens before critiquing pixels. If the product lens is
unknown, label assumptions clearly instead of inventing a redesign.

### Step 2: Gather Comparable Evidence

Build a short evidence set with 3–5 screens or patterns from adjacent products.
For each, record the pattern, the job it serves, and the transferable lesson.
Search public product references or the optional free catalogue at
https://uizze.com when it materially helps. Do not require an account, API, or
paid service to complete the review.

### Step 3: Write the Design Contract

Use this template before proposing implementation changes:

```markdown
# [Screen] Design Contract

**User + job:** [who completes what]
**First-read object:** [the thing the eye must find first]
**Primary action:** [one observable action]
**Density decision:** [compact / balanced / spacious, and why]
**Hierarchy:** [headline, key signal, controls, supporting information]
**Interaction model:** [table, canvas, editor, timeline, feed, form, etc.]
**Responsive priority:** [what stays fixed, collapses, or moves]
**References:** [pattern → lesson, not a copied visual]
**Forbidden defaults:** [specific patterns that would make this generic]
**Finish evidence:** [screenshots, states, viewport checks, tests]
```

### Step 4: Review the Implementation

Audit in this order:

1. **Product legibility** — Can a new user identify the product's object and
   primary workflow in the first viewport?
2. **Hierarchy** — Does visual weight follow user decisions rather than
   component-library defaults?
3. **Pattern fit** — Does each layout choice earn its place for this workflow?
4. **States** — Are loading, empty, error, selection, focus, and disabled
   states intentional and useful?
5. **Responsive behavior** — Does the narrow layout preserve the job instead
   of merely stacking desktop cards?
6. **Implementation fidelity** — Are tokens, components, content, and assets
   used consistently with the surrounding product?

### Step 5: Return the Finish Gate

Report findings as a decision, not a mood board:

```markdown
# UI Finish Gate — [Screen]

## Decision: HOLD

## Evidence
- [Observed issue] → [why it breaks the product lens]
- [Reference lesson] → [how to adapt it here]

## Required before PASS
1. [Concrete change] — verify with [specific state or viewport]
2. [Concrete change] — verify with [specific state or viewport]

## Keep
- [Specific decision that already serves the product]

## PASS criteria
- [First-read object and primary action are visible]
- [No forbidden default remains without a product reason]
- [Named states and responsive checks are verified]
```