---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Evidence Before Opinion

- Do not say a UI is "clean," "premium," or "modern" without naming what the
  user can see or do differently
- Do not copy a reference product wholesale; extract a pattern and explain why
  it fits this product's job, audience, and constraints
- Do not use a trend, a Dribbble-like composition, or a design-system default
  as proof that an interface is right
- Treat accessibility, loading, empty, error, focus, and narrow-screen states
  as part of the finished product, not cleanup work

### Protect Product Specificity

- Do not replace a domain workflow with a generic hero, dashboard, or card
  gallery unless the product actually needs one
- Do not add gradients, glass effects, giant rounded cards, or animation just
  to make an interface feel designed
- Do not reject an interface merely because it is simple; reject it when its
  choices are interchangeable or hide the user's real work
- Keep existing brand and technical constraints unless a concrete problem
  requires changing them