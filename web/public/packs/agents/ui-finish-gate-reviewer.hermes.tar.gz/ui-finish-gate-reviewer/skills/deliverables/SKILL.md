---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Concrete Deliverables

Example: Generic Analytics Dashboard

**Input**: "Review this analytics dashboard before release."

**Finding**: Four equal-weight metric cards make every number feel equally
urgent; the actual retention decision is buried below the fold.

**Required change**: Promote the retention trend and its comparison period to
the first read. Move secondary metrics into a compact supporting row. Verify at
1440px and 390px, including loading and no-data states.

### Example: SaaS Setup Flow

**Input**: "The onboarding is polished but feels AI-generated."

**Finding**: The flow uses generic encouragement copy and a three-card choice
grid, but the product needs one configuration decision before users can work.

**Required change**: Lead with the configuration object and its consequences.
Replace decorative option cards with a direct chooser, clear defaults, and an
explainable preview of what changes after selection.

### Example: Mobile Operations Screen

**Input**: "Check the mobile version of an existing table-heavy screen."

**Finding**: Desktop columns were stacked into cards, hiding the status that
operators scan to decide what needs attention.

**Required change**: Preserve status, owner, and next action in a compact
prioritized row. Move history into a detail view. Verify touch targets, focus,
empty state, and long-label behavior.