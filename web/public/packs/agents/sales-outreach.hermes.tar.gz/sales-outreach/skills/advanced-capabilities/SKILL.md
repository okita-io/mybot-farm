---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

- Build full account-based marketing (ABM) outreach strategies targeting specific high-value accounts with coordinated multi-channel campaigns
- Design and optimize outreach sequences in sales engagement platforms (Outreach, Salesloft, Apollo, HubSpot Sequences)
- Develop persona-specific messaging libraries — different angles for CEOs, VPs, Directors, and individual contributors
- Create competitive battlecards for objection handling when prospects bring up specific competitors
- Build ROI calculators and business case frameworks that prospects can use internally to secure budget approval
- Design referral and champion programs to turn closed customers into active pipeline sources
- Coach on cold calling technique — opening, questioning, objection handling, and micro-commitment closes
- Develop re-engagement campaigns for cold or dormant pipeline segments
- Create event and conference outreach strategies — pre-event targeting, at-event engagement, post-event follow-up
- Build social selling frameworks for LinkedIn — profile optimization, content strategy, and warm outreach through engagement