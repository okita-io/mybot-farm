---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Ideal Customer Profile (ICP) Framework

```
ICP DEFINITION TEMPLATE
───────────────────────────────────────
Firmographic:
  - Industry: [target verticals]
  - Company size: [employee count or revenue range]
  - Geography: [regions or markets]
  - Business model: [B2B / B2C / SaaS / Services / etc.]
  - Tech stack signals: [tools that indicate fit or need]

Persona:
  - Title/Role: [decision maker and champion titles]
  - Seniority: [C-suite / VP / Director / Manager]
  - Key responsibilities: [what they own and care about]
  - Pain points: [the problems they lose sleep over]
  - Success metrics: [how their performance is measured]

Trigger events (reach out when):
  - Company raised funding (growth mode, budget available)
  - New executive hire in the buying role
  - Company announced expansion or new product line
  - Competitor displacement opportunity
  - Job posting signals pain (hiring for the problem you solve)
  - Recent news coverage of a relevant challenge

Disqualifiers (do not pursue):
  - [List of company types, sizes, or signals that indicate poor fit]
```

### Cold Email Framework

```
COLD EMAIL STRUCTURE
───────────────────────────────────────
Subject line principles:
  - Under 7 words
  - Specific to their world, not yours
  - Curiosity or relevance — never clickbait
  Examples:
    "Question about [Company]'s [relevant initiative]"
    "[Mutual connection] suggested I reach out"
    "Idea for [Company]'s [specific goal]"
    "[Their competitor] is doing this — are you?"

Body structure (under 150 words):

  Line 1 — RELEVANCE (why them, why now)
    "I noticed [specific trigger / company news / role change] —
    [one sentence connecting it to a relevant pain point]."

  Line 2-3 — VALUE (what's in it for them)
    "We help [ICP description] [achieve specific outcome]
    without [common frustration]. [One-line social proof or result]."

  Line 4 — CTA (one specific, low-friction ask)
    "Would it be worth a 15-minute call this week to see if
    there's a fit? Happy to work around your schedule."

  Sign-off:
    "[First name]
    [Title] at [Company]
    [Phone] | [LinkedIn URL]"

What to avoid:
  ❌ "I hope this email finds you well"
  ❌ "I wanted to reach out because..."
  ❌ "We are the leading provider of..."
  ❌ Multiple questions or CTAs
  ❌ Attachments on first contact
  ❌ More than 3 paragraphs
```

### Multi-Touch Outreach Cadence

```
7-TOUCH OUTREACH SEQUENCE
───────────────────────────────────────
Touch 1 — Day 1: Cold email (personalized, value-led)
Touch 2 — Day 3: LinkedIn connection request (no pitch — just connect)
Touch 3 — Day 5: Follow-up email (add new value — case study, insight, or stat)
Touch 4 — Day 8: LinkedIn message (short, reference the email, different angle)
Touch 5 — Day 12: Phone call + voicemail (30 seconds max, specific and warm)
Touch 6 — Day 17: Email with relevant content (article, report, or tool they'd find useful)
Touch 7 — Day 21: Breakup email (honest, respectful, leaves the door open)

Breakup email template:
  Subject: "Should I close your file?"

  "[First name], I've reached out a few times and haven't heard back —
  which usually means one of two things: the timing isn't right, or
  this isn't relevant to you right now.

  Either way, totally fine. I'll close out your file so I'm not
  cluttering your inbox.

  If things change and [pain point] becomes a priority, I'm always
  here. Wishing you a great [quarter/year].

  [Name]"

  Note: Breakup emails often get the highest response rates of any touch.
  Respect + honesty + low pressure = replies.
```

### Objection Handling Framework

```
OBJECTION RESPONSE PLAYBOOK
───────────────────────────────────────
"We don't have budget right now."
  Explore: "I completely understand. Can I ask — is it a matter of
  no budget existing, or no budget allocated for this yet? The reason
  I ask is that a lot of our customers found budget by [reframing ROI /
  consolidating other tools / timing with Q[X] planning]."

"We're already using [competitor]."
  Explore: "That's helpful to know. What made you go with [competitor]
  originally? And is there anything you wish worked differently?"
  (Never badmouth competitors — let the prospect identify the gaps.)

"This isn't a priority right now."
  Explore: "That makes sense — there's always a lot going on. Can I
  ask what IS the top priority for [their team/function] this quarter?
  I want to make sure I'm not wasting your time if there's no fit."…