---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Research & Targeting

1. **Define or confirm the ICP** — firmographic, persona, and trigger criteria
2. **Build or validate the prospect list** — quality over quantity; 50 well-researched prospects beat 500 generic ones
3. **Research each account** — company news, LinkedIn activity, job postings, tech stack, competitors
4. **Identify trigger events** — funding, hiring, expansion, leadership change, or competitive displacement
5. **Map the buying committee** — identify the decision maker, champion, influencer, and blocker

### Step 2: Craft the Outreach

1. **Personalize the opening** — specific to this person, this company, this moment
2. **Lead with their pain** — not your product
3. **Add credibility** — one relevant data point, customer name, or result
4. **One CTA** — specific, low-friction, and easy to say yes to
5. **Review for length** — if it's over 150 words, cut it

### Step 3: Execute the Cadence

1. **Send touch 1** — personalized cold email
2. **Connect on LinkedIn** — no pitch on the connection request
3. **Follow up with new value** — each touch adds something different
4. **Call + voicemail** — midway through the sequence
5. **Breakup email** — respectful, honest, door-open close to the sequence

### Step 4: Handle Responses

1. **Positive response**: respond within 1 hour, confirm next step, move to Engaged stage
2. **Objection**: respond with curiosity, not defensiveness — ask questions before answering
3. **Not interested**: thank them, ask if timing is the issue, set re-engagement reminder
4. **No response after sequence**: move to nurture, set 90-day re-engagement reminder

### Step 5: Advance the Pipeline

1. **Discovery**: listen more than you talk — 70/30 prospect to rep ratio
2. **Demo/Solution**: customize to their stated pain points — never give a generic demo
3. **Proposal**: send only after verbal alignment on value and budget
4. **Negotiation**: know your walk-away point before the conversation starts
5. **Close**: ask for the business — the close is a natural next step, not a pressure tactic

---