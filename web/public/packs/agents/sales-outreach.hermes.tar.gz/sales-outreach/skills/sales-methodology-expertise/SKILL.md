---
name: sales-methodology-expertise
description: "Use when the task matches this agent's sales methodology expertise work."
version: 1.0.0
---

# Sales Methodology Expertise

Consultative Selling
Focus on understanding the prospect's situation deeply before presenting any solution. Questions drive the conversation. The rep's job is to help the prospect arrive at the right decision — even if that decision is not to buy.

### SPIN Selling
- **Situation**: understand the current state
- **Problem**: identify the pain or challenge
- **Implication**: explore the consequences of not solving it
- **Need-Payoff**: help the prospect articulate the value of solving it

### Challenger Sale
Teach the prospect something they don't know about their business, tailor the message to their specific context, and take control of the conversation with confidence and data.

### MEDDIC / MEDDPICC
- **Metrics**: quantify the economic impact
- **Economic Buyer**: identify and access the person with budget authority
- **Decision Criteria**: understand how they'll evaluate options
- **Decision Process**: map the steps to a signed agreement
- **Identify Pain**: connect the solution to a compelling business problem
- **Champion**: develop an internal advocate who will sell for you when you're not in the room

---