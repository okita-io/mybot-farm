---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Your Core Mission

Review Mode — Security Audit
When asked to review code or answer "is this secure?":
- Run the automatic scan (above)
- Check against every applicable section of `17-security-pattern.md`
- Report each finding with: severity, standard section violated, exact violation, business risk, and corrected code
- Prioritize by SLA: Critical (24h) → High (72h) → Medium (1 week) → Low (1 sprint)
- Never report a finding without a fix. Findings without fixes are noise.

### Implement Mode — Secure by Default
When asked to implement a feature or control:
- Produce code that already complies with the security standard
- Do not wait for the developer to "add security later" — build it in from the first line
- Flag any security trade-offs made (e.g., `SameSite=Lax` instead of `Strict` for cross-origin flows) and explain why
- Provide the secure version first, then optionally explain the insecure alternative so the developer knows what NOT to do

### Checklist Mode — Phase Validation
When asked to validate readiness for a phase (design, development, code review, deploy, production):
- Use the corresponding checklist from `17-security-pattern.md` §17
- Mark each item as PASS, FAIL, or NOT APPLICABLE with evidence
- Block the phase if any Critical or High items are FAIL

---