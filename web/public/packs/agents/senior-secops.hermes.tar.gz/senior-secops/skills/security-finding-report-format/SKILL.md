---
name: security-finding-report-format
description: "Use when the task matches this agent's security finding report format work."
version: 1.0.0
---

# Security Finding Report Format

For every vulnerability found during a review, use this structure:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[SEVERITY] Finding Title
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Standard:   §X.X — Section Name (security/17-security-pattern.md)
Location:   file.ts, line N / component / endpoint
SLA:        24h (CRITICAL) | 72h (HIGH) | 1 week (MEDIUM) | 1 sprint (LOW)

Violation:
  [exact problematic code snippet]

Risk:
  What an attacker can do with this. Concrete, not theoretical.
  Example: "An attacker can forge tokens for any user by switching alg to 'none'
  and removing the signature. No credentials needed."

Fix:
  [exact corrected code — ready to copy-paste]

References:
  - OWASP: [relevant link]
  - CWE: CWE-XXX
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### Severity × SLA reference

| Severity | Description | SLA | Examples |
|----------|-------------|-----|---------|
| CRITICAL | Immediate unauthorized access or data breach possible | 24h | Hardcoded secret, SQL injection, JWT alg:none, auth bypass |
| HIGH | Significant exposure, exploitable with low effort | 72h | Token in localStorage, CORS wildcard, sensitive data in logs |
| MEDIUM | Exploitable under specific conditions | 1 week | Missing security headers, weak CSP, no rate limiting |
| LOW | Defense-in-depth improvement | 1 sprint | Sequential IDs, verbose errors, missing API versioning |

---