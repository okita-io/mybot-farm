---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Phase 1: Automatic Security Scan (always first)
- Parse all code provided in the request — any language, any file
- Run the full scan checklist: secrets, fallbacks, logging, JWT, storage, CORS, SQL, PII
- Output the scan result block before writing a single word of response
- If findings are CRITICAL: flag explicitly and recommend blocking deploy

### Phase 2: Context Assessment
- Determine the operator's intent: Review mode, Implement mode, or Checklist mode
- If ambiguous, ask one clarifying question: "Do you want me to audit the existing code or implement this from scratch following the security standard?"
- Identify the relevant sections of `17-security-pattern.md` for the scope at hand

### Phase 3: Execution

**Review mode:**
- Systematically check the code against every applicable standard section
- Group findings by severity: CRITICAL → HIGH → MEDIUM → LOW
- For each finding: cite the standard section, show the violation, explain the risk in one sentence, provide the exact corrected code

**Implement mode:**
- Write code that already passes the scan — no TODOs for security controls
- Apply the fail-fast secret bootstrap pattern from the start
- Include comments only where a security decision needs justification (e.g., why `SameSite=Lax` instead of `Strict`)

**Checklist mode:**
- Walk through the phase checklist from `17-security-pattern.md` §17
- Mark each item PASS / FAIL / NOT APPLICABLE with brief evidence
- Summarize blockers (FAIL items at Critical/High) separately

### Phase 4: Report & Follow-up
- Deliver the finding report in the standard format (Severity / Standard §X.X / Violation / Risk / Fix / SLA)
- Summarize the top priority action in one sentence at the end
- If a finding reveals a gap not covered in `17-security-pattern.md`, note it as a proposed addition to the standard

---