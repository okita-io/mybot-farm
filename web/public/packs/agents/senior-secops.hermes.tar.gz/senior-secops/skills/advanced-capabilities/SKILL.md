---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Multi-File Codebase Scan
When given access to a full codebase (via file tree or multiple files), the agent performs a systematic sweep across all layers:
- **Config files**: `.env.example`, `docker-compose.yml`, `k8s/*.yaml` — checking for secrets, exposed ports, privileged containers
- **Auth layer**: token validation files, middleware, guards — checking algorithm pinning, claim validation, IdP integration
- **API layer**: all route handlers — checking input validation, authorization guards, error response sanitization
- **Frontend**: storage calls, cookie handling, inline scripts, CSP compliance
- **Infrastructure**: Nginx/Caddy config, CI/CD pipeline files — headers, HTTPS enforcement, secrets in environment blocks

### Dependency & SCA Analysis
- Reviews `package.json`, `requirements.txt`, `go.mod`, `Gemfile` for known vulnerable packages
- Flags dependencies with published CVEs relevant to the application's security surface
- Recommends upgrade paths or alternatives for dependencies with no fix available
- Proposes adding `npm audit`, `pip audit`, `trivy`, or `Snyk` to the CI/CD pipeline

### CI/CD Security Pipeline Design
Designs or audits the security stage of CI/CD pipelines:
```yaml
# Minimum security gates for any production pipeline
security:
  - secrets-scan:    gitleaks / trufflehog (pre-commit + CI)
  - sast:            semgrep (OWASP Top 10 + CWE Top 25 ruleset)
  - dependency-scan: trivy / snyk (CRITICAL,HIGH exit-code: 1)
  - container-scan:  trivy image (if Dockerized)
  - dast:            OWASP ZAP baseline (staging, not blocking)
```

### Feature Threat Modeling
For new features with security implications (auth changes, file uploads, payment flows, admin panels), produces a lightweight STRIDE analysis:
- Identifies trust boundaries introduced by the feature
- Maps each threat to a specific control from `17-security-pattern.md`
- Flags any gap where the standard doesn't cover the new attack surface

### Security Regression Testing
Proposes test cases that encode security requirements as executable assertions — so regressions are caught in CI, not in production:
```typescript
// Security regression: JWT alg:none must be rejected
it("should reject tokens with alg:none", async () => {
  const noneToken = buildTokenWithAlg("none", { sub: "user-1" });
  const res = await request(app).get("/api/me")
    .set("Cookie", `access_token=${noneToken}`);
  expect(res.status).toBe(401);
});

// Security regression: tokens must not appear in response body
it("should not return tokens in login response body", async () => {
  const res = await loginAs("user@example.com", "password");
  expect(res.body).not.toHaveProperty("accessToken");
  expect(res.body).not.toHaveProperty("token");
});
```