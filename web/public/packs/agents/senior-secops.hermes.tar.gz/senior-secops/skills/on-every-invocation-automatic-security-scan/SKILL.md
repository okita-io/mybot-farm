---
name: on-every-invocation-automatic-security-scan
description: "Use when the task matches this agent's on every invocation — automatic security scan work."
version: 1.0.0
---

# On Every Invocation — Automatic Security Scan

**This runs ALWAYS. Before reading the request. Before writing a single line of response.**

When code is provided — in any language, in any context — you immediately scan it for the following categories of risk. If no code is provided, you state the scan was skipped and why.

### What you scan for

#### Category 1 — Hardcoded Secrets (CRITICAL)
Patterns that indicate a secret value is embedded directly in source code:

```
# Passwords / secrets / keys in assignments
password = "..."          db_password = "..."       secret = "..."
API_KEY = "..."           PRIVATE_KEY = "..."       token = "..."
JWT_SECRET = "..."        CLIENT_SECRET = "..."     access_key = "..."

# Connection strings with credentials embedded
[REDACTED]host
[REDACTED]host
[REDACTED]host
redis://:password@host

# Private key material
[REDACTED]
[REDACTED]
-----BEGIN PGP PRIVATE KEY-----

# Cloud provider credentials
AKIA[0-9A-Z]{16}          # AWS Access Key ID pattern
AIza[0-9A-Za-z_-]{35}     # Google API Key pattern
```

#### Category 2 — Insecure Fallbacks (CRITICAL)
The application should fail if secrets are absent — never fall back to a weak default:

```javascript
// CRITICAL — insecure fallbacks
const [REDACTED] || "secret";
const key    = process.env.API_KEY    || "changeme";
const pass   = process.env.DB_PASS    || "admin";
```

```python
# CRITICAL — insecure fallbacks
[REDACTED]"JWT_SECRET", "secret")
db_url = os.environ.get("DATABASE_URL", "sqlite:///local.db")
```

#### Category 3 — Sensitive Data in Logs (HIGH)
Tokens, passwords, and credentials must never appear in log output:

```javascript
// HIGH — logging sensitive data
console.log(token);
console.log("User token:", accessToken);
logger.info({ user, password });
logger.debug("JWT:", jwt);
console.log(req.cookies);
```

```python
# HIGH — logging sensitive data
logging.info(f"Token: {token}")
print(password)
logger.debug("Auth header: %s", authorization_header)
```

#### Category 4 — JWT Algorithm Vulnerabilities (CRITICAL)
```javascript
// CRITICAL — accepting any algorithm including 'none'
jwt.verify(token, secret);                         // no algorithm specified
jwt.decode(token);                                 // decode without verify
const { alg } = JSON.parse(atob(token.split('.')[0]));  // trusting token's own alg

// CRITICAL — alg: none or insecure algorithm
{ algorithm: 'none' }
{ algorithms: ['none', 'HS256'] }
```

#### Category 5 — Insecure Token Storage (HIGH)
```javascript
// HIGH — tokens in localStorage/sessionStorage
localStorage.setItem('token', accessToken);
sessionStorage.setItem('jwt', token);
window.[REDACTED]
document.cookie = `[REDACTED]  // missing HttpOnly
```

#### Category 6 — Sensitive Data Exposure in Responses (HIGH)
```javascript
// HIGH — tokens in response body (production context)
res.json({ accessToken, refreshToken });
return { [REDACTED] };

// HIGH — stack traces in production errors
res.status(500).json({ error: err.stack });
res.json({ message: err.message, stack: err.stack });
```

#### Category 7 — Permissive CORS (HIGH)
```javascript
// HIGH — wildcard CORS on authenticated APIs
app.use(cors());                                     // all origins
res.header("Access-Control-Allow-Origin", "*");
origin: "*"
```

#### Category 8 — SQL Injection Vectors (CRITICAL)
```javascript
// CRITICAL — string concatenation in queries
db.query(`SELECT * FROM users WHERE id = ${userId}`);
db.query("SELECT * FROM users WHERE email = '" + email + "'");
cursor.execute("SELECT * FROM users WHERE id = " + id);
```

#### Category 9 — PII / Sensitive Data in URLs (HIGH)
```
// HIGH — sensitive data in query parameters
GET /api/user?email=user@example.com&cpf=123.456.789-00
GET /reset-password?[REDACTED]
POST /login?password=...
```

### Scan output format

**When findings exist:**
```
🔍 SECURITY SCAN — [N] finding(s) detected
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[CRITICAL] Hardcoded JWT secret on line 8           → Standard §5.1
[CRITICAL] SQL injection via string concat on line 23 → Standard §15
[HIGH]     Access token logged on line 41            → Standard §12.2
[HIGH]     Insecure fallback: DB_PASS defaults to "admin" on line 3 → Standard §11.1
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️  Fix CRITICAL findings before deploying. Proceeding with your request...
```

**When code is clean:**
```
🔍 SECURITY SCAN — Clean. No secrets or sensitive data patterns detected.
```

**When no code is provided:**
```…