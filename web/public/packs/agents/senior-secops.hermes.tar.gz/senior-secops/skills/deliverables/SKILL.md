---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Fail-Fast Secret Bootstrap

```typescript
// TypeScript / Node.js — fail at startup if secrets missing
function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    console.error(`FATAL: Required environment variable "${name}" is not set.`);
    process.exit(1);
  }
  return value;
}

const config = {
  jwtSecret:    requireEnv("JWT_SECRET"),
  dbUrl:        requireEnv("DATABASE_URL"),
  idpJwksUri:   requireEnv("IDP_JWKS_URI"),
  allowedOrigins: requireEnv("ALLOWED_ORIGINS").split(","),
};
```

```python
# Python — fail at startup if secrets missing
import os, sys

def require_env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        print(f"FATAL: Required environment variable '{name}' is not set.", file=sys.stderr)
        sys.exit(1)
    return value

config = {
    "jwt_secret":    require_env("JWT_SECRET"),
    "db_url":        require_env("DATABASE_URL"),
    "idp_jwks_uri":  require_env("IDP_JWKS_URI"),
}
```

### JWT Validation (Node.js — RS256 + JWKS)

```typescript
import jwksClient from "jwks-rsa";
import jwt from "jsonwebtoken";

const client = jwksClient({ jwksUri: config.idpJwksUri });

async function validateToken([REDACTED] Promise<jwt.JwtPayload> {
  const decoded = jwt.decode(token, { complete: true });
  if (!decoded || typeof decoded === "string") throw new Error("Invalid token format");

  const key = await client.getSigningKey(decoded.header.kid);
  const publicKey = key.getPublicKey();

  // Algorithm explicitly set — never trust the token's own alg claim
  const payload = jwt.verify(token, publicKey, {
    algorithms: ["RS256"],        // never 'none', never from token header
    issuer: config.idpIssuer,
    audience: config.idpAudience,
  }) as jwt.JwtPayload;

  if (!payload.sub || !payload.exp || !payload.iat) {
    throw new Error("Missing required JWT claims");
  }

  return payload;
}
```

### Secure Cookie Configuration

```typescript
// Express — production-ready cookie settings
const COOKIE_OPTIONS = {
  httpOnly: true,                            // not accessible via JavaScript
  secure: process.env.NODE_ENV === "production",  // HTTPS only in prod
  sameSite: "lax" as const,                 // CSRF protection
  maxAge: 15 * 60 * 1000,                   // 15 minutes (access token)
  path: "/",
};

const REFRESH_COOKIE_OPTIONS = {
  ...COOKIE_OPTIONS,
  maxAge: 7 * 24 * 60 * 60 * 1000,          // 7 days (refresh token)
  path: "/api/auth/refresh",                  // scope to refresh endpoint only
};

// Setting tokens — never in response body in production
res.cookie("access_token", accessToken, COOKIE_OPTIONS);
res.cookie("refresh_token", refreshToken, REFRESH_COOKIE_OPTIONS);
res.json({ message: "Authenticated" });     // NO token in body
```

### HTTP Security Headers (Nginx)

```nginx
server {
    # Force HTTPS (1 year + subdomains + preload)
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;

    # Prevent MIME sniffing
    add_header X-Content-Type-Options "nosniff" always;

    # Clickjacking protection
    add_header X-Frame-Options "DENY" always;

    # Referrer policy
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Disable unnecessary browser features
    add_header Permissions-Policy "camera=(), microphone=(), geolocation=(), payment=()" always;

    # CSP — adjust script/style sources to match your CDNs
    add_header Content-Security-Policy "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none';" always;

    # No-cache for auth routes
    location /api/auth/ {
        add_header Cache-Control "no-store" always;
    }

    # Remove server version
    server_tokens off;
}
```

### CORS — Restricted Configuration

```typescript
// Express + cors package — explicit allowlist
import cors from "cors";

const corsOptions: cors.CorsOptions = {
  origin: (origin, callback) => {
    // Allow requests with no origin (server-to-server, curl, mobile)
    if (!origin) return callback(null, true);

    if (config.allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error(`CORS: origin '${origin}' not allowed`));
    }
  },
  credentials: true,              // required for cookies
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"],
};…