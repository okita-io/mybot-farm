---
name: sast-secrets-detection-full-pattern-reference
description: "Use when the task matches this agent's sast & secrets detection — full pattern reference work."
version: 1.0.0
---

# SAST & Secrets Detection — Full Pattern Reference

Authentication & JWT

| Pattern | Severity | Standard |
|---------|----------|----------|
| `jwt.decode(token)` without verify | CRITICAL | §3.1 |
| `algorithms: ['none']` or `algorithm: 'none'` | CRITICAL | §3.1, §5.1 |
| `jwt.verify(token, secret)` without algorithm option | CRITICAL | §5.1 |
| JWT secret in code literal | CRITICAL | §5.1, §11.1 |
| `JWT_SECRET || "fallback"` | CRITICAL | §5.1 |
| No `iss`, `aud`, `exp` validation | HIGH | §5.1 |

### Secrets & Environment

| Pattern | Severity | Standard |
|---------|----------|----------|
| Hardcoded password/key/secret literal | CRITICAL | §11.1 |
| Insecure `os.getenv("X", "default")` for secrets | CRITICAL | §11.1 |
| Private key PEM material in source | CRITICAL | §11.1 |
| AWS/GCP/Azure credential patterns | CRITICAL | §11.1 |
| `.env` file committed (not in `.gitignore`) | HIGH | §11.1 |
| Secret shared across environments | HIGH | §11.1 |

### Logging

| Pattern | Severity | Standard |
|---------|----------|----------|
| `log(token)`, `log(password)`, `log(secret)` | HIGH | §12.2 |
| Error response with `err.stack` | HIGH | §13 |
| PII (email, CPF, card) in log statements | HIGH | §12.2 |
| Request body logged entirely | MEDIUM | §12.2 |

### Storage & Cookies

| Pattern | Severity | Standard |
|---------|----------|----------|
| `localStorage.setItem('token', ...)` | HIGH | §6.1, §14 |
| `sessionStorage.setItem('token', ...)` | HIGH | §6.1, §14 |
| Cookie without `HttpOnly` flag | HIGH | §6.1 |
| Cookie without `Secure` flag (production) | HIGH | §6.1 |
| Cookie without `SameSite` | MEDIUM | §6.1 |

### CORS & Headers

| Pattern | Severity | Standard |
|---------|----------|----------|
| `Access-Control-Allow-Origin: *` on auth API | HIGH | §8.1 |
| `cors()` with no origin restriction | HIGH | §8.1 |
| Missing `Strict-Transport-Security` header | MEDIUM | §7 |
| Missing `X-Content-Type-Options: nosniff` | MEDIUM | §7 |
| Missing `X-Frame-Options` | MEDIUM | §7 |
| Missing `Content-Security-Policy` | MEDIUM | §10 |

### Database & Injection

| Pattern | Severity | Standard |
|---------|----------|----------|
| String interpolation in SQL query | CRITICAL | §15 |
| `.raw()` with user-supplied input | CRITICAL | §15 |
| `eval()` with external data | CRITICAL | §14 |
| `innerHTML =` with user data | HIGH | §14 |
| `dangerouslySetInnerHTML` without sanitization | HIGH | §14 |

### API Security

| Pattern | Severity | Standard |
|---------|----------|----------|
| Sequential integer IDs in public endpoints | MEDIUM | §13 |
| No input schema validation | HIGH | §13 |
| No pagination on list endpoints | LOW | §13 |
| Unversioned API routes | LOW | §13 |

---