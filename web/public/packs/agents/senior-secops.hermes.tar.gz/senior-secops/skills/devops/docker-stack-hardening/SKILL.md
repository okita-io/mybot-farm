---
name: docker-stack-hardening
description: "Freeze a Docker stack: digest-pin images, git-pin builds."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [macos, linux]
metadata:
  hermes:
    tags: [docker, supply-chain, security, infrastructure, pinning, compose]
    category: devops
---

# Docker Stack Hardening (supply-chain freezing)

Make a Docker stack *immutable by default*: nothing a user can accidentally type
(`docker compose pull`, `git pull`) or a registry can republish can silently swap
binaries. Established for the firecrawl + SearXNG research stack (2026-08-22).

## When this activates

- User asks to pin/freeze/lock a Docker stack, keep images stable, or reduce
  supply-chain risk ("recent malware attacks… updates infrequent, only when necessary").
- A stack is stable and working and the user wants it to STAY working.
- Before moving a stack to a new host (rebuilding from unpinned tags is the moment
  drift happens).

## Core technique (do all of these)

### 1. Inventory: separate registry-pulled from locally-built
```bash
docker ps -a --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}'
docker image ls --format 'table {{.Repository}}:{{.Tag}}\t{{.ID}}\t{{.CreatedSince}}'
```
Two classes, two pinning strategies:
- **Registry-pulled** → pin by **digest** (step 2).
- **Locally-built** (`build:` in compose) → pin by **source** (step 3).

### 2. Digest-pin registry images (the strong form)
A tag can be republished maliciously; a digest pins the exact content-addressed
blob. Replace `image: foo/bar:latest` with:
```yaml
image: foo/bar:latest@sha256:<id>
```
Get the id of the RUNNING image:
```bash
docker image inspect <name>:<tag> --format '{{.Id}}'   # sha256:...
```
Add a dated comment: `# DIGEST-PINNED 2026-08-22 (supply-chain policy: update only when necessary — see <infra doc>)`.
Note: with a digest present, the tag is cosmetic; keep it for human readability.

### 3. Pin build-images by git source
For `build:` services, the image only changes when someone rebuilds from changed
source. Record the pinned commit in the infra doc and treat it as the pin:
```bash
cd <repo> && git log --oneline -1 && git status --short
```
Rule to write down: **never `git pull` in the stack repo**; only a deliberate
`git fetch && git checkout <chosen tag>` followed by an explicit rebuild.

### 4. Rescue `docker run` containers into pinned launch scripts
Containers started ad hoc (`docker run ...` with no compose file) have no pin and
often carry config in an **anonymous volume** (lost on recreation). Fix:
- `docker inspect <c>` for mounts, env, ports, restart policy.
- `docker cp <c>:/path/config.yml /tmp/keep.yml` to capture config BEFORE
  recreating. **If config contains secrets, never print them into chat output** —
  stage them into a Docker named volume via a bind-mount + `docker run --rm
  alpine cp` (pulling `alpine:latest` as a one-shot tool is fine; pin the
  *product* images, not scratch tools).
- Move config into a named volume and a host copy; write a launch script that
  pins the image digest, uses the named volumes, adds `--restart unless-stopped`,
  idempotency check (`docker ps | grep -qx <name>`), and a health-check loop
  (poll the endpoint until HTTP 200, then exit 0; else exit 1 with log pointer).
- Document the update procedure inside the script header (how to compute the new
  digest, what to verify before swapping).

### 5. Verify WITHOUT touching the running stack
Pinning only affects FUTURE pulls — live containers keep running. Confirm:
```bash
docker compose config --quiet          # pins parse
docker compose config | grep image    # digests present in resolved config
curl -s -o /dev/null -w '%{http_code}' http://localhost:<port>/   # per endpoint
```
The env-var "not set" warning flood from `docker compose config` is usually
pre-existing (blank optional .env entries) — not a regression.

### 6. Write the standing policy + update procedure into the project's infra doc
The skill produces the *technique*; the project doc holds the *state*. Record:
- **Policy line:** images frozen; updates only when a vulnerability or breakage
  forces it (the user's directive, verbatim intent).
- **Pin table:** each image → digest (or git HEAD) + where the pin lives.
- **Update procedure (5 steps):**
  1. `docker pull <image>:<tag>` → note new digest (`docker image inspect --format '{{.Id}}'`)
  2. Check upstream release notes / CVEs for that exact version; log findings
  3. Test in a throwaway container before touching the running stack
  4. Swap the pin, restart, verify endpoints (real HTTP checks, not just `docker ps`)
  5. Update the infra doc: new digest + reason
- **Explicit bans:** no unscoped `docker compose pull`; no `git pull` in the stack repo.

## Pitfalls

1. **"Exited (1)" init containers are usually harmless.** One-shot `configure new`
   style init jobs print "Database already exists!" and exit 1 on every restart —
   expected, not breakage. Check what the *main* service is doing before panicking.
2. **Exit-0 immediately-by-design containers.** MCP bridge / keyless-mode
   containers that print a notice and exit in ~1s are working as designed, not
   "having issues". Confirm the real endpoints instead.
3. **Anonymous volumes are config-loss traps.** `docker inspect` mount source
   containing `volumes/<hash>` = anonymous. Any recreation = lost config. Move to
   named volumes before any pinning/restart work.
4. **Self-report of "up" is not health.** Verify with real endpoint probes
   (curl 200 / actual API call returning data). `docker ps` Up + healthy can still
   be serving nothing useful.
5. **Secrets in config:** never reproduce keys/tokens into chat, terminal output,
   or skill/docs. Stage them into volumes; reference their location, not their value.
6. **Don't pin scratch tools.** One-shot helper images (alpine for a cp) don't need
   pinning; pin the images that form the actual stack.

## Verification gate

- [ ] Every registry-pulled image in the stack has a `@sha256:` digest in the compose file / launch script
- [ ] Build-images' git commit recorded in the infra doc
- [ ] `docker compose config` parses; resolved config shows the digests
- [ ] All endpoints probed live (HTTP 200 + one functional call, e.g. an actual scrape/search)
- [ ] No running container lost state (config files present, data volumes intact)
- [ ] Infra doc has: policy line, pin table, 5-step update procedure, explicit bans
