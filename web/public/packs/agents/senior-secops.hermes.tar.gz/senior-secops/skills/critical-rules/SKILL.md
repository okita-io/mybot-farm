---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

These rules are absolute. They come from `security/17-security-pattern.md` and are non-negotiable. No deadline, no convenience argument overrides them.

### RULE 1 — Secrets are never in code
Secrets (JWT_SECRET, API keys, DB passwords, private keys) live in environment variables or a secrets vault. Never in source code. The application **must fail at startup** if a required secret is missing — no fallbacks, no defaults.

```javascript
// CORRECT — fail-fast secret loading
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error("FATAL: JWT_SECRET is not set. Refusing to start.");
  process.exit(1);
}
```

### RULE 2 — Tokens live in HttpOnly cookies
Access tokens and refresh tokens are stored in `HttpOnly; Secure; SameSite=Lax` cookies. Never in `localStorage`, `sessionStorage`, or JavaScript-accessible cookies. Tokens are never returned in response bodies in production.

### RULE 3 — JWT algorithm is fixed and verified
The algorithm is hardcoded in the verification call. `alg: none` is explicitly rejected. The token's own `alg` claim is never trusted.

```javascript
// CORRECT
jwt.verify(token, JWT_SECRET, { algorithms: ['HS256'] });

// CORRECT (RS256 with JWKS)
const client = jwksClient({ jwksUri: `${IDP_URL}/.well-known/jwks.json` });
// algorithm explicitly set to RS256 — never 'none', never from token header
```

### RULE 4 — Roles come from the IdP, always
The Identity Provider is the single source of truth for roles and permissions. Local database roles are a cache — they are re-synced from the IdP on every login. A local role that contradicts the IdP is always overwritten by the IdP.

### RULE 5 — Sensitive data is never logged
Tokens, passwords, secrets, API keys, cookie values, PII (CPF, email in full, credit card data) are never written to any log stream — not debug, not info, not error. Mask or omit them.

```javascript
// CORRECT — log user context without sensitive data
logger.info({ userId: user.id, action: 'login', ip: req.ip });

// WRONG
logger.info({ user, token, password });
```

### RULE 6 — CORS is an allowlist, not a wildcard
In production, `Access-Control-Allow-Origin` is an explicit list of known origins. `*` is never used on endpoints that accept cookies or Authorization headers. `Access-Control-Allow-Credentials: true` requires an explicit origin — it never works with `*`.

### RULE 7 — Every auth route has rate limiting
Login, registration, password reset, MFA verification, and token refresh endpoints have rate limiting by IP (and by user where applicable). HTTP 429 is returned when the limit is exceeded.

### RULE 8 — All inputs are validated at the trust boundary
Every external input — request body, query params, headers, path params — is validated against a strict schema before reaching business logic. ORM or parameterized queries are used for all database interactions. String concatenation into SQL is never acceptable.

---