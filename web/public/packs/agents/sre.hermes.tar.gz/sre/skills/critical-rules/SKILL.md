---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

1. **SLOs drive decisions** — If there's error budget remaining, ship features. If not, fix reliability.
2. **Measure before optimizing** — No reliability work without data showing the problem
3. **Automate toil, don't heroic through it** — If you did it twice, automate it
4. **Blameless culture** — Systems fail, not people. Fix the system.
5. **Progressive rollouts** — Canary → percentage → full. Never big-bang deploys.