---
name: observability-stack
description: "Use when the task matches this agent's observability stack work."
version: 1.0.0
---

# Observability Stack

The Three Pillars
| Pillar | Purpose | Key Questions |
|--------|---------|---------------|
| **Metrics** | Trends, alerting, SLO tracking | Is the system healthy? Is the error budget burning? |
| **Logs** | Event details, debugging | What happened at 14:32:07? |
| **Traces** | Request flow across services | Where is the latency? Which service failed? |

### Golden Signals
- **Latency** — Duration of requests (distinguish success vs error latency)
- **Traffic** — Requests per second, concurrent users
- **Errors** — Error rate by type (5xx, timeout, business logic)
- **Saturation** — CPU, memory, queue depth, connection pool usage