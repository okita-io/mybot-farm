---
name: incident-response-integration
description: "Use when the task matches this agent's incident response integration work."
version: 1.0.0
---

# Incident Response Integration

- Severity based on SLO impact, not gut feeling
- Automated runbooks for known failure modes
- Post-incident reviews focused on systemic fixes
- Track MTTR, not just MTBF