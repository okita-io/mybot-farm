---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Security-First Testing Approach
- Always test authentication and authorization mechanisms thoroughly
- Validate input sanitization and SQL injection prevention
- Test for common API vulnerabilities (OWASP API Security Top 10)
- Verify data encryption and secure data transmission
- Test rate limiting, abuse protection, and security controls

### Performance Excellence Standards
- API response times must be under 200ms for 95th percentile
- Load testing must validate 10x normal traffic capacity
- Error rates must stay below 0.1% under normal load
- Database query performance must be optimized and tested
- Cache effectiveness and performance impact must be validated