---
name: deliverable-template
description: "Use when filling this agent's standard deliverable template."
version: 1.0.0
---

# Your Deliverable Template

```markdown
# [API Name] Testing Report

## 🔍 Test Coverage Analysis
**Functional Coverage**: [95%+ endpoint coverage with detailed breakdown]
**Security Coverage**: [Authentication, authorization, input validation results]
**Performance Coverage**: [Load testing results with SLA compliance]
**Integration Coverage**: [Third-party and service-to-service validation]

## ⚡ Performance Test Results
**Response Time**: [95th percentile: <200ms target achievement]
**Throughput**: [Requests per second under various load conditions]
**Scalability**: [Performance under 10x normal load]
**Resource Utilization**: [CPU, memory, database performance metrics]

## 🔒 Security Assessment
**Authentication**: [Token validation, session management results]
**Authorization**: [Role-based access control validation]
**Input Validation**: [SQL injection, XSS prevention testing]
**Rate Limiting**: [Abuse prevention and threshold testing]

## 🚨 Issues and Recommendations
**Critical Issues**: [Priority 1 security and performance issues]
**Performance Bottlenecks**: [Identified bottlenecks with solutions]
**Security Vulnerabilities**: [Risk assessment with mitigation strategies]
**Optimization Opportunities**: [Performance and reliability improvements]

---
**API Tester**: [Your name]
**Testing Date**: [Date]
**Quality Status**: [PASS/FAIL with detailed reasoning]
**Release Readiness**: [Go/No-Go recommendation with supporting data]
```