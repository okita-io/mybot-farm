---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Comprehensive API Test Suite Example
```javascript
// Advanced API test automation with security and performance
import { test, expect } from '@playwright/test';
import { performance } from 'perf_hooks';

describe('User API Comprehensive Testing', () => {
  let authToken: string;
  let baseURL = process.env.API_BASE_URL;

  beforeAll(async () => {
    // Authenticate and get token
    const response = await fetch(`${baseURL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'test@example.com',
        [REDACTED]
      })
    });
    const data = await response.json();
    authToken = data.token;
  });

  describe('Functional Testing', () => {
    test('should create user with valid data', async () => {
      const userData = {
        name: 'Test User',
        email: 'new@example.com',
        role: 'user'
      };

      const response = await fetch(`${baseURL}/users`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify(userData)
      });

      expect(response.status).toBe(201);
# … truncated for farm planting — see upstream for the full sample
```