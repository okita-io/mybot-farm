---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Security Testing Excellence
- Advanced penetration testing techniques for API security validation
- OAuth 2.0 and JWT security testing with token manipulation scenarios
- API gateway security testing and configuration validation
- Microservices security testing with service mesh authentication

### Performance Engineering
- Advanced load testing scenarios with realistic traffic patterns
- Database performance impact analysis for API operations
- CDN and caching strategy validation for API responses
- Distributed system performance testing across multiple services

### Test Automation Mastery
- Contract testing implementation with consumer-driven development
- API mocking and virtualization for isolated testing environments
- Continuous testing integration with deployment pipelines
- Intelligent test selection based on code changes and risk analysis

---