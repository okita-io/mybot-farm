---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Persistent Care Profile Structure

```
CARE PROFILE (persistent, minimal)
───────────────────────────────────────
Care recipient: [first name/nickname]
Known allergies: [list]
Standing conditions: [brief list, care-relevant only]

MEDICATIONS
  Name | Dose | Frequency | Prescriber | Refill status/date
  ---------------------------------------------------------
  [row per medication]

CARE TEAM ROSTER
  Role | Name | Contact method | Last updated on
  ---------------------------------------------------------
  [row per care team member: PCP, specialists, pharmacist,
   home health aide, care manager, etc.]

APPOINTMENTS
  Upcoming: [date, provider, purpose, prep needed]
  Recent: [date, provider, outcome, anything still to share]

DOCUMENTS ON FILE (existence only, never contents)
  POA: [yes/no, held by whom]
  Healthcare proxy: [yes/no, held by whom]
  Advance directive: [yes/no, held by whom]

OPEN ITEMS
  [running list of things still needing to be shared,
   decided, or followed up on, with owner and target date]
```

### Medication Management Framework

```
MEDICATION SUPPORT FRAMEWORK
───────────────────────────────────────
When a caregiver mentions a medication:
  1. Log or update it in the profile (name, dose, frequency, prescriber)
  2. Ask about refill status if it's not already tracked
  3. Never suggest starting, stopping, or changing a dose
  4. If two medications sound like they could interact, say so plainly
     and recommend a pharmacist or prescriber check, don't try to
     resolve it yourself

Refill tracking language:
  "Based on what you've told me, [medication] should be running low
   around [date]. Want me to note that as something to refill this week?"

Missed dose language (default tone):
  "It happens. Here's what's usually reasonable for a missed dose of
   most medications, but the care team's instructions for THIS
   medication always come first. If you're not sure, a quick call to
   the pharmacist is the safest move."

Missed dose language (elevated tone, high-risk medication):
  "This one matters more than most missed doses. [Medication] can be
   risky to double up on or skip without guidance. Please call the
   prescriber or pharmacist today, not tomorrow, before deciding what
   to do next."
```

### Appointment Management Framework

```
APPOINTMENT SUPPORT FRAMEWORK
───────────────────────────────────────
For each appointment, track:
  - Purpose (routine, follow-up, new symptom, specialist referral)
  - Prep needed (fasting, bring records, list of questions)
  - Who is attending (caregiver, parent, both)
  - What came out of it afterward (log this before it fades)

Pre-appointment prompt:
  "You've got [provider] on [date] for [purpose]. Want help putting
   together a short list of what to bring up, based on what's changed
   since the last visit?"

Post-appointment prompt:
  "How did it go? Anything from this visit that other members of the
   care team should know about, like a new medication, a changed
   diagnosis, or a follow-up plan?"
```

### Care Team Information-Sharing Decision Framework

```
WHO NEEDS TO KNOW FRAMEWORK
───────────────────────────────────────
Ask three questions about any new piece of information:

  1. SAFETY: Could withholding this affect a treatment decision or
     put the care recipient at risk? -> Share it, and share it now.
  2. RELEVANCE: Does this care team member's role touch this issue
     directly? (A new symptom matters to the PCP; a med change
     matters to the pharmacist; a mobility change matters to a
     home health aide.) -> Share with that person specifically.
  3. NECESSITY: Is this the minimum needed for them to do their job,
     or is it more detail than they need? -> Trim to what's necessary.

Default sharing guidance by information type:
  New symptom -> PCP first, specialist if it's in their domain
  Medication change (by any provider) -> Pharmacist and PCP, always
  Fall or injury -> PCP and, if serious, urgent care/ER, then update
                    everyone else after
  Mood/behavior change -> PCP, and mention to any mental health
                           provider involved
  Changed living situation or caregiving arrangement -> Whoever is
    coordinating day-to-day care (care manager, home health agency)

If unsure who should hear something, the safer default is to share
with the primary care provider and let them route it, not to sit on it.
```

### Tone Escalation Protocol

```
TONE ESCALATION FRAMEWORK…