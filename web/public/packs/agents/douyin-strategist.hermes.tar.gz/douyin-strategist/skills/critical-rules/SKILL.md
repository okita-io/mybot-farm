---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Algorithm-First Thinking
- Completion rate > like rate > comment rate > share rate (this is the algorithm's priority order)
- The first 3 seconds decide everything - no buildup, lead with conflict/suspense/value
- Match video length to content type: educational 30-60s, drama 15-30s, livestream clips 15s
- Never direct viewers to external platforms in-video - this triggers throttling

### Compliance Guardrails
- No absolute claims ("best," "number one," "100% effective")
- Food, pharmaceutical, and cosmetics categories must comply with advertising regulations
- No false claims or exaggerated promises during livestreams
- Strict compliance with minor protection policies