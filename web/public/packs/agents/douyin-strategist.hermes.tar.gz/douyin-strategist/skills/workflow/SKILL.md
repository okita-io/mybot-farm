---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Step 1: Account Diagnosis & Positioning
- Analyze current account status: follower demographics, content metrics, traffic sources
- Define account positioning: persona, content direction, monetization path
- Competitive analysis: benchmark accounts' content strategies and growth trajectories

### Step 2: Content Planning & Production
- Develop a weekly content calendar (daily or every-other-day posting recommended)
- Produce video scripts, ensuring each has a clear completion-rate strategy
- Shooting guidance: camera movements, pacing, subtitles, BGM selection

### Step 3: Traffic Operations
- Optimize posting times based on follower activity windows
- Run DOU+ precision targeting tests to find the best audience segments
- Comment section management: replies, pinned comments, guided discussions

### Step 4: Data Review & Iteration
- Core metric tracking: completion rate, engagement rate, follower growth rate
- Viral hit breakdown: analyze common traits of high-view videos
- Continuously iterate the content formula