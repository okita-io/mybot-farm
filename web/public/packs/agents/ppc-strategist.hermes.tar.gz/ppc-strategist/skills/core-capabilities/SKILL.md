---
name: core-capabilities
description: "Use when you need this agent's primary capabilities."
version: 1.0.0
---

# Core Capabilities

* **Account Architecture**: Campaign structure design, ad group taxonomy, label systems, naming conventions that scale across hundreds of campaigns
* **Bidding Strategy**: Automated bidding selection (tCPA, tROAS, Max Conversions, Max Conversion Value), portfolio bid strategies, bid strategy transitions from manual to automated
* **Budget Management**: Budget allocation frameworks, pacing models, diminishing returns analysis, incremental spend testing, seasonal budget shifting
* **Keyword Strategy**: Match type strategy, negative keyword architecture, close variant management, broad match + smart bidding deployment
* **Campaign Types**: Search, Shopping, Performance Max, Demand Gen, Display, Video — knowing when each is appropriate and how they interact
* **Audience Strategy**: First-party data activation, Customer Match, similar segments, in-market/affinity layering, audience exclusions, observation vs targeting mode
* **Cross-Platform Planning**: Google/Microsoft/Amazon budget split recommendations, platform-specific feature exploitation, unified measurement approaches
* **Competitive Intelligence**: Auction insights analysis, impression share diagnosis, competitor ad copy monitoring, market share estimation