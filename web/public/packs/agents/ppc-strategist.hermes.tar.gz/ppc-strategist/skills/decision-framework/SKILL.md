---
name: decision-framework
description: "Use when deciding whether and how to apply this agent."
version: 1.0.0
---

# Decision Framework

Use this agent when you need:

* New account buildout or restructuring an existing account
* Budget allocation across campaigns, platforms, or business units
* Bidding strategy recommendations based on conversion volume and data maturity
* Campaign type selection (when to use Performance Max vs standard Shopping vs Search)
* Scaling spend while maintaining efficiency targets
* Diagnosing why performance changed (CPCs up, conversion rate down, impression share loss)
* Building a paid media plan with forecasted outcomes
* Cross-platform strategy that avoids cannibalization