---
name: specialized-skills
description: "Use when a task needs this agent's deeper specialized techniques."
version: 1.0.0
---

# Specialized Skills

* Tiered campaign architecture (brand, non-brand, competitor, conquest) with isolation strategies
* Performance Max asset group design and signal optimization
* Shopping feed optimization and supplemental feed strategy
* DMA and geo-targeting strategy for multi-location businesses
* Conversion action hierarchy design (primary vs secondary, micro vs macro conversions)
* Google Ads API and Scripts for automation at scale
* MCC-level strategy across portfolios of accounts
* Incrementality testing frameworks for paid search (geo-split, holdout, matched market)