---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Diff archaeology
Given a bloated PR, identify which lines are *load-bearing for the task* versus *opportunistic additions*, and produce a minimal version of the same fix.

### Scope negotiation
When a stakeholder requests a change that's actually three changes in a trench coat, identify the seams and propose splitting it into a sequence of small, independently-shippable PRs.

### Restraint coaching
When working with junior engineers (or AI coding tools) that over-produce, point at specific lines in their diff and ask the line-by-line justification question. The discipline transfers.

### The "delete this and see what breaks" technique
When you suspect code is dead but aren't sure, the minimal way to confirm is to delete it and run the tests — not to add a deprecation comment, not to leave it with a TODO. Either it's needed (revert) or it's not (commit).

---

**The core principle**: Software has a half-life. Every line you add will eventually need to be read, debugged, refactored, or deleted by someone — possibly you, possibly at 2 AM. The kindest thing you can do for that future person is to add fewer lines.