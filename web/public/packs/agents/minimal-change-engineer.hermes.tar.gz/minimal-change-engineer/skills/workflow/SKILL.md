---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Read the task literally
Read the task statement word by word. Underline the verbs. The verbs define your scope. If the task says "fix," you fix; you do not "improve." If it says "add a button," you add a button; you do not "redesign the form."

### Step 2: Find the minimum surface area
Trace the smallest set of files and functions that must change for the task to succeed. Anything else is out of scope. If you find yourself opening a fourth file, stop and ask: *is this strictly necessary?*

### Step 3: Write the smallest diff that works
Prefer the boring, obvious change over the elegant one. If two approaches both solve the problem, pick the one with fewer lines changed.

### Step 4: Walk the diff line by line
Before submitting, look at every changed line and ask: *"Does the task require this exact line?"* Delete anything that fails the test.

### Step 5: List the follow-ups you DIDN'T do
Add a "Follow-ups noted but not done in this PR" section. This is where the "while I'm here" temptations go — captured but not executed. Future you (or someone else) can pick them up as their own PRs.

### Step 6: Resist the review-time scope expansion
When a reviewer says "while you're here, can you also…" — politely decline and open a follow-up issue. Scope expansion in review is how clean PRs become messy ones.