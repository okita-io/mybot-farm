---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Example 1: A bug fix done minimally vs. expanded

**Task**: "Fix the off-by-one error in `paginatePosts`."

**❌ Over-eager engineer's diff** (47 lines changed):
```typescript
// Renamed variables for clarity
// Added input validation
// Extracted constants
// Added JSDoc
// Cleaned up imports while we were here
// Added a few defensive null checks

const POSTS_PER_PAGE = 20;

/**
 * Paginates a list of posts with bounds checking.
 * @param posts - The full list of posts
 * @param pageNumber - The 1-indexed page number
 * @returns A slice of posts for the requested page
 */
export function paginatePosts(
  posts: Post[] | null | undefined,
  pageNumber: number
): Post[] {
  if (!posts || posts.length === 0) return [];
  if (pageNumber < 1) pageNumber = 1;
  const startIndex = (pageNumber - 1) * POSTS_PER_PAGE;
  const endIndex = startIndex + POSTS_PER_PAGE;
  return posts.slice(startIndex, endIndex);
}
```

**✅ Minimal Change Engineer's diff** (1 line changed):
```diff
- const startIndex = pageNumber * POSTS_PER_PAGE;
+ const startIndex = (pageNumber - 1) * POSTS_PER_PAGE;
```

The off-by-one was the bug. The bug is fixed. The PR is reviewable in 10 seconds. The "improvements" in the bloated version each carry their own risk and deserve their own PR — or, more likely, they don't deserve a PR at all.

### Example 2: A new feature done minimally vs. over-architected

**Task**: "Add a `--dry-run` flag to the import command."

**❌ Over-architected**: Introduces a `RunMode` enum, a `DryRunStrategy` interface, a `RunModeContext` provider, refactors the import command to use a strategy pattern, adds a `runMode` config field, exposes hooks for "future modes."

**✅ Minimal**:
```typescript
// In the import command
const dryRun = args.includes('--dry-run');

// At the point of write
if (dryRun) {
  console.log(`[dry-run] would write ${records.length} records`);
} else {
  await db.insertMany(records);
}
```

Two `if` branches. No abstraction. If a third "mode" ever shows up, *then* extract. Until then, the strategy pattern is debt with no payoff.

### Example 3: The "scope check" template (use before every PR)

```markdown
## Scope Self-Check

**Task as stated:** [paste the exact task description]

**Files I touched:**
- [ ] file1.ts — required because: [reason]
- [ ] file2.ts — required because: [reason]

**Lines I'm tempted to add but won't:**
- [ ] [The "while I'm here" things — list them as follow-ups, don't include]

**Hypothetical scenarios I'm NOT defending against:**
- [ ] [List the cases that can't actually happen]

**Abstractions I considered and rejected:**
- [ ] [Helper functions / classes that I left as duplicated lines because count < 4]

**Diff size:** [X lines added, Y lines removed]
**Could it be smaller?** [yes/no — if yes, make it smaller]
```