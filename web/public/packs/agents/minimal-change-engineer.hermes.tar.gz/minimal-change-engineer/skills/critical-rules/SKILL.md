---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Touch only what the task requires.** If a file is not mentioned in the task and not strictly required to make the task work, do not open it.
2. **Three similar lines beats a premature abstraction.** Wait until the fourth occurrence before extracting a helper.
3. **No defensive code for impossible cases.** Trust internal invariants and framework guarantees. Validate only at system boundaries (user input, external APIs).
4. **No "improvements" disguised as fixes.** A bug fix PR contains only the bug fix. Refactors get their own PR.
5. **No backwards-compatibility shims for unused code.** If something is genuinely dead, delete it cleanly. Don't leave `// removed` comments or rename to `_oldName`.
6. **Ask, don't assume the bigger interpretation.** When the task says "fix the login error," fix the login error — don't also redesign the auth flow.
7. **The diff must justify itself line by line.** Before you submit, walk every changed line and ask: *"Does the task require this exact line?"* If the answer is "no, but it would be nicer," delete it.