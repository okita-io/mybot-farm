---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

Feishu App Project Structure

```
feishu-integration/
├── src/
│   ├── config/
│   │   ├── feishu.ts              # Feishu app configuration
│   │   └── env.ts                 # Environment variable management
│   ├── auth/
│   │   ├── token-manager.ts       # Token retrieval and caching
│   │   └── event-verify.ts        # Event subscription verification
│   ├── bot/
│   │   ├── command-handler.ts     # Bot command handler
│   │   ├── message-sender.ts      # Message sending wrapper
│   │   └── card-builder.ts        # Message card builder
│   ├── approval/
│   │   ├── approval-define.ts     # Approval definition management
│   │   ├── approval-instance.ts   # Approval instance operations
│   │   └── approval-callback.ts   # Approval event callbacks
│   ├── bitable/
│   │   ├── table-client.ts        # Bitable CRUD operations
│   │   └── sync-service.ts        # Data synchronization service
│   ├── sso/
│   │   ├── oauth-handler.ts       # OAuth authorization flow
│   │   └── user-sync.ts           # User info synchronization
│   ├── webhook/
│   │   ├── event-dispatcher.ts    # Event dispatcher
│   │   └── handlers/              # Event handlers by type
│   └── utils/
│       ├── http-client.ts         # HTTP request wrapper
│       ├── logger.ts              # Logging utility
│       └── retry.ts               # Retry mechanism
├── tests/
├── docker-compose.yml
└── package.json
```

### Token Management & API Request Wrapper

```typescript
// src/auth/token-manager.ts
import * as lark from '@larksuiteoapi/node-sdk';

const client = new lark.Client({
  appId: process.env.FEISHU_APP_ID!,
  appSecret: process.env.FEISHU_APP_SECRET!,
  disableTokenCache: false, // SDK built-in caching
});

export { client };

// Manual token management scenario (when not using the SDK)
class TokenManager {
  private token: string = '';
  private expireAt: number = 0;

  async getTenantAccessToken(): Promise<string> {
    if (this.token && Date.now() < this.expireAt) {
      return this.token;
    }

    const resp = await fetch(
      'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          app_id: process.env.FEISHU_APP_ID,
          app_secret: process.env.FEISHU_APP_SECRET,
        }),
      }
    );

    const data = await resp.json();
    if (data.code !== 0) {
      throw new Error(`Failed to obtain [REDACTED]
    }

    this.[REDACTED]
    // Expire 5 minutes early to avoid boundary issues
# … truncated for farm planting — see upstream for the full sample
```

### Message Card Builder & Sender

```typescript
// src/bot/card-builder.ts
interface CardAction {
  tag: string;
  text: { tag: string; content: string };
  type: string;
  value: Record<string, string>;
}

// Build an approval notification card
function buildApprovalCard(params: {
  title: string;
  applicant: string;
  reason: string;
  amount: string;
  instanceId: string;
}): object {
  return {
    config: { wide_screen_mode: true },
    header: {
      title: { tag: 'plain_text', content: params.title },
      template: 'orange',
    },
    elements: [
      {
        tag: 'div',
        fields: [
          {
            is_short: true,
            text: { tag: 'lark_md', content: `**Applicant**\n${params.applicant}` },
          },
          {
            is_short: true,
            text: { tag: 'lark_md', content: `**Amount**\n¥${params.amount}` },
          },
        ],
      },
      {
        tag: 'div',
        text: { tag: 'lark_md', content: `**Reason**\n${params.reason}` },
      },
# … truncated for farm planting — see upstream for the full sample
```

### Event Subscription & Callback Handling

```typescript
// src/webhook/event-dispatcher.ts
import * as lark from '@larksuiteoapi/node-sdk';
import express from 'express';

const app = express();

const eventDispatcher = new lark.EventDispatcher({
  encryptKey: process.env.FEISHU_ENCRYPT_KEY || '',
  verificationToken: process.env.FEISHU_VERIFICATION_TOKEN || '',
});

// Listen for bot message received events
eventDispatcher.register({
  'im.message.receive_v1': async (data) => {
    const message = data.message;
    const chatId = message.chat_id;
    const content = JSON.parse(message.content);

    // Handle plain text messages
    if (message.message_type === 'text') {
      const text = content.text as string;…