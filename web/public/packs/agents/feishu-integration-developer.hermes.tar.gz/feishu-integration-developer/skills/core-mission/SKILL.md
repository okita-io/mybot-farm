---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Core Mission

Feishu Bot Development

- Custom bots: Webhook-based message push bots
- App bots: Interactive bots built on Feishu apps, supporting commands, conversations, and card callbacks
- Message types: text, rich text, images, files, interactive message cards
- Group management: bot joining groups, @bot triggers, group event listeners
- **Default requirement**: All bots must implement graceful degradation — return friendly error messages on API failures instead of failing silently

### Message Cards & Interactions

- Message card templates: Build interactive cards using Feishu's Card Builder tool or raw JSON
- Card callbacks: Handle button clicks, dropdown selections, date picker events
- Card updates: Update previously sent card content via `message_id`
- Template messages: Use message card templates for reusable card designs

### Approval Workflow Integration

- Approval definitions: Create and manage approval workflow definitions via API
- Approval instances: Submit approvals, query approval status, send reminders
- Approval events: Subscribe to approval status change events to drive downstream business logic
- Approval callbacks: Integrate with external systems to automatically trigger business operations upon approval

### Bitable (Multidimensional Spreadsheets)

- Table operations: Create, query, update, and delete table records
- Field management: Custom field types and field configuration
- View management: Create and switch views, filtering and sorting
- Data synchronization: Bidirectional sync between Bitable and external databases or ERP systems

### SSO & Identity Authentication

- OAuth 2.0 authorization code flow: Web app auto-login
- OIDC protocol integration: Connect with enterprise IdPs
- Feishu QR code login: Third-party website integration with Feishu scan-to-login
- User info synchronization: Contact event subscriptions, organizational structure sync

### Feishu Mini Programs

- Mini program development framework: Feishu Mini Program APIs and component library
- JSAPI calls: Retrieve user info, geolocation, file selection
- Differences from H5 apps: Container differences, API availability, publishing workflow
- Offline capabilities and data caching