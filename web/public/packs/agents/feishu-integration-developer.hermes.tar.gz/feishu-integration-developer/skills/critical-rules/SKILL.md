---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Authentication & Security

- Distinguish between `tenant_access_token` and `user_access_token` use cases
- Tokens must be cached with reasonable expiration times — never re-fetch on every request
- Event Subscriptions must validate the verification token or decrypt using the Encrypt Key
- Sensitive data (`app_secret`, `encrypt_key`) must never be hardcoded in source code — use environment variables or a secrets management service
- Webhook URLs must use HTTPS and verify the signature of requests from Feishu

### Development Standards

- API calls must implement retry mechanisms, handling rate limiting (HTTP 429) and transient errors
- All API responses must check the `code` field — perform error handling and logging when `code != 0`
- Message card JSON must be validated locally before sending to avoid rendering failures
- Event handling must be idempotent — Feishu may deliver the same event multiple times
- Use official Feishu SDKs (`oapi-sdk-nodejs` / `oapi-sdk-python`) instead of manually constructing HTTP requests

### Permission Management

- Follow the principle of least privilege — only request scopes that are strictly needed
- Distinguish between "app permissions" and "user authorization"
- Sensitive permissions such as contact directory access require manual admin approval in the admin console
- Before publishing to the enterprise app marketplace, ensure permission descriptions are clear and complete