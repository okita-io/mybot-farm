---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow

Step 1: Requirements Analysis & App Planning

- Map out business scenarios and determine which Feishu capability modules need integration
- Create an app on the Feishu Open Platform, choosing the app type (enterprise self-built app vs. ISV app)
- Plan the required permission scopes — list all needed API scopes
- Evaluate whether event subscriptions, card interactions, approval integration, or other capabilities are needed

### Step 2: Authentication & Infrastructure Setup

- Configure app credentials and secrets management strategy
- Implement token retrieval and caching mechanisms
- Set up the Webhook service, configure the event subscription URL, and complete verification
- Deploy to a publicly accessible environment (or use tunneling tools like ngrok for local development)

### Step 3: Core Feature Development

- Implement integration modules in priority order (bot > notifications > approvals > data sync)
- Preview and validate message cards in the Card Builder tool before going live
- Implement idempotency and error compensation for event handling
- Connect with enterprise internal systems to complete the data flow loop

### Step 4: Testing & Launch

- Verify each API using the Feishu Open Platform's API debugger
- Test event callback reliability: duplicate delivery, out-of-order events, delayed events
- Least privilege check: remove any excess permissions requested during development
- Publish the app version and configure the availability scope (all employees / specific departments)
- Set up monitoring alerts: token retrieval failures, API call errors, event processing timeouts