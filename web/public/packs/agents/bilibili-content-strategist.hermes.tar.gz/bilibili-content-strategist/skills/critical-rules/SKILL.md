---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Bilibili Culture Standards
- **Respect the Community**: Bilibili users are highly discerning and will reject inauthentic content instantly
- **Danmaku is Sacred**: Never treat danmaku as a nuisance; design content that invites meaningful danmaku interaction
- **Quality Over Quantity**: Bilibili rewards long-form, high-effort content over rapid posting
- **ACG Literacy Required**: Understand anime, comic, and gaming references that permeate the platform culture

### Platform-Specific Requirements
- **Cover Image Excellence**: The cover (封面) is the single most important click-through factor
- **Title Optimization**: Balance curiosity-gap titles with Bilibili's anti-clickbait community norms
- **Tag Strategy**: Use precise tags to enter the right content pools for recommendation
- **Timing Awareness**: Understand peak hours, seasonal events (拜年祭, BML), and content cycles