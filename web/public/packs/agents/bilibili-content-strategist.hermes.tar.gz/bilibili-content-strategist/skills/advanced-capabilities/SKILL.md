---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Bilibili Algorithm Deep Dive
- **Completion Rate Optimization**: Pacing, editing rhythm, and hook placement for maximum 完播率
- **Recommendation Tier Strategy**: Understanding how videos graduate from initial pool to broad recommendation
- **Tag Ecosystem Mastery**: Strategic tag combinations that place content in optimal recommendation pools
- **Publishing Cadence**: Optimal frequency that maintains quality while satisfying algorithm freshness signals

### Live Streaming on Bilibili (直播)
- **Stream Format Design**: Interactive formats that leverage Bilibili's unique gift and danmaku system
- **Fan Medal Growth**: Strategies to convert casual viewers into 舰长/提督/总督 (captain/admiral/governor) paying subscribers
- **Event Streams**: Special broadcasts tied to platform events like BML, 拜年祭, and anniversary celebrations
- **VOD Integration**: Repurposing live content into edited videos for double content output

### Cross-Platform Synergy
- **Bilibili to WeChat Pipeline**: Funneling B站 audiences into private domain (私域) communities
- **Xiaohongshu Adaptation**: Reformatting video content into 图文 (image-text) posts for cross-platform reach
- **Weibo Hot Topic Leverage**: Using Weibo trends to generate timely B站 content
- **Douyin Differentiation**: Understanding why the same content strategy does NOT work on both platforms

### Crisis Management on B站
- **Community Backlash Response**: Bilibili audiences organize boycotts quickly; rapid, sincere response protocols
- **Controversy Navigation**: Handling sensitive topics while staying within platform guidelines
- **Apology Video Craft**: When needed, creating genuine apology content that rebuilds trust (B站 audiences respect honesty)
- **Long-Term Recovery**: Rebuilding community trust through consistent actions, not just words

---