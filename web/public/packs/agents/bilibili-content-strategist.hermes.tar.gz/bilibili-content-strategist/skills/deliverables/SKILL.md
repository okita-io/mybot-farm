---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Content Strategy Blueprint
```markdown
# [Brand/Channel] Bilibili Content Strategy

## 账号定位 (Account Positioning)
**Target Vertical**: [知识区/科技区/生活区/美食区/etc.]
**Content Personality**: [Defined voice and visual style]
**Core Value Proposition**: [Why users should follow]
**Differentiation**: [What makes this channel unique on B站]

## 内容规划 (Content Planning)
**Pillar Content** (40%): Deep-dive videos, 10-20 min, high production value
**Trending Content** (30%): Hot topic responses, meme integration, timely commentary
**Community Content** (20%): Q&A, fan interaction, behind-the-scenes
**Experimental Content** (10%): New formats, collaborations, live streams

## 数据目标 (Performance Targets)
**播放量 (Views)**: [Target per video tier]
**三连率 (Triple Combo Rate)**: [Coin + Favorite + Like target]
**弹幕密度 (Danmaku Density)**: [Target per minute of video]
**粉丝转化率 (Follow Conversion)**: [Views to follower ratio]
```

### Danmaku Engagement Design Template
```markdown
# Danmaku Interaction Design

## Trigger Points (弹幕触发点设计)
| Timestamp | Content Moment           | Expected Danmaku Response    |
|-----------|--------------------------|------------------------------|
| 0:03      | Signature opening line   | Community catchphrase echo   |
| 2:15      | Surprising fact reveal   | "??" and shock reactions     |
| 5:30      | Interactive question     | Audience answers in danmaku  |
| 8:00      | Callback to old video    | Veteran fan recognition      |
| END       | Closing ritual           | "下次一定" / farewell phrases |

## Danmaku Seeding Strategy
- Prepare 10-15 seed danmaku for the first hour after publishing
- Include timestamp-specific comments that guide interaction patterns
- Plant humorous callbacks to build inside jokes over time
```

### Cover Image and Title A/B Testing Framework
```markdown
# Video Packaging Optimization

## Cover Design Checklist
- [ ] High contrast, readable at mobile thumbnail size
- [ ] Face or expressive character visible (30% CTR boost)
- [ ] Text overlay: max 8 characters, bold font
- [ ] Color palette matches channel brand identity
- [ ] Passes the "scroll test" - stands out in a feed of 20 thumbnails

## Title Formula Templates
- 【Category】Curiosity Hook + Specific Detail + Emotional Anchor
- Example: 【硬核科普】为什么中国高铁能跑350km/h？答案让我震惊
- Example: 挑战！用100元在上海吃一整天，结果超出预期

## A/B Testing Protocol
- Test 2 covers per video using Bilibili's built-in A/B tool
- Measure CTR difference over first 48 hours
- Archive winning patterns in a cover style library
```