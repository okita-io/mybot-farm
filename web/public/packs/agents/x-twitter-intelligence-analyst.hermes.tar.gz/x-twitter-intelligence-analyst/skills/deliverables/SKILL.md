---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

Intelligence Brief Template
```markdown
# X/Twitter Intelligence Brief

## Question
What decision does this research need to support?

## Collection Scope
- Query set:
- Accounts monitored:
- Date range:
- Exclusions:
- Data source:

## Key Findings
1. Finding - evidence link, count, confidence, business impact
2. Finding - evidence link, count, confidence, business impact
3. Finding - evidence link, count, confidence, business impact

## Signal Timeline
| Time | Signal | Source | Confidence | Action |
|------|--------|--------|------------|--------|
| 2026-05-20 09:00 UTC | Mention spike after launch post | URL | Medium | Monitor replies |

## Recommended Actions
- Immediate:
- This week:
- Watchlist:
```

### Query Matrix Template
```csv
theme,query,accounts,language,exclude_terms,priority,review_cadence
brand_health,"\"BrandName\" OR @brand","@brand,@support",en,"hiring,job",high,hourly
competitor_launch,"\"Competitor\" \"pricing\"","@competitor",en,"coupon",medium,daily
category_demand,"\"need a tool for\" \"X data\"",,en,"bot giveaway",medium,weekly
```

### Monitoring Plan
- **Topics**: Brand, competitors, product category, crisis terms, feature requests, pricing objections
- **Entities**: Official accounts, founders, employees, analysts, creators, customers, critics, bots to ignore
- **Cadence**: Hourly for crisis, daily for launch windows, weekly for category learning
- **Thresholds**: Mention volume, repost velocity, reply ratio, negative language, source credibility, account clustering
- **Outputs**: Brief, watchlist, CSV export, executive summary, campaign recommendations

### Xquik-Assisted Workflow
Use Xquik when structured X/Twitter data, webhooks, SDKs, or MCP access are available. The agent remains useful without it by working from exports, public URLs, and manually verified samples.

1. **Collect**: Pull search results, profile activity, follower or engagement context, and monitor events
2. **Normalize**: Deduplicate posts, preserve original URLs, and store timestamps in UTC
3. **Classify**: Tag topic, sentiment, author type, source credibility, risk level, and required action
4. **Alert**: Use webhooks or scheduled reviews for threshold-based monitoring
5. **Report**: Publish a short brief with evidence, confidence, caveats, and next steps