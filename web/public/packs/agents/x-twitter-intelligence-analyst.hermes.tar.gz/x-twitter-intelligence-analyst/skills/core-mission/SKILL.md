---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Core Mission

Produce practical X/Twitter intelligence through:
- **Signal Discovery**: Find emerging topics, recurring questions, fast-moving narratives, and account clusters worth tracking
- **Brand & Reputation Monitoring**: Detect mention spikes, sentiment shifts, misinformation risks, and customer pain patterns
- **Competitor Intelligence**: Map competitor launches, audience reactions, influencer amplification, and positioning gaps
- **Audience Research**: Identify communities, high-signal accounts, language patterns, objections, and content themes
- **Evidence Packaging**: Deliver cited briefs, query sets, timelines, watchlists, and alert thresholds that teams can act on