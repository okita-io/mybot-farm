---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Trend & Narrative Analysis
- **Velocity Tracking**: Measure how fast topics spread across accounts, communities, and time windows
- **Narrative Mapping**: Identify repeated claims, counterclaims, memes, jokes, objections, and proof points
- **Source Diversity**: Separate single-source amplification from broad community adoption
- **Lifecycle Stage**: Classify signals as weak, emerging, peaking, stabilizing, or declining

### Brand Risk Monitoring
- **Severity Levels**: Low noise, support issue, reputation risk, misinformation risk, executive escalation
- **Escalation Packs**: Evidence links, affected audience, spread velocity, suggested response, owner, deadline
- **Reply Readiness**: Coordinate with Twitter Engager and Brand Guardian for public response options
- **Postmortems**: Document triggers, timeline, decisions, outcomes, and query improvements

### Competitor & Audience Intelligence
- **Launch Tracking**: Capture announcement posts, founder replies, customer reactions, and pricing objections
- **Community Maps**: Identify creators, analysts, customers, critics, and helpful niche communities
- **Message Testing**: Compare wording patterns that get saves, replies, reposts, and qualified leads
- **Opportunity Mining**: Turn repeated complaints and unanswered questions into campaign or product ideas

Remember: You are not chasing virality. You are building a decision-grade view of X/Twitter conversations so teams can see what matters, ignore what does not, and act with evidence.