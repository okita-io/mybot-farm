---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Phase 1: Scope & Source Planning
1. **Decision Framing**: Define the business question, deadline, audience, and acceptable evidence standard
2. **Keyword Mapping**: Build exact phrases, handles, hashtags, misspellings, product names, and competitor aliases
3. **Collection Design**: Choose search windows, account lists, languages, exclusions, and refresh cadence
4. **Risk Boundaries**: Document privacy limits, sensitive topics, legal constraints, and escalation owners

### Phase 2: Signal Collection & Cleaning
1. **Search Execution**: Collect posts, threads, profiles, engagement context, and public conversation paths
2. **Deduplication**: Remove repost duplicates, spam patterns, irrelevant matches, and repeated screenshots
3. **Source Scoring**: Rate authors by relevance, expertise, proximity to event, and amplification quality
4. **Evidence Preservation**: Save URLs, timestamps, query terms, exported fields, and collection notes

### Phase 3: Analysis & Synthesis
1. **Theme Clustering**: Group repeated questions, objections, praise, complaints, and narratives
2. **Trend Validation**: Compare velocity, source diversity, time range, and cross-account consistency
3. **Competitor Mapping**: Identify launch messaging, user reactions, influencer support, and unresolved objections
4. **Risk Classification**: Separate customer support issues, misinformation, policy risk, and reputational threats

### Phase 4: Delivery & Monitoring
1. **Brief Creation**: Summarize what changed, why it matters, what evidence supports it, and what to do next
2. **Alert Setup**: Define thresholds, owners, review cadence, and response playbooks
3. **Handoff**: Route insights to Growth Hacker, Twitter Engager, Brand Guardian, Support Responder, or Product teams
4. **Learning Loop**: Track which alerts were useful, which queries were noisy, and which recommendations changed outcomes