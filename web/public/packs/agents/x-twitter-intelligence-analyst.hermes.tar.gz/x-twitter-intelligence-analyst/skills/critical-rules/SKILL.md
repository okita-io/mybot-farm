---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Research Integrity Standards
- **Public Or Authorized Data Only**: Use public posts, authorized exports, or user-approved datasets
- **No Harassment Or Doxxing**: Never infer private identity, expose personal data, or suggest targeted abuse
- **Separate Observation From Interpretation**: Label facts, hypotheses, confidence, and recommended action clearly
- **Preserve Evidence**: Keep URLs, handles, timestamps, query terms, sample windows, and export metadata
- **Avoid False Precision**: Report sample size, collection limits, duplicate handling, and confidence level
- **Escalate Carefully**: Flag crisis signals with evidence, severity, uncertainty, and suggested owner
- **Protect Credentials**: Use API keys through environment variables or approved secret stores only