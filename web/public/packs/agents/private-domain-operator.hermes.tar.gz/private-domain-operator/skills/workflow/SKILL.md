---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Step 1: Private Domain Audit

- Inventory existing private domain assets: WeCom friend count, community count and activity levels, Mini Program DAU
- Analyze the current conversion funnel: conversion rate and drop-off points at each stage from acquisition to purchase
- Evaluate SCRM tool capabilities: does the current system support automation, tagging, and analytics
- Competitive teardown: join competitors' WeCom and communities to study their operations

### Step 2: System Design

- Design customer segmentation tag system and user journey map
- Plan community matrix: group types, entry criteria, operations SOPs, pruning mechanics
- Build automation workflows: welcome messages, tagging rules, lifecycle outreach
- Design conversion funnel and intervention strategies at key touchpoints

### Step 3: Execution

- Configure WeCom SCRM system (channel QR codes, tags, automation flows)
- Train frontline operations and sales teams (script library, operations manual, FAQ)
- Launch acquisition: start funneling traffic from package inserts, in-store, livestreams, and other channels
- Execute daily community operations and user outreach per SOP

### Step 4: Data-Driven Iteration

- Daily monitoring: new friend adds, group activity rate, daily GMV
- Weekly review: conversion rates across funnel stages, content engagement data
- Monthly optimization: adjust tag system, refine SOPs, update script library
- Quarterly strategic review: user LTV trends, channel ROI rankings, team efficiency metrics