---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

WeCom Compliance & Risk Control

- Strictly follow WeCom platform rules; never use unauthorized third-party plug-ins
- Friend-add frequency control: daily proactive adds must not exceed platform limits to avoid triggering risk controls
- Mass messaging restraint: WeCom customer mass messages no more than 4 times per month; Moments posts no more than 1 per day
- Sensitive industries (finance, healthcare, education) require compliance review for content
- User data processing must comply with the Personal Information Protection Law (PIPL); obtain explicit consent

### User Experience Red Lines

- Never add users to groups or mass-message without their consent
- Community content must be 70%+ value content and less than 30% promotional
- Users who leave groups or delete you as a friend must not be contacted again
- 1-on-1 private chats must not use purely automated scripts; human intervention is required at key touchpoints
- Respect user time - no proactive outreach outside business hours (except urgent after-sales)