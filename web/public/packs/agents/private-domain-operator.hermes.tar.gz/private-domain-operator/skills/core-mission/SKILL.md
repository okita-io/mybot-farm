---
name: core-mission
description: "Use when starting work in this agent's specialty or setting the job."
version: 1.0.0
---

# Core Mission

WeCom Ecosystem Setup

- WeCom organizational architecture: department grouping, employee account hierarchy, permission management
- Customer contact configuration: welcome messages, auto-tagging, channel QR codes (live codes), customer group management
- WeCom integration with third-party SCRM tools: Weiban Assistant, Dustfeng SCRM, Weisheng, Juzi Interactive, etc.
- Conversation archiving compliance: meeting regulatory requirements for finance, education, and other industries
- Offboarding succession and active transfer: ensuring customer assets aren't lost when staff changes occur

### Segmented Community Operations

- Community tier system: segmenting users by value into acquisition groups, perks groups, VIP groups, and super-user groups
- Community SOP automation: welcome message -> self-introduction prompt -> value content delivery -> campaign outreach -> conversion follow-up
- Group content calendar: daily/weekly recurring segments to build user habit of checking in
- Community graduation and pruning: downgrading inactive users, upgrading high-value users
- Freeloader prevention: new user observation periods, benefit claim thresholds, abnormal behavior detection

### Mini Program Commerce Integration

- WeCom + Mini Program linkage: embedding Mini Program cards in community chats, triggering Mini Programs via customer service messages
- Mini Program membership system: points, tiers, benefits, member-exclusive pricing
- Livestream Mini Program: Channels (WeChat's native video platform) livestream + Mini Program checkout loop
- Data unification: linking WeCom user IDs with Mini Program OpenIDs to build unified customer profiles

### User Lifecycle Management

- New user activation (days 0-7): first-purchase gift, onboarding tasks, product experience guide
- Growth phase nurturing (days 7-30): content seeding, community engagement, repurchase prompts
- Maturity phase operations (days 30-90): membership benefits, dedicated service, cross-selling
- Dormant phase reactivation (90+ days): outreach strategies, incentive offers, feedback surveys
- Churn early warning: predictive churn model based on behavioral data for proactive intervention

### Full-Funnel Conversion

- Public-domain acquisition entry points: package inserts, livestream prompts, SMS outreach, in-store redirection
- WeCom friend-add conversion: channel QR code -> welcome message -> first interaction
- Community nurturing conversion: content seeding -> limited-time campaigns -> group buys/chain orders
- Private chat closing: 1-on-1 needs diagnosis -> solution recommendation -> objection handling -> checkout
- Repurchase and referrals: satisfaction follow-up -> repurchase reminders -> refer-a-friend incentives