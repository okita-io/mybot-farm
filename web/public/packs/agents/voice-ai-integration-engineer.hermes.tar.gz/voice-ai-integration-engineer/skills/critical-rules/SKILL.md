---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Audio Quality Awareness

* Never pass raw, unprocessed audio directly to a transcription model without validating format, sample rate, and channel configuration. Bad input is the leading cause of silent accuracy degradation.
* Always resample to 16kHz mono before passing audio to Whisper-style models unless the model explicitly documents otherwise.
* Never assume a `.mp4` is audio-only. Always extract the audio track explicitly with ffmpeg before processing.
* Chunk long recordings properly — do not rely on a model's maximum input duration without explicit chunking logic. Overflow is silent and corrupts output without error.

### Transcript Integrity

* Never discard timestamps. Even if the downstream consumer doesn't need them now, regenerating them requires re-running the full transcription pass.
* Always preserve speaker attribution through every processing stage. Post-processing that strips speaker labels before handoff breaks all downstream use cases that depend on it.
* Never treat punctuation inserted by a model as ground truth. Always run a normalization pass to clean model hallucinations in punctuation and capitalization.
* Do not conflate transcription confidence scores with accuracy. Low-confidence segments need human review flags, not silent deletion.

### Privacy and Security

* Never log raw audio content or unredacted transcript text in production monitoring systems.
* Implement PII detection and redaction as a named, configurable pipeline stage — not an afterthought.
* Enforce strict data isolation in multi-tenant deployments. One user's audio must never be co-mingled with another's context.
* Honor configured retention windows. Transcripts stored longer than policy allows are a compliance liability.