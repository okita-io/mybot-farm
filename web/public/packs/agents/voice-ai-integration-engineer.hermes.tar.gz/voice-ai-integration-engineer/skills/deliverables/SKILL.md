---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Input Handling and Validation

* **Supported formats**: wav, mp3, m4a, ogg, flac, mp4, mov, webm — with explicit format detection, not extension-based guessing
* **File validation**: duration bounds, codec detection, sample rate, channel count, file size limits, corruption checks
* **ffmpeg preprocessing pipeline**: resample to 16kHz, downmix to mono, normalize loudness (EBU R128), strip video, trim silence, apply noise gate
* **Chunking strategy**: overlap-aware chunking for long audio (>30 minutes), with configurable overlap window to prevent word splits at chunk boundaries

### Transcription Architecture

* **Local Whisper-style models**: `openai/whisper`, `faster-whisper` (CTranslate2-optimized), `whisper.cpp` for CPU-only environments — model size selection (tiny through large-v3) based on latency/accuracy budget
* **Cloud ASR services**: OpenAI Whisper API, AssemblyAI, Deepgram, Rev AI, Google Cloud Speech-to-Text, AWS Transcribe — with vendor-specific configuration for accuracy, diarization, and language support
* **Tradeoff framework**: cost per audio hour, real-time factor, WER benchmarks by domain, privacy posture, diarization quality, language coverage
* **Hybrid routing**: local models for sensitive or offline content, cloud for high-volume batch or when accuracy is critical

### Post-Processing Pipeline

* **Punctuation and capitalization normalization**: rule-based cleanup + optional LLM normalization pass
* **Timestamp formatting**: word-level, segment-level, and scene-level timestamps for every output format
* **Subtitle generation**: SRT (SubRip), VTT (WebVTT), ASS/SSA — with configurable line length, gap handling, and reading speed validation
* **Speaker diarization**: integration with `pyannote.audio`, AssemblyAI speaker labels, Deepgram diarization — merge diarization results with transcription output to produce speaker-attributed segments
* **Structured extraction**: named entity recognition over transcript text, topic segmentation, action item extraction, keyword tagging

### Integration Targets

* **Python**: `faster-whisper` pipeline scripts, FastAPI transcription service, Celery async processing workers
* **Node.js**: Express transcript API, Bull/BullMQ queue-based audio processing, stream-based WebSocket transcription
* **REST APIs**: OpenAPI-documented endpoints for upload, status polling, transcript retrieval, webhook delivery
* **CMS ingestion**: Drupal media entity creation via REST/JSON:API, WordPress REST API transcript attachment, structured field mapping for custom content types
* **GitHub Actions**: CI workflow for automated transcription of audio assets, subtitle generation as a pipeline artifact, transcript diff validation
* **Agent handoff**: structured JSON output schema consumable by LangChain, CrewAI, and custom LLM pipelines for summarization, Q&A, and action item extraction