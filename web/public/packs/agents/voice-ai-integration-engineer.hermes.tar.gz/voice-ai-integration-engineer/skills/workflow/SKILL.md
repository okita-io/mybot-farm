---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Audio Ingestion and Validation

```python
import subprocess
import json
from pathlib import Path

SUPPORTED_EXTENSIONS = {".wav", ".mp3", ".m4a", ".ogg", ".flac", ".mp4", ".mov", ".webm"}
MAX_DURATION_SECONDS = 14400  # 4 hours

def validate_audio_file(file_path: str) -> dict:
    """
    Validate audio file before processing.
    Uses ffprobe to detect format, duration, codec, and channel layout.
    Never trust file extensions — always probe the actual container.
    """
    path = Path(file_path)
    if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"Unsupported extension: {path.suffix}")

    result = subprocess.run([
        "ffprobe", "-v", "quiet",
        "-print_format", "json",
        "-show_streams", "-show_format",
        str(path)
    ], capture_output=True, text=True, check=True)

    probe = json.loads(result.stdout)
    duration = float(probe["format"]["duration"])

    if duration > MAX_DURATION_SECONDS:
        raise ValueError(f"File exceeds max duration: {duration:.0f}s > {MAX_DURATION_SECONDS}s")

    audio_streams = [s for s in probe["streams"] if s["codec_type"] == "audio"]
    if not audio_streams:
        raise ValueError("No audio stream found in file")

    stream = audio_streams[0]
    return {
        "duration": duration,
        "codec": stream["codec_name"],
        "sample_rate": int(stream["sample_rate"]),
        "channels": stream["channels"],
# … truncated for farm planting — see upstream for the full sample
```

### Step 2: Audio Preprocessing with ffmpeg

```python
import subprocess
from pathlib import Path

def preprocess_audio(input_path: str, output_path: str) -> str:
    """
    Normalize audio for Whisper-style model input.

    Critical steps:
    - Resample to 16kHz (Whisper's native sample rate)
    - Downmix to mono (prevents channel-dependent accuracy variance)
    - Normalize loudness to EBU R128 standard
    - Strip video track if present (reduces file size, speeds processing)

    Returns path to preprocessed wav file.
    """
    cmd = [
        "ffmpeg", "-y",
        "-i", input_path,
        "-vn",                        # strip video
        "-acodec", "pcm_s16le",       # 16-bit PCM
        "-ar", "16000",               # 16kHz sample rate
        "-ac", "1",                   # mono
        "-af", "loudnorm=I=-16:TP=-1.5:LRA=11",  # EBU R128 loudness normalization
        output_path
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return output_path


def chunk_audio(input_path: str, chunk_dir: str,
                chunk_duration: int = 1800, overlap: int = 30) -> list[str]:
    """
    Split long audio into overlapping chunks for model processing.

    Uses overlap to prevent word truncation at chunk boundaries.
    Overlap segments are trimmed during transcript assembly.

    chunk_duration: seconds per chunk (default 30 min)
    overlap: overlap window in seconds (default 30s)
    """
# … truncated for farm planting — see upstream for the full sample
```

### Step 3: Transcription with faster-whisper

```python
from faster_whisper import WhisperModel
from dataclasses import dataclass

@dataclass
class TranscriptSegment:
    start: float
    end: float
    text: str
    speaker: str | None = None
    confidence: float | None = None

def transcribe_chunk(audio_path: str, model: WhisperModel,
                     language: str | None = None) -> list[TranscriptSegment]:
    """
    Transcribe a single audio chunk using faster-whisper.

    Returns segments with timestamps. Word-level timestamps enabled
    for subtitle generation accuracy.

    Model size guidance:
    - tiny/base: real-time local use, lower accuracy
    - small/medium: balanced accuracy/speed for most use cases
    - large-v3: highest accuracy, requires GPU, ~2-3x real-time on A10G
    """
    segments, info = model.transcribe(
        audio_path,
        language=language,
        word_timestamps=True,
        beam_size=5,
        vad_filter=True,           # voice activity detection — skip silence
        vad_parameters={"min_silence_duration_ms": 500}
    )

    result = []
    for seg in segments:
        result.append(TranscriptSegment(
            start=seg.start,
            end=seg.end,
            text=seg.text.strip(),
            confidence=getattr(seg, "avg_logprob", None)
# … truncated for farm planting — see upstream for the full sample
```

### Step 4: Speaker Diarization Integration

```python…