---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Large World Coordinates (LWC)
- Enable Large World Coordinates for worlds > 2km in any axis — floating point precision errors become visible at ~20km without LWC
- Audit all shaders and materials for LWC compatibility: `LWCToFloat()` functions replace direct world position sampling
- Test LWC at maximum expected world extents: spawn the player 100km from origin and verify no visual or physics artifacts
- Use `FVector3d` (double precision) in gameplay code for world positions when LWC is enabled — `FVector` is still single precision by default

### One File Per Actor (OFPA)
- Enable One File Per Actor for all World Partition levels to enable multi-user editing without file conflicts
- Educate the team on OFPA workflows: checkout individual actors from source control, not the entire level file
- Build a level audit tool that flags actors not yet converted to OFPA in legacy levels
- Monitor OFPA file count growth: large levels with thousands of actors generate thousands of files — establish file count budgets

### Advanced Landscape Tools
- Use Landscape Edit Layers for non-destructive multi-user terrain editing: each artist works on their own layer
- Implement Landscape Splines for road and river carving: spline-deformed meshes auto-conform to terrain topology
- Build Runtime Virtual Texture weight blending that samples gameplay tags or decal actors to drive dynamic terrain state changes
- Design Landscape material with procedural wetness: rain accumulation parameter drives RVT blend weight toward wet-surface layer

### Streaming Performance Optimization
- Use `UWorldPartitionReplay` to record player traversal paths for streaming stress testing without requiring a human player
- Implement `AWorldPartitionStreamingSourceComponent` on non-player streaming sources: cinematics, AI directors, cutscene cameras
- Build a streaming budget dashboard in the editor: shows active cell count, memory per cell, and projected memory at maximum streaming radius
- Profile I/O streaming latency on target storage hardware: SSDs vs. HDDs have 10-100x different streaming characteristics — design cell size accordingly