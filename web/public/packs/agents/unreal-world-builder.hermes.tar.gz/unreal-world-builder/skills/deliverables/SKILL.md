---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

World Partition Setup Reference
```markdown
## World Partition Configuration — [Project Name]

**World Size**: [X km × Y km]
**Target Platform**: [ ] PC  [ ] Console  [ ] Both

### Grid Configuration
| Grid Name         | Cell Size | Loading Range | Content Type        |
|-------------------|-----------|---------------|---------------------|
| MainGrid          | 128m      | 512m          | Terrain, props      |
| ActorGrid         | 64m       | 256m          | NPCs, gameplay actors|
| VFXGrid           | 32m       | 128m          | Particle emitters   |

### Data Layers
| Layer Name        | Type           | Contents                           |
|-------------------|----------------|------------------------------------|
| AlwaysLoaded      | Always Loaded  | Sky, audio manager, game systems   |
| HighDetail        | Runtime        | Loaded when setting = High         |
| PlayerCampData    | Runtime        | Quest-specific environment changes |

### Streaming Source
- Player Pawn: primary streaming source, 512m activation range
- Cinematic Camera: secondary source for cutscene area pre-loading
```

### Landscape Material Architecture
```
Landscape Master Material: M_Landscape_Master

Layer Stack (max 4 per blended region):
  Layer 0: Grass (base — always present, fills empty regions)
  Layer 1: Dirt/Path (replaces grass along worn paths)
  Layer 2: Rock (driven by slope angle — auto-blend > 35°)
  Layer 3: Snow (driven by height — above 800m world units)

Blending Method: Runtime Virtual Texture (RVT)
  RVT Resolution: 2048×2048 per 4096m² grid cell
  RVT Format: YCoCg compressed (saves memory vs. RGBA)

Auto-Slope Rock Blend:
  WorldAlignedBlend node:
    Input: Slope threshold = 0.6 (dot product of world up vs. surface normal)
    Above threshold: Rock layer at full strength
    Below threshold: Grass/Dirt gradient

Auto-Height Snow Blend:
  Absolute World Position Z > [SnowLine parameter] → Snow layer fade in
  Blend range: 200 units above SnowLine for smooth transition

Runtime Virtual Texture Output Volumes:
  Placed every 4096m² grid cell aligned to landscape components
  Virtual Texture Producer on Landscape: enabled
```

### HLOD Layer Configuration
```markdown
## HLOD Layer: [Level Name] — HLOD0

**Method**: Mesh Merge (fastest build, acceptable quality for > 500m)
**LOD Screen Size Threshold**: 0.01
**Draw Distance**: 50,000 cm (500m)
**Material Baking**: Enabled — 1024×1024 baked texture

**Included Actor Types**:
- All StaticMeshActor in zone
- Exclusion: Nanite-enabled meshes (Nanite handles its own LOD)
- Exclusion: Skeletal meshes (HLOD does not support skeletal)

**Build Settings**:
- Merge distance: 50cm (welds nearby geometry)
- Hard angle threshold: 80° (preserves sharp edges)
- Target triangle count: 5000 per HLOD mesh

**Rebuild Trigger**: Any geometry addition or removal in HLOD coverage area
**Visual Validation**: Required at 600m, 1000m, and 2000m camera distances before milestone
```

### PCG Forest Population Graph
```
PCG Graph: G_ForestPopulation

Step 1: Surface Sampler
  Input: World Partition Surface
  Point density: 0.5 per 10m²
  Normal filter: angle from up < 25° (no steep slopes)

Step 2: Attribute Filter — Biome Mask
  Sample biome density texture at world XY
  Density remap: biome mask value 0.0–1.0 → point keep probability

Step 3: Exclusion
  Road spline buffer: 8m — remove points within road corridor
  Path spline buffer: 4m
  Water body: 2m from shoreline
  Hand-placed structure: 15m sphere exclusion

Step 4: Poisson Disk Distribution
  Min separation: 3.0m — prevents unnatural clustering

Step 5: Randomization
  Rotation: random Yaw 0–360°, Pitch ±2°, Roll ±2°
  Scale: Uniform(0.85, 1.25) per axis independently

Step 6: Weighted Mesh Assignment
  40%: Oak_LOD0 (Nanite enabled)
  30%: Pine_LOD0 (Nanite enabled)
  20%: Birch_LOD0 (Nanite enabled)
  10%: DeadTree_LOD0 (non-Nanite — manual LOD chain)

Step 7: Culling
  Cull distance: 80,000 cm (Nanite meshes — Nanite handles geometry detail)
  Cull distance: 30,000 cm (non-Nanite dead trees)

Exposed Graph Parameters:
  - GlobalDensityMultiplier: 0.0–2.0 (designer tuning knob)
  - MinForestSeparation: 1.0–8.0m
  - RoadExclusionEnabled: bool
```

### Open-World Performance Profiling Checklist
```markdown
## Open-World Performance Review — [Build Version]

**Platform**: ___  **Target Frame Rate**: ___fps

Streaming
- [ ] No hitches > 16ms during normal traversal at 8m/s run speed…