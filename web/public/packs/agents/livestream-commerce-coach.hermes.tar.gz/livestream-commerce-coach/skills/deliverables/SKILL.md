---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Technical Deliverables

Livestream Script Template

```markdown
# Single-Product Walkthrough Script (5 minutes per product)

## Minute 1: Retention + Pain Point Setup
"Don't scroll away! This next product is today's showstopper - it sold out
instantly last time we featured it. Anyone here who's dealt with [pain point scenario]?
If that's you, type 1 in the chat!"
(Wait for engagement, read comments)
"I see so many of you with this exact problem. This product was made to solve it."

## Minutes 2-3: Product Introduction + Trust Building
"Take a look (show product) - this [product name] is made with [brand story/ingredients/craftsmanship].
The biggest difference between this and ordinary XXX is [key differentiator 1] and [key differentiator 2].
I've been using it for [duration], and honestly [personal experience]."
(Weave in demonstrations/trials/comparisons)
"It's not just me saying this - look (show sales figures/reviews/certifications)."

## Minute 4: Price Reveal + Urgency Close
"Retail/official store price is XXX yuan. But our livestream deal today -
hold on, don't look at the price yet! First, check out what's included: [gift 1], [gift 2], [gift 3].
The gifts alone are worth XX yuan.
Today in our livestream, it's only - XXX yuan! (pause)
And we only have [quantity] units! 3, 2, 1 - link is up!"

## Minute 5: Follow-Up + Transition
"If you already grabbed it, type 'got it' so I can see!
Still missed out? Let me ask the ops team to release XX more units.
(Read names of buyers) Congrats!
Alright, the next product is even bigger - anyone who's been asking about XXX, pay attention!"
```

### Qianchuan Campaign Strategy Template

```markdown
# Qianchuan Campaign Full-Process SOP

## Account Setup
- Maintain at least 3 ad accounts in rotation to avoid single-account spending bottlenecks
- Build 5-8 campaigns per account for simultaneous testing
- Campaign naming convention: date_audience_creative-type_bid, e.g., "0312_beauty-interest_talking-head-A_35"

## Targeting Strategy
| Phase | Targeting Method | Notes |
|-------|-----------------|-------|
| Cold start | System recommended + behavioral interest | Let the system explore; don't over-restrict |
| Scale-up | Creator lookalike + LaiKa targeting | Target users similar to competitor live rooms |
| Mature | Custom audience packs + DMP | Build lookalikes from your actual buyer profiles |

## Bidding Strategy
- CPA bidding (recommended for beginners): target ROI / AOV. E.g., AOV 100 yuan, target ROI 3, bid 33 yuan
- Deep conversion bidding: suitable for high-AOV, long-consideration categories
- Per-campaign budget = bid x 20 to give the system enough exploration room
- Don't touch new campaigns for the first 6 hours; let the system complete its learning phase

## Creative Strategy
- Talking-head creatives (most stable conversion): host on camera discussing pain points + value props
- Product showcase creatives (for visually impactful categories): unboxing / trials / before-after comparisons
- Compilation creatives (lowest cost): livestream highlight clips + subtitles + BGM
- Creative refresh cycle: swap underperforming creatives after 3 days; prepare iterations of winning creatives before they decay

## ROI Monitoring & Adjustments
- Check campaign data every 2 hours
- ROI > 120% of target: increase budget by 30%
- ROI between 80%-120% of target: hold steady
- ROI < 80% of target: reduce budget or kill campaign
- Any campaign spending over 500 yuan with zero conversions: kill immediately
```

### Live Room Data Review Dashboard

```markdown
# Livestream Daily Data Report Template

## Core Metrics
| Metric | Today | Yesterday | Change | Target |
|--------|-------|-----------|--------|--------|
| Stream duration | h | h | | 6h |
| Total viewers | | | | |
| Peak concurrent | | | | |
| Average concurrent | | | | |
| Avg watch time | s | s | | >60s |
| New followers | | | | |
| Engagement rate | % | % | | >5% |

## Sales Data
| Metric | Today | Yesterday | Change | Target |
|--------|-------|-----------|--------|--------|
| GMV | ¥ | ¥ | | |
| Orders | | | | |
| AOV | ¥ | ¥ | | |
| GPM (GMV per 1K views) | ¥ | ¥ | | >¥800 |
| UV value | ¥ | ¥ | | >¥1.5 |
| Payment conversion rate | % | % | | >3% |

## Traffic Breakdown
| Source | Share | Viewers | Conv. Rate | Notes |
|--------|-------|---------|------------|-------|
| Organic recommendations | % | | % | Recommendation feed |
| Short video referrals | % | | % | Teaser videos |
| Qianchuan paid | % | | % | Paid campaigns |…