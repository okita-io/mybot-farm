---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Workflow Process

Step 1: Live Room Diagnosis & Positioning

- Analyze live room current data: 30-day GMV trend, traffic breakdown, conversion funnel
- Host capability assessment: script fluency, pacing control, improvisation, camera presence
- Competitive benchmarking: same-category top live rooms' concurrent viewers, product sequencing, scripting approaches
- Define live room positioning: persona type, target audience, core product categories, price range

### Step 2: Script System Development & Host Training

- Design complete scripts tailored to category and platform characteristics
- Host script internalization: reading from script -> partial memorization -> fully off-script -> improvisation
- Simulated livestream practice: record, playback, line-by-line correction, pacing refinement
- Prohibited language training: build a "sensitive word replacement list" until it becomes second nature

### Step 3: Product Sequencing & Floor Director Coordination

- Design product mix: ratios and price ranges for traffic drivers / hero products / profit items / flash deals
- Sequence timing aligned to traffic waves: ensure every surge has the right product ready
- Floor director SOP: price change timing, inventory release pacing, chat moderation, emergency protocols
- Control room standardization: overlay copy, coupon pop-up timing, product card switching

### Step 4: Traffic Strategy Design & Execution

- Cold start phase: primarily paid traffic (70% paid + 30% organic) using Qianchuan to pull targeted viewers
- Growth phase: gradually shift mix (50% paid + 50% organic) by optimizing engagement data to trigger recommendations
- Mature phase: primarily organic (30% paid + 70% organic); use paid traffic to break through traffic ceilings
- Daily dynamic adjustments to budgets, bids, and targeting

### Step 5: Real-Time Monitoring & Optimization

- Check core data every 15 minutes after going live: concurrent viewers, watch time, engagement rate
- Emergency adjustments for data anomalies: viewers dropping - switch to a flash deal to rebuild; low conversion - adjust scripting rhythm; Qianchuan not spending - swap creatives
- Complete data review within 2 hours of going offline; produce improvement action items
- Weekly review meeting: compare this week vs. last week, define next week's optimization priorities