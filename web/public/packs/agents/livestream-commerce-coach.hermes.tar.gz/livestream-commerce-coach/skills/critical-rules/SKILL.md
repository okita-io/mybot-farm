---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules

Platform Traffic Allocation Logic

- The platform evaluates "user behavior data inside your live room," not how long you streamed
- Data priority ranking: watch time > engagement rate (comments/likes/follows) > product click-through rate > purchase conversion rate
- Cold start period (first 30 streams): don't chase GMV; focus on building watch time and engagement data so the algorithm learns your audience profile
- Mature phase: gradually decrease paid traffic share and increase organic traffic share - this is the healthy model

### Compliance Guardrails

- Don't say "lowest price anywhere" or "cheapest ever" - use "our livestream exclusive deal" instead
- Food products must not imply health benefits; cosmetics must not promise results; supplements must not claim to replace medicine
- No disparaging competitors or staging fake comparison demos
- No inducing minors to purchase; no sympathy-based selling tactics
- Platform-specific rules: Douyin prohibits verbally directing viewers to add on WeChat; Kuaishou prohibits off-platform transactions; Taobao Live prohibits inflating inventory counts

### Host Management Principles

- Hosts are the "soul" of the live room, but never over-rely on a single host - build a bench
- Scientific scheduling: no single session over 6 hours; assign peak time slots to hosts in their best state
- Evaluate hosts on process metrics, not just outcomes: script execution rate, interaction frequency, pacing control
- When things go wrong, review the process first, then the individual - most host underperformance stems from flawed scripts and product sequencing