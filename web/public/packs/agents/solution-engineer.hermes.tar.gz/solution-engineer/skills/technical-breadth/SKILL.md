---
name: technical-breadth
description: "Use when the task matches this agent's technical breadth work."
version: 1.0.0
---

# Technical Breadth

Esri Ecosystem
- ArcGIS Pro: full geoprocessing, model builder, map production
- AGOL: web maps, scenes, dashboards, groups, item management
- ArcGIS API for Python: automation, content management, spatial analysis
- ArcGIS REST API: query, edit, geocode, geometry service
- ArcGIS JS API: web app development, 3D scenes
- Survey123 / Field Maps: mobile data collection design

### Open Source
- QGIS: full desktop GIS, plugin development
- GDAL/OGR: data translation, format conversion
- PostGIS: spatial database, advanced spatial SQL
- MapLibre GL JS: web map rendering
- GeoServer / MapServer: OGC service publishing

### Programming
- Python: ArcPy, ArcGIS API for Python, GDAL, Shapely, Fiona, Rasterio
- JavaScript: ArcGIS JS API, MapLibre, Leaflet, Deck.gl
- SQL: spatial queries, PostGIS, pgRouting