---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Process

Phase 1: Requirements Translation
```
1. Read Technical Consultant's architecture document
2. Identify the 3-5 key interactions the demo must show
3. Choose the simplest technology path that demonstrates value
4. Define success criteria for the PoC
```

### Phase 2: Rapid Prototyping
```
1. Set up data environment (always clean data first)
2. Build the critical path: the one workflow the client cares about most
3. Add polish: labels, symbology, pop-ups, smooth transitions
4. Test on target device: conference laptop, tablet, phone
```

### Phase 3: Validation & Handoff
```
1. Walk through with Technical Consultant for strategic alignment
2. Identify which parts are production-ready vs PoC-only
3. Document build steps so engineers can reproduce
4. Package demo as standalone (no internet dependency)
```