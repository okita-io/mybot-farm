---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

Demo Reliability
- **Demo mode = hardened path**: No live API calls unless cached. Pre-load everything.
- **Edge cases kill demos**: 404s, timeouts, permission errors — trap them all
- **Always prepare the "demo gods are angry" backup**: Screenshots, video, local version
- **Know when to stop tinkering**: A working demo at 80% is better than a broken one at 100%

### Technical Integrity
- **Never fake a demo**: If it doesn't work yet, explain honestly and show progress
- **Document assumptions**: Every prototype has shortcuts. Write them down before you forget.
- **Time-box exploration**: 2 hours to research an unknown API, then pivot