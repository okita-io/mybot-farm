---
name: critical-rules
description: "Use when checking constraints, safety rules, or must-follow policies."
version: 1.0.0
---

# Critical Rules You Must Follow

1. **Profile before you change anything — never optimize on a hunch.** Capture a baseline with Lighthouse, the database query log, and a profiler (Webprofiler/XHProf) before touching code. An "optimization" with no before-and-after measurement is a guess, and guesses make sites slower as often as faster.
2. **Never disable a cache to fix a stale-content bug — fix the cacheability metadata.** A block showing old data is a cache *tags* problem, not a reason to set `max-age: 0` or turn off the Dynamic Page Cache. Disabling caches to fix invalidation trades one wrong render for a site-wide performance collapse.
3. **Every render array declares correct cache tags, contexts, and max-age.** Content that varies by user gets the right context (`user`, `user.roles`, `url`, etc.); content that depends on an entity carries that entity's cache tag so it invalidates on save. Missing metadata serves stale content; over-broad metadata destroys hit rates.
4. **`max-age: 0` is a last resort, scoped as tightly as possible — never applied to a whole page.** If something is truly uncacheable, isolate it behind a lazy builder/placeholder so BigPipe can stream it while the rest of the page stays cached. One uncacheable block must never make the entire page uncacheable.
5. **Never write raw, unsanitized SQL or unindexed queries against entity/field tables.** Use the Entity Query API and the Database API with placeholders; ensure `field_*` columns filtered or sorted on are indexed. A full table scan behind a homepage block is a latency and a security problem at once.
6. **Views are optimized and bounded — never render more than you display.** Set a pager or range, query only the fields you use, prefer rendered-entity caching or aggregated/count queries over loading full entities to count them, and cache Views output with correct tags. An unbounded View on a high-traffic page is a self-inflicted outage.
7. **Aggregate and optimize front-end assets without breaking them.** Enable CSS/JS aggregation, defer non-critical JS, and inline critical CSS where it pays off — but verify the page still renders and functions. Over-aggressive aggregation or bad defer order breaks layout and interactivity, which is worse than the bytes it saved.
8. **Every image is served through an image style with explicit dimensions and lazy loading.** Use responsive image styles and modern formats (WebP/AVIF), set width/height to prevent layout shift (CLS), and lazy-load below-the-fold media. Never output full-resolution originals or dimensionless images into a template.
9. **Caching must be verified live behind the CDN/reverse proxy, not just locally.** Confirm cache headers (`X-Drupal-Cache`, `X-Drupal-Dynamic-Cache`, `Cache-Control`, `Age`), confirm the CDN honors them, and confirm personalized/authenticated responses are never cached publicly. A cache that works in dev and leaks one user's session at the edge is a breach, not a speedup.
10. **Prove every change against Core Web Vitals on a real mobile device before calling it done.** LCP, INP, and CLS on a throttled mobile connection are the verdict — not desktop, not a fast office network. A change that improves a synthetic desktop score but regresses mobile field metrics has made the site slower for the people who actually visit it.

---