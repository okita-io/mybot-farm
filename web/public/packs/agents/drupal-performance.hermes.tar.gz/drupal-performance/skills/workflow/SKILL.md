---
name: workflow
description: "Use when running this agent's step-by-step process."
version: 1.0.0
---

# Your Workflow Process

Step 1: Measure & Establish the Baseline

1. **Run Lighthouse on key templates, on throttled mobile** — capture LCP, INP, CLS, and the perf score
2. **Enable the database query log / profiler** — capture the slowest queries and rows examined
3. **Inspect the caching posture** — Page Cache, Dynamic Page Cache, BigPipe status, and any `max-age: 0` offenders
4. **Check cache headers live** — `X-Drupal-Cache`, `X-Drupal-Dynamic-Cache`, `Cache-Control`, `Age` behind the CDN
5. **Record everything** — you can't prove an improvement you didn't baseline

### Step 2: Fix Cacheability First (Biggest Wins, Least Risk)

1. **Hunt down every `max-age: 0`** — find what made it uncacheable and fix the real cause
2. **Correct cache tags** — so renders invalidate on entity/config change instead of being disabled
3. **Correct cache contexts** — vary by the right dimension, no broader than necessary
4. **Isolate truly-dynamic content behind lazy builders** — let BigPipe stream it, keep the page cached
5. **Re-enable Internal and Dynamic Page Cache** — and verify HIT on repeat loads

### Step 3: Optimize the Database & Render Pipeline

1. **Attack the slowest queries** — index `field_*` columns, eliminate full scans
2. **Bound and trim every View** — pager/range, only needed fields, no loading entities to count them
3. **Kill N+1 patterns** — multi-load instead of per-row loads
4. **Cache rendered output with correct tags** — Views, blocks, and expensive controllers
5. **Re-measure each query** — before/after milliseconds, proven not assumed

### Step 4: Trim the Front End

1. **Enable CSS/JS aggregation and verify nothing broke** — render and interactivity intact
2. **Defer non-critical assets** — JS deferred, non-critical CSS async, critical CSS inlined where it pays
3. **Fix every image** — responsive styles, WebP/AVIF, explicit dimensions, lazy below the fold
4. **Prioritize the LCP element** — preload it, never lazy-load it
5. **Re-run Lighthouse on mobile** — confirm LCP/CLS moved the right way

### Step 5: Tune Infrastructure, Verify & Hand Off

1. **Tune opcache and PHP-FPM** — sized to the codebase and the box, slow log on
2. **Put Redis/Memcache in front of the cache bins** — offload render and dynamic page cache
3. **Verify CDN behavior** — headers honored, personalized responses never cached publicly
4. **Re-baseline against Step 1 numbers** — every metric, before vs. after, on mobile
5. **Document what changed and why** — so the next person doesn't "fix" it by disabling a cache

---