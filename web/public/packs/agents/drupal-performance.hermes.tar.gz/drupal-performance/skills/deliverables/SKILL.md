---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Performance Audit Baseline

```
DRUPAL PERFORMANCE AUDIT BASELINE
───────────────────────────────────────
ENVIRONMENT
  Drupal version:       [10.x / 11.x]
  PHP version:          [8.x — opcache on? JIT?]
  Cache backend:        [Database / Redis / Memcache]
  Reverse proxy / CDN:  [Varnish / Cloudflare / Fastly / none]

CACHING POSTURE
  Internal Page Cache:  [Enabled / Disabled — anon HTML cache]
  Dynamic Page Cache:   [Enabled / Disabled — auth-aware cache]
  BigPipe:              [Enabled / Disabled]
  max-age:0 offenders:  [Modules/blocks forcing no-cache — LIST]

CORE WEB VITALS (mobile, throttled — BASELINE)
  LCP:                  [__ s]   (target < 2.5s)
  INP:                  [__ ms]  (target < 200ms)
  CLS:                  [__ ]    (target < 0.1)
  Lighthouse perf:      [__ /100]

DATABASE
  Slowest queries:      [Top 5 by total time — source]
  Unindexed filters:    [field_* columns scanned]
  Worst Views:          [View — rows loaded vs. rows shown]

FRONT END
  CSS/JS aggregation:   [On / Off]
  Render-blocking:      [Count of blocking CSS/JS]
  Largest assets:       [Top images/scripts by weight]
  Images:               [Image styles used? Lazy load? WebP/AVIF?]
```

### Cacheability Metadata Specification

```
RENDER ARRAY CACHEABILITY CONTRACT
───────────────────────────────────────
RENDER TARGET:         [Block / field / controller response / View]

CACHE TAGS (invalidate WHEN the underlying data changes):
  Entity tags:         [node:123, taxonomy_term:45 — auto via entity render]
  List tags:           [node_list, node_list:article — for listings]
  Config tags:         [config:system.site, config:block.block.X]

CACHE CONTEXTS (vary the cache BY request dimension):
  [user / user.roles / user.permissions]
  [url / url.path / url.query_args:page]
  [route / theme / languages:language_interface]

MAX-AGE:
  [Cache::PERMANENT (default) — invalidate via tags, NOT time]
  [N seconds — only for genuinely time-bound data]
  [0 — LAST RESORT, isolated behind a lazy builder/placeholder]

UNCACHEABLE CONTENT ISOLATION:
  - Truly dynamic bit → #lazy_builder placeholder
  - BigPipe streams it; rest of page stays fully cached
  - One uncacheable element NEVER taints the whole page

VERIFICATION:
  □ Edit underlying entity → cached render updates (tags work)
  □ Switch user/role → correct variation served (contexts work)
  □ X-Drupal-Dynamic-Cache: HIT on repeat authenticated load
```

### Query & Views Optimization Plan

```
DATABASE OPTIMIZATION PLAN
───────────────────────────────────────
SLOW QUERY:            [Captured from DB log / Webprofiler]
  Source:              [Which View / entity query / module]
  Current cost:        [__ ms, __ rows examined]
  Cause:               [Unindexed column / full scan / N+1 / unbounded]

FIX:
  □ Add index on filtered/sorted field_* column
  □ Bound the result set (pager / range — never unbounded)
  □ Query only needed fields (no SELECT-everything entity loads)
  □ Use aggregated/count query instead of loading full entities
  □ Eliminate N+1 (load entities in one multi-load, not per-row)
  □ Cache the rendered output with correct tags

VIEWS-SPECIFIC:
  Rows loaded vs shown: [e.g., 5000 loaded → 10 displayed = FIX]
  Render strategy:      [Rendered entity cache / fields / raw]
  Caching:              [Tag-based output cache enabled]

VERIFICATION:
  Before:  [__ ms]   After:  [__ ms]   (measured, not assumed)
```

### Front-End & Image Optimization Spec

```
FRONT-END DELIVERY OPTIMIZATION
───────────────────────────────────────
ASSET AGGREGATION:
  CSS aggregation:     [Enabled — combined + minified]
  JS aggregation:      [Enabled — combined + minified]
  Critical CSS:        [Inlined for above-the-fold? Y/N]
  JS loading:          [defer / async on non-critical — verified working]

RENDER-BLOCKING REDUCTION:
  □ Non-critical CSS deferred/loaded async
  □ Non-critical JS deferred
  □ Fonts: font-display: swap + preload key font
  □ Third-party scripts audited (analytics/tag managers gated)

IMAGES (every image, no exceptions):
  Delivery:            [Responsive image style — srcset/sizes]
  Format:              [WebP / AVIF with fallback]
  Dimensions:          [Explicit width/height — prevents CLS]
  Loading:             [loading="lazy" below the fold; eager for LCP image]
  LCP image:           [Preloaded, NOT lazy-loaded]

VERIFICATION (mobile, throttled):
  □ Page renders + functions after aggregation (nothing broke)…