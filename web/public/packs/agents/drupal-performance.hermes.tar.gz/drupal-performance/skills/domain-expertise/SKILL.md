---
name: domain-expertise
description: "Use when you need domain-specific patterns for this specialty."
version: 1.0.0
---

# Domain Expertise

Drupal Caching System

- **Cache API**: cache bins, `CacheBackendInterface`, `Cache::PERMANENT`, and tag-based invalidation
- **Render Caching**: `#cache` metadata (`tags`, `contexts`, `max-age`, `keys`), auto-placeholdering, and lazy builders
- **Page-Level Caches**: Internal Page Cache (anonymous) and Dynamic Page Cache (auth-aware), and how they layer
- **BigPipe**: streaming personalized placeholders after the cached page shell, and what belongs in a lazy builder
- **Cache Tags & Contexts**: entity/list/config tags, the standard context hierarchy, and bubbling through the render tree
- **External Caching**: cache header emission, `Cache-Control`/`Surrogate-Control`, and CDN/reverse-proxy integration

### Database & Query Optimization

- **Entity Query & Database APIs**: parameterized queries, `EntityQuery`, multi-loads, and avoiding N+1
- **Indexing**: indexing `field_*` value columns used in filters/sorts, and reading `EXPLAIN`
- **Views Performance**: query pruning, pagers/ranges, rendered-entity vs. field rendering, aggregation, and output caching
- **Profiling**: Webprofiler, XHProf/Tideways, the slow query log, and `dblog`/watchdog overhead

### Front-End Performance

- **Asset Pipeline**: Drupal libraries, CSS/JS aggregation, `defer`/`async`, and critical-CSS strategies
- **Core Web Vitals**: LCP (largest paint), INP (interactivity), CLS (layout stability) — causes and fixes in a Drupal theme
- **Responsive Images**: responsive image styles, `srcset`/`sizes`, image style derivatives, and WebP/AVIF
- **Lazy Loading & Fonts**: native lazy loading, LCP-image prioritization, `font-display`, and font preloading

### Infrastructure & Tooling

- **PHP Runtime**: opcache sizing, `validate_timestamps`, JIT evaluation, and PHP-FPM pool tuning
- **Cache Backends**: Redis/Memcache fronting Drupal cache bins, and cache stampede avoidance
- **Reverse Proxy / CDN**: Varnish, Cloudflare, Fastly — header honoring and authenticated-response safety
- **Measurement Tooling**: Lighthouse/PageSpeed Insights, WebPageTest, field (CrUX) vs. lab data, and Drupal's Performance/Devel modules

---