---
name: deliverables
description: "Use when producing templates, examples, or technical artifacts."
version: 1.0.0
---

# Your Technical Deliverables

Dissolve Shader Graph Layout
```
Blackboard Parameters:
  [Texture2D] Base Map        — Albedo texture
  [Texture2D] Dissolve Map    — Noise texture driving dissolve
  [Float]     Dissolve Amount — Range(0,1), artist-driven
  [Float]     Edge Width      — Range(0,0.2)
  [Color]     Edge Color      — HDR enabled for emissive edge

Node Graph Structure:
  [Sample Texture 2D: DissolveMap] → [R channel] → [Subtract: DissolveAmount]
  → [Step: 0] → [Clip]  (drives Alpha Clip Threshold)

  [Subtract: DissolveAmount + EdgeWidth] → [Step] → [Multiply: EdgeColor]
  → [Add to Emission output]

Sub-Graph: "DissolveCore" encapsulates above for reuse across character materials
```

### Custom URP Renderer Feature — Outline Pass
```csharp
// OutlineRendererFeature.cs
public class OutlineRendererFeature : ScriptableRendererFeature
{
    [System.Serializable]
    public class OutlineSettings
    {
        public Material outlineMaterial;
        public RenderPassEvent renderPassEvent = RenderPassEvent.AfterRenderingOpaques;
    }

    public OutlineSettings settings = new OutlineSettings();
    private OutlineRenderPass _outlinePass;

    public override void Create()
    {
        _outlinePass = new OutlineRenderPass(settings);
    }

    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        renderer.EnqueuePass(_outlinePass);
    }
}

public class OutlineRenderPass : ScriptableRenderPass
{
    private OutlineRendererFeature.OutlineSettings _settings;
    private RTHandle _outlineTexture;

    public OutlineRenderPass(OutlineRendererFeature.OutlineSettings settings)
    {
        _settings = settings;
        renderPassEvent = settings.renderPassEvent;
    }

    public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
    {
        var cmd = CommandBufferPool.Get("Outline Pass");
        // Blit with outline material — samples depth and normals for edge detection
        Blitter.BlitCameraTexture(cmd, renderingData.cameraData.renderer.cameraColorTargetHandle,
# … truncated for farm planting — see upstream for the full sample
```

### Optimized HLSL — URP Lit Custom
```hlsl
// CustomLit.hlsl — URP-compatible physically based shader
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"

TEXTURE2D(_BaseMap);    SAMPLER(sampler_BaseMap);
TEXTURE2D(_NormalMap);  SAMPLER(sampler_NormalMap);
TEXTURE2D(_ORM);        SAMPLER(sampler_ORM);

CBUFFER_START(UnityPerMaterial)
    float4 _BaseMap_ST;
    float4 _BaseColor;
    float _Smoothness;
CBUFFER_END

struct Attributes { float4 positionOS : POSITION; float2 uv : TEXCOORD0; float3 normalOS : NORMAL; float4 tangentOS : TANGENT; };
struct Varyings  { float4 positionHCS : SV_POSITION; float2 uv : TEXCOORD0; float3 normalWS : TEXCOORD1; float3 positionWS : TEXCOORD2; };

Varyings Vert(Attributes IN)
{
    Varyings OUT;
    OUT.positionHCS = TransformObjectToHClip(IN.positionOS.xyz);
    OUT.positionWS  = TransformObjectToWorld(IN.positionOS.xyz);
    OUT.normalWS    = TransformObjectToWorldNormal(IN.normalOS);
    OUT.uv          = TRANSFORM_TEX(IN.uv, _BaseMap);
    return OUT;
}

half4 Frag(Varyings IN) : SV_Target
{
    half4 albedo = SAMPLE_TEXTURE2D(_BaseMap, sampler_BaseMap, IN.uv) * _BaseColor;
    half3 orm    = SAMPLE_TEXTURE2D(_ORM, sampler_ORM, IN.uv).rgb;

    InputData inputData;
    inputData.normalWS    = normalize(IN.normalWS);
    inputData.positionWS  = IN.positionWS;
    inputData.viewDirectionWS = GetWorldSpaceNormalizeViewDir(IN.positionWS);
    inputData.shadowCoord = TransformWorldToShadowCoord(IN.positionWS);

    SurfaceData surfaceData;
    surfaceData.albedo      = albedo.rgb;
# … truncated for farm planting — see upstream for the full sample
```

### Shader Complexity Audit
```markdown
## Shader Review: [Shader Name]

**Pipeline**: [ ] URP  [ ] HDRP  [ ] Built-in
**Target Platform**: [ ] PC  [ ] Console  [ ] Mobile

Texture Samples
- Fragment texture samples: ___ (mobile limit: 8 for opaque, 4 for transparent)

ALU Instructions
- Estimated ALU (from Shader Graph stats or compiled inspection): ___
- Mobile budget: ≤ 60 opaque / ≤ 40 transparent

Render State
- Blend Mode: [ ] Opaque  [ ] Alpha Clip  [ ] Alpha Blend
- Depth Write: [ ] On  [ ] Off
- Two-Sided: [ ] Yes (adds overdraw risk)

Sub-Graphs Used: ___…