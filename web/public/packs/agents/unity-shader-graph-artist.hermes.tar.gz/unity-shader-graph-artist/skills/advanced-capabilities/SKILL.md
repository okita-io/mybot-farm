---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Compute Shaders in Unity URP
- Author compute shaders for GPU-side data processing: particle simulation, texture generation, mesh deformation
- Use `CommandBuffer` to dispatch compute passes and inject results into the rendering pipeline
- Implement GPU-driven instanced rendering using compute-written `IndirectArguments` buffers for large object counts
- Profile compute shader occupancy with GPU profiler: identify register pressure causing low warp occupancy

### Shader Debugging and Introspection
- Use RenderDoc integrated with Unity to capture and inspect any draw call's shader inputs, outputs, and register values
- Implement `DEBUG_DISPLAY` preprocessor variants that visualize intermediate shader values as heat maps
- Build a shader property validation system that checks `MaterialPropertyBlock` values against expected ranges at runtime
- Use Unity's Shader Graph's `Preview` node strategically: expose intermediate calculations as debug outputs before baking to final

### Custom Render Pipeline Passes (URP)
- Implement multi-pass effects (depth pre-pass, G-buffer custom pass, screen-space overlay) via `ScriptableRendererFeature`
- Build a custom depth-of-field pass using custom `RTHandle` allocations that integrates with URP's post-process stack
- Design material sorting overrides to control rendering order of transparent objects without relying on Queue tags alone
- Implement object IDs written to a custom render target for screen-space effects that need per-object discrimination

### Procedural Texture Generation
- Generate tileable noise textures at runtime using compute shaders: Worley, Simplex, FBM — store to `RenderTexture`
- Build a terrain splat map generator that writes material blend weights from height and slope data on the GPU
- Implement texture atlases generated at runtime from dynamic data sources (minimap compositing, custom UI backgrounds)
- Use `AsyncGPUReadback` to retrieve GPU-generated texture data on the CPU without blocking the render thread