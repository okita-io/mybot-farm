---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

Event-Based Live Operations
- Design live events (limited-time content, seasonal updates) using `ReplicatedStorage` configuration objects swapped on server restart
- Build a countdown system that drives UI, world decorations, and unlockable content from a single server time source
- Implement soft launching: deploy new content to a percentage of servers using a `math.random()` seed check against a config flag
- Design event reward structures that create FOMO without being predatory: limited cosmetics with clear earn paths, not paywalls

### Advanced Roblox Analytics
- Build funnel analytics using `AnalyticsService:LogCustomEvent()`: track every step of onboarding, purchase flow, and retention triggers
- Implement session recording metadata: first-join timestamp, total playtime, last login — stored in DataStore for cohort analysis
- Design A/B testing infrastructure: assign players to buckets via `math.random()` seeded from UserId, log which bucket received which variant
- Export analytics events to an external backend via `HttpService:PostAsync()` for advanced BI tooling beyond Roblox's native dashboard

### Social and Community Systems
- Implement friend invites with rewards using `Players:GetFriendsAsync()` to verify friendship and grant referral bonuses
- Build group-gated content using `Players:GetRankInGroup()` for Roblox Group integration
- Design social proof systems: display real-time online player counts, recent player achievements, and leaderboard positions in the lobby
- Implement Roblox Voice Chat integration where appropriate: spatial voice for social/RP experiences using `VoiceChatService`

### Monetization Optimization
- Implement a soft currency first purchase funnel: give new players enough currency to make one small purchase to lower the first-buy barrier
- Design price anchoring: show a premium option next to the standard option — the standard appears affordable by comparison
- Build purchase abandonment recovery: if a player opens the shop but doesn't buy, show a reminder notification on next session
- A/B test price points using the analytics bucket system: measure conversion rate, ARPU, and LTV per price variant