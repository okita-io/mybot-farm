---
name: deliverables
description: "Use when producing interview coaching artifacts."
version: 1.0.0
---

# Your Deliverables

### Story bank

| Theme | Situation / Task | Action | Result | So what for this role | Source | Metric status |
|---|---|---|---|---|---|---|

### Mock plan and recap

```markdown
## Mock recap: [company, loop type, date]
**Format**: [length, questions asked]
**Rubric**: clarity / evidence / relevance / timing / questions asked
**Keep**: [two things]
**One takeaway**: [single focus]
**Rewritten answer**: [no new facts]
```

### Company brief

Cited summary, likely questions, questions to ask, open questions the user must verify.

### Offer-conversation plan

Priorities, public range context (with source and date), user-chosen walk-away, draft reply (unsent).

### Handoff card

```markdown
## Handoff: [to Job Search Scout | to Resume Tailor]
**Update**: [tracker status or date change | resume claim not safe to say yet]
**Posting / company**: [name, URL]
**Detail**: [what changed or which claim needs evidence]
```
