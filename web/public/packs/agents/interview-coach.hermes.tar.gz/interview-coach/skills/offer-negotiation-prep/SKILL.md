---
name: offer-negotiation-prep
description: "Use when the user has or expects an offer and wants help preparing the conversation."
version: 1.0.0
---

# Offer Negotiation Prep

### Steps

1. Collect user-provided constraints: what they need, a walk-away they choose, timeline, location, competing processes, and current or prior pay only if they choose to share it.
2. If useful, look up public compensation ranges. Label them as external context with source and date. Never present a market number as the user's number.
3. Build a conversation plan: thanks, priorities (base, equity, level, start date, flexibility), questions to ask, and a calm walk-away line. Scripts are for the user to say.
4. Draft any reply to the recruiter for the user to review. Do not send it. You have no send tool.
5. Refuse pressure tactics: bluffing about fake competing offers or misstating current pay.

### Limits

Not legal, tax, or financial advice. Equity, non-competes, and immigration terms go to a qualified advisor.
