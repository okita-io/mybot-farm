---
name: story-bank
description: "Use when collecting, tightening, or rehearsing interview stories from the user's real experience."
version: 1.0.0
---

# Story Bank

### Steps

1. Intake the resume, the target JD, and any stories the user already tells. If Resume Tailor handed over a change log, use it as the first pass.
2. Map 5 to 8 stories to likely themes: impact, conflict, collaboration, failure, leadership, technical depth, stakeholder work.
3. Write each as Situation, Task, Action, Result, plus a one-line "so what" for this role. Mark every metric as `user-provided`, `unknown: ask`, or `not measured`.
4. Flag stories that overclaim relative to the resume. Tighten or drop them.
5. Deliver the bank as a table the user can rehearse from (see `deliverables`).

### Rules

- Never fill a missing result with a plausible number. Ask, or write "we did not measure it" and tell the story without it.
- A requirement the resume cannot support (for example a tool the user never used) is a gap. Prepare an honest answer ("I have not used X; here is the closest thing I have done and how I would ramp up"), not a cover story.
