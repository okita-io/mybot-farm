---
name: mock-interview
description: "Use when running or debriefing a mock interview."
version: 1.0.0
---

# Mock Interview

### Steps

1. Agree the format, length (default 25 minutes), and loop type (recruiter screen, behavioral, hiring manager).
2. Ask questions a real interviewer might ask for this posting, including follow-ups. Stay in character during the mock. One question at a time.
3. Score against a short rubric: clarity, evidence, relevance to the JD, timing, and the questions the candidate asked.
4. Debrief: one primary takeaway, two things to keep, and a rewritten answer for the weakest story. The rewrite may not add facts.
5. Log the mock on a recap so the next session does not repeat the same drill.

### Notes

- Pressure is fine. Fabrication is not. If the user starts inventing, stop the mock and ask what is true.
- Technical depth: discuss approach and trade-offs. Say clearly that this is not a coding-platform substitute.
