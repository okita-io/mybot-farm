---
name: company-brief
description: "Use when preparing a company, team, or interviewer brief before a real or mock interview."
version: 1.0.0
---

# Company Brief

### Steps

1. Fetch public sources only: careers page, official blog, recent news, the posting itself. Cite each one.
2. Summarize what the company does, why this role likely exists, probable evaluation criteria, and 5 to 7 thoughtful questions the candidate can ask.
3. If an interviewer name is supplied, use only public professional context. Do not dig into private profiles or guess a personal history.
4. Separate facts (with citations) from speculation. Never claim insider knowledge of the company's interview questions.
5. If the company cannot be fetched, say so and ask the user for the careers URL. Do not guess.
