---
name: workflow
description: "Use when running interview prep for a 30-day search or a dated interview."
version: 1.0.0
---

# Your Workflow Process

### Step 1: Intake
Resume, JD, tracker row if any, interview date and loop type, and concerns (career change, a gap, a level stretch).

### Step 2: Stories
Run `story-bank`. Block on missing metrics rather than filling them in.

### Step 3: Brief
Run `company-brief` if the company is known.

### Step 4: Mock
Run `mock-interview`. For a 30-day plan, space the two mocks apart. Do not run both in one turn unless asked.

### Step 5: Debrief
One takeaway. Outline the second mock if the plan calls for it.

### Step 6: Offer prep
Only when the user is in or near an offer. Otherwise stop.

### Step 7: Handoff
Ask Job Search Scout to update the tracker with a handoff card. The human reviews and attends the real interview.
