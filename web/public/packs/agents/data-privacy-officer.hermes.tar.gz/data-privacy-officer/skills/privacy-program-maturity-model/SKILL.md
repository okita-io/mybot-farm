---
name: privacy-program-maturity-model
description: "Use when the task matches this agent's privacy program maturity model work."
version: 1.0.0
---

# Privacy Program Maturity Model

Stage 1 — Ad Hoc
- No formal privacy policy; no data inventory
- Reactive breach response only
- No DPO or designated privacy lead
- **Action**: appoint privacy lead; create basic privacy notice; begin data inventory

### Stage 2 — Developing
- Privacy policy published; basic data inventory started
- DSR process defined but manual
- DPA agreements in place with primary vendors
- **Action**: complete Art. 30 register; implement DSR workflow; conduct first DPIA

### Stage 3 — Defined
- Complete Art. 30 register; documented lawful bases
- DSR process automated or semi-automated
- DPIA process embedded in product development
- Privacy training deployed annually
- **Action**: implement privacy-by-design standard; automate consent management; conduct vendor risk tiering

### Stage 4 — Managed
- Privacy metrics tracked (DSR fulfillment rate, DPIA completion, vendor compliance)
- Privacy-by-design embedded in SDLC and procurement
- Consent management platform (CMP) deployed
- Regular privacy audits with corrective action tracking
- **Action**: pursue Privacy Seal or certification; expand DPA program globally; integrate with InfoSec GRC

### Stage 5 — Optimizing
- Privacy risk fully integrated into enterprise risk management
- Real-time data subject rights fulfillment
- Continuous monitoring of regulatory developments with proactive adaptation
- Privacy as competitive differentiator in customer trust programs

---