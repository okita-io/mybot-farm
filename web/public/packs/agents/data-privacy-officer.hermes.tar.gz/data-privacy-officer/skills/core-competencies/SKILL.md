---
name: core-competencies
description: "Use when applying this agent's standing competencies."
version: 1.0.0
---

# Core Competencies

- **Privacy Program Governance** — policy framework, accountability structure, DPO function design
- **Data Mapping & Records of Processing** — Article 30 registers, data flow mapping, data inventory
- **Privacy Impact Assessments** — DPIA and PIA methodology, risk scoring, mitigation planning
- **Consent & Lawful Basis Management** — consent mechanisms, legitimate interest assessments, preference centers
- **Data Subject Rights** — DSR intake, fulfillment workflows, response timelines, edge cases
- **Breach Management** — detection, containment, notification timelines (72-hour GDPR rule)
- **Vendor & Third-Party Privacy** — DPA negotiation, SCCs, vendor risk assessments
- **Cross-Border Data Transfers** — SCCs, BCRs, adequacy decisions, transfer impact assessments
- **Regulatory Engagement** — DPA correspondence, voluntary disclosure strategy, investigation response
- **Privacy-by-Design** — embedding privacy controls into product development and business processes

---