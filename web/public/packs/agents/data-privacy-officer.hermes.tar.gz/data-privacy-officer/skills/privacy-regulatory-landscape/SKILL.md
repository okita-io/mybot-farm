---
name: privacy-regulatory-landscape
description: "Use when the task matches this agent's privacy regulatory landscape work."
version: 1.0.0
---

# Privacy Regulatory Landscape

Key Regulations Reference

| Regulation | Jurisdiction | Scope | Key Obligations |
|---|---|---|---|
| GDPR | EU/EEA | Processing EU resident data | Lawful basis, DPO, 72hr breach notice, DPIA, DSRs |
| UK GDPR + DPA 2018 | United Kingdom | Processing UK resident data | Mirrors GDPR; ICO as supervisory authority |
| CCPA / CPRA | California, US | Businesses meeting thresholds | Right to know, delete, opt-out, correct; CPPA enforcement |
| VCDPA | Virginia, US | Controllers meeting thresholds | Consent for sensitive data; opt-out of targeted advertising |
| CPA | Colorado, US | Controllers meeting thresholds | Universal opt-out; data protection assessments |
| LGPD | Brazil | Processing Brazilian resident data | Similar to GDPR; ANPD as authority |
| PIPL | China | Processing Chinese citizen data | Data localization; cross-border transfer rules; consent |
| PDPA | Thailand/Singapore | Varies by country | Consent-based; DPO requirements vary |
| HIPAA | United States | PHI in healthcare | Covered entity / BA agreements; breach notification |
| COPPA | United States | Data of children under 13 | Verifiable parental consent; data minimization |

### GDPR Lawful Basis Quick Reference

| Lawful Basis | When to Use | Key Condition |
|---|---|---|
| Consent (Art. 6(1)(a)) | Marketing, non-essential cookies, optional features | Freely given, specific, informed, unambiguous; withdrawable |
| Contract (Art. 6(1)(b)) | Processing necessary to fulfill a contract with the data subject | Must be genuinely necessary, not convenient |
| Legal Obligation (Art. 6(1)(c)) | Compliance with EU/member state law | Specific legal obligation must exist |
| Vital Interests (Art. 6(1)(d)) | Life-or-death situations | Last resort; rarely applicable |
| Public Task (Art. 6(1)(e)) | Public authorities performing official functions | Not applicable to most private entities |
| Legitimate Interests (Art. 6(1)(f)) | Fraud prevention, IT security, direct marketing (with opt-out) | Must pass 3-part LIA test |

### Legitimate Interest Assessment (LIA) Template

**Part 1 — Purpose Test**
- What is the specific legitimate interest being pursued?
- Is it a genuine, real interest (not speculative)?
- Is it lawful?

**Part 2 — Necessity Test**
- Is processing necessary to achieve the purpose?
- Could the purpose be achieved with less or no personal data?
- Could the purpose be achieved through less intrusive means?

**Part 3 — Balancing Test**
| Factor | Assessment |
|---|---|
| Nature of data (sensitive?) | |
| Reasonable expectations of data subjects | |
| Likely impact on individuals | |
| Power imbalance between controller and data subject | |
| Are safeguards in place to limit impact? | |

**Outcome**: If legitimate interests override → document and proceed. If data subject interests prevail → select different lawful basis or redesign processing.

---