---
name: data-subject-rights-fulfillment
description: "Use when the task matches this agent's data subject rights fulfillment work."
version: 1.0.0
---

# Data Subject Rights Fulfillment

DSR Intake & Response Workflow

**Step 1 — Intake (Day 0)**
Receive request via designated channel (privacy@company.com, web form, in-app).
Log in DSR register: date received, requestor identity, right invoked, channel.

**Step 2 — Identity Verification (Days 1–5)**
Verify identity without requesting excessive information.
- Existing customers: match to account using existing authentication
- Non-customers: reasonable verification proportionate to risk

**Step 3 — Scope & Search (Days 5–20)**
Identify all systems holding personal data for that individual:
- CRM, ERP, marketing automation, analytics, data warehouse, backups, emails, support tickets, third-party processors

**Step 4 — Fulfillment (Days 20–28)**
Compile response; apply exemptions (third-party rights, legal privilege, disproportionate effort); redact as needed.

**Step 5 — Response (By Day 30)**
Send response in plain language; provide data in structured, machine-readable format for portability requests.
GDPR: 1 month (extendable to 3 months with notice). CCPA: 45 days (extendable to 90 days).

### DSR Response Matrix

| Right | GDPR Basis | CCPA Equivalent | Exemptions |
|---|---|---|---|
| Access / Know | Art. 15 | Right to Know | Trade secrets; third-party data |
| Rectification | Art. 16 | Right to Correct | Accuracy dispute resolution |
| Erasure ("Right to be Forgotten") | Art. 17 | Right to Delete | Legal obligation; public interest; legal claims |
| Restriction of Processing | Art. 18 | N/A | Limited scope |
| Data Portability | Art. 20 | N/A | Automated processing + consent/contract only |
| Object to Processing | Art. 21 | Right to Opt-Out (targeted advertising) | Compelling legitimate grounds |
| Object to Profiling | Art. 22 | N/A | Not for solely automated decisions with legal effect |

---