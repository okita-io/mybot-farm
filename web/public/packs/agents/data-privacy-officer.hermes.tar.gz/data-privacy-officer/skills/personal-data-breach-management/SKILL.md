---
name: personal-data-breach-management
description: "Use when the task matches this agent's personal data breach management work."
version: 1.0.0
---

# Personal Data Breach Management

Breach Response Protocol

**Hour 0–4 — Detection & Initial Assessment**
- Identify the breach: what data, how many records, what systems
- Contain immediately: isolate affected systems, revoke compromised credentials
- Notify DPO and CISO immediately
- Open incident ticket; preserve evidence (logs, screenshots)

**Hour 4–24 — Risk Assessment**
Assess:
1. Nature of the breach (confidentiality, integrity, availability)
2. Categories and approximate volume of records affected
3. Likely consequences for individuals (financial loss, discrimination, reputational harm, identity theft)
4. Measures taken to mitigate

**Hour 24–72 — Regulatory Notification Decision**
GDPR: Notify supervisory authority within 72 hours if breach is "likely to result in a risk to individuals' rights and freedoms."

**If notification required — DPA Notification Content:**
- Nature of the breach
- Categories and approximate number of data subjects
- Categories and approximate number of records
- DPO name and contact details
- Likely consequences
- Measures taken or proposed to address the breach

**72 Hours+ — Individual Notification**
Notify affected individuals "without undue delay" if breach is "likely to result in high risk" to individuals.
- Plain language; specific; actionable advice for individuals to protect themselves

### Breach Risk Scoring Matrix

| Factor | Low | Medium | High |
|---|---|---|---|
| Data type | Public / non-sensitive | Standard PII (name, email) | Special category / financial / health |
| Volume | <100 records | 100–10,000 | >10,000 |
| Recipient | Accidental internal disclosure | Unknown / unintended third party | Malicious actor / dark web |
| Mitigation | Data encrypted; access not possible | Partial mitigation | No mitigation; data accessible |
| Individual impact | Unlikely harm | Minor inconvenience | Significant harm likely |

All-Medium = Notify DPA. Any High = Notify DPA + individuals.

---