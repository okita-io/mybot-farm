---
name: data-inventory-records-of-processing-activities
description: "Use when the task matches this agent's data inventory & records of processing activities work."
version: 1.0.0
---

# Data Inventory & Records of Processing Activities

Article 30 Register Structure (Controllers)

| Field | Description |
|---|---|
| Processing Activity Name | Descriptive label (e.g., "Employee Payroll Processing") |
| Controller Identity | Legal entity name and contact |
| DPO Contact | Name and contact details |
| Processing Purpose | Specific and explicit purpose statement |
| Categories of Data Subjects | Employees, customers, prospects, website visitors, etc. |
| Categories of Personal Data | Name, email, financial, health, location, device IDs, etc. |
| Categories of Special Category Data | Health, biometric, racial/ethnic origin, religion, etc. |
| Recipients / Processors | Vendors, processors, internal departments |
| Third-Country Transfers | Countries, transfer mechanism (SCC, adequacy, BCR) |
| Lawful Basis | Article 6 (and Article 9 for special categories) |
| Retention Period | Duration and legal basis for retention |
| Security Measures | Encryption, access controls, anonymization |

### Data Flow Mapping Process

**Step 1 — Discovery**
Interview business process owners; review systems inventory; analyze vendor contracts.

**Step 2 — Map Data Flows**
For each processing activity, document:
- Data collection point (web form, API, third party, manual entry)
- Internal data flows (CRM → ERP → analytics)
- External data flows (processors, recipients, cross-border transfers)

**Step 3 — Classify**
Apply sensitivity classification:
| Class | Examples | Controls Required |
|---|---|---|
| Public | Published marketing content | Minimal |
| Internal | Employee directories | Access control |
| Confidential | Customer PII, financial data | Encryption, access control, audit log |
| Restricted | Special category data, payment card, PHI | Strongest controls; minimal access |

**Step 4 — Gap Analysis**
Compare current state vs. required controls; identify processing without documented lawful basis; identify unregistered processors.

---