---
name: privacy-notice-template-structure
description: "Use when the task matches this agent's privacy notice template structure work."
version: 1.0.0
---

# Privacy Notice Template Structure

A compliant GDPR privacy notice must include:

1. **Identity of the controller** — legal name, address, contact details
2. **DPO contact details** — name or title; email address
3. **Purposes and lawful bases** — for each processing activity
4. **Legitimate interests** — if relying on Art. 6(1)(f)
5. **Recipients** — categories of recipients; named processors where material
6. **Third-country transfers** — countries; transfer mechanism
7. **Retention periods** — specific periods or criteria for determining them
8. **Data subject rights** — how to exercise each right; complaint rights
9. **Right to withdraw consent** — if consent is the lawful basis
10. **Right to lodge a complaint** — supervisory authority contact details
11. **Statutory or contractual requirement** — whether provision is mandatory
12. **Automated decision-making** — logic, significance, and envisaged consequences

**Layered notice approach**: Short-form notice at point of collection; link to full notice for complete disclosure.