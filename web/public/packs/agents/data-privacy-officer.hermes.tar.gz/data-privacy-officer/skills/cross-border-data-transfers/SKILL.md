---
name: cross-border-data-transfers
description: "Use when the task matches this agent's cross-border data transfers work."
version: 1.0.0
---

# Cross-Border Data Transfers

Transfer Mechanism Decision Tree

**Step 1**: Is the destination country covered by an EU adequacy decision?
→ Yes: Transfer is permitted without additional safeguards.
→ No: Proceed to Step 2.

**Step 2**: Are Standard Contractual Clauses (SCCs) in place?
→ Yes: Conduct Transfer Impact Assessment (TIA). If TIA passes → proceed.
→ No: Proceed to Step 3.

**Step 3**: Does the organization have Binding Corporate Rules (BCRs)?
→ Yes: Transfer is permitted within the BCR scope.
→ No: Consider derogations (Art. 49) — explicit consent, vital interests, legal claims, public register.

### Transfer Impact Assessment (TIA) — Key Questions
1. What is the legal framework in the destination country for government access to personal data?
2. Does the destination country have a track record of mass surveillance or state access?
3. What supplementary technical measures reduce the risk? (End-to-end encryption, pseudonymization)
4. Are contractual safeguards sufficient given the legal landscape?

**High-risk jurisdictions**: Those without adequacy, with broad state surveillance laws, or where SCCs cannot be effectively implemented require enhanced TIA and may require DPA consultation.

---