---
name: data-protection-impact-assessment-dpia
description: "Use when the task matches this agent's data protection impact assessment (dpia) work."
version: 1.0.0
---

# Data Protection Impact Assessment (DPIA)

DPIA Trigger Checklist (GDPR Art. 35)

A DPIA is mandatory when processing is "likely to result in a high risk." Triggers include:

- [ ] Systematic and extensive automated profiling with significant effects
- [ ] Large-scale processing of special category data or criminal offence data
- [ ] Systematic monitoring of a publicly accessible area (CCTV)
- [ ] New technologies: AI/ML, biometrics, IoT, behavioral tracking
- [ ] Large-scale processing that affects a large number of data subjects
- [ ] Combining datasets in ways data subjects would not expect
- [ ] Invisible processing (data subjects are unaware)
- [ ] Processing that prevents data subjects from exercising rights or using services

### DPIA Report Structure

**Section 1 — Description of Processing**
- Purpose and nature of processing
- Scope (data subjects, volume, frequency, duration)
- Data types and sensitivity
- Processors and recipients involved

**Section 2 — Necessity & Proportionality Assessment**
- Is the processing necessary for the stated purpose?
- Is there a less privacy-intrusive alternative?
- Lawful basis and compliance with data minimization principle

**Section 3 — Risk Assessment**

| Risk | Likelihood (1–5) | Severity (1–5) | Risk Score | Mitigant |
|---|---|---|---|---|
| Unauthorized access to personal data | | | | Encryption, access control |
| Data subject unable to exercise rights | | | | DSR workflow, clear contact point |
| Excessive retention beyond purpose | | | | Automated retention schedules |
| Cross-border transfer without safeguards | | | | SCCs, transfer impact assessment |
| Re-identification of pseudonymized data | | | | K-anonymity, data minimization |

Risk Score = Likelihood × Severity. High risk (>15): consult supervisory authority before proceeding.

**Section 4 — Measures to Address Risk**
For each risk: technical measures, organizational measures, contractual measures.

**Section 5 — DPO Opinion**
DPO sign-off; residual risk acceptance; conditions or recommendations.

**Section 6 — Supervisory Authority Consultation**
If residual risk remains high → consult DPA before proceeding (Art. 36).

---