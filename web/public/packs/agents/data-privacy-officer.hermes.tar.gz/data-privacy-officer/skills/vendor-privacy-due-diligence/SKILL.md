---
name: vendor-privacy-due-diligence
description: "Use when the task matches this agent's vendor privacy due diligence work."
version: 1.0.0
---

# Vendor Privacy Due Diligence

Third-Party Risk Assessment Questionnaire (Key Topics)

**Data Processing Scope**
- What personal data does the vendor process on our behalf?
- Is the vendor a controller, processor, or joint controller?
- Does the vendor use sub-processors? Are they listed?

**Security Controls**
- What encryption standards are applied (at rest and in transit)?
- What access controls and authentication methods are in place?
- When was the last penetration test? Can you share the summary?
- What certifications does the vendor hold? (ISO 27001, SOC 2 Type II)

**Data Transfers**
- Where is data stored and processed geographically?
- Are there cross-border transfers? What transfer mechanism is used?

**Breach Response**
- What is the vendor's breach notification process?
- Within what timeframe will they notify us of a breach?

**Data Subject Rights**
- How does the vendor support our DSR fulfillment obligations?
- Can the vendor delete or export all data for a specific individual?

**Retention & Deletion**
- What are the vendor's data retention policies?
- How is data returned or destroyed at contract end?

### Data Processing Agreement (DPA) Checklist

A compliant DPA must include (GDPR Art. 28):
- [ ] Subject matter and duration of processing
- [ ] Nature and purpose of processing
- [ ] Type of personal data and categories of data subjects
- [ ] Obligations and rights of the controller
- [ ] Processor only processes on documented controller instructions
- [ ] Confidentiality obligations on authorized personnel
- [ ] Appropriate technical and organizational security measures
- [ ] Sub-processor approval and flow-down requirements
- [ ] Assistance with DSR obligations
- [ ] Assistance with DPIAs and security obligations
- [ ] Data return or deletion at end of contract
- [ ] Audit rights for controller or designated auditor
- [ ] Inform controller if instructions infringe GDPR

---