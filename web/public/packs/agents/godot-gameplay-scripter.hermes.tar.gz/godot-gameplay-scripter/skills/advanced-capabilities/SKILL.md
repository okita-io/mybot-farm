---
name: advanced-capabilities
description: "Use when the task needs advanced or edge-case techniques."
version: 1.0.0
---

# Advanced Capabilities

GDExtension and C++ Integration
- Use GDExtension to write performance-critical systems in C++ while exposing them to GDScript as native nodes
- Build GDExtension plugins for: custom physics integrators, complex pathfinding, procedural generation — anything GDScript is too slow for
- Implement `GDVIRTUAL` methods in GDExtension to allow GDScript to override C++ base methods
- Profile GDScript vs GDExtension performance with `Benchmark` and the built-in profiler — justify C++ only where the data supports it

### Godot's Rendering Server (Low-Level API)
- Use `RenderingServer` directly for batch mesh instance creation: create VisualInstances from code without scene node overhead
- Implement custom canvas items using `RenderingServer.canvas_item_*` calls for maximum 2D rendering performance
- Build particle systems using `RenderingServer.particles_*` for CPU-controlled particle logic that bypasses the Particles2D/3D node overhead
- Profile `RenderingServer` call overhead with the GPU profiler — direct server calls reduce scene tree traversal cost significantly

### Advanced Scene Architecture Patterns
- Implement the Service Locator pattern using Autoloads registered at startup, unregistered on scene change
- Build a custom event bus with priority ordering: high-priority listeners (UI) receive events before low-priority (ambient systems)
- Design a scene pooling system using `Node.remove_from_parent()` and re-parenting instead of `queue_free()` + re-instantiation
- Use `@export_group` and `@export_subgroup` in GDScript 2.0 to organize complex node configuration for designers

### Godot Networking Advanced Patterns
- Implement a high-performance state synchronization system using packed byte arrays instead of `MultiplayerSynchronizer` for low-latency requirements
- Build a dead reckoning system for client-side position prediction between server updates
- Use WebRTC DataChannel for peer-to-peer game data in browser-deployed Godot Web exports
- Implement lag compensation using server-side snapshot history: roll back the world state to when the client fired their shot