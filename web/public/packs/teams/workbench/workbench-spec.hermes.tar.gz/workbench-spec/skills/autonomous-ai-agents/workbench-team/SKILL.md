---
name: workbench-team
description: "DM workbench teammates without the message_agent tool."
version: 1.0.0
---

# Workbench Team Routines

Three-agent web-app team (Spec = this profile / Scaffold / Smoke) coordinated through
a shared board, not chat. All durable state lives in `~/.hermes/teams/workbench/`:
`TEAM.md` (protocol), `WORK.md` (board, source of truth), `reports/` (standup, QA,
harvest), `repos/<project>/` (code). Read both .md files before acting; never move
card state yourself past what your role owns.

## DMing a teammate when `message_agent` is missing

`message_agent` is injected ONLY into Bot-Mode-managed "Bot Chat" sessions. Cron and
plain-CLI sessions do not have it — do not grep the source tree to re-derive the
transport; use the fallback below (it is the same transport `message_agent` uses).

1. Confirm the target profile exists: `hermes profile list` (names without the `@`).
2. Write the message body to a file, prefixed with your attribution, because the CLI
   path does not add it server-side:
   `Message from 🤖 <your-handle> (@<your-handle>): <body>`
3. Deliver (one short message; fire-and-forget):
   ```
   hermes -p <target-profile> chat --in ~ -c "Bot Chat" --create-if-missing -Q --query-file <msgfile>
   ```
   Run it as a background terminal task with `notify=true`; the turn is asynchronous
   and the reply is not part of your task. Do not poll for a reply.
4. For a teammate on a DIFFERENT machine, it is `hermes peer dm <peer>[/profile]`
   (stdin transport, peer must be registered) — not a different `-p` flag.

### Pitfalls
- `-c "Bot Chat"` is load-bearing: it targets the profile's canonical persistent
  chat. Omitting it mints a scratch session the teammate will not read.
- `hermes send` is for messaging platforms (Telegram/Discord), not agent-to-agent —
  wrong tool.
- Keep one DM = one short message (card id, state, what the recipient needs). Fan-out
  and status pings violate the team's quiet-when-idle rule; if the board is empty or
  unchanged since the last standup, write the report and send no DMs.
- `--in ~` is a fixed flag (user home) that is part of the canonical Bot Chat turn
  argv — never substitute another agent's home or workspace into it.
