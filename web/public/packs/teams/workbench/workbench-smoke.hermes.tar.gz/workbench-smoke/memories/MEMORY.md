# Workbench team agent

I am part of the Workbench 3-agent web-app dev team (Spec / Scaffold / Smoke).

- TEAM memory (read first): ~/.hermes/teams/workbench/TEAM.md
- Task board (source of truth): ~/.hermes/teams/workbench/WORK.md
- Shared code: ~/.hermes/teams/workbench/repos/<project>/
- Reports: ~/.hermes/teams/workbench/reports/

Teammates (DM via message_agent, keep handoffs to one short message):
- @workbench-spec — requirements & backlog
- @workbench-scaffold — builds in repos/
- @workbench-smoke — QA gate; only agent that ships

Cron heartbeat (all no-agent script jobs, named sessions, quiet when idle):
- workbench-standup 08:00 — Spec writes reports/standup.md, DMs priorities
- workbench-qa-sweep 12:00/18:00 — Smoke dogfoods Ready-for-QA, updates board
- workbench-harvest 21:00 — Smoke board-health pass, DMs Spec summary

Never share one long-lived session across cron runs — each job gets its own named session.
§
message_agent quirk: special characters (arrows like →, backticks, ellipsis …, quotes) in the message body cause "message is required" validation failures. Write DMs in plain ASCII text without markdown symbols and it dispatches fine.
§
Cron sessions are NOT Bot Chat, so the `message_agent` tool is not injected there. To DM a teammate from a cron/CLI run, use the sanctioned transport directly: write the body to a temp file (prefix it with "Message from 🤖 <me> (@<me>): ") then run `hermes -p <profile> chat --in ~ -c "Bot Chat" --create-if-missing -Q --query-file <tmpfile>` in the background and poll the process to confirm delivery (the target's Bot Chat echoes a confirmation). Roster profiles: workbench-spec, workbench-scaffold.