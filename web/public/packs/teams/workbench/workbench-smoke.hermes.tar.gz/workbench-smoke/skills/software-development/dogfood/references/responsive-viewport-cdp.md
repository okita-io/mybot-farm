# Responsive / viewport testing with CDP emulation

For when you need to verify a mobile breakpoint (e.g. 375px) but the browser
automation CLI you're driving has **no resize / viewport command**. Verified
working with the `browser-use` CLI (backed by a real Chrome). Generalizes to any
browser you can reach over the Chrome DevTools Protocol.

## Find the CDP port

The backing Chrome is launched with a remote-debugging flag:

```sh
ps aux | grep -oE -- '--remote-debugging-port=[0-9]+' | head -1
# e.g. --remote-debugging-port=62069
```

Confirm it's the right browser (the one your CLI session drives) by checking the
URL list:

```sh
curl -s http://localhost:<port>/json | python3 -c "import json,sys; [print(t['type'], t['url'][:70]) for t in json.load(sys.stdin)]"
```

## Emulate a viewport

Send `Emulation.setDeviceMetricsOverride` over the page target's websocket.

**Use the `websockets` library**, not a hand-rolled socket client: a raw
`socket`-based WebSocket client fails because it omits the per-frame masking
required for client→server frames (the server closes the connection and you
get a short/garbled read).

The `websockets` package is already available in the browser-use venv, so invoke
that interpreter directly:

```sh
/Users/<you>/.browser-use-env/bin/python3 - <<'PY'
import asyncio, json, urllib.request
import websockets

def page_ws(port):
    tabs = json.load(urllib.request.urlopen(f'http://localhost:{port}/json'))
    page = next(t for t in tabs if t['type'] == 'page')
    return page['webSocketDebuggerUrl']

async def cdp(port, method, params=None):
    async with websockets.connect(page_ws(port), max_size=2**24) as ws:
        await ws.send(json.dumps({'id': 1, 'method': method, 'params': params or {}}))
        for _ in range(50):
            r = json.loads(await ws.recv())
            if r.get('id') == 1:
                return r

asyncio.run(cdp(62069, 'Emulation.setDeviceMetricsOverride',
                {'width': 375, 'height': 812, 'deviceScaleFactor': 1, 'mobile': True}))
print('emulated 375')
PY
```

Clear it again with `Emulation.clearDeviceMetricsOverride` (empty params) when
you're done, so later captures aren't stuck at mobile size.

## Pitfall: full-page screenshot under emulation can be blank

`browser-use screenshot --full` taken while a device metrics override is active
has come out as a **blank dark canvas** even though the DOM is fully rendered.
Do not treat a blank mobile capture as a broken page. Instead, prove the layout
from the DOM + CSS:

```js
// via browser eval
JSON.stringify({
  innerWidth: window.innerWidth,                       // should equal 375
  cards: document.querySelectorAll('article.card').length,
  hOverflow: document.documentElement.scrollWidth > document.documentElement.clientWidth,
  gridCols: getComputedStyle(document.getElementById('grid')).gridTemplateColumns
})
```

Cross-check the CSS media query that drives the breakpoint (e.g.
`@media (max-width: 400px) { .grid { grid-template-columns: 1fr; } }`) so the
assertion is deterministic rather than screenshot-dependent. A non-overflow
`scrollWidth <= clientWidth` at the target width plus the correct column count is
solid evidence.

## Pitfall: vision analysis times out on large PNGs

Image-analysis tools (e.g. `vision_analyze`) time out on very large screenshots
(a 2560px full page). Downscale a crop to roughly 900–1200px on the long edge
before sending it for analysis:

```sh
python3 -c "from PIL import Image; im=Image.open('big.png'); im.thumbnail((1100,1600)); im.save('/tmp/small.png')"
```

If the vision service is simply down (repeated timeouts on small images too),
fall back to DOM/CSS evidence and say so in the report rather than guessing
from a broken capture.
